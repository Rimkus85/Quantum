from flask import Blueprint, request, jsonify
from datetime import datetime
from src.services.metrics_service import metrics_service
from src.services.predictive_cache_service import predictive_cache_service
from src.services.websocket_service import websocket_service
from src.services.auth_service import optional_token
import logging

logger = logging.getLogger(__name__)

metrics_bp = Blueprint('metrics', __name__)

@metrics_bp.route('/dashboard', methods=['GET'])
@optional_token
def get_dashboard_metrics(current_user):
    """Obtém métricas para dashboard em tempo real"""
    try:
        dashboard_data = metrics_service.get_dashboard_data()
        
        return jsonify({
            'success': True,
            'data': dashboard_data
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter métricas do dashboard: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/performance', methods=['GET'])
@optional_token
def get_performance_metrics(current_user):
    """Obtém métricas detalhadas de performance"""
    try:
        # Métricas de cache
        cache_stats = predictive_cache_service.get_cache_stats()
        
        # Métricas de WebSocket
        websocket_metrics = websocket_service.get_metrics()
        
        # Métricas de API
        api_stats = metrics_service.collector.get_histogram_stats('api_request_duration')
        
        # Métricas do sistema
        system_metrics = metrics_service.performance.get_system_metrics()
        
        performance_data = {
            'cache': {
                'hit_rate': cache_stats.get('hit_rate', 0),
                'miss_rate': 100 - cache_stats.get('hit_rate', 0),
                'size': cache_stats.get('cache_size', 0),
                'prediction_accuracy': cache_stats.get('prediction_accuracy', 0),
                'preload_efficiency': cache_stats.get('preload_efficiency', 0),
                'patterns_tracked': cache_stats.get('patterns_tracked', 0),
                'preload_queue_size': cache_stats.get('preload_queue_size', 0)
            },
            'api': {
                'total_requests': metrics_service.collector.get_counter('api_requests_total'),
                'total_errors': metrics_service.collector.get_counter('api_errors_total'),
                'error_rate': metrics_service.alerting._get_error_rate(),
                'avg_response_time_ms': api_stats.get('mean', 0) * 1000,
                'p95_response_time_ms': api_stats.get('p95', 0) * 1000,
                'p99_response_time_ms': api_stats.get('p99', 0) * 1000,
                'min_response_time_ms': api_stats.get('min', 0) * 1000,
                'max_response_time_ms': api_stats.get('max', 0) * 1000
            },
            'websocket': {
                'active_connections': websocket_metrics.get('active_connections', 0),
                'total_connections': websocket_metrics.get('total_connections', 0),
                'messages_sent': websocket_metrics.get('messages_sent', 0),
                'messages_failed': websocket_metrics.get('messages_failed', 0),
                'disconnections': websocket_metrics.get('disconnections', 0),
                'rooms_active': websocket_metrics.get('rooms_active', 0),
                'users_connected': websocket_metrics.get('users_connected', 0)
            },
            'system': system_metrics,
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify({
            'success': True,
            'data': performance_data
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter métricas de performance: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/timeseries/<metric_name>', methods=['GET'])
@optional_token
def get_timeseries_data(current_user, metric_name):
    """Obtém dados de série temporal para gráficos"""
    try:
        duration_hours = int(request.args.get('duration_hours', 1))
        
        if duration_hours > 24:  # Limitar a 24 horas
            duration_hours = 24
        
        timeseries_data = metrics_service.get_time_series_data(metric_name, duration_hours)
        
        return jsonify({
            'success': True,
            'data': {
                'metric_name': metric_name,
                'duration_hours': duration_hours,
                'points': timeseries_data,
                'count': len(timeseries_data)
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter dados de série temporal: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/alerts', methods=['GET'])
@optional_token
def get_alerts(current_user):
    """Obtém alertas recentes do sistema"""
    try:
        limit = int(request.args.get('limit', 50))
        
        if limit > 200:  # Limitar a 200 alertas
            limit = 200
        
        alerts = metrics_service.alerting.get_alert_history(limit)
        
        return jsonify({
            'success': True,
            'data': {
                'alerts': alerts,
                'count': len(alerts)
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter alertas: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/cache/stats', methods=['GET'])
@optional_token
def get_cache_detailed_stats(current_user):
    """Obtém estatísticas detalhadas do cache"""
    try:
        cache_stats = predictive_cache_service.get_cache_stats()
        
        return jsonify({
            'success': True,
            'data': cache_stats
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas do cache: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/cache/optimize', methods=['POST'])
@optional_token
def optimize_cache(current_user):
    """Otimiza padrões de cache"""
    try:
        predictive_cache_service.optimize_patterns()
        
        return jsonify({
            'success': True,
            'message': 'Cache otimizado com sucesso'
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao otimizar cache: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/websocket/stats', methods=['GET'])
@optional_token
def get_websocket_stats(current_user):
    """Obtém estatísticas detalhadas do WebSocket"""
    try:
        websocket_metrics = websocket_service.get_metrics()
        
        # Informações adicionais sobre rooms
        room_info = {}
        for room, subscribers in websocket_service.room_subscribers.items():
            if subscribers:  # Apenas rooms com subscribers
                room_info[room] = len(subscribers)
        
        websocket_data = {
            **websocket_metrics,
            'room_details': room_info,
            'connected_clients': len(websocket_service.connected_clients)
        }
        
        return jsonify({
            'success': True,
            'data': websocket_data
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas do WebSocket: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/custom', methods=['POST'])
@optional_token
def record_custom_metric(current_user):
    """Registra métrica customizada"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'Dados são obrigatórios'}), 400
        
        name = data.get('name')
        value = data.get('value')
        metric_type = data.get('type', 'gauge')
        tags = data.get('tags', {})
        
        if not name or value is None:
            return jsonify({'message': 'Nome e valor são obrigatórios'}), 400
        
        metrics_service.record_custom_metric(name, float(value), metric_type, tags)
        
        return jsonify({
            'success': True,
            'message': f'Métrica {name} registrada com sucesso'
        }), 200
        
    except ValueError as e:
        return jsonify({'message': f'Valor inválido: {str(e)}'}), 400
    except Exception as e:
        logger.error(f"Erro ao registrar métrica customizada: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/aggregated', methods=['GET'])
@optional_token
def get_aggregated_metrics(current_user):
    """Obtém métricas agregadas por intervalo"""
    try:
        interval = request.args.get('interval', '5m')
        
        valid_intervals = ['1m', '5m', '15m', '1h']
        if interval not in valid_intervals:
            return jsonify({
                'message': f'Intervalo inválido. Use um dos: {", ".join(valid_intervals)}'
            }), 400
        
        aggregated_data = metrics_service.collector.aggregate_metrics(interval)
        
        return jsonify({
            'success': True,
            'data': {
                'interval': interval,
                'metrics': aggregated_data,
                'timestamp': datetime.now().isoformat()
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter métricas agregadas: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@metrics_bp.route('/health', methods=['GET'])
def metrics_health_check():
    """Health check específico do sistema de métricas"""
    try:
        # Verificar se serviços estão funcionando
        cache_working = predictive_cache_service.get_cache_stats() is not None
        websocket_working = websocket_service.get_metrics() is not None
        metrics_working = metrics_service.get_dashboard_data() is not None
        
        all_healthy = cache_working and websocket_working and metrics_working
        
        return jsonify({
            'success': True,
            'status': 'healthy' if all_healthy else 'degraded',
            'services': {
                'cache': 'ok' if cache_working else 'error',
                'websocket': 'ok' if websocket_working else 'error',
                'metrics': 'ok' if metrics_working else 'error'
            },
            'timestamp': datetime.now().isoformat()
        }), 200 if all_healthy else 503
        
    except Exception as e:
        logger.error(f"Erro no health check de métricas: {e}")
        return jsonify({
            'success': False,
            'status': 'unhealthy',
            'error': str(e)
        }), 500

@metrics_bp.route('/export', methods=['GET'])
@optional_token
def export_metrics(current_user):
    """Exporta métricas em formato JSON para análise"""
    try:
        export_format = request.args.get('format', 'json')
        duration_hours = int(request.args.get('duration_hours', 1))
        
        if export_format != 'json':
            return jsonify({'message': 'Apenas formato JSON é suportado'}), 400
        
        if duration_hours > 24:
            duration_hours = 24
        
        # Coletar todas as métricas
        export_data = {
            'export_info': {
                'timestamp': datetime.now().isoformat(),
                'duration_hours': duration_hours,
                'format': export_format
            },
            'dashboard': metrics_service.get_dashboard_data(),
            'cache_stats': predictive_cache_service.get_cache_stats(),
            'websocket_stats': websocket_service.get_metrics(),
            'alerts': metrics_service.alerting.get_alert_history(100),
            'aggregated_5m': metrics_service.collector.aggregate_metrics('5m'),
            'aggregated_1h': metrics_service.collector.aggregate_metrics('1h')
        }
        
        return jsonify({
            'success': True,
            'data': export_data
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao exportar métricas: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

