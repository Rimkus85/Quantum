from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from src.services.technical_analysis_service import TechnicalAnalysisService
from src.services.auth_service import optional_token
from src.services.optimized_financial_service import OptimizedFinancialDataService
from src.services.predictive_cache_service import predictive_cache_service
import logging

logger = logging.getLogger(__name__)

technical_bp = Blueprint('technical', __name__)

# Inicializar serviços
technical_service = TechnicalAnalysisService()
financial_service = OptimizedFinancialDataService(predictive_cache_service)

@technical_bp.route('/indicators/<symbol>', methods=['GET'])
@optional_token
def get_indicators(current_user, symbol):
    """Calcula indicadores técnicos para um símbolo"""
    try:
        # Parâmetros da requisição
        period = request.args.get('period', '1d')  # 1d, 1h, 5m, etc.
        indicators = request.args.get('indicators', '').split(',') if request.args.get('indicators') else None
        
        # Obter dados históricos (simulado - em produção viria de uma API de dados históricos)
        price_data = _get_historical_data(symbol, period)
        
        if not price_data:
            return jsonify({'message': 'Dados históricos não encontrados'}), 404
        
        # Configurar indicadores se especificados
        indicators_config = None
        if indicators:
            indicators_config = {}
            for indicator in indicators:
                indicator = indicator.strip()
                if indicator in technical_service.default_configs:
                    indicators_config[indicator] = technical_service.default_configs[indicator]
        
        # Calcular indicadores
        results = technical_service.calculate_indicators(symbol, price_data, indicators_config)
        
        return jsonify({
            'success': True,
            'data': {
                'symbol': symbol,
                'period': period,
                'indicators': technical_service._serialize_indicators(results),
                'timestamp': datetime.now().isoformat()
            }
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        logger.error(f"Erro ao calcular indicadores para {symbol}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@technical_bp.route('/analysis/<symbol>', methods=['GET'])
@optional_token
def get_technical_analysis(current_user, symbol):
    """Análise técnica completa de um símbolo"""
    try:
        # Parâmetros da requisição
        strategy = request.args.get('strategy', 'swing_trading')
        period = request.args.get('period', '1d')
        
        # Validar estratégia
        if strategy not in technical_service.strategy_presets:
            return jsonify({
                'message': f'Estratégia inválida. Disponíveis: {list(technical_service.strategy_presets.keys())}'
            }), 400
        
        # Obter dados históricos
        price_data = _get_historical_data(symbol, period)
        
        if not price_data:
            return jsonify({'message': 'Dados históricos não encontrados'}), 404
        
        # Realizar análise técnica
        analysis = technical_service.analyze_symbol(symbol, price_data, strategy)
        
        return jsonify({
            'success': True,
            'data': analysis
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        logger.error(f"Erro na análise técnica para {symbol}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@technical_bp.route('/strategies', methods=['GET'])
@optional_token
def get_strategies(current_user):
    """Lista estratégias de análise técnica disponíveis"""
    try:
        strategies = technical_service.get_strategy_presets()
        
        return jsonify({
            'success': True,
            'data': {
                'strategies': strategies,
                'count': len(strategies)
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter estratégias: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@technical_bp.route('/strategies', methods=['POST'])
@optional_token
def create_custom_strategy(current_user):
    """Cria estratégia customizada"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'Dados são obrigatórios'}), 400
        
        name = data.get('name')
        indicators = data.get('indicators', [])
        timeframe = data.get('timeframe', '1h')
        description = data.get('description', '')
        
        if not name or not indicators:
            return jsonify({'message': 'Nome e indicadores são obrigatórios'}), 400
        
        # Criar estratégia
        success = technical_service.create_custom_strategy(name, indicators, timeframe, description)
        
        if not success:
            return jsonify({'message': 'Indicadores inválidos'}), 400
        
        return jsonify({
            'success': True,
            'message': f'Estratégia "{name}" criada com sucesso'
        }), 201
        
    except Exception as e:
        logger.error(f"Erro ao criar estratégia customizada: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@technical_bp.route('/backtest/<symbol>', methods=['POST'])
@optional_token
def backtest_strategy(current_user, symbol):
    """Executa backtesting de estratégia"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'Dados são obrigatórios'}), 400
        
        strategy = data.get('strategy', 'swing_trading')
        initial_capital = float(data.get('initial_capital', 10000))
        period = data.get('period', '1d')
        
        # Validar estratégia
        if strategy not in technical_service.strategy_presets:
            return jsonify({
                'message': f'Estratégia inválida. Disponíveis: {list(technical_service.strategy_presets.keys())}'
            }), 400
        
        # Obter dados históricos mais extensos para backtesting
        price_data = _get_historical_data(symbol, period, extended=True)
        
        if not price_data or len(price_data['close']) < 100:
            return jsonify({'message': 'Dados históricos insuficientes para backtesting'}), 400
        
        # Executar backtesting
        backtest_results = technical_service.backtest_strategy(symbol, price_data, strategy, initial_capital)
        
        return jsonify({
            'success': True,
            'data': backtest_results
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        logger.error(f"Erro no backtesting para {symbol}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@technical_bp.route('/signals/<symbol>', methods=['GET'])
@optional_token
def get_trading_signals(current_user, symbol):
    """Obtém sinais de trading em tempo real"""
    try:
        strategy = request.args.get('strategy', 'swing_trading')
        
        # Obter dados atuais
        price_data = _get_historical_data(symbol, '1d')
        
        if not price_data:
            return jsonify({'message': 'Dados não encontrados'}), 404
        
        # Análise rápida para sinais
        analysis = technical_service.analyze_symbol(symbol, price_data, strategy)
        
        # Extrair apenas os sinais
        signals_data = {
            'symbol': symbol,
            'strategy': strategy,
            'trading_signals': analysis['trading_signals'],
            'trend_analysis': analysis['trend_analysis'],
            'momentum_analysis': analysis['momentum_analysis'],
            'recommendations': analysis['recommendations'],
            'risk_assessment': analysis['risk_assessment'],
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify({
            'success': True,
            'data': signals_data
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter sinais para {symbol}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@technical_bp.route('/screener', methods=['POST'])
@optional_token
def technical_screener(current_user):
    """Screener técnico para múltiplos símbolos"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'Dados são obrigatórios'}), 400
        
        symbols = data.get('symbols', [])
        strategy = data.get('strategy', 'swing_trading')
        filters = data.get('filters', {})
        
        if not symbols:
            return jsonify({'message': 'Lista de símbolos é obrigatória'}), 400
        
        if len(symbols) > 50:  # Limitar para evitar sobrecarga
            return jsonify({'message': 'Máximo 50 símbolos por vez'}), 400
        
        screener_results = []
        
        for symbol in symbols:
            try:
                # Obter dados e analisar
                price_data = _get_historical_data(symbol, '1d')
                
                if not price_data:
                    continue
                
                analysis = technical_service.analyze_symbol(symbol, price_data, strategy)
                
                # Aplicar filtros
                if _passes_filters(analysis, filters):
                    screener_results.append({
                        'symbol': symbol,
                        'action': analysis['trading_signals']['action'],
                        'confidence': analysis['trading_signals']['confidence'],
                        'trend': analysis['trend_analysis'].get('trend', 'unknown'),
                        'momentum': analysis['momentum_analysis'].get('momentum', 'neutral'),
                        'risk_level': analysis['risk_assessment']['risk_level'],
                        'score': _calculate_score(analysis)
                    })
                    
            except Exception as e:
                logger.warning(f"Erro ao analisar {symbol} no screener: {e}")
                continue
        
        # Ordenar por score
        screener_results.sort(key=lambda x: x['score'], reverse=True)
        
        return jsonify({
            'success': True,
            'data': {
                'results': screener_results,
                'total_analyzed': len(symbols),
                'total_matches': len(screener_results),
                'strategy': strategy,
                'filters': filters,
                'timestamp': datetime.now().isoformat()
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro no screener técnico: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

def _get_historical_data(symbol: str, period: str, extended: bool = False) -> dict:
    """Obtém dados históricos simulados (em produção, usar API real)"""
    try:
        # Cache key
        cache_key = f"historical:{symbol}:{period}:{'ext' if extended else 'std'}"
        
        # Tentar cache primeiro
        cached_data = predictive_cache_service.get(cache_key)
        if cached_data:
            return cached_data
        
        # Simular dados históricos baseados na cotação atual
        current_quote = financial_service.get_stock_quote_with_fallback(symbol)
        
        if not current_quote:
            return None
        
        current_price = current_quote['price']
        
        # Gerar dados históricos simulados
        import random
        import hashlib
        
        # Usar hash do símbolo como seed para consistência
        seed = int(hashlib.md5(symbol.encode()).hexdigest()[:8], 16)
        random.seed(seed)
        
        # Número de pontos baseado no período
        if extended:
            num_points = 200  # Para backtesting
        else:
            num_points = 100   # Para análise normal
        
        # Gerar série de preços
        prices = []
        highs = []
        lows = []
        volumes = []
        
        price = current_price
        
        for i in range(num_points):
            # Variação aleatória (-3% a +3%)
            change = random.uniform(-0.03, 0.03)
            price = price * (1 + change)
            
            # High/Low baseados no preço
            high = price * random.uniform(1.0, 1.02)
            low = price * random.uniform(0.98, 1.0)
            
            # Volume aleatório
            volume = random.randint(100000, 5000000)
            
            prices.append(price)
            highs.append(high)
            lows.append(low)
            volumes.append(volume)
        
        # Reverter para ordem cronológica (mais antigo primeiro)
        prices.reverse()
        highs.reverse()
        lows.reverse()
        volumes.reverse()
        
        historical_data = {
            'close': prices,
            'high': highs,
            'low': lows,
            'volume': volumes
        }
        
        # Cache por 5 minutos
        predictive_cache_service.set(cache_key, historical_data, timeout=300)
        
        return historical_data
        
    except Exception as e:
        logger.error(f"Erro ao obter dados históricos para {symbol}: {e}")
        return None

def _passes_filters(analysis: dict, filters: dict) -> bool:
    """Verifica se análise passa pelos filtros especificados"""
    if not filters:
        return True
    
    # Filtro por ação
    if 'action' in filters:
        if analysis['trading_signals']['action'] not in filters['action']:
            return False
    
    # Filtro por confiança
    if 'min_confidence' in filters:
        confidence_map = {'low': 1, 'medium': 2, 'high': 3}
        current_confidence = confidence_map.get(analysis['trading_signals']['confidence'], 0)
        min_confidence = confidence_map.get(filters['min_confidence'], 0)
        
        if current_confidence < min_confidence:
            return False
    
    # Filtro por tendência
    if 'trend' in filters:
        if analysis['trend_analysis'].get('trend') not in filters['trend']:
            return False
    
    # Filtro por risco
    if 'max_risk' in filters:
        risk_map = {'low': 1, 'medium': 2, 'high': 3}
        current_risk = risk_map.get(analysis['risk_assessment']['risk_level'], 3)
        max_risk = risk_map.get(filters['max_risk'], 3)
        
        if current_risk > max_risk:
            return False
    
    return True

def _calculate_score(analysis: dict) -> float:
    """Calcula score para ranking no screener"""
    score = 0
    
    # Score baseado na ação
    action_scores = {'buy': 3, 'sell': 2, 'hold': 1}
    score += action_scores.get(analysis['trading_signals']['action'], 0)
    
    # Score baseado na confiança
    confidence_scores = {'high': 3, 'medium': 2, 'low': 1}
    score += confidence_scores.get(analysis['trading_signals']['confidence'], 0)
    
    # Score baseado na tendência
    trend_scores = {'bullish': 2, 'bearish': 1, 'neutral': 0}
    score += trend_scores.get(analysis['trend_analysis'].get('trend'), 0)
    
    # Penalizar alto risco
    risk_penalties = {'low': 0, 'medium': -0.5, 'high': -1}
    score += risk_penalties.get(analysis['risk_assessment']['risk_level'], 0)
    
    return score

