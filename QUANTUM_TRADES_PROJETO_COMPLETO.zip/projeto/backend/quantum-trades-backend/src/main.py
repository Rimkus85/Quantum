import os
import sys
import logging
from datetime import datetime

# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify, request
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.market import market_bp
from src.config import config

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_app(config_name='default'):
    """Factory function para criar a aplicação Flask"""
    app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
    
    # Carregar configuração
    app.config.from_object(config[config_name])
    
    # Configurar CORS para permitir requisições do frontend
    CORS(app, origins="*", supports_credentials=True)
    
    # Inicializar extensões
    db.init_app(app)
    
    # Registrar blueprints
    app.register_blueprint(user_bp, url_prefix='/api/users')
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(market_bp, url_prefix='/api/market')
    
    # Criar tabelas do banco de dados
    with app.app_context():
        try:
            db.create_all()
            logger.info("Banco de dados inicializado com sucesso")
        except Exception as e:
            logger.error(f"Erro ao inicializar banco de dados: {e}")
    
    # Rota de health check geral
    @app.route('/api/health', methods=['GET'])
    def health_check():
        """Health check geral da aplicação"""
        try:
            # Testar conexão com banco
            db.session.execute('SELECT 1')
            db_status = 'ok'
        except Exception as e:
            db_status = f'error: {str(e)}'
            logger.error(f"Erro na conexão com banco: {e}")
        
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '3.0.0',
            'services': {
                'database': db_status,
                'api': 'ok'
            }
        }), 200
    
    # Rota para informações da API
    @app.route('/api/info', methods=['GET'])
    def api_info():
        """Informações sobre a API"""
        return jsonify({
            'name': 'Quantum Trades API',
            'version': '3.0.0',
            'description': 'API para plataforma de trading e análise financeira',
            'endpoints': {
                'auth': '/api/auth',
                'users': '/api/users',
                'market': '/api/market',
                'health': '/api/health'
            },
            'documentation': '/api/docs',  # Para futuro Swagger
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    # Middleware para logging de requisições
    @app.before_request
    def log_request_info():
        """Log informações da requisição"""
        if not request.path.startswith('/api/health'):  # Evitar spam de health checks
            logger.info(f"{request.method} {request.path} - {request.remote_addr}")
    
    # Handler para erros 404
    @app.errorhandler(404)
    def not_found(error):
        if request.path.startswith('/api/'):
            return jsonify({'message': 'Endpoint não encontrado'}), 404
        # Para rotas não-API, servir o frontend
        return serve('')
    
    # Handler para erros 500
    @app.errorhandler(500)
    def internal_error(error):
        logger.error(f"Erro interno: {error}")
        return jsonify({'message': 'Erro interno do servidor'}), 500
    
    # Servir frontend (mantido da versão original)
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve(path):
        static_folder_path = app.static_folder
        if static_folder_path is None:
            return "Static folder not configured", 404

        if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
            return send_from_directory(static_folder_path, path)
        else:
            index_path = os.path.join(static_folder_path, 'index.html')
            if os.path.exists(index_path):
                return send_from_directory(static_folder_path, 'index.html')
            else:
                return "index.html not found", 404
    
    return app

# Criar aplicação
app = create_app(os.environ.get('FLASK_ENV', 'default'))

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    
    logger.info(f"Iniciando Quantum Trades API v3.0.0 na porta {port}")
    logger.info(f"Modo debug: {debug}")
    
    app.run(host='0.0.0.0', port=port, debug=debug)

