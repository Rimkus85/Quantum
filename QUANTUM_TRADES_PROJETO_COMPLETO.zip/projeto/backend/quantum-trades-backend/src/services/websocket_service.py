from flask_socketio import SocketIO, emit, join_room, leave_room, disconnect
from flask import request
import json
import time
import threading
from datetime import datetime
from typing import Dict, List, Set, Optional
import logging
from collections import defaultdict, deque

logger = logging.getLogger(__name__)

class WebSocketService:
    """Serviço de WebSockets para comunicação em tempo real"""
    
    def __init__(self, app=None):
        self.socketio = None
        self.connected_clients = {}  # session_id -> client_info
        self.user_rooms = defaultdict(set)  # user_id -> set of rooms
        self.room_subscribers = defaultdict(set)  # room -> set of session_ids
        self.message_queue = deque(maxlen=1000)  # Queue para mensagens não entregues
        self.heartbeat_interval = 30  # 30 segundos
        self.heartbeat_thread = None
        self.running = False
        
        # Métricas de WebSocket
        self.metrics = {
            'total_connections': 0,
            'active_connections': 0,
            'messages_sent': 0,
            'messages_failed': 0,
            'heartbeats_sent': 0,
            'disconnections': 0,
            'room_subscriptions': 0
        }
        
        if app:
            self.init_app(app)
    
    def init_app(self, app):
        """Inicializa WebSocket com Flask app"""
        self.socketio = SocketIO(
            app,
            cors_allowed_origins="*",
            async_mode='eventlet',
            ping_timeout=60,
            ping_interval=25,
            logger=False,
            engineio_logger=False
        )
        
        self._register_handlers()
        self._start_heartbeat_thread()
        self.running = True
        
        logger.info("WebSocket service inicializado")
    
    def _register_handlers(self):
        """Registra handlers de WebSocket"""
        
        @self.socketio.on('connect')
        def handle_connect(auth):
            """Handler para conexão de cliente"""
            session_id = request.sid
            client_info = {
                'session_id': session_id,
                'connected_at': time.time(),
                'last_heartbeat': time.time(),
                'user_id': None,
                'subscriptions': set(),
                'ip_address': request.environ.get('REMOTE_ADDR', 'unknown')
            }
            
            # Autenticação opcional
            if auth and 'user_id' in auth:
                client_info['user_id'] = auth['user_id']
                self.user_rooms[auth['user_id']].add(session_id)
            
            self.connected_clients[session_id] = client_info
            self.metrics['total_connections'] += 1
            self.metrics['active_connections'] = len(self.connected_clients)
            
            logger.info(f"Cliente conectado: {session_id}")
            
            # Enviar confirmação de conexão
            emit('connection_confirmed', {
                'session_id': session_id,
                'server_time': datetime.now().isoformat(),
                'heartbeat_interval': self.heartbeat_interval
            })
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            """Handler para desconexão de cliente"""
            session_id = request.sid
            
            if session_id in self.connected_clients:
                client_info = self.connected_clients[session_id]
                
                # Remover de rooms
                for room in client_info['subscriptions']:
                    self.room_subscribers[room].discard(session_id)
                
                # Remover de user rooms
                if client_info['user_id']:
                    self.user_rooms[client_info['user_id']].discard(session_id)
                
                del self.connected_clients[session_id]
                self.metrics['disconnections'] += 1
                self.metrics['active_connections'] = len(self.connected_clients)
                
                logger.info(f"Cliente desconectado: {session_id}")
        
        @self.socketio.on('subscribe')
        def handle_subscribe(data):
            """Handler para inscrição em rooms"""
            session_id = request.sid
            
            if session_id not in self.connected_clients:
                emit('error', {'message': 'Cliente não autenticado'})
                return
            
            room = data.get('room')
            if not room:
                emit('error', {'message': 'Room é obrigatório'})
                return
            
            # Validar room
            if not self._validate_room(room):
                emit('error', {'message': 'Room inválido'})
                return
            
            join_room(room)
            self.connected_clients[session_id]['subscriptions'].add(room)
            self.room_subscribers[room].add(session_id)
            self.metrics['room_subscriptions'] += 1
            
            emit('subscribed', {'room': room})
            logger.debug(f"Cliente {session_id} inscrito em {room}")
        
        @self.socketio.on('unsubscribe')
        def handle_unsubscribe(data):
            """Handler para desincrição de rooms"""
            session_id = request.sid
            
            if session_id not in self.connected_clients:
                return
            
            room = data.get('room')
            if not room:
                return
            
            leave_room(room)
            self.connected_clients[session_id]['subscriptions'].discard(room)
            self.room_subscribers[room].discard(session_id)
            
            emit('unsubscribed', {'room': room})
            logger.debug(f"Cliente {session_id} desinscrito de {room}")
        
        @self.socketio.on('heartbeat')
        def handle_heartbeat():
            """Handler para heartbeat do cliente"""
            session_id = request.sid
            
            if session_id in self.connected_clients:
                self.connected_clients[session_id]['last_heartbeat'] = time.time()
                emit('heartbeat_ack', {'server_time': datetime.now().isoformat()})
        
        @self.socketio.on('get_status')
        def handle_get_status():
            """Handler para status do servidor"""
            emit('status', {
                'active_connections': len(self.connected_clients),
                'server_time': datetime.now().isoformat(),
                'uptime': time.time() - self.connected_clients.get(request.sid, {}).get('connected_at', time.time())
            })
    
    def _validate_room(self, room: str) -> bool:
        """Valida se o room é permitido"""
        allowed_patterns = [
            'market_data',
            'alerts_',
            'user_',
            'symbol_',
            'portfolio_',
            'notifications'
        ]
        
        return any(room.startswith(pattern) for pattern in allowed_patterns)
    
    def _start_heartbeat_thread(self):
        """Inicia thread de heartbeat"""
        def heartbeat_worker():
            while self.running:
                try:
                    time.sleep(self.heartbeat_interval)
                    self._send_heartbeat()
                    self._cleanup_stale_connections()
                except Exception as e:
                    logger.error(f"Erro no heartbeat worker: {e}")
        
        self.heartbeat_thread = threading.Thread(target=heartbeat_worker, daemon=True)
        self.heartbeat_thread.start()
    
    def _send_heartbeat(self):
        """Envia heartbeat para todos os clientes"""
        if not self.socketio:
            return
        
        heartbeat_data = {
            'type': 'heartbeat',
            'server_time': datetime.now().isoformat(),
            'active_connections': len(self.connected_clients)
        }
        
        self.socketio.emit('server_heartbeat', heartbeat_data)
        self.metrics['heartbeats_sent'] += 1
    
    def _cleanup_stale_connections(self):
        """Remove conexões inativas"""
        current_time = time.time()
        stale_threshold = self.heartbeat_interval * 3  # 3x o intervalo de heartbeat
        
        stale_sessions = []
        for session_id, client_info in self.connected_clients.items():
            if current_time - client_info['last_heartbeat'] > stale_threshold:
                stale_sessions.append(session_id)
        
        for session_id in stale_sessions:
            logger.warning(f"Removendo conexão inativa: {session_id}")
            self.disconnect_client(session_id)
    
    def broadcast_to_room(self, room: str, event: str, data: Dict, include_metrics: bool = False):
        """Envia mensagem para todos os clientes de um room"""
        if not self.socketio:
            logger.warning("SocketIO não inicializado")
            return False
        
        try:
            message_data = data.copy()
            if include_metrics:
                message_data['_meta'] = {
                    'timestamp': datetime.now().isoformat(),
                    'room': room,
                    'subscribers': len(self.room_subscribers.get(room, set()))
                }
            
            self.socketio.emit(event, message_data, room=room)
            self.metrics['messages_sent'] += 1
            
            logger.debug(f"Mensagem enviada para room {room}: {event}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao enviar mensagem para room {room}: {e}")
            self.metrics['messages_failed'] += 1
            return False
    
    def send_to_user(self, user_id: str, event: str, data: Dict):
        """Envia mensagem para um usuário específico"""
        if not self.socketio:
            return False
        
        user_sessions = self.user_rooms.get(user_id, set())
        if not user_sessions:
            logger.warning(f"Usuário {user_id} não está conectado")
            return False
        
        success_count = 0
        for session_id in user_sessions.copy():  # Copy para evitar modificação durante iteração
            if session_id in self.connected_clients:
                try:
                    self.socketio.emit(event, data, room=session_id)
                    success_count += 1
                except Exception as e:
                    logger.error(f"Erro ao enviar mensagem para sessão {session_id}: {e}")
                    self.user_rooms[user_id].discard(session_id)
        
        if success_count > 0:
            self.metrics['messages_sent'] += success_count
            return True
        
        self.metrics['messages_failed'] += 1
        return False
    
    def broadcast_market_update(self, symbol: str, quote_data: Dict):
        """Envia atualização de mercado para subscribers"""
        rooms_to_notify = [
            'market_data',
            f'symbol_{symbol.lower()}',
            f'symbol_{symbol.upper()}'
        ]
        
        update_data = {
            'type': 'market_update',
            'symbol': symbol,
            'data': quote_data,
            'timestamp': datetime.now().isoformat()
        }
        
        for room in rooms_to_notify:
            self.broadcast_to_room(room, 'market_update', update_data)
    
    def broadcast_alert(self, user_id: str, alert_data: Dict):
        """Envia alerta para usuário específico"""
        alert_message = {
            'type': 'alert',
            'data': alert_data,
            'timestamp': datetime.now().isoformat(),
            'priority': alert_data.get('priority', 'medium')
        }
        
        # Enviar para usuário específico
        success = self.send_to_user(user_id, 'alert_triggered', alert_message)
        
        # Também enviar para room de alertas do usuário
        user_alert_room = f'alerts_{user_id}'
        self.broadcast_to_room(user_alert_room, 'alert_triggered', alert_message)
        
        return success
    
    def disconnect_client(self, session_id: str):
        """Desconecta cliente específico"""
        if session_id in self.connected_clients:
            try:
                self.socketio.emit('force_disconnect', {'reason': 'Server initiated'}, room=session_id)
                # O handler de disconnect será chamado automaticamente
            except Exception as e:
                logger.error(f"Erro ao desconectar cliente {session_id}: {e}")
    
    def get_room_subscribers(self, room: str) -> List[str]:
        """Retorna lista de subscribers de um room"""
        return list(self.room_subscribers.get(room, set()))
    
    def get_user_sessions(self, user_id: str) -> List[str]:
        """Retorna sessões ativas de um usuário"""
        return list(self.user_rooms.get(user_id, set()))
    
    def get_metrics(self) -> Dict:
        """Retorna métricas do WebSocket service"""
        return {
            **self.metrics,
            'rooms_active': len([room for room, subs in self.room_subscribers.items() if subs]),
            'users_connected': len([user for user, sessions in self.user_rooms.items() if sessions]),
            'average_subscriptions_per_client': (
                sum(len(client['subscriptions']) for client in self.connected_clients.values()) / 
                len(self.connected_clients) if self.connected_clients else 0
            ),
            'timestamp': datetime.now().isoformat()
        }
    
    def shutdown(self):
        """Para o serviço de WebSocket"""
        self.running = False
        
        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            self.heartbeat_thread.join(timeout=5)
        
        # Notificar todos os clientes sobre shutdown
        if self.socketio:
            self.socketio.emit('server_shutdown', {
                'message': 'Servidor sendo reiniciado',
                'timestamp': datetime.now().isoformat()
            })
        
        logger.info("WebSocket service finalizado")

# Instância global do serviço WebSocket
websocket_service = WebSocketService()

