import jwt
from datetime import datetime, timedelta
from functools import wraps
from flask import request, jsonify, current_app
from src.models.user import User, RefreshToken, db
import uuid

class AuthService:
    """Serviço de autenticação com JWT"""
    
    @staticmethod
    def generate_tokens(user):
        """Gera access token e refresh token para o usuário"""
        # Access Token
        access_payload = {
            'user_id': user.id,
            'email': user.email,
            'exp': datetime.utcnow() + current_app.config['JWT_ACCESS_TOKEN_EXPIRES'],
            'iat': datetime.utcnow(),
            'type': 'access'
        }
        access_token = jwt.encode(
            access_payload,
            current_app.config['JWT_SECRET_KEY'],
            algorithm='HS256'
        )
        
        # Refresh Token
        refresh_payload = {
            'user_id': user.id,
            'exp': datetime.utcnow() + current_app.config['JWT_REFRESH_TOKEN_EXPIRES'],
            'iat': datetime.utcnow(),
            'type': 'refresh',
            'jti': str(uuid.uuid4())
        }
        refresh_token = jwt.encode(
            refresh_payload,
            current_app.config['JWT_SECRET_KEY'],
            algorithm='HS256'
        )
        
        # Salvar refresh token no banco
        refresh_token_obj = RefreshToken(
            user_id=user.id,
            token=refresh_token,
            expires_at=datetime.utcnow() + current_app.config['JWT_REFRESH_TOKEN_EXPIRES']
        )
        db.session.add(refresh_token_obj)
        db.session.commit()
        
        return access_token, refresh_token
    
    @staticmethod
    def verify_token(token, token_type='access'):
        """Verifica e decodifica um token JWT"""
        try:
            payload = jwt.decode(
                token,
                current_app.config['JWT_SECRET_KEY'],
                algorithms=['HS256']
            )
            
            if payload.get('type') != token_type:
                return None
                
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    @staticmethod
    def refresh_access_token(refresh_token):
        """Gera um novo access token usando refresh token"""
        payload = AuthService.verify_token(refresh_token, 'refresh')
        if not payload:
            return None
            
        # Verificar se o refresh token existe no banco e não foi revogado
        refresh_token_obj = RefreshToken.query.filter_by(
            token=refresh_token,
            is_revoked=False
        ).first()
        
        if not refresh_token_obj or refresh_token_obj.is_expired():
            return None
            
        user = User.query.get(payload['user_id'])
        if not user or not user.is_active:
            return None
            
        # Gerar novo access token
        access_payload = {
            'user_id': user.id,
            'email': user.email,
            'exp': datetime.utcnow() + current_app.config['JWT_ACCESS_TOKEN_EXPIRES'],
            'iat': datetime.utcnow(),
            'type': 'access'
        }
        access_token = jwt.encode(
            access_payload,
            current_app.config['JWT_SECRET_KEY'],
            algorithm='HS256'
        )
        
        return access_token
    
    @staticmethod
    def revoke_refresh_token(refresh_token):
        """Revoga um refresh token"""
        refresh_token_obj = RefreshToken.query.filter_by(token=refresh_token).first()
        if refresh_token_obj:
            refresh_token_obj.revoke()
            return True
        return False
    
    @staticmethod
    def authenticate_user(email, password):
        """Autentica um usuário com email e senha"""
        user = User.query.filter_by(email=email, is_active=True).first()
        if user and user.check_password(password):
            user.update_last_login()
            return user
        return None

def token_required(f):
    """Decorator para rotas que requerem autenticação"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Verificar header Authorization
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer <token>
            except IndexError:
                return jsonify({'message': 'Token format invalid'}), 401
        
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        
        try:
            payload = AuthService.verify_token(token)
            if not payload:
                return jsonify({'message': 'Token is invalid or expired'}), 401
                
            current_user = User.query.get(payload['user_id'])
            if not current_user or not current_user.is_active:
                return jsonify({'message': 'User not found or inactive'}), 401
                
        except Exception as e:
            return jsonify({'message': 'Token verification failed'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

def optional_token(f):
    """Decorator para rotas que podem ter autenticação opcional"""
    @wraps(f)
    def decorated(*args, **kwargs):
        current_user = None
        
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]
                payload = AuthService.verify_token(token)
                if payload:
                    current_user = User.query.get(payload['user_id'])
            except:
                pass  # Ignora erros de token em rotas opcionais
        
        return f(current_user, *args, **kwargs)
    
    return decorated

