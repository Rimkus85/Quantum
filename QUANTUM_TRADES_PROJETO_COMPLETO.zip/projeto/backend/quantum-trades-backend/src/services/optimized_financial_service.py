import requests
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import time
import logging
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import threading
from collections import defaultdict

logger = logging.getLogger(__name__)

class CircuitBreaker:
    """Circuit breaker para APIs externas"""
    
    def __init__(self, failure_threshold=3, recovery_timeout=30, expected_exception=Exception):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        self.failure_count = 0
        self.last_failure_time = None
        self.state = 'CLOSED'  # CLOSED, OPEN, HALF_OPEN
        self._lock = threading.Lock()
    
    def call(self, func, *args, **kwargs):
        """Executa função com circuit breaker"""
        with self._lock:
            if self.state == 'OPEN':
                if self._should_attempt_reset():
                    self.state = 'HALF_OPEN'
                else:
                    raise Exception("Circuit breaker is OPEN")
            
            try:
                result = func(*args, **kwargs)
                self._on_success()
                return result
            except self.expected_exception as e:
                self._on_failure()
                raise e
    
    def _should_attempt_reset(self):
        """Verifica se deve tentar resetar o circuit breaker"""
        return (time.time() - self.last_failure_time) >= self.recovery_timeout
    
    def _on_success(self):
        """Chamado quando operação é bem-sucedida"""
        self.failure_count = 0
        self.state = 'CLOSED'
    
    def _on_failure(self):
        """Chamado quando operação falha"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.failure_count >= self.failure_threshold:
            self.state = 'OPEN'

class OptimizedFinancialDataService:
    """Serviço otimizado para dados financeiros com circuit breakers e connection pooling"""
    
    def __init__(self, cache_service=None):
        self.cache_service = cache_service
        self.yahoo_base_url = "https://query1.finance.yahoo.com/v8/finance/chart/"
        self.alpha_vantage_base_url = "https://www.alphavantage.co/query"
        self.alpha_vantage_api_key = "demo"
        
        # Circuit breakers para cada API
        self.yahoo_circuit_breaker = CircuitBreaker(
            failure_threshold=2,
            recovery_timeout=15,
            expected_exception=requests.RequestException
        )
        self.alpha_vantage_circuit_breaker = CircuitBreaker(
            failure_threshold=2,
            recovery_timeout=30,
            expected_exception=requests.RequestException
        )
        
        # Connection pooling otimizado
        self.session = self._create_optimized_session()
        
        # Rate limiting otimizado
        self.last_yahoo_request = 0
        self.last_alpha_vantage_request = 0
        self.yahoo_rate_limit = 0.05  # 50ms entre requests (mais agressivo)
        self.alpha_vantage_rate_limit = 10  # 10 segundos entre requests
        
        # Métricas de performance
        self.metrics = {
            'yahoo_requests': 0,
            'yahoo_successes': 0,
            'yahoo_failures': 0,
            'alpha_vantage_requests': 0,
            'alpha_vantage_successes': 0,
            'alpha_vantage_failures': 0,
            'cache_hits': 0,
            'cache_misses': 0,
            'fallback_uses': 0
        }
        self._metrics_lock = threading.Lock()
        
        # Sistema de priorização
        self.priority_symbols = {
            'high': ['PETR4.SA', 'VALE3.SA', 'ITUB4.SA', 'BBDC4.SA', '^BVSP'],
            'medium': ['ABEV3.SA', 'MGLU3.SA', 'WEGE3.SA', '^GSPC', '^DJI'],
            'low': []
        }
    
    def _create_optimized_session(self):
        """Cria sessão HTTP otimizada com connection pooling"""
        session = requests.Session()
        
        # Configurar retry strategy
        retry_strategy = Retry(
            total=2,  # Máximo 2 tentativas
            backoff_factor=0.1,  # Backoff rápido
            status_forcelist=[429, 500, 502, 503, 504],
        )
        
        # Configurar adapter com connection pooling
        adapter = HTTPAdapter(
            pool_connections=10,  # Pool de conexões
            pool_maxsize=20,      # Máximo de conexões por pool
            max_retries=retry_strategy
        )
        
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Headers otimizados
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive'
        })
        
        return session
    
    def _update_metrics(self, metric_name, increment=1):
        """Atualiza métricas de forma thread-safe"""
        with self._metrics_lock:
            self.metrics[metric_name] += increment
    
    def _get_symbol_priority(self, symbol: str) -> str:
        """Determina prioridade do símbolo"""
        for priority, symbols in self.priority_symbols.items():
            if symbol in symbols:
                return priority
        return 'low'
    
    def _rate_limit_yahoo(self, symbol: str):
        """Rate limiting otimizado baseado na prioridade"""
        priority = self._get_symbol_priority(symbol)
        
        # Símbolos de alta prioridade têm rate limiting mais relaxado
        rate_limit = {
            'high': 0.02,    # 20ms
            'medium': 0.05,  # 50ms
            'low': 0.1       # 100ms
        }.get(priority, self.yahoo_rate_limit)
        
        now = time.time()
        time_since_last = now - self.last_yahoo_request
        if time_since_last < rate_limit:
            time.sleep(rate_limit - time_since_last)
        self.last_yahoo_request = time.time()
    
    def _rate_limit_alpha_vantage(self):
        """Rate limiting para Alpha Vantage"""
        now = time.time()
        time_since_last = now - self.last_alpha_vantage_request
        if time_since_last < self.alpha_vantage_rate_limit:
            time.sleep(self.alpha_vantage_rate_limit - time_since_last)
        self.last_alpha_vantage_request = time.time()
    
    def get_stock_quote(self, symbol: str) -> Optional[Dict]:
        """Obtém cotação com otimizações de performance"""
        cache_key = f"quote:{symbol}"
        
        # Cache primeiro (com métricas)
        if self.cache_service:
            cached_data = self.cache_service.get(cache_key)
            if cached_data:
                self._update_metrics('cache_hits')
                return cached_data
            else:
                self._update_metrics('cache_misses')
        
        # Tentar Yahoo Finance com circuit breaker
        quote_data = None
        try:
            quote_data = self.yahoo_circuit_breaker.call(self._get_yahoo_quote, symbol)
            if quote_data:
                self._update_metrics('yahoo_successes')
        except Exception as e:
            self._update_metrics('yahoo_failures')
            logger.warning(f"Yahoo Finance falhou para {symbol}: {e}")
        
        # Fallback para Alpha Vantage se Yahoo falhar
        if not quote_data:
            try:
                quote_data = self.alpha_vantage_circuit_breaker.call(self._get_alpha_vantage_quote, symbol)
                if quote_data:
                    self._update_metrics('alpha_vantage_successes')
            except Exception as e:
                self._update_metrics('alpha_vantage_failures')
                logger.warning(f"Alpha Vantage falhou para {symbol}: {e}")
        
        # Cache o resultado se obtido
        if quote_data and self.cache_service:
            # TTL baseado na prioridade do símbolo
            priority = self._get_symbol_priority(symbol)
            ttl = {'high': 30, 'medium': 60, 'low': 120}.get(priority, 60)
            self.cache_service.set(cache_key, quote_data, timeout=ttl)
        
        return quote_data
    
    def _get_yahoo_quote(self, symbol: str) -> Optional[Dict]:
        """Obtém cotação do Yahoo Finance com timeout agressivo"""
        self._rate_limit_yahoo(symbol)
        self._update_metrics('yahoo_requests')
        
        url = f"{self.yahoo_base_url}{symbol}"
        params = {
            'interval': '1d',
            'range': '1d',
            'includePrePost': 'true'
        }
        
        # Timeout agressivo de 2 segundos
        response = self.session.get(url, params=params, timeout=2)
        response.raise_for_status()
        
        data = response.json()
        
        if 'chart' not in data or not data['chart']['result']:
            return None
        
        result = data['chart']['result'][0]
        meta = result['meta']
        
        current_price = meta.get('regularMarketPrice', 0)
        previous_close = meta.get('previousClose', 0)
        change = current_price - previous_close if current_price and previous_close else 0
        change_percent = (change / previous_close * 100) if previous_close else 0
        
        return {
            'symbol': symbol,
            'price': current_price,
            'previous_close': previous_close,
            'change': change,
            'change_percent': change_percent,
            'volume': meta.get('regularMarketVolume', 0),
            'market_cap': meta.get('marketCap'),
            'currency': meta.get('currency', 'USD'),
            'exchange': meta.get('exchangeName'),
            'timestamp': datetime.now().isoformat(),
            'source': 'yahoo',
            'priority': self._get_symbol_priority(symbol)
        }
    
    def _get_alpha_vantage_quote(self, symbol: str) -> Optional[Dict]:
        """Obtém cotação do Alpha Vantage com timeout agressivo"""
        self._rate_limit_alpha_vantage()
        self._update_metrics('alpha_vantage_requests')
        
        params = {
            'function': 'GLOBAL_QUOTE',
            'symbol': symbol,
            'apikey': self.alpha_vantage_api_key
        }
        
        # Timeout agressivo de 3 segundos
        response = self.session.get(self.alpha_vantage_base_url, params=params, timeout=3)
        response.raise_for_status()
        
        data = response.json()
        
        if 'Global Quote' not in data:
            return None
        
        quote = data['Global Quote']
        
        current_price = float(quote.get('05. price', 0))
        previous_close = float(quote.get('08. previous close', 0))
        change = float(quote.get('09. change', 0))
        change_percent = float(quote.get('10. change percent', '0%').replace('%', ''))
        
        return {
            'symbol': symbol,
            'price': current_price,
            'previous_close': previous_close,
            'change': change,
            'change_percent': change_percent,
            'volume': int(quote.get('06. volume', 0)),
            'high': float(quote.get('03. high', 0)),
            'low': float(quote.get('04. low', 0)),
            'open': float(quote.get('02. open', 0)),
            'timestamp': datetime.now().isoformat(),
            'source': 'alpha_vantage',
            'priority': self._get_symbol_priority(symbol)
        }
    
    def get_multiple_quotes_optimized(self, symbols: List[str]) -> Dict[str, Dict]:
        """Obtém múltiplas cotações com processamento otimizado"""
        quotes = {}
        errors = []
        
        # Ordenar símbolos por prioridade
        sorted_symbols = sorted(symbols, key=lambda s: {
            'high': 0, 'medium': 1, 'low': 2
        }.get(self._get_symbol_priority(s), 2))
        
        for symbol in sorted_symbols:
            try:
                quote_data = self.get_stock_quote(symbol.upper().strip())
                if quote_data:
                    quotes[symbol] = quote_data
                else:
                    errors.append(f"Dados não encontrados para {symbol}")
            except Exception as e:
                errors.append(f"Erro ao obter dados para {symbol}: {str(e)}")
        
        return {
            'quotes': quotes,
            'errors': errors,
            'metrics': self.get_performance_metrics()
        }
    
    def get_stock_quote_with_fallback(self, symbol: str) -> Dict:
        """Obtém cotação com fallback garantido para dados mockados"""
        try:
            quote_data = self.get_stock_quote(symbol)
            if quote_data:
                return quote_data
        except Exception as e:
            logger.error(f"Erro ao obter cotação real para {symbol}: {e}")
        
        # Fallback para dados mockados
        self._update_metrics('fallback_uses')
        return self._generate_mock_quote(symbol)
    
    def _generate_mock_quote(self, symbol: str) -> Dict:
        """Gera dados mockados consistentes"""
        import random
        import hashlib
        
        seed = int(hashlib.md5(symbol.encode()).hexdigest()[:8], 16)
        random.seed(seed)
        
        base_price = 50 + (seed % 200)
        change_percent = (random.random() - 0.5) * 10
        change = base_price * (change_percent / 100)
        current_price = base_price + change
        
        return {
            'symbol': symbol,
            'price': round(current_price, 2),
            'previous_close': round(base_price, 2),
            'change': round(change, 2),
            'change_percent': round(change_percent, 2),
            'volume': random.randint(100000, 10000000),
            'currency': 'BRL' if '.SA' in symbol else 'USD',
            'timestamp': datetime.now().isoformat(),
            'source': 'mock_data',
            'priority': self._get_symbol_priority(symbol)
        }
    
    def get_performance_metrics(self) -> Dict:
        """Retorna métricas de performance do serviço"""
        with self._metrics_lock:
            total_requests = (self.metrics['yahoo_requests'] + 
                            self.metrics['alpha_vantage_requests'])
            total_successes = (self.metrics['yahoo_successes'] + 
                             self.metrics['alpha_vantage_successes'])
            
            success_rate = (total_successes / total_requests * 100) if total_requests > 0 else 0
            cache_hit_rate = (self.metrics['cache_hits'] / 
                            (self.metrics['cache_hits'] + self.metrics['cache_misses']) * 100) if (self.metrics['cache_hits'] + self.metrics['cache_misses']) > 0 else 0
            
            return {
                **self.metrics,
                'success_rate': round(success_rate, 2),
                'cache_hit_rate': round(cache_hit_rate, 2),
                'yahoo_circuit_breaker_state': self.yahoo_circuit_breaker.state,
                'alpha_vantage_circuit_breaker_state': self.alpha_vantage_circuit_breaker.state,
                'timestamp': datetime.now().isoformat()
            }
    
    def warm_cache_intelligent(self, financial_service_fallback=None):
        """Aquece o cache de forma inteligente baseada em prioridades"""
        all_priority_symbols = []
        for priority_level in ['high', 'medium']:
            all_priority_symbols.extend(self.priority_symbols[priority_level])
        
        warmed_count = 0
        for symbol in all_priority_symbols:
            try:
                quote = self.get_stock_quote(symbol)
                if quote:
                    warmed_count += 1
                    logger.info(f"Cache aquecido para {symbol}")
            except Exception as e:
                logger.warning(f"Erro ao aquecer cache para {symbol}: {e}")
        
        logger.info(f"Cache aquecido com {warmed_count} símbolos de alta prioridade")
        return warmed_count
    
    def cleanup_resources(self):
        """Limpa recursos e fecha conexões"""
        if hasattr(self, 'session'):
            self.session.close()

