import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional, Union
from datetime import datetime
import logging
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

class IndicatorType(Enum):
    """Tipos de indicadores técnicos"""
    TREND = "trend"
    MOMENTUM = "momentum"
    VOLATILITY = "volatility"
    VOLUME = "volume"
    OVERLAY = "overlay"

@dataclass
class IndicatorResult:
    """Resultado de um indicador técnico"""
    name: str
    type: IndicatorType
    values: List[float]
    signals: List[str] = None
    metadata: Dict = None
    
    def __post_init__(self):
        if self.signals is None:
            self.signals = []
        if self.metadata is None:
            self.metadata = {}

class TechnicalIndicators:
    """Biblioteca de indicadores técnicos profissionais"""
    
    @staticmethod
    def sma(prices: List[float], period: int = 20) -> IndicatorResult:
        """Simple Moving Average (SMA)"""
        if len(prices) < period:
            return IndicatorResult("SMA", IndicatorType.OVERLAY, [])
        
        sma_values = []
        for i in range(period - 1, len(prices)):
            sma = sum(prices[i - period + 1:i + 1]) / period
            sma_values.append(sma)
        
        # Gerar sinais básicos
        signals = []
        if len(sma_values) >= 2:
            for i in range(1, len(sma_values)):
                current_price = prices[i + period - 1]
                prev_price = prices[i + period - 2]
                current_sma = sma_values[i]
                prev_sma = sma_values[i - 1]
                
                # Cruzamento de preço com SMA
                if prev_price <= prev_sma and current_price > current_sma:
                    signals.append("bullish_crossover")
                elif prev_price >= prev_sma and current_price < current_sma:
                    signals.append("bearish_crossover")
                else:
                    signals.append("neutral")
        
        return IndicatorResult(
            name=f"SMA({period})",
            type=IndicatorType.OVERLAY,
            values=sma_values,
            signals=signals,
            metadata={"period": period}
        )
    
    @staticmethod
    def ema(prices: List[float], period: int = 20) -> IndicatorResult:
        """Exponential Moving Average (EMA)"""
        if len(prices) < period:
            return IndicatorResult("EMA", IndicatorType.OVERLAY, [])
        
        multiplier = 2 / (period + 1)
        ema_values = []
        
        # Primeiro valor é SMA
        ema = sum(prices[:period]) / period
        ema_values.append(ema)
        
        # Valores subsequentes usam fórmula EMA
        for price in prices[period:]:
            ema = (price * multiplier) + (ema * (1 - multiplier))
            ema_values.append(ema)
        
        # Gerar sinais
        signals = []
        if len(ema_values) >= 2:
            for i in range(1, len(ema_values)):
                current_price = prices[i + period - 1]
                prev_price = prices[i + period - 2]
                current_ema = ema_values[i]
                prev_ema = ema_values[i - 1]
                
                if prev_price <= prev_ema and current_price > current_ema:
                    signals.append("bullish_crossover")
                elif prev_price >= prev_ema and current_price < current_ema:
                    signals.append("bearish_crossover")
                else:
                    signals.append("neutral")
        
        return IndicatorResult(
            name=f"EMA({period})",
            type=IndicatorType.OVERLAY,
            values=ema_values,
            signals=signals,
            metadata={"period": period, "multiplier": multiplier}
        )
    
    @staticmethod
    def wma(prices: List[float], period: int = 20) -> IndicatorResult:
        """Weighted Moving Average (WMA)"""
        if len(prices) < period:
            return IndicatorResult("WMA", IndicatorType.OVERLAY, [])
        
        wma_values = []
        weights = list(range(1, period + 1))
        weight_sum = sum(weights)
        
        for i in range(period - 1, len(prices)):
            price_slice = prices[i - period + 1:i + 1]
            wma = sum(price * weight for price, weight in zip(price_slice, weights)) / weight_sum
            wma_values.append(wma)
        
        return IndicatorResult(
            name=f"WMA({period})",
            type=IndicatorType.OVERLAY,
            values=wma_values,
            metadata={"period": period, "weights": weights}
        )
    
    @staticmethod
    def rsi(prices: List[float], period: int = 14) -> IndicatorResult:
        """Relative Strength Index (RSI)"""
        if len(prices) < period + 1:
            return IndicatorResult("RSI", IndicatorType.MOMENTUM, [])
        
        gains = []
        losses = []
        
        # Calcular ganhos e perdas
        for i in range(1, len(prices)):
            change = prices[i] - prices[i-1]
            if change > 0:
                gains.append(change)
                losses.append(0)
            else:
                gains.append(0)
                losses.append(abs(change))
        
        rsi_values = []
        
        # Primeiro RSI usa média simples
        avg_gain = sum(gains[:period]) / period
        avg_loss = sum(losses[:period]) / period
        
        if avg_loss == 0:
            rsi_values.append(100)
        else:
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            rsi_values.append(rsi)
        
        # RSI subsequentes usam média móvel exponencial
        for i in range(period, len(gains)):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
            
            if avg_loss == 0:
                rsi_values.append(100)
            else:
                rs = avg_gain / avg_loss
                rsi = 100 - (100 / (1 + rs))
                rsi_values.append(rsi)
        
        # Gerar sinais de RSI
        signals = []
        for rsi in rsi_values:
            if rsi >= 70:
                signals.append("overbought")
            elif rsi <= 30:
                signals.append("oversold")
            else:
                signals.append("neutral")
        
        return IndicatorResult(
            name=f"RSI({period})",
            type=IndicatorType.MOMENTUM,
            values=rsi_values,
            signals=signals,
            metadata={"period": period, "overbought_level": 70, "oversold_level": 30}
        )
    
    @staticmethod
    def macd(prices: List[float], fast_period: int = 12, slow_period: int = 26, signal_period: int = 9) -> Dict[str, IndicatorResult]:
        """Moving Average Convergence Divergence (MACD)"""
        if len(prices) < slow_period:
            return {
                "macd_line": IndicatorResult("MACD_LINE", IndicatorType.MOMENTUM, []),
                "signal_line": IndicatorResult("SIGNAL_LINE", IndicatorType.MOMENTUM, []),
                "histogram": IndicatorResult("MACD_HISTOGRAM", IndicatorType.MOMENTUM, [])
            }
        
        # Calcular EMAs
        ema_fast = TechnicalIndicators.ema(prices, fast_period)
        ema_slow = TechnicalIndicators.ema(prices, slow_period)
        
        # Alinhar as EMAs (a EMA lenta começa depois)
        start_index = slow_period - fast_period
        ema_fast_aligned = ema_fast.values[start_index:]
        ema_slow_values = ema_slow.values
        
        # Calcular MACD line
        macd_line_values = []
        for i in range(len(ema_slow_values)):
            macd = ema_fast_aligned[i] - ema_slow_values[i]
            macd_line_values.append(macd)
        
        # Calcular Signal line (EMA do MACD)
        signal_line_result = TechnicalIndicators.ema(macd_line_values, signal_period)
        signal_line_values = signal_line_result.values
        
        # Calcular Histogram
        histogram_values = []
        start_hist = len(macd_line_values) - len(signal_line_values)
        for i in range(len(signal_line_values)):
            histogram = macd_line_values[start_hist + i] - signal_line_values[i]
            histogram_values.append(histogram)
        
        # Gerar sinais
        macd_signals = []
        signal_signals = []
        histogram_signals = []
        
        if len(signal_line_values) >= 2:
            for i in range(1, len(signal_line_values)):
                macd_current = macd_line_values[start_hist + i]
                macd_prev = macd_line_values[start_hist + i - 1]
                signal_current = signal_line_values[i]
                signal_prev = signal_line_values[i - 1]
                
                # Cruzamento MACD com linha de sinal
                if macd_prev <= signal_prev and macd_current > signal_current:
                    macd_signals.append("bullish_crossover")
                    signal_signals.append("bullish_crossover")
                elif macd_prev >= signal_prev and macd_current < signal_current:
                    macd_signals.append("bearish_crossover")
                    signal_signals.append("bearish_crossover")
                else:
                    macd_signals.append("neutral")
                    signal_signals.append("neutral")
                
                # Sinais do histograma
                hist_current = histogram_values[i]
                hist_prev = histogram_values[i - 1]
                
                if hist_prev <= 0 and hist_current > 0:
                    histogram_signals.append("bullish_momentum")
                elif hist_prev >= 0 and hist_current < 0:
                    histogram_signals.append("bearish_momentum")
         # Calcular MACD
        macd_line = ema_fast_values - ema_slow_values
        signal_line = TechnicalIndicators._calculate_ema(macd_line, signal_period)
        histogram = [macd_line[i] - signal_line[i] for i in range(len(signal_line))]
        
        return {
            'macd_line': IndicatorResult(
                name='MACD Line',
                type=IndicatorType.MOMENTUM,
                values=macd_line,
                signals=[],
                metadata={'fast_period': fast_period, 'slow_period': slow_period}
            ),
            'signal_line': IndicatorResult(
                name='MACD Signal',
                type=IndicatorType.MOMENTUM,
                values=signal_line,
                signals=[],
                metadata={'signal_period': signal_period}
            ),
            'histogram': IndicatorResult(
                name='MACD Histogram',
                type=IndicatorType.MOMENTUM,
                values=histogram,
                signals=[],
                metadata={}
            )
        }
    
    @staticmethod
    def bollinger_bands(prices: List[float], period: int = 20, std_dev: float = 2.0) -> Dict[str, IndicatorResult]:
        """Bollinger Bands"""
        if len(prices) < period:
            return {
                "upper_band": IndicatorResult("BB_UPPER", IndicatorType.VOLATILITY, []),
                "middle_band": IndicatorResult("BB_MIDDLE", IndicatorType.VOLATILITY, []),
                "lower_band": IndicatorResult("BB_LOWER", IndicatorType.VOLATILITY, [])
            }
        
        # Calcular SMA (banda média)
        sma_result = TechnicalIndicators.sma(prices, period)
        middle_band_values = sma_result.values
        
        # Calcular desvio padrão e bandas
        upper_band_values = []
        lower_band_values = []
        
        for i in range(period - 1, len(prices)):
            price_slice = prices[i - period + 1:i + 1]
            std = np.std(price_slice)
            sma_index = i - period + 1
            
            upper_band = middle_band_values[sma_index] + (std_dev * std)
            lower_band = middle_band_values[sma_index] - (std_dev * std)
            
            upper_band_values.append(upper_band)
            lower_band_values.append(lower_band)
        
        # Gerar sinais
        signals = []
        if len(upper_band_values) >= 2:
            for i in range(len(upper_band_values)):
                price = prices[i + period - 1]
                upper = upper_band_values[i]
                lower = lower_band_values[i]
                middle = middle_band_values[i]
                
                if price >= upper:
                    signals.append("overbought")
                elif price <= lower:
                    signals.append("oversold")
                elif price > middle:
                    signals.append("bullish")
                else:
                    signals.append("bearish")
        
        # Detectar squeeze (bandas estreitas)
        squeeze_signals = []
        if len(upper_band_values) >= 20:  # Precisamos de histórico para comparar
            for i in range(19, len(upper_band_values)):
                current_width = upper_band_values[i] - lower_band_values[i]
                avg_width = np.mean([upper_band_values[j] - lower_band_values[j] for j in range(i-19, i)])
                
                if current_width < avg_width * 0.8:  # 20% menor que a média
                    squeeze_signals.append("squeeze")
                else:
                    squeeze_signals.append("normal")
        
        return {
            "upper_band": IndicatorResult(
                name=f"BB_Upper({period},{std_dev})",
                type=IndicatorType.VOLATILITY,
                values=upper_band_values,
                signals=signals,
                metadata={"period": period, "std_dev": std_dev}
            ),
            "middle_band": IndicatorResult(
                name=f"BB_Middle({period})",
                type=IndicatorType.VOLATILITY,
                values=middle_band_values,
                signals=signals,
                metadata={"period": period}
            ),
            "lower_band": IndicatorResult(
                name=f"BB_Lower({period},{std_dev})",
                type=IndicatorType.VOLATILITY,
                values=lower_band_values,
                signals=signals,
                metadata={"period": period, "std_dev": std_dev, "squeeze_signals": squeeze_signals}
            )
        }
    
    @staticmethod
    def stochastic(highs: List[float], lows: List[float], closes: List[float], 
                   k_period: int = 14, d_period: int = 3) -> Dict[str, IndicatorResult]:
        """Stochastic Oscillator"""
        if len(closes) < k_period:
            return {
                "k_percent": IndicatorResult("STOCH_K", IndicatorType.MOMENTUM, []),
                "d_percent": IndicatorResult("STOCH_D", IndicatorType.MOMENTUM, [])
            }
        
        k_values = []
        
        # Calcular %K
        for i in range(k_period - 1, len(closes)):
            high_slice = highs[i - k_period + 1:i + 1]
            low_slice = lows[i - k_period + 1:i + 1]
            
            highest_high = max(high_slice)
            lowest_low = min(low_slice)
            current_close = closes[i]
            
            if highest_high == lowest_low:
                k_percent = 50  # Evitar divisão por zero
            else:
                k_percent = ((current_close - lowest_low) / (highest_high - lowest_low)) * 100
            
            k_values.append(k_percent)
        
        # Calcular %D (SMA do %K)
        d_values = []
        if len(k_values) >= d_period:
            for i in range(d_period - 1, len(k_values)):
                d_percent = sum(k_values[i - d_period + 1:i + 1]) / d_period
                d_values.append(d_percent)
        
        # Gerar sinais
        k_signals = []
        d_signals = []
        
        for k in k_values:
            if k >= 80:
                k_signals.append("overbought")
            elif k <= 20:
                k_signals.append("oversold")
            else:
                k_signals.append("neutral")
        
        for d in d_values:
            if d >= 80:
                d_signals.append("overbought")
            elif d <= 20:
                d_signals.append("oversold")
            else:
                d_signals.append("neutral")
        
        return {
            "k_percent": IndicatorResult(
                name=f"Stoch_K({k_period})",
                type=IndicatorType.MOMENTUM,
                values=k_values,
                signals=k_signals,
                metadata={"k_period": k_period, "overbought": 80, "oversold": 20}
            ),
            "d_percent": IndicatorResult(
                name=f"Stoch_D({d_period})",
                type=IndicatorType.MOMENTUM,
                values=d_values,
                signals=d_signals,
                metadata={"d_period": d_period, "overbought": 80, "oversold": 20}
            )
        }
    
    @staticmethod
    def williams_r(highs: List[float], lows: List[float], closes: List[float], 
                   period: int = 14) -> IndicatorResult:
        """Williams %R"""
        if len(closes) < period:
            return IndicatorResult("WILLIAMS_R", IndicatorType.MOMENTUM, [])
        
        williams_values = []
        
        for i in range(period - 1, len(closes)):
            high_slice = highs[i - period + 1:i + 1]
            low_slice = lows[i - period + 1:i + 1]
            
            highest_high = max(high_slice)
            lowest_low = min(low_slice)
            current_close = closes[i]
            
            if highest_high == lowest_low:
                williams_r = -50  # Evitar divisão por zero
            else:
                williams_r = ((highest_high - current_close) / (highest_high - lowest_low)) * -100
            
            williams_values.append(williams_r)
        
        # Gerar sinais
        signals = []
        for wr in williams_values:
            if wr >= -20:
                signals.append("overbought")
            elif wr <= -80:
                signals.append("oversold")
            else:
                signals.append("neutral")
        
        return IndicatorResult(
            name=f"Williams_R({period})",
            type=IndicatorType.MOMENTUM,
            values=williams_values,
            signals=signals,
            metadata={"period": period, "overbought": -20, "oversold": -80}
        )

class IndicatorAnalyzer:
    """Analisador de sinais de indicadores técnicos"""
    
    @staticmethod
    def analyze_trend(sma_short: IndicatorResult, sma_long: IndicatorResult) -> Dict[str, str]:
        """Analisa tendência baseada em duas médias móveis"""
        if not sma_short.values or not sma_long.values:
            return {"trend": "unknown", "strength": "unknown"}
        
        # Alinhar as médias (a longa começa depois)
        min_length = min(len(sma_short.values), len(sma_long.values))
        short_values = sma_short.values[-min_length:]
        long_values = sma_long.values[-min_length:]
        
        if not short_values or not long_values:
            return {"trend": "unknown", "strength": "unknown"}
        
        current_short = short_values[-1]
        current_long = long_values[-1]
        
        # Determinar tendência
        if current_short > current_long:
            trend = "bullish"
        elif current_short < current_long:
            trend = "bearish"
        else:
            trend = "neutral"
        
        # Determinar força da tendência
        if len(short_values) >= 5:
            recent_short = short_values[-5:]
            recent_long = long_values[-5:]
            
            short_slope = (recent_short[-1] - recent_short[0]) / 4
            long_slope = (recent_long[-1] - recent_long[0]) / 4
            
            if abs(short_slope) > abs(long_slope) * 1.5:
                strength = "strong"
            elif abs(short_slope) > abs(long_slope) * 0.5:
                strength = "moderate"
            else:
                strength = "weak"
        else:
            strength = "unknown"
        
        return {"trend": trend, "strength": strength}
    
    @staticmethod
    def analyze_momentum(rsi: IndicatorResult, macd: Dict[str, IndicatorResult]) -> Dict[str, str]:
        """Analisa momentum baseado em RSI e MACD"""
        analysis = {"momentum": "neutral", "divergence": "none"}
        
        if not rsi.values:
            return analysis
        
        current_rsi = rsi.values[-1]
        
        # Análise do RSI
        if current_rsi >= 70:
            rsi_signal = "overbought"
        elif current_rsi <= 30:
            rsi_signal = "oversold"
        else:
            rsi_signal = "neutral"
        
        # Análise do MACD
        macd_signal = "neutral"
        if "macd_line" in macd and "signal_line" in macd:
            macd_line = macd["macd_line"].values
            signal_line = macd["signal_line"].values
            
            if macd_line and signal_line:
                if macd_line[-1] > signal_line[-1]:
                    macd_signal = "bullish"
                elif macd_line[-1] < signal_line[-1]:
                    macd_signal = "bearish"
        
        # Combinar sinais
        if rsi_signal == "oversold" and macd_signal == "bullish":
            analysis["momentum"] = "bullish"
        elif rsi_signal == "overbought" and macd_signal == "bearish":
            analysis["momentum"] = "bearish"
        elif rsi_signal == "neutral" and macd_signal != "neutral":
            analysis["momentum"] = macd_signal
        else:
            analysis["momentum"] = rsi_signal
        
        return analysis
    
    @staticmethod
    def generate_trading_signals(indicators: Dict[str, Union[IndicatorResult, Dict]]) -> Dict[str, str]:
        """Gera sinais de trading baseado em múltiplos indicadores"""
        signals = {
            "overall": "neutral",
            "confidence": "low",
            "action": "hold",
            "reasoning": []
        }
        
        bullish_signals = 0
        bearish_signals = 0
        total_signals = 0
        
        # Analisar cada indicador
        for name, indicator in indicators.items():
            if isinstance(indicator, IndicatorResult):
                if indicator.signals:
                    latest_signal = indicator.signals[-1]
                    total_signals += 1
                    
                    if "bullish" in latest_signal or "oversold" in latest_signal:
                        bullish_signals += 1
                        signals["reasoning"].append(f"{name}: {latest_signal}")
                    elif "bearish" in latest_signal or "overbought" in latest_signal:
                        bearish_signals += 1
                        signals["reasoning"].append(f"{name}: {latest_signal}")
            
            elif isinstance(indicator, dict):
                # Para indicadores compostos como MACD
                for sub_name, sub_indicator in indicator.items():
                    if isinstance(sub_indicator, IndicatorResult) and sub_indicator.signals:
                        latest_signal = sub_indicator.signals[-1]
                        total_signals += 1
                        
                        if "bullish" in latest_signal:
                            bullish_signals += 1
                            signals["reasoning"].append(f"{sub_name}: {latest_signal}")
                        elif "bearish" in latest_signal:
                            bearish_signals += 1
                            signals["reasoning"].append(f"{sub_name}: {latest_signal}")
        
        # Determinar sinal geral
        if total_signals > 0:
            bullish_ratio = bullish_signals / total_signals
            bearish_ratio = bearish_signals / total_signals
            
            if bullish_ratio >= 0.6:
                signals["overall"] = "bullish"
                signals["action"] = "buy"
                signals["confidence"] = "high" if bullish_ratio >= 0.8 else "medium"
            elif bearish_ratio >= 0.6:
                signals["overall"] = "bearish"
                signals["action"] = "sell"
                signals["confidence"] = "high" if bearish_ratio >= 0.8 else "medium"
            else:
                signals["overall"] = "neutral"
                signals["action"] = "hold"
                signals["confidence"] = "low"
        
        return signals

