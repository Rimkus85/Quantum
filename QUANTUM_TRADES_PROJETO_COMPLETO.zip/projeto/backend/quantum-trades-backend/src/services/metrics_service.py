import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from collections import defaultdict, deque
import json
import logging
from dataclasses import dataclass, asdict
import statistics

logger = logging.getLogger(__name__)

@dataclass
class MetricPoint:
    """Ponto de métrica com timestamp"""
    timestamp: float
    value: float
    tags: Dict[str, str] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = {}

class MetricsCollector:
    """Coletor de métricas com agregação em tempo real"""
    
    def __init__(self, max_points: int = 1000):
        self.max_points = max_points
        self.metrics = defaultdict(lambda: deque(maxlen=max_points))
        self.counters = defaultdict(int)
        self.gauges = defaultdict(float)
        self.histograms = defaultdict(list)
        self._lock = threading.RLock()
        
        # Configurações de agregação
        self.aggregation_intervals = {
            '1m': 60,
            '5m': 300,
            '15m': 900,
            '1h': 3600
        }
    
    def record_counter(self, name: str, value: float = 1, tags: Dict[str, str] = None):
        """Registra um contador (valor acumulativo)"""
        with self._lock:
            self.counters[name] += value
            self.metrics[name].append(MetricPoint(time.time(), value, tags))
    
    def record_gauge(self, name: str, value: float, tags: Dict[str, str] = None):
        """Registra um gauge (valor instantâneo)"""
        with self._lock:
            self.gauges[name] = value
            self.metrics[name].append(MetricPoint(time.time(), value, tags))
    
    def record_histogram(self, name: str, value: float, tags: Dict[str, str] = None):
        """Registra um valor para histograma"""
        with self._lock:
            self.histograms[name].append(value)
            # Manter apenas últimos 1000 valores
            if len(self.histograms[name]) > 1000:
                self.histograms[name] = self.histograms[name][-1000:]
            
            self.metrics[name].append(MetricPoint(time.time(), value, tags))
    
    def get_counter(self, name: str) -> int:
        """Obtém valor atual de um contador"""
        return self.counters.get(name, 0)
    
    def get_gauge(self, name: str) -> float:
        """Obtém valor atual de um gauge"""
        return self.gauges.get(name, 0.0)
    
    def get_histogram_stats(self, name: str) -> Dict[str, float]:
        """Obtém estatísticas de um histograma"""
        values = self.histograms.get(name, [])
        if not values:
            return {}
        
        return {
            'count': len(values),
            'min': min(values),
            'max': max(values),
            'mean': statistics.mean(values),
            'median': statistics.median(values),
            'p95': self._percentile(values, 95),
            'p99': self._percentile(values, 99)
        }
    
    def _percentile(self, values: List[float], percentile: float) -> float:
        """Calcula percentil de uma lista de valores"""
        if not values:
            return 0.0
        
        sorted_values = sorted(values)
        index = (percentile / 100) * (len(sorted_values) - 1)
        
        if index.is_integer():
            return sorted_values[int(index)]
        else:
            lower = sorted_values[int(index)]
            upper = sorted_values[int(index) + 1]
            return lower + (upper - lower) * (index - int(index))
    
    def get_time_series(self, name: str, duration_seconds: int = 3600) -> List[Dict]:
        """Obtém série temporal de uma métrica"""
        cutoff_time = time.time() - duration_seconds
        
        with self._lock:
            points = self.metrics.get(name, deque())
            return [
                {
                    'timestamp': point.timestamp,
                    'value': point.value,
                    'tags': point.tags
                }
                for point in points
                if point.timestamp >= cutoff_time
            ]
    
    def aggregate_metrics(self, interval: str = '1m') -> Dict[str, Dict]:
        """Agrega métricas por intervalo de tempo"""
        if interval not in self.aggregation_intervals:
            raise ValueError(f"Intervalo inválido: {interval}")
        
        interval_seconds = self.aggregation_intervals[interval]
        cutoff_time = time.time() - interval_seconds
        
        aggregated = {}
        
        with self._lock:
            for metric_name, points in self.metrics.items():
                recent_points = [p for p in points if p.timestamp >= cutoff_time]
                
                if not recent_points:
                    continue
                
                values = [p.value for p in recent_points]
                
                aggregated[metric_name] = {
                    'count': len(values),
                    'sum': sum(values),
                    'avg': statistics.mean(values),
                    'min': min(values),
                    'max': max(values),
                    'latest': values[-1] if values else 0,
                    'interval': interval
                }
        
        return aggregated

class PerformanceMetrics:
    """Métricas específicas de performance da aplicação"""
    
    def __init__(self, collector: MetricsCollector):
        self.collector = collector
        self.start_time = time.time()
        
        # Métricas de API
        self.api_request_times = defaultdict(list)
        self.api_error_counts = defaultdict(int)
        
        # Métricas de cache
        self.cache_operations = defaultdict(int)
        
        # Métricas de WebSocket
        self.websocket_metrics = defaultdict(int)
    
    def record_api_request(self, endpoint: str, method: str, duration: float, status_code: int):
        """Registra métrica de requisição de API"""
        tags = {
            'endpoint': endpoint,
            'method': method,
            'status_code': str(status_code)
        }
        
        self.collector.record_histogram('api_request_duration', duration, tags)
        self.collector.record_counter('api_requests_total', 1, tags)
        
        if status_code >= 400:
            self.collector.record_counter('api_errors_total', 1, tags)
    
    def record_cache_operation(self, operation: str, hit: bool = None):
        """Registra operação de cache"""
        tags = {'operation': operation}
        
        self.collector.record_counter(f'cache_{operation}_total', 1, tags)
        
        if hit is not None:
            result = 'hit' if hit else 'miss'
            self.collector.record_counter(f'cache_{result}_total', 1, tags)
    
    def record_websocket_event(self, event_type: str, count: int = 1):
        """Registra evento de WebSocket"""
        tags = {'event_type': event_type}
        self.collector.record_counter('websocket_events_total', count, tags)
    
    def record_database_query(self, query_type: str, duration: float):
        """Registra query de database"""
        tags = {'query_type': query_type}
        self.collector.record_histogram('database_query_duration', duration, tags)
        self.collector.record_counter('database_queries_total', 1, tags)
    
    def get_system_metrics(self) -> Dict[str, Any]:
        """Obtém métricas do sistema"""
        import psutil
        
        # Métricas de CPU e memória
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        self.collector.record_gauge('system_cpu_percent', cpu_percent)
        self.collector.record_gauge('system_memory_percent', memory.percent)
        self.collector.record_gauge('system_disk_percent', disk.percent)
        
        return {
            'cpu_percent': cpu_percent,
            'memory_percent': memory.percent,
            'memory_available_mb': memory.available / 1024 / 1024,
            'disk_percent': disk.percent,
            'disk_free_gb': disk.free / 1024 / 1024 / 1024,
            'uptime_seconds': time.time() - self.start_time
        }

class AlertingService:
    """Serviço de alertas baseado em métricas"""
    
    def __init__(self, collector: MetricsCollector):
        self.collector = collector
        self.alert_rules = []
        self.alert_history = deque(maxlen=1000)
        self._lock = threading.Lock()
        
        # Configurar alertas padrão
        self._setup_default_alerts()
    
    def _setup_default_alerts(self):
        """Configura alertas padrão do sistema"""
        default_rules = [
            {
                'name': 'high_api_error_rate',
                'condition': lambda: self._get_error_rate() > 0.05,  # 5% de erro
                'message': 'Taxa de erro de API alta: {error_rate:.2%}',
                'severity': 'warning',
                'cooldown': 300  # 5 minutos
            },
            {
                'name': 'slow_api_response',
                'condition': lambda: self._get_avg_response_time() > 2000,  # 2 segundos
                'message': 'Tempo de resposta de API lento: {avg_time:.0f}ms',
                'severity': 'warning',
                'cooldown': 180  # 3 minutos
            },
            {
                'name': 'low_cache_hit_rate',
                'condition': lambda: self._get_cache_hit_rate() < 0.7,  # 70%
                'message': 'Taxa de acerto de cache baixa: {hit_rate:.2%}',
                'severity': 'info',
                'cooldown': 600  # 10 minutos
            },
            {
                'name': 'high_memory_usage',
                'condition': lambda: self.collector.get_gauge('system_memory_percent') > 85,
                'message': 'Uso de memória alto: {memory:.1f}%',
                'severity': 'critical',
                'cooldown': 120  # 2 minutos
            }
        ]
        
        for rule in default_rules:
            self.add_alert_rule(**rule)
    
    def add_alert_rule(self, name: str, condition: callable, message: str, 
                      severity: str = 'info', cooldown: int = 300):
        """Adiciona regra de alerta"""
        rule = {
            'name': name,
            'condition': condition,
            'message': message,
            'severity': severity,
            'cooldown': cooldown,
            'last_triggered': 0
        }
        
        with self._lock:
            # Remover regra existente com mesmo nome
            self.alert_rules = [r for r in self.alert_rules if r['name'] != name]
            self.alert_rules.append(rule)
    
    def check_alerts(self) -> List[Dict]:
        """Verifica todas as regras de alerta"""
        triggered_alerts = []
        current_time = time.time()
        
        with self._lock:
            for rule in self.alert_rules:
                # Verificar cooldown
                if current_time - rule['last_triggered'] < rule['cooldown']:
                    continue
                
                try:
                    if rule['condition']():
                        alert = {
                            'name': rule['name'],
                            'message': self._format_alert_message(rule['message']),
                            'severity': rule['severity'],
                            'timestamp': current_time
                        }
                        
                        triggered_alerts.append(alert)
                        self.alert_history.append(alert)
                        rule['last_triggered'] = current_time
                        
                        logger.warning(f"Alerta disparado: {alert['name']} - {alert['message']}")
                
                except Exception as e:
                    logger.error(f"Erro ao verificar alerta {rule['name']}: {e}")
        
        return triggered_alerts
    
    def _format_alert_message(self, message_template: str) -> str:
        """Formata mensagem de alerta com valores atuais"""
        try:
            return message_template.format(
                error_rate=self._get_error_rate(),
                avg_time=self._get_avg_response_time(),
                hit_rate=self._get_cache_hit_rate(),
                memory=self.collector.get_gauge('system_memory_percent')
            )
        except:
            return message_template
    
    def _get_error_rate(self) -> float:
        """Calcula taxa de erro das APIs"""
        total_requests = self.collector.get_counter('api_requests_total')
        total_errors = self.collector.get_counter('api_errors_total')
        
        if total_requests == 0:
            return 0.0
        
        return total_errors / total_requests
    
    def _get_avg_response_time(self) -> float:
        """Calcula tempo médio de resposta das APIs"""
        stats = self.collector.get_histogram_stats('api_request_duration')
        return stats.get('mean', 0) * 1000  # Converter para ms
    
    def _get_cache_hit_rate(self) -> float:
        """Calcula taxa de acerto do cache"""
        hits = self.collector.get_counter('cache_hit_total')
        misses = self.collector.get_counter('cache_miss_total')
        
        total = hits + misses
        if total == 0:
            return 1.0
        
        return hits / total
    
    def get_alert_history(self, limit: int = 50) -> List[Dict]:
        """Obtém histórico de alertas"""
        with self._lock:
            return list(self.alert_history)[-limit:]

class MetricsService:
    """Serviço principal de métricas"""
    
    def __init__(self):
        self.collector = MetricsCollector()
        self.performance = PerformanceMetrics(self.collector)
        self.alerting = AlertingService(self.collector)
        
        self.monitoring_thread = None
        self.running = False
        
        # Iniciar monitoramento automático
        self.start_monitoring()
    
    def start_monitoring(self):
        """Inicia monitoramento automático"""
        self.running = True
        
        def monitoring_worker():
            while self.running:
                try:
                    # Coletar métricas do sistema
                    self.performance.get_system_metrics()
                    
                    # Verificar alertas
                    self.alerting.check_alerts()
                    
                    time.sleep(30)  # Verificar a cada 30 segundos
                    
                except Exception as e:
                    logger.error(f"Erro no monitoramento: {e}")
                    time.sleep(60)  # Esperar mais tempo em caso de erro
        
        self.monitoring_thread = threading.Thread(target=monitoring_worker, daemon=True)
        self.monitoring_thread.start()
        
        logger.info("Monitoramento de métricas iniciado")
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """Obtém dados para dashboard de métricas"""
        # Métricas agregadas dos últimos 5 minutos
        aggregated_5m = self.collector.aggregate_metrics('5m')
        
        # Métricas do sistema
        system_metrics = self.performance.get_system_metrics()
        
        # Estatísticas de performance
        api_stats = self.collector.get_histogram_stats('api_request_duration')
        
        # Alertas recentes
        recent_alerts = self.alerting.get_alert_history(10)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'system': system_metrics,
            'api_performance': {
                'avg_response_time_ms': api_stats.get('mean', 0) * 1000,
                'p95_response_time_ms': api_stats.get('p95', 0) * 1000,
                'total_requests': self.collector.get_counter('api_requests_total'),
                'error_rate': self.alerting._get_error_rate()
            },
            'cache_performance': {
                'hit_rate': self.alerting._get_cache_hit_rate(),
                'total_operations': (
                    self.collector.get_counter('cache_hit_total') + 
                    self.collector.get_counter('cache_miss_total')
                )
            },
            'websocket': {
                'total_events': self.collector.get_counter('websocket_events_total')
            },
            'aggregated_metrics': aggregated_5m,
            'recent_alerts': recent_alerts
        }
    
    def get_time_series_data(self, metric_name: str, duration_hours: int = 1) -> List[Dict]:
        """Obtém dados de série temporal para gráficos"""
        duration_seconds = duration_hours * 3600
        return self.collector.get_time_series(metric_name, duration_seconds)
    
    def record_custom_metric(self, name: str, value: float, metric_type: str = 'gauge', tags: Dict[str, str] = None):
        """Registra métrica customizada"""
        if metric_type == 'counter':
            self.collector.record_counter(name, value, tags)
        elif metric_type == 'gauge':
            self.collector.record_gauge(name, value, tags)
        elif metric_type == 'histogram':
            self.collector.record_histogram(name, value, tags)
        else:
            raise ValueError(f"Tipo de métrica inválido: {metric_type}")
    
    def shutdown(self):
        """Para o serviço de métricas"""
        self.running = False
        
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)
        
        logger.info("Serviço de métricas finalizado")

# Instância global do serviço de métricas
metrics_service = MetricsService()

