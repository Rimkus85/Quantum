import time
import threading
from typing import Any, Optional, Dict, List, Tuple
import json
from datetime import datetime, timedelta
from collections import defaultdict, deque
import math
import logging

logger = logging.getLogger(__name__)

class AccessPattern:
    """Classe para rastrear padrões de acesso"""
    
    def __init__(self, key: str):
        self.key = key
        self.access_times = deque(maxlen=100)  # Últimos 100 acessos
        self.access_count = 0
        self.last_access = None
        self.access_intervals = deque(maxlen=50)  # Últimos 50 intervalos
        self.prediction_accuracy = 0.0
        self.predictions_made = 0
        self.predictions_correct = 0
    
    def record_access(self):
        """Registra um novo acesso"""
        now = time.time()
        
        if self.last_access:
            interval = now - self.last_access
            self.access_intervals.append(interval)
        
        self.access_times.append(now)
        self.access_count += 1
        self.last_access = now
    
    def get_access_frequency(self) -> float:
        """Calcula frequência de acesso (acessos por hora)"""
        if len(self.access_times) < 2:
            return 0.0
        
        time_span = self.access_times[-1] - self.access_times[0]
        if time_span == 0:
            return 0.0
        
        return len(self.access_times) / (time_span / 3600)  # acessos por hora
    
    def predict_next_access(self) -> Optional[float]:
        """Prediz quando será o próximo acesso"""
        if len(self.access_intervals) < 3:
            return None
        
        # Calcular média ponderada dos intervalos (mais peso para intervalos recentes)
        weights = [i + 1 for i in range(len(self.access_intervals))]
        weighted_sum = sum(interval * weight for interval, weight in zip(self.access_intervals, weights))
        weight_sum = sum(weights)
        
        avg_interval = weighted_sum / weight_sum
        
        # Adicionar variação baseada na consistência dos intervalos
        variance = sum((interval - avg_interval) ** 2 for interval in self.access_intervals) / len(self.access_intervals)
        std_dev = math.sqrt(variance)
        
        # Se há muita variação, ser mais conservador na predição
        confidence_factor = max(0.5, 1 - (std_dev / avg_interval))
        predicted_interval = avg_interval * confidence_factor
        
        return self.last_access + predicted_interval if self.last_access else None
    
    def update_prediction_accuracy(self, was_correct: bool):
        """Atualiza precisão das predições"""
        self.predictions_made += 1
        if was_correct:
            self.predictions_correct += 1
        
        self.prediction_accuracy = self.predictions_correct / self.predictions_made

class PredictiveCacheService:
    """Cache inteligente com predição de acessos e pre-loading"""
    
    def __init__(self):
        self._cache = {}
        self._access_patterns = {}
        self._lock = threading.RLock()
        self._cleanup_interval = 300  # 5 minutos
        self._last_cleanup = time.time()
        self._preload_queue = deque()
        self._preload_thread = None
        self._preload_running = False
        
        # Métricas avançadas
        self.metrics = {
            'hits': 0,
            'misses': 0,
            'preload_hits': 0,  # Hits que foram resultado de preload
            'preload_misses': 0,  # Preloads que não foram usados
            'predictions_made': 0,
            'predictions_correct': 0,
            'cache_size': 0,
            'patterns_tracked': 0
        }
        
        # Configurações de TTL dinâmico
        self.base_ttl = 300  # 5 minutos base
        self.max_ttl = 3600  # 1 hora máximo
        self.min_ttl = 30    # 30 segundos mínimo
        
        # Iniciar thread de preload
        self._start_preload_thread()
    
    def _start_preload_thread(self):
        """Inicia thread para preload inteligente"""
        self._preload_running = True
        self._preload_thread = threading.Thread(target=self._preload_worker, daemon=True)
        self._preload_thread.start()
    
    def _preload_worker(self):
        """Worker thread para preload de dados"""
        while self._preload_running:
            try:
                # Verificar predições a cada 10 segundos
                time.sleep(10)
                self._check_predictions()
            except Exception as e:
                logger.error(f"Erro no preload worker: {e}")
    
    def _check_predictions(self):
        """Verifica predições e agenda preloads"""
        now = time.time()
        
        with self._lock:
            for key, pattern in self._access_patterns.items():
                predicted_time = pattern.predict_next_access()
                
                if predicted_time and predicted_time <= now + 60:  # Próximos 60 segundos
                    # Verificar se já está no cache
                    if key not in self._cache or self._is_expired(key):
                        self._schedule_preload(key, pattern)
    
    def _schedule_preload(self, key: str, pattern: AccessPattern):
        """Agenda preload de uma chave"""
        # Evitar preloads duplicados
        if key not in [item[0] for item in self._preload_queue]:
            priority = pattern.get_access_frequency()  # Maior frequência = maior prioridade
            self._preload_queue.append((key, priority, time.time()))
            
            # Manter queue ordenada por prioridade
            self._preload_queue = deque(sorted(self._preload_queue, key=lambda x: x[1], reverse=True))
    
    def _calculate_dynamic_ttl(self, key: str) -> int:
        """Calcula TTL dinâmico baseado nos padrões de acesso"""
        if key not in self._access_patterns:
            return self.base_ttl
        
        pattern = self._access_patterns[key]
        frequency = pattern.get_access_frequency()
        
        # Maior frequência = TTL maior (até o máximo)
        if frequency > 0:
            # TTL baseado na frequência: mais acessos = cache mais longo
            dynamic_ttl = self.base_ttl * (1 + math.log(frequency + 1))
            return min(max(int(dynamic_ttl), self.min_ttl), self.max_ttl)
        
        return self.base_ttl
    
    def _cleanup_expired(self):
        """Remove itens expirados e atualiza métricas"""
        current_time = time.time()
        
        if current_time - self._last_cleanup < self._cleanup_interval:
            return
        
        with self._lock:
            expired_keys = []
            preload_misses = 0
            
            for key, (value, expiry, metadata) in self._cache.items():
                if expiry and current_time > expiry:
                    expired_keys.append(key)
                    
                    # Verificar se foi um preload não utilizado
                    if metadata.get('preloaded', False) and not metadata.get('accessed_after_preload', False):
                        preload_misses += 1
            
            for key in expired_keys:
                del self._cache[key]
            
            self.metrics['preload_misses'] += preload_misses
            self.metrics['cache_size'] = len(self._cache)
            self.metrics['patterns_tracked'] = len(self._access_patterns)
            
            self._last_cleanup = current_time
            
            logger.info(f"Cache cleanup: removidos {len(expired_keys)} itens expirados")
    
    def _is_expired(self, key: str) -> bool:
        """Verifica se uma chave está expirada"""
        if key not in self._cache:
            return True
        
        _, expiry, _ = self._cache[key]
        return expiry and time.time() > expiry
    
    def get(self, key: str) -> Optional[Any]:
        """Obtém valor do cache com tracking de padrões"""
        self._cleanup_expired()
        
        with self._lock:
            # Registrar padrão de acesso
            if key not in self._access_patterns:
                self._access_patterns[key] = AccessPattern(key)
            
            self._access_patterns[key].record_access()
            
            if key not in self._cache:
                self.metrics['misses'] += 1
                return None
            
            value, expiry, metadata = self._cache[key]
            
            # Verificar se expirou
            if expiry and time.time() > expiry:
                del self._cache[key]
                self.metrics['misses'] += 1
                return None
            
            # Marcar como acessado após preload
            if metadata.get('preloaded', False) and not metadata.get('accessed_after_preload', False):
                metadata['accessed_after_preload'] = True
                self.metrics['preload_hits'] += 1
            
            self.metrics['hits'] += 1
            return value
    
    def set(self, key: str, value: Any, timeout: Optional[int] = None, preloaded: bool = False) -> bool:
        """Define valor no cache com TTL dinâmico"""
        if timeout is None:
            timeout = self._calculate_dynamic_ttl(key)
        
        expiry = time.time() + timeout if timeout else None
        metadata = {
            'preloaded': preloaded,
            'accessed_after_preload': False,
            'set_time': time.time()
        }
        
        with self._lock:
            self._cache[key] = (value, expiry, metadata)
            self.metrics['cache_size'] = len(self._cache)
        
        return True
    
    def set_smart(self, key: str, value: Any, data_type: str = 'default') -> bool:
        """Define valor com TTL baseado no tipo de dados e padrões"""
        base_timeouts = {
            'quote': 60,
            'historical': 3600,
            'search': 3600,
            'market_summary': 300,
            'user': 1800,
            'alerts': 300
        }
        
        base_timeout = base_timeouts.get(data_type, 300)
        
        # Ajustar baseado nos padrões de acesso
        if key in self._access_patterns:
            pattern = self._access_patterns[key]
            frequency = pattern.get_access_frequency()
            
            # Dados acessados frequentemente ficam mais tempo no cache
            if frequency > 10:  # Mais de 10 acessos por hora
                base_timeout *= 2
            elif frequency > 5:  # Mais de 5 acessos por hora
                base_timeout *= 1.5
        
        return self.set(key, value, timeout=base_timeout)
    
    def preload(self, key: str, loader_func, *args, **kwargs) -> bool:
        """Preload de dados usando função loader"""
        try:
            value = loader_func(*args, **kwargs)
            if value:
                self.set(key, value, preloaded=True)
                logger.debug(f"Preload bem-sucedido para {key}")
                return True
        except Exception as e:
            logger.warning(f"Erro no preload para {key}: {e}")
        
        return False
    
    def get_next_preload_candidate(self) -> Optional[Tuple[str, float]]:
        """Obtém próximo candidato para preload"""
        with self._lock:
            if self._preload_queue:
                key, priority, scheduled_time = self._preload_queue.popleft()
                return key, priority
        return None
    
    def delete(self, key: str) -> bool:
        """Remove item do cache"""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                self.metrics['cache_size'] = len(self._cache)
                return True
        return False
    
    def clear(self) -> bool:
        """Limpa todo o cache"""
        with self._lock:
            self._cache.clear()
            self._access_patterns.clear()
            self.metrics['cache_size'] = 0
            self.metrics['patterns_tracked'] = 0
        return True
    
    def get_cache_stats(self) -> Dict:
        """Retorna estatísticas avançadas do cache"""
        with self._lock:
            total_requests = self.metrics['hits'] + self.metrics['misses']
            hit_rate = (self.metrics['hits'] / total_requests * 100) if total_requests > 0 else 0
            
            preload_total = self.metrics['preload_hits'] + self.metrics['preload_misses']
            preload_efficiency = (self.metrics['preload_hits'] / preload_total * 100) if preload_total > 0 else 0
            
            # Estatísticas de predição
            prediction_accuracy = 0
            if self.metrics['predictions_made'] > 0:
                prediction_accuracy = (self.metrics['predictions_correct'] / self.metrics['predictions_made'] * 100)
            
            # Top padrões por frequência
            top_patterns = sorted(
                [(key, pattern.get_access_frequency()) for key, pattern in self._access_patterns.items()],
                key=lambda x: x[1],
                reverse=True
            )[:10]
            
            return {
                **self.metrics,
                'hit_rate': round(hit_rate, 2),
                'preload_efficiency': round(preload_efficiency, 2),
                'prediction_accuracy': round(prediction_accuracy, 2),
                'preload_queue_size': len(self._preload_queue),
                'top_patterns': top_patterns,
                'avg_ttl': self._calculate_average_ttl(),
                'timestamp': datetime.now().isoformat()
            }
    
    def _calculate_average_ttl(self) -> float:
        """Calcula TTL médio dos itens no cache"""
        if not self._cache:
            return 0
        
        current_time = time.time()
        ttls = []
        
        for _, expiry, metadata in self._cache.values():
            if expiry:
                remaining_ttl = expiry - current_time
                if remaining_ttl > 0:
                    ttls.append(remaining_ttl)
        
        return sum(ttls) / len(ttls) if ttls else 0
    
    def optimize_patterns(self):
        """Otimiza padrões baseado na performance histórica"""
        with self._lock:
            # Remover padrões de chaves que não são mais acessadas
            cutoff_time = time.time() - 3600  # 1 hora atrás
            
            patterns_to_remove = []
            for key, pattern in self._access_patterns.items():
                if pattern.last_access and pattern.last_access < cutoff_time:
                    patterns_to_remove.append(key)
            
            for key in patterns_to_remove:
                del self._access_patterns[key]
            
            logger.info(f"Otimização: removidos {len(patterns_to_remove)} padrões inativos")
    
    def warm_cache_intelligent(self, symbols: List[str], loader_func):
        """Aquece cache de forma inteligente baseada em padrões históricos"""
        # Ordenar símbolos por padrões de acesso históricos
        symbol_priorities = []
        
        for symbol in symbols:
            cache_key = f"quote:{symbol}"
            if cache_key in self._access_patterns:
                frequency = self._access_patterns[cache_key].get_access_frequency()
                symbol_priorities.append((symbol, frequency))
            else:
                symbol_priorities.append((symbol, 0))
        
        # Ordenar por frequência (maior primeiro)
        symbol_priorities.sort(key=lambda x: x[1], reverse=True)
        
        warmed_count = 0
        for symbol, _ in symbol_priorities:
            try:
                cache_key = f"quote:{symbol}"
                if self.preload(cache_key, loader_func, symbol):
                    warmed_count += 1
            except Exception as e:
                logger.warning(f"Erro ao aquecer cache para {symbol}: {e}")
        
        logger.info(f"Cache aquecido inteligentemente com {warmed_count} símbolos")
        return warmed_count
    
    def shutdown(self):
        """Para threads e limpa recursos"""
        self._preload_running = False
        if self._preload_thread and self._preload_thread.is_alive():
            self._preload_thread.join(timeout=5)

# Instância global do cache preditivo
predictive_cache_service = PredictiveCacheService()

