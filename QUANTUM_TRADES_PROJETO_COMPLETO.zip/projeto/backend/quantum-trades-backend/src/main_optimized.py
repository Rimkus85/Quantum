import os
import sys
import logging
from datetime import datetime
import time
import atexit

# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify, request
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.market import market_bp
from src.config import config

# Novos serviços otimizados
from src.services.websocket_service import websocket_service
from src.services.metrics_service import metrics_service
from src.services.predictive_cache_service import predictive_cache_service
from src.services.optimized_financial_service import OptimizedFinancialDataService
from src.services.alerts_engine import alerts_engine

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_optimized_app(config_name='default'):
    """Factory function para criar a aplicação Flask otimizada"""
    app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
    
    # Carregar configuração
    app.config.from_object(config[config_name])
    
    # Configurar CORS para permitir requisições do frontend
    CORS(app, origins="*", supports_credentials=True)
    
    # Inicializar extensões
    db.init_app(app)
    
    # Inicializar WebSocket service
    websocket_service.init_app(app)
    
    # Inicializar engine de alertas
    alerts_engine.start_monitoring()
    
    # Registrar blueprints existentes
    app.register_blueprint(user_bp, url_prefix='/api/users')
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(market_bp, url_prefix='/api/market')
    
    # Registrar novos blueprints
    from src.routes.metrics import metrics_bp
    from src.routes.technical_analysis import technical_bp
    from src.routes.alerts import alerts_bp
    
    app.register_blueprint(metrics_bp, url_prefix='/api/metrics')
    app.register_blueprint(technical_bp, url_prefix='/api/technical')
    app.register_blueprint(alerts_bp, url_prefix='/api/alerts')
    
    # Criar tabelas do banco de dados
    with app.app_context():
        try:
            db.create_all()
            logger.info("Banco de dados inicializado com sucesso")
        except Exception as e:
            logger.error(f"Erro ao inicializar banco de dados: {e}")
    
    # Middleware para métricas de performance
    @app.before_request
    def before_request():
        """Middleware para tracking de performance"""
        request.start_time = time.time()
        
        # Registrar métrica de requisição
        if not request.path.startswith('/api/health'):
            metrics_service.collector.record_counter('http_requests_total', 1, {
                'method': request.method,
                'endpoint': request.endpoint or 'unknown'
            })
    
    @app.after_request
    def after_request(response):
        """Middleware para métricas pós-requisição"""
        if hasattr(request, 'start_time'):
            duration = time.time() - request.start_time
            
            # Registrar métricas de performance
            metrics_service.performance.record_api_request(
                endpoint=request.endpoint or 'unknown',
                method=request.method,
                duration=duration,
                status_code=response.status_code
            )
            
            # Adicionar headers de performance
            response.headers['X-Response-Time'] = f"{duration:.3f}s"
            response.headers['X-Server-Time'] = datetime.utcnow().isoformat()
        
        return response
    
    # Rota de health check otimizada
    @app.route('/api/health', methods=['GET'])
    def health_check():
        """Health check otimizado com métricas detalhadas"""
        try:
            start_time = time.time()
            
            # Testar conexão com banco
            db.session.execute('SELECT 1')
            db_status = 'ok'
            db_time = time.time() - start_time
            
        except Exception as e:
            db_status = f'error: {str(e)}'
            db_time = -1
            logger.error(f"Erro na conexão com banco: {e}")
        
        # Obter métricas dos serviços
        cache_stats = predictive_cache_service.get_cache_stats()
        websocket_metrics = websocket_service.get_metrics()
        
        health_data = {
            'status': 'healthy' if db_status == 'ok' else 'degraded',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '4.0.0-optimized',
            'services': {
                'database': {
                    'status': db_status,
                    'response_time_ms': round(db_time * 1000, 2)
                },
                'cache': {
                    'status': 'ok',
                    'hit_rate': cache_stats.get('hit_rate', 0),
                    'size': cache_stats.get('cache_size', 0)
                },
                'websocket': {
                    'status': 'ok',
                    'active_connections': websocket_metrics.get('active_connections', 0),
                    'total_messages': websocket_metrics.get('messages_sent', 0)
                },
                'metrics': {
                    'status': 'ok',
                    'monitoring': 'active'
                }
            },
            'performance': {
                'cache_hit_rate': cache_stats.get('hit_rate', 0),
                'prediction_accuracy': cache_stats.get('prediction_accuracy', 0),
                'preload_efficiency': cache_stats.get('preload_efficiency', 0)
            }
        }
        
        status_code = 200 if db_status == 'ok' else 503
        return jsonify(health_data), status_code
    
    # Rota para informações da API otimizada
    @app.route('/api/info', methods=['GET'])
    def api_info():
        """Informações sobre a API otimizada"""
        return jsonify({
            'name': 'Quantum Trades API - Optimized',
            'version': '4.0.0',
            'description': 'API otimizada para plataforma de trading com WebSockets e análise técnica',
            'features': [
                'WebSockets em tempo real',
                'Cache preditivo inteligente',
                'Métricas de performance',
                'Circuit breakers',
                'Indicadores técnicos',
                'Sistema de alertas'
            ],
            'endpoints': {
                'auth': '/api/auth',
                'users': '/api/users',
                'market': '/api/market',
                'metrics': '/api/metrics',
                'websocket': '/socket.io',
                'health': '/api/health'
            },
            'optimizations': {
                'cache_hit_rate_target': '90%+',
                'response_time_target': '<2s',
                'websocket_latency_target': '<50ms'
            },
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    # Rota para dashboard de métricas
    @app.route('/api/dashboard', methods=['GET'])
    def api_dashboard():
        """Dashboard de métricas em tempo real"""
        try:
            dashboard_data = metrics_service.get_dashboard_data()
            return jsonify({
                'success': True,
                'data': dashboard_data
            }), 200
        except Exception as e:
            logger.error(f"Erro ao obter dados do dashboard: {e}")
            return jsonify({'message': 'Erro interno do servidor'}), 500
    
    # Handler para erros 404
    @app.errorhandler(404)
    def not_found(error):
        if request.path.startswith('/api/'):
            return jsonify({'message': 'Endpoint não encontrado'}), 404
        # Para rotas não-API, servir o frontend
        return serve('')
    
    # Handler para erros 500
    @app.errorhandler(500)
    def internal_error(error):
        logger.error(f"Erro interno: {error}")
        
        # Registrar métrica de erro
        metrics_service.collector.record_counter('server_errors_total', 1, {
            'error_type': 'internal_server_error'
        })
        
        return jsonify({'message': 'Erro interno do servidor'}), 500
    
    # Servir frontend (mantido da versão original)
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve(path):
        static_folder_path = app.static_folder
        if static_folder_path is None:
            return "Static folder not configured", 404

        if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
            return send_from_directory(static_folder_path, path)
        else:
            # Detectar se é mobile
            user_agent = request.headers.get('User-Agent', '').lower()
            is_mobile = any(device in user_agent for device in [
                'mobile', 'android', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone'
            ])
            
            # Servir login como página inicial
            login_path = os.path.join(static_folder_path, 'login.html')
            if os.path.exists(login_path):
                return send_from_directory(static_folder_path, 'login.html')
            else:
                # Fallback para dashboard se login não existir
                if is_mobile:
                    mobile_path = os.path.join(static_folder_path, 'mobile_index.html')
                    if os.path.exists(mobile_path):
                        return send_from_directory(static_folder_path, 'mobile_index.html')
                
                # Usar o dashboard corrigido como página principal para desktop
                index_path = os.path.join(static_folder_path, 'index_fixed.html')
                if os.path.exists(index_path):
                    return send_from_directory(static_folder_path, 'index_fixed.html')
                else:
                    # Fallback para index.html original
                    index_path = os.path.join(static_folder_path, 'index.html')
                    if os.path.exists(index_path):
                        return send_from_directory(static_folder_path, 'index.html')
                    else:
                        return "index.html not found", 404
    
    # Rota específica para dashboard (após login)
    @app.route('/dashboard')
    def dashboard():
        """Dashboard principal após login"""
        user_agent = request.headers.get('User-Agent', '').lower()
        is_mobile = any(device in user_agent for device in [
            'mobile', 'android', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone'
        ])
        
        if is_mobile:
            return send_from_directory('static', 'mobile_index.html')
        else:
            return send_from_directory('static', 'index_fixed.html')
    
    # Registrar cleanup na saída
    def cleanup_services():
        """Limpa recursos dos serviços na saída"""
        logger.info("Finalizando serviços...")
        
        try:
            alerts_engine.stop_monitoring()
            websocket_service.shutdown()
            metrics_service.shutdown()
            predictive_cache_service.shutdown()
            logger.info("Serviços finalizados com sucesso")
        except Exception as e:
            logger.error(f"Erro ao finalizar serviços: {e}")
    
    atexit.register(cleanup_services)
    
    return app

# Criar aplicação otimizada
app = create_optimized_app(os.environ.get('FLASK_ENV', 'default'))

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    
    logger.info(f"Iniciando Quantum Trades API Otimizada v4.0.0 na porta {port}")
    logger.info(f"Modo debug: {debug}")
    logger.info("Funcionalidades ativas:")
    logger.info("  ✅ WebSockets em tempo real")
    logger.info("  ✅ Cache preditivo inteligente")
    logger.info("  ✅ Métricas de performance")
    logger.info("  ✅ Circuit breakers")
    logger.info("  ✅ Sistema de monitoramento")
    
    # Aquecer cache com símbolos populares
    try:
        optimized_service = OptimizedFinancialDataService(predictive_cache_service)
        warmed_count = optimized_service.warm_cache_intelligent()
        logger.info(f"Cache aquecido com {warmed_count} símbolos")
    except Exception as e:
        logger.warning(f"Erro ao aquecer cache: {e}")
    
    # Iniciar aplicação com WebSocket support
    websocket_service.socketio.run(
        app, 
        host='0.0.0.0', 
        port=port, 
        debug=debug,
        use_reloader=False  # Evitar problemas com threads
    )

