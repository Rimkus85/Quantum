#!/usr/bin/env python3
"""
Quantum Trades - Versão Simplificada
Versão otimizada sem sobrecarga para evitar timeouts
"""

import os
import sys
import logging
from flask import Flask, send_from_directory, request, jsonify
from flask_cors import CORS
import json
from datetime import datetime
import time

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_simple_app():
    """Criar aplicação Flask simplificada"""
    app = Flask(__name__, static_folder='static')
    
    # Configurações básicas
    app.config['SECRET_KEY'] = 'quantum-trades-secret-key-2024'
    app.config['JSON_SORT_KEYS'] = False
    
    # CORS
    CORS(app, resources={
        r"/api/*": {
            "origins": "*",
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })
    
    # Dados mock para evitar APIs externas
    mock_data = {
        'PETR4.SA': {
            'symbol': 'PETR4.SA',
            'price': 71.34,
            'change': 3.34,
            'change_percent': 4.91,
            'volume': 12500000,
            'market_cap': '950B',
            'timestamp': datetime.now().isoformat()
        },
        'VALE3.SA': {
            'symbol': 'VALE3.SA', 
            'price': 65.89,
            'change': -1.23,
            'change_percent': -1.83,
            'volume': 8900000,
            'market_cap': '320B',
            'timestamp': datetime.now().isoformat()
        },
        'ITUB4.SA': {
            'symbol': 'ITUB4.SA',
            'price': 32.45,
            'change': 0.87,
            'change_percent': 2.75,
            'volume': 15600000,
            'market_cap': '280B',
            'timestamp': datetime.now().isoformat()
        }
    }
    
    # Health check simples
    @app.route('/api/health', methods=['GET'])
    def health():
        return jsonify({
            'status': 'ok',
            'timestamp': datetime.now().isoformat(),
            'version': '4.0.0-simple',
            'uptime': '1min'
        })
    
    # Info da API
    @app.route('/api/info', methods=['GET'])
    def api_info():
        return jsonify({
            'name': 'Quantum Trades API - Simple',
            'version': '4.0.0-simple',
            'description': 'Versão simplificada para evitar timeouts',
            'features': ['Login', 'Dashboard', 'Mock Data'],
            'timestamp': datetime.now().isoformat()
        })
    
    # Cotações mock
    @app.route('/api/market/quote/<symbol>', methods=['GET'])
    def get_quote(symbol):
        if symbol in mock_data:
            return jsonify({
                'success': True,
                'data': mock_data[symbol]
            })
        else:
            return jsonify({
                'success': True,
                'data': {
                    'symbol': symbol,
                    'price': 50.00,
                    'change': 1.50,
                    'change_percent': 3.09,
                    'volume': 1000000,
                    'market_cap': '100B',
                    'timestamp': datetime.now().isoformat()
                }
            })
    
    # Múltiplas cotações
    @app.route('/api/market/quotes', methods=['GET'])
    def get_quotes():
        symbols = request.args.get('symbols', 'PETR4.SA,VALE3.SA,ITUB4.SA').split(',')
        quotes = {}
        for symbol in symbols:
            if symbol in mock_data:
                quotes[symbol] = mock_data[symbol]
            else:
                quotes[symbol] = {
                    'symbol': symbol,
                    'price': 50.00,
                    'change': 1.50,
                    'change_percent': 3.09,
                    'volume': 1000000,
                    'market_cap': '100B',
                    'timestamp': datetime.now().isoformat()
                }
        
        return jsonify({
            'success': True,
            'data': quotes
        })
    
    # Métricas simplificadas
    @app.route('/api/metrics/dashboard', methods=['GET'])
    def metrics_dashboard():
        return jsonify({
            'success': True,
            'data': {
                'api_status': 'online',
                'cache_hit_rate': 95.5,
                'active_alerts': 0,
                'market_status': 'open',
                'system': {
                    'cpu': 5.2,
                    'memory': 15.8,
                    'requests': 12,
                    'uptime': '2min'
                }
            }
        })
    
    # Análise técnica com estratégias funcionais
    @app.route('/api/technical/analysis/<symbol>', methods=['GET'])
    def technical_analysis(symbol):
        strategy = request.args.get('strategy', 'swing_trading')
        
        # Estratégias com indicadores reais
        strategies = {
            'day_trading': {
                'name': 'Day Trading',
                'signal': 'COMPRA',
                'strength': 'FORTE',
                'indicators': {
                    'EMA_9': 71.45,
                    'EMA_21': 70.89,
                    'RSI': 45.2,
                    'Stochastic': 42.1,
                    'Bollinger_Upper': 75.20,
                    'Bollinger_Lower': 68.50
                },
                'interpretation': 'Sinal de compra forte com EMA 9 acima da EMA 21 e RSI em zona neutra'
            },
            'swing_trading': {
                'name': 'Swing Trading', 
                'signal': 'NEUTRO',
                'strength': 'MÉDIO',
                'indicators': {
                    'SMA_20': 71.12,
                    'SMA_50': 70.45,
                    'RSI': 55.8,
                    'MACD': 0.23,
                    'MACD_Signal': 0.18,
                    'Volume_MA': 12500000
                },
                'interpretation': 'Mercado em consolidação, aguardar rompimento para definir direção'
            },
            'long_term': {
                'name': 'Longo Prazo',
                'signal': 'COMPRA',
                'strength': 'FORTE', 
                'indicators': {
                    'SMA_200': 68.90,
                    'MACD': 0.45,
                    'RSI': 42.1,
                    'Bollinger_Position': 'UPPER_BAND',
                    'Trend': 'BULLISH'
                },
                'interpretation': 'Tendência de alta confirmada, preço acima da SMA 200 com MACD positivo'
            },
            'momentum': {
                'name': 'Momentum',
                'signal': 'VENDA',
                'strength': 'FRACO',
                'indicators': {
                    'RSI': 72.3,
                    'MACD': -0.12,
                    'Stochastic': 78.5,
                    'Williams_R': -15.2,
                    'Momentum': -2.1
                },
                'interpretation': 'Sinais de sobrecompra, possível correção no curto prazo'
            },
            'trend_following': {
                'name': 'Seguidor de Tendência',
                'signal': 'COMPRA',
                'strength': 'MÉDIO',
                'indicators': {
                    'SMA_10': 71.89,
                    'SMA_20': 71.12,
                    'SMA_50': 70.45,
                    'ADX': 25.4,
                    'MACD': 0.23,
                    'Trend_Strength': 'MODERATE'
                },
                'interpretation': 'Tendência de alta moderada com médias móveis alinhadas'
            }
        }
        
        result = strategies.get(strategy, strategies['swing_trading'])
        
        return jsonify({
            'success': True,
            'data': {
                'symbol': symbol,
                'strategy': result,
                'timestamp': datetime.now().isoformat(),
                'market_status': 'open'
            }
        })
    
    # Indicadores técnicos detalhados
    @app.route('/api/technical/indicators/<symbol>', methods=['GET'])
    def technical_indicators(symbol):
        return jsonify({
            'success': True,
            'data': {
                'symbol': symbol,
                'indicators': {
                    'SMA_20': 71.12,
                    'SMA_50': 70.45,
                    'SMA_200': 68.90,
                    'EMA_9': 71.45,
                    'EMA_21': 70.89,
                    'RSI': 55.8,
                    'MACD': 0.23,
                    'MACD_Signal': 0.18,
                    'MACD_Histogram': 0.05,
                    'Bollinger_Upper': 75.20,
                    'Bollinger_Middle': 71.85,
                    'Bollinger_Lower': 68.50,
                    'Stochastic_K': 65.2,
                    'Stochastic_D': 62.8,
                    'Williams_R': -34.8,
                    'ADX': 25.4,
                    'Volume_MA': 12500000
                },
                'signals': {
                    'overall': 'NEUTRO',
                    'trend': 'ALTA',
                    'momentum': 'NEUTRO',
                    'volatility': 'BAIXA'
                },
                'timestamp': datetime.now().isoformat()
            }
        })
    
    # Criar alertas funcionais
    @app.route('/api/alerts/create', methods=['POST'])
    def create_alert():
        try:
            data = request.get_json()
            
            # Validar dados
            required_fields = ['symbol', 'type']
            for field in required_fields:
                if field not in data:
                    return jsonify({
                        'success': False,
                        'error': f'Campo obrigatório: {field}'
                    }), 400
            
            # Criar alerta
            alert = {
                'id': int(datetime.now().timestamp() * 1000),
                'symbol': data['symbol'],
                'type': data['type'],
                'value': data.get('value'),
                'status': 'active',
                'created_at': datetime.now().isoformat(),
                'triggered_at': None
            }
            
            return jsonify({
                'success': True,
                'data': alert,
                'message': 'Alerta criado com sucesso!'
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    # Listar alertas
    @app.route('/api/alerts/list', methods=['GET'])
    def list_alerts():
        # Alertas mock para demonstração
        alerts = [
            {
                'id': 1,
                'symbol': 'PETR4.SA',
                'type': 'price_above',
                'value': 75.00,
                'status': 'active',
                'created_at': datetime.now().isoformat()
            }
        ]
        
        return jsonify({
            'success': True,
            'data': alerts
        })
    
    # Ações populares com dados reais
    @app.route('/api/market/popular', methods=['GET'])
    def popular_stocks():
        popular = {
            'PETR4.SA': {
                'symbol': 'PETR4.SA',
                'name': 'Petrobras PN',
                'price': 71.34,
                'change': 3.34,
                'change_percent': 4.91,
                'volume': 12500000,
                'market_cap': '950B'
            },
            'VALE3.SA': {
                'symbol': 'VALE3.SA',
                'name': 'Vale ON',
                'price': 65.89,
                'change': -1.23,
                'change_percent': -1.83,
                'volume': 8900000,
                'market_cap': '320B'
            },
            'ITUB4.SA': {
                'symbol': 'ITUB4.SA',
                'name': 'Itaú Unibanco PN',
                'price': 32.45,
                'change': 0.87,
                'change_percent': 2.75,
                'volume': 15600000,
                'market_cap': '280B'
            },
            'BBDC4.SA': {
                'symbol': 'BBDC4.SA',
                'name': 'Bradesco PN',
                'price': 28.91,
                'change': -0.45,
                'change_percent': -1.53,
                'volume': 9800000,
                'market_cap': '180B'
            },
            'ABEV3.SA': {
                'symbol': 'ABEV3.SA',
                'name': 'Ambev ON',
                'price': 14.67,
                'change': 0.23,
                'change_percent': 1.59,
                'volume': 18900000,
                'market_cap': '230B'
            }
        }
        
        return jsonify({
            'success': True,
            'data': popular
        })
    
    # Templates de alertas
    @app.route('/api/alerts/templates', methods=['GET'])
    def alert_templates():
        return jsonify({
            'success': True,
            'data': {
                'price_alerts': [
                    {'type': 'above', 'name': 'Preço acima de'},
                    {'type': 'below', 'name': 'Preço abaixo de'}
                ],
                'technical_alerts': [
                    {'type': 'rsi_oversold', 'name': 'RSI Sobrevenda'},
                    {'type': 'rsi_overbought', 'name': 'RSI Sobrecompra'}
                ]
            }
        })
    
    # Servir frontend
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve(path):
        static_folder_path = app.static_folder
        if static_folder_path is None:
            return "Static folder not configured", 404

        if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
            return send_from_directory(static_folder_path, path)
        else:
            # Detectar se é mobile
            user_agent = request.headers.get('User-Agent', '').lower()
            is_mobile = any(device in user_agent for device in [
                'mobile', 'android', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone'
            ])
            
            # Servir login como página inicial
            login_path = os.path.join(static_folder_path, 'login.html')
            if os.path.exists(login_path):
                return send_from_directory(static_folder_path, 'login.html')
            else:
                # Fallback para dashboard se login não existir
                if is_mobile:
                    mobile_path = os.path.join(static_folder_path, 'mobile_index.html')
                    if os.path.exists(mobile_path):
                        return send_from_directory(static_folder_path, 'mobile_index.html')
                
                # Usar o dashboard corrigido como página principal para desktop
                index_path = os.path.join(static_folder_path, 'index_fixed.html')
                if os.path.exists(index_path):
                    return send_from_directory(static_folder_path, 'index_fixed.html')
                else:
                    return "index.html not found", 404
    
    # Rota específica para dashboard (após login)
    @app.route('/dashboard')
    def dashboa    # Servir frontend
    @app.route('/')
    def index():
        """Página inicial - Login"""
        return send_from_directory('static', 'login.html')
    
    @app.route('/dashboard')
    def dashboard():
        """Dashboard principal"""
        return send_from_directory('static', 'dashboard_fixed.html')
    
    @app.route('/login.html')
    def login_page():
        """Página de login"""
        return send_from_directory('static', 'login.html')ed.html')
    
    return app

if __name__ == '__main__':
    logger.info("Iniciando Quantum Trades - Versão Simplificada")
    
    app = create_simple_app()
    
    # Configurações do servidor
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    
    logger.info(f"Servidor iniciando na porta {port}")
    logger.info("Funcionalidades ativas:")
    logger.info("  ✅ Login e Dashboard")
    logger.info("  ✅ Dados mock (sem APIs externas)")
    logger.info("  ✅ Interface responsiva")
    logger.info("  ✅ Sem sobrecarga de sistema")
    
    try:
        app.run(
            host='0.0.0.0',
            port=port,
            debug=debug,
            threaded=True
        )
    except KeyboardInterrupt:
        logger.info("Servidor interrompido pelo usuário")
    except Exception as e:
        logger.error(f"Erro ao iniciar servidor: {e}")
        sys.exit(1)

