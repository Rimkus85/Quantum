/**
 * 🎯 QUANTUM FINANCE - CACHE STRATEGIES
 * Estratégias específicas de cache para diferentes tipos de dados financeiros
 */

/**
 * Configurações de cache por tipo de dados
 */
const CacheStrategies = {
  STOCK_PRICES: {
    ttl: 60,           // 1 minuto
    strategy: 'write-through',
    invalidateOn: ['market_close', 'symbol_update'],
    refreshAhead: true,
    refreshThreshold: 0.2 // Refresh quando restam 20% do TTL
  },
  
  HISTORICAL_DATA: {
    ttl: 3600,         // 1 hora
    strategy: 'cache-aside',
    invalidateOn: ['end_of_day'],
    refreshAhead: false
  },
  
  SEARCH_RESULTS: {
    ttl: 86400,        // 24 horas
    strategy: 'write-behind',
    invalidateOn: ['symbol_list_update'],
    refreshAhead: false
  },
  
  MARKET_OVERVIEW: {
    ttl: 300,          // 5 minutos
    strategy: 'refresh-ahead',
    invalidateOn: ['market_hours_change'],
    refreshAhead: true,
    refreshThreshold: 0.3
  },

  DIVIDENDS: {
    ttl: 86400,        // 24 horas
    strategy: 'cache-aside',
    invalidateOn: ['dividend_announcement'],
    refreshAhead: false
  },

  COMPANY_INFO: {
    ttl: 604800,       // 7 dias
    strategy: 'cache-aside',
    invalidateOn: ['company_update'],
    refreshAhead: false
  }
};

/**
 * Gerenciador inteligente de cache
 */
class IntelligentCacheManager {
  constructor(cacheService) {
    this.cache = cacheService;
    this.strategies = CacheStrategies;
    this.refreshQueue = new Set();
    this.refreshCallbacks = new Map();
    
    // Configurar refresh automático
    this.setupAutoRefresh();
  }

  /**
   * Obter dados com estratégia específica
   */
  async get(key, dataType, fetchFunction = null) {
    const strategy = this.strategies[dataType];
    
    if (!strategy) {
      console.warn(`[Cache] Unknown data type: ${dataType}`);
      return await this.cache.get(key);
    }

    switch (strategy.strategy) {
      case 'refresh-ahead':
        return await this.refreshAheadGet(key, strategy, fetchFunction);
      
      case 'write-through':
        return await this.writeThroughGet(key, strategy, fetchFunction);
      
      case 'cache-aside':
        return await this.cacheAsideGet(key, strategy, fetchFunction);
      
      case 'write-behind':
        return await this.writeBehindGet(key, strategy, fetchFunction);
      
      default:
        return await this.cache.get(key);
    }
  }

  /**
   * Armazenar dados com estratégia específica
   */
  async set(key, value, dataType) {
    const strategy = this.strategies[dataType];
    
    if (!strategy) {
      return await this.cache.set(key, value);
    }

    return await this.cache.set(key, value, strategy.ttl);
  }

  /**
   * Estratégia Refresh-Ahead
   */
  async refreshAheadGet(key, strategy, fetchFunction) {
    const cached = await this.cache.get(key);
    
    if (cached) {
      // Verificar se está próximo do vencimento
      const timeToExpiry = this.cache.getTimeToExpiry(key);
      const refreshThreshold = strategy.ttl * (strategy.refreshThreshold || 0.2);
      
      if (timeToExpiry < refreshThreshold && fetchFunction) {
        // Refresh em background
        this.refreshInBackground(key, fetchFunction, strategy);
      }
      
      return cached;
    }
    
    // Se não existe no cache, buscar agora
    if (fetchFunction) {
      const data = await fetchFunction();
      await this.cache.set(key, data, strategy.ttl);
      return data;
    }
    
    return null;
  }

  /**
   * Estratégia Write-Through
   */
  async writeThroughGet(key, strategy, fetchFunction) {
    const cached = await this.cache.get(key);
    
    if (cached) {
      return cached;
    }
    
    // Cache miss - buscar e armazenar
    if (fetchFunction) {
      const data = await fetchFunction();
      await this.cache.set(key, data, strategy.ttl);
      return data;
    }
    
    return null;
  }

  /**
   * Estratégia Cache-Aside
   */
  async cacheAsideGet(key, strategy, fetchFunction) {
    const cached = await this.cache.get(key);
    
    if (cached) {
      return cached;
    }
    
    // Cache miss - aplicação é responsável por buscar
    return null;
  }

  /**
   * Estratégia Write-Behind
   */
  async writeBehindGet(key, strategy, fetchFunction) {
    const cached = await this.cache.get(key);
    
    if (cached) {
      return cached;
    }
    
    // Cache miss - buscar e armazenar de forma assíncrona
    if (fetchFunction) {
      // Buscar dados de forma assíncrona
      this.writeBehindFetch(key, fetchFunction, strategy);
      
      // Retornar null por enquanto
      return null;
    }
    
    return null;
  }

  /**
   * Refresh em background
   */
  async refreshInBackground(key, fetchFunction, strategy) {
    if (this.refreshQueue.has(key)) {
      return; // Já está sendo atualizado
    }
    
    this.refreshQueue.add(key);
    
    try {
      console.log(`[Cache] Background refresh for ${key}`);
      const data = await fetchFunction();
      await this.cache.set(key, data, strategy.ttl);
      
      // Notificar callbacks se existirem
      const callback = this.refreshCallbacks.get(key);
      if (callback) {
        callback(data);
      }
      
    } catch (error) {
      console.error(`[Cache] Background refresh failed for ${key}:`, error);
    } finally {
      this.refreshQueue.delete(key);
    }
  }

  /**
   * Write-behind fetch
   */
  async writeBehindFetch(key, fetchFunction, strategy) {
    setTimeout(async () => {
      try {
        const data = await fetchFunction();
        await this.cache.set(key, data, strategy.ttl);
        console.log(`[Cache] Write-behind completed for ${key}`);
      } catch (error) {
        console.error(`[Cache] Write-behind failed for ${key}:`, error);
      }
    }, 100); // Delay mínimo para não bloquear
  }

  /**
   * Invalidar cache por evento
   */
  async invalidateByEvent(event) {
    const keysToInvalidate = [];
    
    for (const [dataType, strategy] of Object.entries(this.strategies)) {
      if (strategy.invalidateOn.includes(event)) {
        keysToInvalidate.push(dataType.toLowerCase());
      }
    }
    
    for (const pattern of keysToInvalidate) {
      await this.cache.invalidate(pattern);
    }
    
    console.log(`[Cache] Invalidated cache for event: ${event}`);
  }

  /**
   * Configurar auto-refresh para dados críticos
   */
  setupAutoRefresh() {
    // Refresh de preços a cada 30 segundos durante horário de mercado
    setInterval(() => {
      if (this.isMarketHours()) {
        this.invalidateByEvent('auto_refresh_prices');
      }
    }, 30000);
    
    // Refresh de overview do mercado a cada 2 minutos
    setInterval(() => {
      if (this.isMarketHours()) {
        this.invalidateByEvent('auto_refresh_overview');
      }
    }, 120000);
  }

  /**
   * Verificar se está em horário de mercado
   */
  isMarketHours() {
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay();
    
    // Mercado brasileiro: Segunda a Sexta, 10h às 17h
    return day >= 1 && day <= 5 && hour >= 10 && hour < 17;
  }

  /**
   * Registrar callback para refresh
   */
  onRefresh(key, callback) {
    this.refreshCallbacks.set(key, callback);
  }

  /**
   * Remover callback de refresh
   */
  offRefresh(key) {
    this.refreshCallbacks.delete(key);
  }

  /**
   * Obter estatísticas das estratégias
   */
  getStrategyStats() {
    const stats = {};
    
    for (const [dataType, strategy] of Object.entries(this.strategies)) {
      const pattern = dataType.toLowerCase();
      const keys = Array.from(this.cache.cache.keys())
        .filter(key => key.includes(pattern));
      
      stats[dataType] = {
        strategy: strategy.strategy,
        ttl: strategy.ttl,
        cachedItems: keys.length,
        refreshAhead: strategy.refreshAhead || false
      };
    }
    
    return stats;
  }

  /**
   * Pré-carregar dados importantes
   */
  async preloadCriticalData(symbols = ['PETR4', 'VALE3', 'ITUB4', 'BBDC4']) {
    console.log('[Cache] Preloading critical data...');
    
    const preloadPromises = symbols.map(async (symbol) => {
      const key = `stock_price_${symbol}`;
      
      // Simular fetch (seria substituído pela função real)
      const mockData = {
        symbol,
        price: Math.random() * 100,
        timestamp: new Date()
      };
      
      await this.set(key, mockData, 'STOCK_PRICES');
    });
    
    await Promise.all(preloadPromises);
    console.log(`[Cache] Preloaded data for ${symbols.length} symbols`);
  }

  /**
   * Otimizar cache baseado em padrões de uso
   */
  optimizeCache() {
    const metrics = this.cache.getMetrics();
    
    // Se hit ratio está baixo, aumentar TTL de dados frequentes
    if (metrics.hitRatio < 50) {
      console.log('[Cache] Low hit ratio, optimizing TTL...');
      
      const topKeys = this.cache.getTopAccessedKeys(10);
      for (const keyInfo of topKeys) {
        if (keyInfo.accessCount > 5) {
          // Aumentar TTL para chaves muito acessadas
          const currentTTL = this.cache.getTimeToExpiry(keyInfo.key);
          if (currentTTL > 0) {
            const cached = this.cache.cache.get(keyInfo.key);
            if (cached) {
              this.cache.set(keyInfo.key, cached.value, currentTTL * 1.5);
            }
          }
        }
      }
    }
    
    // Se uso de memória está alto, fazer limpeza agressiva
    const memoryUsage = metrics.memoryUsage;
    if (parseInt(memoryUsage.mb) > 50) {
      console.log('[Cache] High memory usage, performing cleanup...');
      this.cache.evictLeastUsed(20);
    }
  }
}

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { IntelligentCacheManager, CacheStrategies };
} else {
  window.IntelligentCacheManager = IntelligentCacheManager;
  window.CacheStrategies = CacheStrategies;
}

