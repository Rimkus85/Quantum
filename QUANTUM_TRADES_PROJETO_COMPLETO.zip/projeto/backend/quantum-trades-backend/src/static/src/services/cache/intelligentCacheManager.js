/**
 * 🧠 QUANTUM FINANCE - INTELLIGENT CACHE MANAGER
 * Sistema de cache inteligente com múltiplas estratégias e auto-otimização
 */

class IntelligentCacheManager {
  constructor() {
    this.strategies = new Map();
    this.metrics = {
      hits: 0,
      misses: 0,
      errors: 0,
      totalRequests: 0,
      backgroundRefreshes: 0,
      evictions: 0
    };
    
    this.storage = new Map();
    this.metadata = new Map();
    this.refreshQueue = new Set();
    
    this.setupStrategies();
    this.startAutoCleanup();
    this.startMetricsReporting();
  }
  
  /**
   * Configurar estratégias de cache
   */
  setupStrategies() {
    // Estratégia para preços em tempo real
    this.strategies.set('stock-price', {
      ttl: 30000, // 30 segundos
      maxSize: 1000,
      refreshThreshold: 0.8, // Refresh quando 80% do TTL passou
      compression: false,
      priority: 'high',
      backgroundRefresh: true
    });
    
    // Estratégia para dados históricos
    this.strategies.set('stock-history', {
      ttl: 300000, // 5 minutos
      maxSize: 100,
      refreshThreshold: 0.9,
      compression: true,
      priority: 'medium',
      backgroundRefresh: false
    });
    
    // Estratégia para visão geral do mercado
    this.strategies.set('market-overview', {
      ttl: 60000, // 1 minuto
      maxSize: 10,
      refreshThreshold: 0.7,
      compression: false,
      priority: 'high',
      backgroundRefresh: true
    });
    
    // Estratégia para resultados de busca
    this.strategies.set('search-results', {
      ttl: 600000, // 10 minutos
      maxSize: 500,
      refreshThreshold: 0.9,
      compression: false,
      priority: 'low',
      backgroundRefresh: false
    });
    
    // Estratégia para dados fundamentais
    this.strategies.set('fundamental-data', {
      ttl: 3600000, // 1 hora
      maxSize: 200,
      refreshThreshold: 0.9,
      compression: true,
      priority: 'medium',
      backgroundRefresh: true
    });
  }
  
  /**
   * Obter dados do cache com fallback
   */
  async get(key, dataType, fetchFunction, options = {}) {
    this.metrics.totalRequests++;
    
    const strategy = this.strategies.get(dataType);
    if (!strategy) {
      console.warn(`[IntelligentCache] No strategy for data type: ${dataType}`);
      this.metrics.misses++;
      return await fetchFunction();
    }
    
    const cacheKey = this.generateCacheKey(key, dataType);
    
    try {
      // Verificar cache
      const cached = this.getCachedData(cacheKey, strategy);
      
      if (cached) {
        this.metrics.hits++;
        
        // Verificar se precisa de refresh em background
        if (this.shouldBackgroundRefresh(cacheKey, strategy)) {
          this.scheduleBackgroundRefresh(cacheKey, dataType, fetchFunction);
        }
        
        return cached.data;
      }
      
    } catch (error) {
      this.metrics.errors++;
      console.warn('[IntelligentCache] Error retrieving from cache:', error);
    }
    
    // Cache miss - buscar dados
    this.metrics.misses++;
    
    try {
      const data = await fetchFunction();
      
      // Armazenar no cache
      await this.set(cacheKey, data, strategy);
      
      return data;
      
    } catch (error) {
      console.error('[IntelligentCache] Error fetching data:', error);
      
      // Tentar retornar dados expirados se disponíveis
      const staleData = this.getStaleData(cacheKey);
      if (staleData && options.allowStale) {
        console.warn('[IntelligentCache] Returning stale data due to fetch error');
        return staleData.data;
      }
      
      throw error;
    }
  }
  
  /**
   * Armazenar dados no cache
   */
  async set(cacheKey, data, strategy) {
    try {
      // Verificar limite de tamanho
      if (this.storage.size >= strategy.maxSize) {
        this.evictLeastUsed(strategy);
      }
      
      // Comprimir dados se necessário
      const processedData = strategy.compression ? 
        this.compressData(data) : data;
      
      // Armazenar dados
      this.storage.set(cacheKey, {
        data: processedData,
        compressed: strategy.compression,
        timestamp: Date.now(),
        ttl: strategy.ttl,
        accessCount: 0,
        lastAccess: Date.now()
      });
      
      // Armazenar metadata
      this.metadata.set(cacheKey, {
        dataType: this.getDataTypeFromKey(cacheKey),
        priority: strategy.priority,
        size: this.calculateSize(processedData)
      });
      
    } catch (error) {
      console.error('[IntelligentCache] Error storing in cache:', error);
    }
  }
  
  /**
   * Obter dados do cache
   */
  getCachedData(cacheKey, strategy) {
    const cached = this.storage.get(cacheKey);
    
    if (!cached) return null;
    
    // Verificar se expirou
    const age = Date.now() - cached.timestamp;
    if (age > cached.ttl) {
      return null;
    }
    
    // Atualizar estatísticas de acesso
    cached.accessCount++;
    cached.lastAccess = Date.now();
    
    // Descomprimir se necessário
    const data = cached.compressed ? 
      this.decompressData(cached.data) : cached.data;
    
    return { data, age };
  }
  
  /**
   * Obter dados expirados (stale)
   */
  getStaleData(cacheKey) {
    const cached = this.storage.get(cacheKey);
    
    if (!cached) return null;
    
    // Retornar mesmo se expirado
    const data = cached.compressed ? 
      this.decompressData(cached.data) : cached.data;
    
    return { data, stale: true };
  }
  
  /**
   * Verificar se deve fazer refresh em background
   */
  shouldBackgroundRefresh(cacheKey, strategy) {
    if (!strategy.backgroundRefresh) return false;
    
    const cached = this.storage.get(cacheKey);
    if (!cached) return false;
    
    const age = Date.now() - cached.timestamp;
    const refreshTime = cached.ttl * strategy.refreshThreshold;
    
    return age >= refreshTime && !this.refreshQueue.has(cacheKey);
  }
  
  /**
   * Agendar refresh em background
   */
  scheduleBackgroundRefresh(cacheKey, dataType, fetchFunction) {
    if (this.refreshQueue.has(cacheKey)) return;
    
    this.refreshQueue.add(cacheKey);
    
    // Executar refresh em background
    setTimeout(async () => {
      try {
        console.log(`[IntelligentCache] Background refresh for: ${cacheKey}`);
        
        const data = await fetchFunction();
        const strategy = this.strategies.get(dataType);
        
        if (strategy) {
          await this.set(cacheKey, data, strategy);
          this.metrics.backgroundRefreshes++;
        }
        
      } catch (error) {
        console.warn('[IntelligentCache] Background refresh failed:', error);
      } finally {
        this.refreshQueue.delete(cacheKey);
      }
    }, 100); // Pequeno delay para não bloquear
  }
  
  /**
   * Remover entradas menos usadas
   */
  evictLeastUsed(strategy) {
    const entries = Array.from(this.storage.entries())
      .filter(([key]) => {
        const meta = this.metadata.get(key);
        return meta && meta.priority === strategy.priority;
      })
      .sort((a, b) => {
        // Ordenar por frequência de acesso e último acesso
        const scoreA = a[1].accessCount + (Date.now() - a[1].lastAccess) / 1000;
        const scoreB = b[1].accessCount + (Date.now() - b[1].lastAccess) / 1000;
        return scoreA - scoreB;
      });
    
    // Remover 10% das entradas menos usadas
    const toRemove = Math.max(1, Math.floor(entries.length * 0.1));
    
    for (let i = 0; i < toRemove && i < entries.length; i++) {
      const [key] = entries[i];
      this.storage.delete(key);
      this.metadata.delete(key);
      this.metrics.evictions++;
    }
  }
  
  /**
   * Comprimir dados
   */
  compressData(data) {
    try {
      // Simples compressão JSON (em produção usar LZ-string ou similar)
      return JSON.stringify(data);
    } catch (error) {
      console.warn('[IntelligentCache] Compression failed:', error);
      return data;
    }
  }
  
  /**
   * Descomprimir dados
   */
  decompressData(compressedData) {
    try {
      return JSON.parse(compressedData);
    } catch (error) {
      console.warn('[IntelligentCache] Decompression failed:', error);
      return compressedData;
    }
  }
  
  /**
   * Calcular tamanho dos dados
   */
  calculateSize(data) {
    try {
      return JSON.stringify(data).length;
    } catch (error) {
      return 0;
    }
  }
  
  /**
   * Gerar chave de cache
   */
  generateCacheKey(key, dataType) {
    return `${dataType}:${key}`;
  }
  
  /**
   * Extrair tipo de dados da chave
   */
  getDataTypeFromKey(cacheKey) {
    return cacheKey.split(':')[0];
  }
  
  /**
   * Limpeza automática
   */
  startAutoCleanup() {
    setInterval(() => {
      this.cleanupExpiredEntries();
    }, 60000); // Cleanup a cada minuto
  }
  
  /**
   * Limpar entradas expiradas
   */
  cleanupExpiredEntries() {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [key, cached] of this.storage.entries()) {
      const age = now - cached.timestamp;
      if (age > cached.ttl * 1.5) { // 50% além do TTL
        this.storage.delete(key);
        this.metadata.delete(key);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      console.log(`[IntelligentCache] Cleaned ${cleaned} expired entries`);
    }
  }
  
  /**
   * Relatório de métricas
   */
  startMetricsReporting() {
    setInterval(() => {
      this.reportMetrics();
    }, 300000); // Relatório a cada 5 minutos
  }
  
  /**
   * Reportar métricas
   */
  reportMetrics() {
    const hitRatio = this.getHitRatio();
    const stats = this.getDetailedStats();
    
    console.log('[IntelligentCache] Metrics Report:', {
      hitRatio: `${hitRatio.toFixed(1)}%`,
      totalRequests: this.metrics.totalRequests,
      cacheSize: this.storage.size,
      backgroundRefreshes: this.metrics.backgroundRefreshes,
      evictions: this.metrics.evictions,
      ...stats
    });
  }
  
  /**
   * Obter taxa de acerto
   */
  getHitRatio() {
    const total = this.metrics.hits + this.metrics.misses;
    return total > 0 ? (this.metrics.hits / total) * 100 : 0;
  }
  
  /**
   * Obter estatísticas detalhadas
   */
  getDetailedStats() {
    const typeStats = new Map();
    
    for (const [key, meta] of this.metadata.entries()) {
      if (!typeStats.has(meta.dataType)) {
        typeStats.set(meta.dataType, { count: 0, totalSize: 0 });
      }
      
      const stats = typeStats.get(meta.dataType);
      stats.count++;
      stats.totalSize += meta.size;
    }
    
    return Object.fromEntries(typeStats);
  }
  
  /**
   * Limpar cache
   */
  clear(dataType = null) {
    if (dataType) {
      // Limpar apenas um tipo específico
      for (const [key] of this.storage.entries()) {
        if (this.getDataTypeFromKey(key) === dataType) {
          this.storage.delete(key);
          this.metadata.delete(key);
        }
      }
    } else {
      // Limpar tudo
      this.storage.clear();
      this.metadata.clear();
    }
    
    console.log(`[IntelligentCache] Cache cleared${dataType ? ` for ${dataType}` : ''}`);
  }
  
  /**
   * Invalidar entrada específica
   */
  invalidate(key, dataType) {
    const cacheKey = this.generateCacheKey(key, dataType);
    this.storage.delete(cacheKey);
    this.metadata.delete(cacheKey);
  }
  
  /**
   * Pré-carregar dados
   */
  async preload(key, dataType, fetchFunction) {
    const cacheKey = this.generateCacheKey(key, dataType);
    
    if (!this.storage.has(cacheKey)) {
      try {
        const data = await fetchFunction();
        const strategy = this.strategies.get(dataType);
        
        if (strategy) {
          await this.set(cacheKey, data, strategy);
          console.log(`[IntelligentCache] Preloaded: ${cacheKey}`);
        }
      } catch (error) {
        console.warn(`[IntelligentCache] Preload failed for ${cacheKey}:`, error);
      }
    }
  }
}

// Exportar para uso global
if (typeof module !== 'undefined' && module.exports) {
  module.exports = IntelligentCacheManager;
} else {
  window.IntelligentCacheManager = IntelligentCacheManager;
}

