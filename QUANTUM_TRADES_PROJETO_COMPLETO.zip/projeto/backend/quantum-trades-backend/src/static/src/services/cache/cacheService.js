/**
 * 🗄️ QUANTUM FINANCE - CACHE SERVICE
 * Sistema de cache inteligente com TTL dinâmico e métricas
 */

class CacheService {
  constructor() {
    this.cache = new Map();
    this.ttl = new Map();
    this.accessTimes = new Map();
    this.metrics = {
      hits: 0,
      misses: 0,
      sets: 0,
      evictions: 0,
      totalRequests: 0
    };
    
    // Limpeza automática a cada 5 minutos
    this.cleanupInterval = setInterval(() => this.cleanup(), 300000);
    
    // Configurações padrão
    this.config = {
      maxSize: 1000,
      defaultTTL: 3600, // 1 hora
      cleanupThreshold: 0.8 // Limpar quando atingir 80% da capacidade
    };
  }

  /**
   * Armazenar item no cache
   */
  async set(key, value, ttlSeconds = null) {
    const ttl = ttlSeconds || this.config.defaultTTL;
    const expiresAt = Date.now() + (ttl * 1000);
    
    // Verificar se precisa fazer limpeza
    if (this.cache.size >= this.config.maxSize * this.config.cleanupThreshold) {
      this.evictLeastUsed();
    }
    
    this.cache.set(key, {
      value,
      createdAt: Date.now(),
      accessCount: 0,
      lastAccessed: Date.now(),
      size: this.estimateSize(value)
    });
    
    this.ttl.set(key, expiresAt);
    this.metrics.sets++;
    
    console.log(`[Cache SET] ${key} (TTL: ${ttl}s)`);
    return true;
  }

  /**
   * Recuperar item do cache
   */
  async get(key) {
    this.metrics.totalRequests++;
    
    const ttlExpiry = this.ttl.get(key);
    
    // Verificar se expirou
    if (!ttlExpiry || Date.now() > ttlExpiry) {
      this.delete(key);
      this.metrics.misses++;
      return null;
    }

    const cached = this.cache.get(key);
    if (cached) {
      // Atualizar estatísticas de acesso
      cached.accessCount++;
      cached.lastAccessed = Date.now();
      this.accessTimes.set(key, Date.now());
      
      this.metrics.hits++;
      console.log(`[Cache HIT] ${key} (age: ${this.getAge(cached)}s)`);
      return cached.value;
    }

    this.metrics.misses++;
    return null;
  }

  /**
   * Verificar se item existe no cache
   */
  has(key) {
    const ttlExpiry = this.ttl.get(key);
    
    if (!ttlExpiry || Date.now() > ttlExpiry) {
      this.delete(key);
      return false;
    }

    return this.cache.has(key);
  }

  /**
   * Remover item do cache
   */
  delete(key) {
    const existed = this.cache.has(key);
    this.cache.delete(key);
    this.ttl.delete(key);
    this.accessTimes.delete(key);
    
    if (existed) {
      console.log(`[Cache DELETE] ${key}`);
    }
    
    return existed;
  }

  /**
   * Invalidar cache por padrão
   */
  async invalidate(pattern) {
    let evicted = 0;
    
    for (const key of this.cache.keys()) {
      if (this.matchesPattern(key, pattern)) {
        this.delete(key);
        evicted++;
      }
    }
    
    this.metrics.evictions += evicted;
    console.log(`[Cache INVALIDATE] Pattern: ${pattern}, Evicted: ${evicted}`);
    return evicted;
  }

  /**
   * Limpar cache expirado
   */
  cleanup() {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [key, expiry] of this.ttl.entries()) {
      if (now > expiry) {
        this.delete(key);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      console.log(`[Cache CLEANUP] Removed ${cleaned} expired entries`);
    }
    
    return cleaned;
  }

  /**
   * Remover itens menos usados (LRU)
   */
  evictLeastUsed(count = 10) {
    const entries = Array.from(this.cache.entries())
      .map(([key, data]) => ({
        key,
        score: this.calculateEvictionScore(data)
      }))
      .sort((a, b) => a.score - b.score)
      .slice(0, count);
    
    let evicted = 0;
    for (const entry of entries) {
      this.delete(entry.key);
      evicted++;
    }
    
    this.metrics.evictions += evicted;
    console.log(`[Cache EVICT] Removed ${evicted} least used entries`);
    return evicted;
  }

  /**
   * Calcular score para eviction (menor = mais provável de ser removido)
   */
  calculateEvictionScore(data) {
    const age = this.getAge(data);
    const timeSinceAccess = (Date.now() - data.lastAccessed) / 1000;
    const accessFrequency = data.accessCount / Math.max(age, 1);
    
    // Score menor = mais provável de ser removido
    return accessFrequency / (timeSinceAccess + 1);
  }

  /**
   * Obter idade do item em segundos
   */
  getAge(data) {
    return (Date.now() - data.createdAt) / 1000;
  }

  /**
   * Verificar se chave corresponde ao padrão
   */
  matchesPattern(key, pattern) {
    if (typeof pattern === 'string') {
      return key.includes(pattern);
    }
    
    if (pattern instanceof RegExp) {
      return pattern.test(key);
    }
    
    return false;
  }

  /**
   * Estimar tamanho do objeto em bytes
   */
  estimateSize(obj) {
    const jsonString = JSON.stringify(obj);
    return new Blob([jsonString]).size;
  }

  /**
   * Obter métricas do cache
   */
  getMetrics() {
    const total = this.metrics.hits + this.metrics.misses;
    const hitRatio = total > 0 ? (this.metrics.hits / total) * 100 : 0;
    
    return {
      ...this.metrics,
      hitRatio: parseFloat(hitRatio.toFixed(2)),
      cacheSize: this.cache.size,
      memoryUsage: this.estimateMemoryUsage(),
      averageAge: this.calculateAverageAge()
    };
  }

  /**
   * Estimar uso de memória
   */
  estimateMemoryUsage() {
    let totalSize = 0;
    
    for (const [key, data] of this.cache.entries()) {
      totalSize += data.size || 0;
      totalSize += key.length * 2; // Aproximação para string UTF-16
    }
    
    return {
      bytes: totalSize,
      kb: (totalSize / 1024).toFixed(2),
      mb: (totalSize / (1024 * 1024)).toFixed(2)
    };
  }

  /**
   * Calcular idade média dos itens
   */
  calculateAverageAge() {
    if (this.cache.size === 0) return 0;
    
    let totalAge = 0;
    for (const data of this.cache.values()) {
      totalAge += this.getAge(data);
    }
    
    return (totalAge / this.cache.size).toFixed(2);
  }

  /**
   * Obter tempo restante até expiração
   */
  getTimeToExpiry(key) {
    const expiry = this.ttl.get(key);
    if (!expiry) return 0;
    
    return Math.max(0, expiry - Date.now()) / 1000;
  }

  /**
   * Limpar todo o cache
   */
  clear() {
    const size = this.cache.size;
    this.cache.clear();
    this.ttl.clear();
    this.accessTimes.clear();
    
    console.log(`[Cache CLEAR] Removed ${size} entries`);
    return size;
  }

  /**
   * Destruir o cache e limpar intervalos
   */
  destroy() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
    
    this.clear();
    console.log('[Cache] Service destroyed');
  }

  /**
   * Obter estatísticas detalhadas
   */
  getDetailedStats() {
    const metrics = this.getMetrics();
    const topKeys = this.getTopAccessedKeys(5);
    const expiringSoon = this.getExpiringSoon(5);
    
    return {
      metrics,
      topKeys,
      expiringSoon,
      config: this.config
    };
  }

  /**
   * Obter chaves mais acessadas
   */
  getTopAccessedKeys(limit = 5) {
    return Array.from(this.cache.entries())
      .map(([key, data]) => ({
        key,
        accessCount: data.accessCount,
        lastAccessed: new Date(data.lastAccessed)
      }))
      .sort((a, b) => b.accessCount - a.accessCount)
      .slice(0, limit);
  }

  /**
   * Obter itens que expiram em breve
   */
  getExpiringSoon(limit = 5) {
    const now = Date.now();
    
    return Array.from(this.ttl.entries())
      .map(([key, expiry]) => ({
        key,
        expiresIn: Math.max(0, expiry - now) / 1000,
        expiresAt: new Date(expiry)
      }))
      .sort((a, b) => a.expiresIn - b.expiresIn)
      .slice(0, limit);
  }
}

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CacheService;
} else {
  window.CacheService = CacheService;
}

