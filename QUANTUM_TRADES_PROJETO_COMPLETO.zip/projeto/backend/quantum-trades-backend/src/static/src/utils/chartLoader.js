/**
 * 📊 QUANTUM FINANCE - CHART LOADER
 * Carregador robusto para Chart.js com fallback e retry
 */

class ChartLoader {
  static instance = null;
  static chartPromise = null;
  static loadAttempts = 0;
  static maxAttempts = 3;
  
  /**
   * Garantir que Chart.js está carregado
   */
  static async ensureChartJS() {
    if (this.instance) {
      return this.instance;
    }
    
    // Verificar se já está disponível globalmente
    if (typeof Chart !== 'undefined') {
      this.instance = Chart;
      console.log('[ChartLoader] Chart.js already available');
      return Chart;
    }
    
    // Se já está tentando carregar, aguardar
    if (this.chartPromise) {
      return this.chartPromise;
    }
    
    // Iniciar carregamento
    this.chartPromise = this.loadChartJS();
    return this.chartPromise;
  }
  
  /**
   * Carregar Chart.js dinamicamente
   */
  static async loadChartJS() {
    console.log('[ChartLoader] Loading Chart.js...');
    
    while (this.loadAttempts < this.maxAttempts) {
      try {
        this.loadAttempts++;
        
        const chart = await this.loadScript();
        this.instance = chart;
        
        console.log(`[ChartLoader] Chart.js loaded successfully (attempt ${this.loadAttempts})`);
        return chart;
        
      } catch (error) {
        console.warn(`[ChartLoader] Attempt ${this.loadAttempts} failed:`, error.message);
        
        if (this.loadAttempts >= this.maxAttempts) {
          console.error('[ChartLoader] Max attempts reached, Chart.js failed to load');
          throw new Error('Failed to load Chart.js after multiple attempts');
        }
        
        // Aguardar antes de tentar novamente
        await this.delay(1000 * this.loadAttempts);
      }
    }
  }
  
  /**
   * Carregar script Chart.js
   */
  static loadScript() {
    return new Promise((resolve, reject) => {
      // Verificar se script já existe
      const existingScript = document.querySelector('script[src*="chart.js"]');
      if (existingScript) {
        existingScript.remove();
      }
      
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.js';
      script.async = true;
      script.crossOrigin = 'anonymous';
      
      script.onload = () => {
        if (typeof Chart !== 'undefined') {
          resolve(window.Chart);
        } else {
          reject(new Error('Chart.js loaded but Chart object not available'));
        }
      };
      
      script.onerror = () => {
        reject(new Error('Failed to load Chart.js script'));
      };
      
      // Timeout de 10 segundos
      const timeout = setTimeout(() => {
        reject(new Error('Chart.js loading timeout'));
      }, 10000);
      
      script.onload = () => {
        clearTimeout(timeout);
        if (typeof Chart !== 'undefined') {
          resolve(window.Chart);
        } else {
          reject(new Error('Chart.js loaded but Chart object not available'));
        }
      };
      
      document.head.appendChild(script);
    });
  }
  
  /**
   * Delay helper
   */
  static delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  /**
   * Verificar se Chart.js está disponível
   */
  static isAvailable() {
    return this.instance !== null || typeof Chart !== 'undefined';
  }
  
  /**
   * Reset do loader (para testes)
   */
  static reset() {
    this.instance = null;
    this.chartPromise = null;
    this.loadAttempts = 0;
  }
  
  /**
   * Configurar defaults do Chart.js
   */
  static setupDefaults() {
    if (!this.instance) {
      console.warn('[ChartLoader] Cannot setup defaults - Chart.js not loaded');
      return;
    }
    
    // Configurações padrão para o Quantum Finance
    this.instance.defaults.color = '#ffffff';
    this.instance.defaults.font.family = 'Inter, sans-serif';
    this.instance.defaults.font.size = 12;
    
    // Configurações de responsividade
    this.instance.defaults.responsive = true;
    this.instance.defaults.maintainAspectRatio = false;
    
    // Configurações de animação
    this.instance.defaults.animation.duration = 750;
    this.instance.defaults.animation.easing = 'easeInOutQuart';
    
    // Configurações de interação
    this.instance.defaults.interaction.intersect = false;
    this.instance.defaults.interaction.mode = 'index';
    
    // Configurações de escala
    this.instance.defaults.scales = {
      x: {
        grid: {
          color: 'rgba(255, 255, 255, 0.1)',
          borderColor: 'rgba(255, 255, 255, 0.2)'
        },
        ticks: {
          color: '#ffffff'
        }
      },
      y: {
        grid: {
          color: 'rgba(255, 255, 255, 0.1)',
          borderColor: 'rgba(255, 255, 255, 0.2)'
        },
        ticks: {
          color: '#ffffff'
        }
      }
    };
    
    // Configurações de plugins
    this.instance.defaults.plugins.legend.labels.color = '#ffffff';
    this.instance.defaults.plugins.tooltip.backgroundColor = 'rgba(26, 26, 46, 0.95)';
    this.instance.defaults.plugins.tooltip.titleColor = '#FFD700';
    this.instance.defaults.plugins.tooltip.bodyColor = '#ffffff';
    this.instance.defaults.plugins.tooltip.borderColor = '#FFD700';
    this.instance.defaults.plugins.tooltip.borderWidth = 1;
    
    console.log('[ChartLoader] Chart.js defaults configured');
  }
}

// Exportar para uso global
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ChartLoader;
} else {
  window.ChartLoader = ChartLoader;
}

