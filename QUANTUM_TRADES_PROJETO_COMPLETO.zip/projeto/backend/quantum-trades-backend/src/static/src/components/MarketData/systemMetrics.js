/**
 * 📊 QUANTUM FINANCE - SYSTEM METRICS COMPONENT
 * Componente para exibir métricas do sistema e performance
 */

class SystemMetricsComponent {
  constructor(financialService) {
    this.financialService = financialService;
    this.container = document.getElementById('system-metrics');
    this.metrics = null;
    this.updateInterval = null;
    
    this.init();
  }

  /**
   * Inicializar componente
   */
  init() {
    if (!this.container) {
      console.warn('[SystemMetrics] Container not found');
      return;
    }
    
    // Configurar auto-update
    this.setupAutoUpdate();
    
    console.log('[SystemMetrics] Component initialized');
  }

  /**
   * Carregar dados das métricas
   */
  async loadData() {
    if (!this.container) return;
    
    try {
      // Buscar métricas do serviço
      const serviceMetrics = this.financialService.getMetrics();
      const healthStatus = await this.financialService.getHealthStatus();
      
      this.metrics = {
        service: serviceMetrics,
        health: healthStatus,
        timestamp: new Date()
      };
      
      // Renderizar métricas
      this.render();
      
      console.log('[SystemMetrics] Metrics loaded successfully');
      
    } catch (error) {
      console.error('[SystemMetrics] Failed to load metrics:', error);
      this.showError('Erro ao carregar métricas do sistema');
    }
  }

  /**
   * Renderizar componente
   */
  render() {
    if (!this.metrics || !this.container) return;
    
    const { service, health } = this.metrics;
    
    this.container.innerHTML = `
      ${this.renderPerformanceMetrics(service)}
      ${this.renderCacheMetrics(service.cache)}
      ${this.renderAPIMetrics(service.fallback)}
      ${this.renderHealthMetrics(health)}
    `;
  }

  /**
   * Renderizar métricas de performance
   */
  renderPerformanceMetrics(serviceMetrics) {
    const errorRate = serviceMetrics.service.requests > 0 ? 
      (serviceMetrics.service.errors / serviceMetrics.service.requests) * 100 : 0;
    
    const successRate = 100 - errorRate;
    
    return `
      <div class="quantum-metric-card">
        <div class="quantum-metric-header">
          <i class="fas fa-tachometer-alt"></i>
          <h3 class="quantum-h3">Performance</h3>
        </div>
        <div class="quantum-metric-content">
          <div class="quantum-metric-item">
            <span class="quantum-metric-value ${successRate >= 95 ? 'quantum-text-positive' : successRate >= 80 ? 'quantum-text-warning' : 'quantum-text-negative'}">
              ${successRate.toFixed(1)}%
            </span>
            <span class="quantum-metric-label">Taxa de Sucesso</span>
          </div>
          <div class="quantum-metric-details">
            <div class="quantum-detail-row">
              <span>Total de Requisições</span>
              <span>${serviceMetrics.service.requests.toLocaleString()}</span>
            </div>
            <div class="quantum-detail-row">
              <span>Erros</span>
              <span class="${serviceMetrics.service.errors > 0 ? 'quantum-text-negative' : ''}">${serviceMetrics.service.errors}</span>
            </div>
            <div class="quantum-detail-row">
              <span>Chamadas de API</span>
              <span>${serviceMetrics.service.apiCalls.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Renderizar métricas de cache
   */
  renderCacheMetrics(cacheMetrics) {
    const hitRatio = cacheMetrics.hitRatio || 0;
    const cacheSize = cacheMetrics.cacheSize || 0;
    const memoryUsage = cacheMetrics.memoryUsage || { mb: '0' };
    
    return `
      <div class="quantum-metric-card">
        <div class="quantum-metric-header">
          <i class="fas fa-database"></i>
          <h3 class="quantum-h3">Cache</h3>
        </div>
        <div class="quantum-metric-content">
          <div class="quantum-metric-item">
            <span class="quantum-metric-value ${hitRatio >= 70 ? 'quantum-text-positive' : hitRatio >= 50 ? 'quantum-text-warning' : 'quantum-text-negative'}">
              ${hitRatio.toFixed(1)}%
            </span>
            <span class="quantum-metric-label">Hit Ratio</span>
          </div>
          <div class="quantum-metric-details">
            <div class="quantum-detail-row">
              <span>Itens em Cache</span>
              <span>${cacheSize.toLocaleString()}</span>
            </div>
            <div class="quantum-detail-row">
              <span>Hits</span>
              <span class="quantum-text-positive">${cacheMetrics.hits?.toLocaleString() || 0}</span>
            </div>
            <div class="quantum-detail-row">
              <span>Misses</span>
              <span class="quantum-text-negative">${cacheMetrics.misses?.toLocaleString() || 0}</span>
            </div>
            <div class="quantum-detail-row">
              <span>Uso de Memória</span>
              <span>${memoryUsage.mb} MB</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Renderizar métricas de API
   */
  renderAPIMetrics(fallbackMetrics) {
    if (!fallbackMetrics) {
      return `
        <div class="quantum-metric-card">
          <div class="quantum-metric-header">
            <i class="fas fa-plug"></i>
            <h3 class="quantum-h3">APIs</h3>
          </div>
          <div class="quantum-metric-content">
            <div class="quantum-metric-item">
              <span class="quantum-metric-value">N/A</span>
              <span class="quantum-metric-label">Fallback não configurado</span>
            </div>
          </div>
        </div>
      `;
    }

    const fallbackRate = fallbackMetrics.totalCalls > 0 ? 
      (fallbackMetrics.fallbacks / fallbackMetrics.totalCalls) * 100 : 0;
    
    return `
      <div class="quantum-metric-card">
        <div class="quantum-metric-header">
          <i class="fas fa-plug"></i>
          <h3 class="quantum-h3">APIs</h3>
        </div>
        <div class="quantum-metric-content">
          <div class="quantum-metric-item">
            <span class="quantum-metric-value ${fallbackRate < 10 ? 'quantum-text-positive' : fallbackRate < 30 ? 'quantum-text-warning' : 'quantum-text-negative'}">
              ${fallbackRate.toFixed(1)}%
            </span>
            <span class="quantum-metric-label">Taxa de Fallback</span>
          </div>
          <div class="quantum-metric-details">
            <div class="quantum-detail-row">
              <span>Total de Chamadas</span>
              <span>${fallbackMetrics.totalCalls.toLocaleString()}</span>
            </div>
            <div class="quantum-detail-row">
              <span>Fallbacks</span>
              <span class="${fallbackMetrics.fallbacks > 0 ? 'quantum-text-warning' : ''}">${fallbackMetrics.fallbacks}</span>
            </div>
            <div class="quantum-detail-row">
              <span>Falhas</span>
              <span class="${fallbackMetrics.failures > 0 ? 'quantum-text-negative' : ''}">${fallbackMetrics.failures}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Renderizar métricas de saúde
   */
  renderHealthMetrics(healthMetrics) {
    const isHealthy = healthMetrics.healthy;
    const errorRate = healthMetrics.metrics?.errorRate || 0;
    const totalRequests = healthMetrics.metrics?.totalRequests || 0;
    
    return `
      <div class="quantum-metric-card">
        <div class="quantum-metric-header">
          <i class="fas fa-heartbeat"></i>
          <h3 class="quantum-h3">Saúde do Sistema</h3>
        </div>
        <div class="quantum-metric-content">
          <div class="quantum-metric-item">
            <span class="quantum-metric-value ${isHealthy ? 'quantum-text-positive' : 'quantum-text-negative'}">
              ${isHealthy ? 'Saudável' : 'Problemas'}
            </span>
            <span class="quantum-metric-label">Status Geral</span>
          </div>
          <div class="quantum-metric-details">
            <div class="quantum-detail-row">
              <span>Taxa de Erro</span>
              <span class="${errorRate > 10 ? 'quantum-text-negative' : errorRate > 5 ? 'quantum-text-warning' : 'quantum-text-positive'}">
                ${errorRate.toFixed(2)}%
              </span>
            </div>
            <div class="quantum-detail-row">
              <span>Requisições Totais</span>
              <span>${totalRequests.toLocaleString()}</span>
            </div>
            <div class="quantum-detail-row">
              <span>Última Verificação</span>
              <span>${this.formatTime(healthMetrics.timestamp)}</span>
            </div>
            ${this.renderAPIHealthStatus(healthMetrics.apis)}
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Renderizar status de saúde das APIs
   */
  renderAPIHealthStatus(apis) {
    if (!apis) return '';
    
    const apiEntries = Object.entries(apis);
    if (apiEntries.length === 0) return '';
    
    return `
      <div class="quantum-api-health">
        <div class="quantum-api-health-title">Status das APIs:</div>
        ${apiEntries.map(([name, status]) => `
          <div class="quantum-detail-row">
            <span>${this.formatAPIName(name)}</span>
            <span class="quantum-api-status ${status.status}">
              <i class="fas fa-${this.getStatusIcon(status.status)}"></i>
              ${this.translateStatus(status.status)}
            </span>
          </div>
        `).join('')}
      </div>
    `;
  }

  /**
   * Mostrar erro
   */
  showError(message) {
    if (!this.container) return;
    
    this.container.innerHTML = `
      <div class="quantum-metric-card">
        <div class="quantum-error">
          <div class="quantum-error__icon">
            <i class="fas fa-exclamation-triangle"></i>
          </div>
          <div class="quantum-error__message">${message}</div>
          <button class="quantum-error__retry" onclick="systemMetricsComponent.loadData()">
            Tentar Novamente
          </button>
        </div>
      </div>
    `;
  }

  /**
   * Configurar auto-update
   */
  setupAutoUpdate() {
    // Atualizar métricas a cada 30 segundos
    this.updateInterval = setInterval(() => {
      this.loadData();
    }, 30000);
  }

  /**
   * Parar auto-update
   */
  stopAutoUpdate() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }

  /**
   * Obter estatísticas detalhadas
   */
  getDetailedStats() {
    if (!this.metrics) return null;
    
    return {
      performance: {
        successRate: this.calculateSuccessRate(),
        errorRate: this.calculateErrorRate(),
        totalRequests: this.metrics.service.service.requests
      },
      cache: {
        hitRatio: this.metrics.service.cache.hitRatio,
        size: this.metrics.service.cache.cacheSize,
        memoryUsage: this.metrics.service.cache.memoryUsage
      },
      health: {
        isHealthy: this.metrics.health.healthy,
        lastCheck: this.metrics.health.timestamp
      }
    };
  }

  /**
   * Calcular taxa de sucesso
   */
  calculateSuccessRate() {
    if (!this.metrics) return 0;
    
    const { requests, errors } = this.metrics.service.service;
    return requests > 0 ? ((requests - errors) / requests) * 100 : 100;
  }

  /**
   * Calcular taxa de erro
   */
  calculateErrorRate() {
    if (!this.metrics) return 0;
    
    const { requests, errors } = this.metrics.service.service;
    return requests > 0 ? (errors / requests) * 100 : 0;
  }

  /**
   * Utilitários de formatação
   */
  formatAPIName(name) {
    const names = {
      'primary': 'Yahoo Finance',
      'secondary': 'BRAPI',
      'tertiary': 'HG Brasil'
    };
    
    return names[name] || name;
  }

  getStatusIcon(status) {
    const icons = {
      'healthy': 'check-circle',
      'unhealthy': 'times-circle',
      'disabled': 'minus-circle'
    };
    
    return icons[status] || 'question-circle';
  }

  translateStatus(status) {
    const translations = {
      'healthy': 'Saudável',
      'unhealthy': 'Com problemas',
      'disabled': 'Desabilitada'
    };
    
    return translations[status] || status;
  }

  formatTime(date) {
    if (!(date instanceof Date)) return 'N/A';
    
    return date.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  }

  /**
   * Destruir componente
   */
  destroy() {
    this.stopAutoUpdate();
    console.log('[SystemMetrics] Component destroyed');
  }
}

// Estilos específicos do componente
const systemMetricsStyles = `
  .quantum-metric-card {
    background: var(--quantum-bg-secondary);
    border-radius: 8px;
    padding: var(--space-lg);
    border: 1px solid var(--quantum-border);
  }

  .quantum-metric-header {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    margin-bottom: var(--space-md);
    color: var(--quantum-gold);
  }

  .quantum-metric-header i {
    font-size: 1.25rem;
  }

  .quantum-metric-header h3 {
    margin: 0;
    color: var(--quantum-text-primary);
  }

  .quantum-metric-content {
    display: flex;
    flex-direction: column;
    gap: var(--space-md);
  }

  .quantum-metric-item {
    text-align: center;
  }

  .quantum-metric-value {
    display: block;
    font-size: 2rem;
    font-weight: 700;
    line-height: 1;
    margin-bottom: var(--space-xs);
  }

  .quantum-metric-label {
    font-size: 0.875rem;
    color: var(--quantum-text-secondary);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .quantum-metric-details {
    display: flex;
    flex-direction: column;
    gap: var(--space-sm);
  }

  .quantum-detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--space-xs) 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  }

  .quantum-detail-row:last-child {
    border-bottom: none;
  }

  .quantum-detail-row span:first-child {
    color: var(--quantum-text-secondary);
    font-size: 0.875rem;
  }

  .quantum-detail-row span:last-child {
    color: var(--quantum-text-primary);
    font-weight: 500;
    font-size: 0.875rem;
  }

  .quantum-api-health {
    margin-top: var(--space-sm);
    padding-top: var(--space-sm);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
  }

  .quantum-api-health-title {
    font-size: 0.75rem;
    color: var(--quantum-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: var(--space-sm);
  }

  .quantum-api-status {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.75rem;
    text-transform: uppercase;
    font-weight: 500;
  }

  .quantum-api-status.healthy {
    color: var(--quantum-success);
  }

  .quantum-api-status.unhealthy {
    color: var(--quantum-danger);
  }

  .quantum-api-status.disabled {
    color: var(--quantum-text-muted);
  }

  .quantum-text-warning {
    color: var(--quantum-warning);
  }

  /* Responsividade */
  @media (max-width: 767px) {
    .quantum-metric-card {
      padding: var(--space-md);
    }

    .quantum-metric-value {
      font-size: 1.5rem;
    }

    .quantum-detail-row {
      flex-direction: column;
      align-items: flex-start;
      gap: 4px;
    }

    .quantum-api-status {
      align-self: flex-end;
    }
  }
`;

// Adicionar estilos ao documento
if (typeof document !== 'undefined') {
  const styleSheet = document.createElement('style');
  styleSheet.textContent = systemMetricsStyles;
  document.head.appendChild(styleSheet);
}

// Instância global para acesso nos event handlers inline
let systemMetricsComponent = null;

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SystemMetricsComponent;
} else {
  window.SystemMetricsComponent = SystemMetricsComponent;
}

