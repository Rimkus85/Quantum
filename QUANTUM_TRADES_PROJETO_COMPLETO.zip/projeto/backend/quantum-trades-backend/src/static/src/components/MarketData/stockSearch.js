/**
 * 🔍 QUANTUM FINANCE - STOCK SEARCH COMPONENT
 * Componente para busca e seleção de ações
 */

class StockSearchComponent {
  constructor(financialService) {
    this.financialService = financialService;
    this.searchInput = document.getElementById('stock-search');
    this.suggestionsContainer = document.getElementById('search-suggestions');
    this.onStockSelected = null; // Callback para seleção de ação
    
    this.searchTimeout = null;
    this.currentQuery = '';
    this.suggestions = [];
    this.selectedIndex = -1;
    
    this.init();
  }

  /**
   * Inicializar componente
   */
  init() {
    if (!this.searchInput || !this.suggestionsContainer) {
      console.warn('[StockSearch] Required elements not found');
      return;
    }
    
    this.setupEventListeners();
    console.log('[StockSearch] Component initialized');
  }

  /**
   * Configurar event listeners
   */
  setupEventListeners() {
    // Input de busca
    this.searchInput.addEventListener('input', (e) => {
      this.handleSearchInput(e.target.value);
    });

    // Navegação por teclado
    this.searchInput.addEventListener('keydown', (e) => {
      this.handleKeyNavigation(e);
    });

    // Perder foco - esconder sugestões
    this.searchInput.addEventListener('blur', () => {
      // Delay para permitir clique nas sugestões
      setTimeout(() => {
        this.hideSuggestions();
      }, 200);
    });

    // Focar - mostrar sugestões se houver
    this.searchInput.addEventListener('focus', () => {
      if (this.suggestions.length > 0) {
        this.showSuggestions();
      }
    });

    // Clique fora - esconder sugestões
    document.addEventListener('click', (e) => {
      if (!this.searchInput.contains(e.target) && !this.suggestionsContainer.contains(e.target)) {
        this.hideSuggestions();
      }
    });
  }

  /**
   * Manipular entrada de busca
   */
  handleSearchInput(value) {
    const query = value.trim();
    
    // Limpar timeout anterior
    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
    }

    // Se query está vazia, esconder sugestões
    if (!query) {
      this.hideSuggestions();
      this.currentQuery = '';
      return;
    }

    // Se query é muito curta, não buscar
    if (query.length < 2) {
      this.currentQuery = query;
      return;
    }

    // Debounce da busca
    this.searchTimeout = setTimeout(() => {
      this.performSearch(query);
    }, 300);
  }

  /**
   * Realizar busca
   */
  async performSearch(query) {
    if (query === this.currentQuery) return;
    
    this.currentQuery = query;
    
    try {
      // Mostrar loading nas sugestões
      this.showLoadingSuggestions();
      
      // Buscar ações
      const results = await this.financialService.searchStocksWithFallback(query, 8);
      
      this.suggestions = results;
      this.selectedIndex = -1;
      
      // Renderizar sugestões
      this.renderSuggestions();
      
      console.log(`[StockSearch] Found ${results.length} results for "${query}"`);
      
    } catch (error) {
      console.error('[StockSearch] Search failed:', error);
      this.showErrorSuggestions('Erro na busca');
    }
  }

  /**
   * Manipular navegação por teclado
   */
  handleKeyNavigation(e) {
    if (!this.suggestionsContainer.classList.contains('visible')) {
      return;
    }

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        this.selectedIndex = Math.min(this.selectedIndex + 1, this.suggestions.length - 1);
        this.updateSelection();
        break;
        
      case 'ArrowUp':
        e.preventDefault();
        this.selectedIndex = Math.max(this.selectedIndex - 1, -1);
        this.updateSelection();
        break;
        
      case 'Enter':
        e.preventDefault();
        if (this.selectedIndex >= 0 && this.suggestions[this.selectedIndex]) {
          this.selectStock(this.suggestions[this.selectedIndex]);
        } else {
          // Se não há seleção, tentar buscar diretamente
          const query = this.searchInput.value.trim().toUpperCase();
          if (query.match(/^[A-Z]{4}[0-9]{1,2}$/)) {
            this.selectStockBySymbol(query);
          }
        }
        break;
        
      case 'Escape':
        e.preventDefault();
        this.hideSuggestions();
        this.searchInput.blur();
        break;
    }
  }

  /**
   * Atualizar seleção visual
   */
  updateSelection() {
    const items = this.suggestionsContainer.querySelectorAll('.quantum-suggestion-item');
    
    items.forEach((item, index) => {
      if (index === this.selectedIndex) {
        item.classList.add('selected');
        item.scrollIntoView({ block: 'nearest' });
      } else {
        item.classList.remove('selected');
      }
    });
  }

  /**
   * Renderizar sugestões
   */
  renderSuggestions() {
    if (this.suggestions.length === 0) {
      this.showNoResultsSuggestions();
      return;
    }

    const html = this.suggestions.map((stock, index) => `
      <div class="quantum-suggestion-item" data-index="${index}" onclick="stockSearchComponent.selectStock(stockSearchComponent.suggestions[${index}])">
        <div class="quantum-suggestion-main">
          <span class="quantum-suggestion-symbol">${stock.symbol}</span>
          <span class="quantum-suggestion-name">${this.truncateName(stock.name)}</span>
        </div>
        <div class="quantum-suggestion-details">
          <span class="quantum-suggestion-exchange">${stock.exchange}</span>
          <span class="quantum-suggestion-type">${this.translateType(stock.type)}</span>
        </div>
      </div>
    `).join('');

    this.suggestionsContainer.innerHTML = html;
    this.showSuggestions();
  }

  /**
   * Mostrar loading nas sugestões
   */
  showLoadingSuggestions() {
    this.suggestionsContainer.innerHTML = `
      <div class="quantum-suggestion-item">
        <div class="quantum-suggestion-loading">
          <div class="quantum-loading-spinner"></div>
          <span>Buscando...</span>
        </div>
      </div>
    `;
    this.showSuggestions();
  }

  /**
   * Mostrar erro nas sugestões
   */
  showErrorSuggestions(message) {
    this.suggestionsContainer.innerHTML = `
      <div class="quantum-suggestion-item">
        <div class="quantum-suggestion-error">
          <i class="fas fa-exclamation-triangle"></i>
          <span>${message}</span>
        </div>
      </div>
    `;
    this.showSuggestions();
  }

  /**
   * Mostrar "nenhum resultado"
   */
  showNoResultsSuggestions() {
    this.suggestionsContainer.innerHTML = `
      <div class="quantum-suggestion-item">
        <div class="quantum-suggestion-empty">
          <i class="fas fa-search"></i>
          <span>Nenhum resultado encontrado</span>
        </div>
      </div>
    `;
    this.showSuggestions();
  }

  /**
   * Mostrar sugestões
   */
  showSuggestions() {
    this.suggestionsContainer.classList.add('visible');
  }

  /**
   * Esconder sugestões
   */
  hideSuggestions() {
    this.suggestionsContainer.classList.remove('visible');
    this.selectedIndex = -1;
  }

  /**
   * Selecionar ação
   */
  selectStock(stock) {
    if (!stock) return;
    
    // Atualizar input
    this.searchInput.value = stock.symbol;
    
    // Esconder sugestões
    this.hideSuggestions();
    
    // Chamar callback
    if (this.onStockSelected) {
      this.onStockSelected(stock.symbol);
    }
    
    console.log(`[StockSearch] Selected stock: ${stock.symbol}`);
  }

  /**
   * Selecionar ação por símbolo
   */
  selectStockBySymbol(symbol) {
    // Atualizar input
    this.searchInput.value = symbol;
    
    // Esconder sugestões
    this.hideSuggestions();
    
    // Chamar callback
    if (this.onStockSelected) {
      this.onStockSelected(symbol);
    }
    
    console.log(`[StockSearch] Selected stock by symbol: ${symbol}`);
  }

  /**
   * Limpar busca
   */
  clearSearch() {
    this.searchInput.value = '';
    this.hideSuggestions();
    this.currentQuery = '';
    this.suggestions = [];
    this.selectedIndex = -1;
  }

  /**
   * Focar no input de busca
   */
  focus() {
    if (this.searchInput) {
      this.searchInput.focus();
    }
  }

  /**
   * Obter sugestões populares
   */
  getPopularSuggestions() {
    return [
      { symbol: 'PETR4', name: 'Petróleo Brasileiro S.A. - Petrobras', exchange: 'B3', type: 'Equity' },
      { symbol: 'VALE3', name: 'Vale S.A.', exchange: 'B3', type: 'Equity' },
      { symbol: 'ITUB4', name: 'Itaú Unibanco Holding S.A.', exchange: 'B3', type: 'Equity' },
      { symbol: 'BBDC4', name: 'Banco Bradesco S.A.', exchange: 'B3', type: 'Equity' },
      { symbol: 'ABEV3', name: 'Ambev S.A.', exchange: 'B3', type: 'Equity' },
      { symbol: 'MGLU3', name: 'Magazine Luiza S.A.', exchange: 'B3', type: 'Equity' }
    ];
  }

  /**
   * Mostrar sugestões populares
   */
  showPopularSuggestions() {
    this.suggestions = this.getPopularSuggestions();
    this.selectedIndex = -1;
    
    const html = `
      <div class="quantum-suggestion-header">
        <i class="fas fa-star"></i>
        <span>Ações Populares</span>
      </div>
      ${this.suggestions.map((stock, index) => `
        <div class="quantum-suggestion-item" data-index="${index}" onclick="stockSearchComponent.selectStock(stockSearchComponent.suggestions[${index}])">
          <div class="quantum-suggestion-main">
            <span class="quantum-suggestion-symbol">${stock.symbol}</span>
            <span class="quantum-suggestion-name">${this.truncateName(stock.name)}</span>
          </div>
          <div class="quantum-suggestion-details">
            <span class="quantum-suggestion-exchange">${stock.exchange}</span>
          </div>
        </div>
      `).join('')}
    `;

    this.suggestionsContainer.innerHTML = html;
    this.showSuggestions();
  }

  /**
   * Utilitários
   */
  truncateName(name, maxLength = 40) {
    if (!name) return 'N/A';
    return name.length > maxLength ? name.substring(0, maxLength) + '...' : name;
  }

  translateType(type) {
    const types = {
      'Equity': 'Ação',
      'ETF': 'ETF',
      'Index': 'Índice',
      'Fund': 'Fundo'
    };
    
    return types[type] || type;
  }
}

// Estilos específicos do componente
const stockSearchStyles = `
  .quantum-search-suggestions {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    z-index: 1000;
    max-height: 300px;
    overflow-y: auto;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
  }

  .quantum-suggestion-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    cursor: pointer;
    border-bottom: 1px solid var(--quantum-border);
    transition: all 0.2s ease;
  }

  .quantum-suggestion-item:hover,
  .quantum-suggestion-item.selected {
    background: rgba(255, 215, 0, 0.1);
    border-left: 3px solid var(--quantum-gold);
  }

  .quantum-suggestion-item:last-child {
    border-bottom: none;
  }

  .quantum-suggestion-main {
    display: flex;
    flex-direction: column;
    gap: 4px;
    flex: 1;
  }

  .quantum-suggestion-symbol {
    font-weight: 600;
    color: var(--quantum-text-primary);
    font-size: 0.875rem;
  }

  .quantum-suggestion-name {
    color: var(--quantum-text-secondary);
    font-size: 0.75rem;
    line-height: 1.2;
  }

  .quantum-suggestion-details {
    display: flex;
    flex-direction: column;
    gap: 4px;
    align-items: flex-end;
    text-align: right;
  }

  .quantum-suggestion-exchange,
  .quantum-suggestion-type {
    font-size: 0.75rem;
    color: var(--quantum-text-muted);
    background: rgba(255, 255, 255, 0.1);
    padding: 2px 6px;
    border-radius: 3px;
  }

  .quantum-suggestion-loading,
  .quantum-suggestion-error,
  .quantum-suggestion-empty {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    color: var(--quantum-text-secondary);
    font-size: 0.875rem;
    width: 100%;
    justify-content: center;
  }

  .quantum-suggestion-error {
    color: var(--quantum-danger);
  }

  .quantum-suggestion-header {
    display: flex;
    align-items: center;
    gap: var(--space-sm);
    padding: 8px 16px;
    background: rgba(255, 215, 0, 0.1);
    color: var(--quantum-gold);
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 1px solid var(--quantum-border);
  }

  .quantum-search-container {
    position: relative;
  }

  /* Scrollbar customizada para sugestões */
  .quantum-search-suggestions::-webkit-scrollbar {
    width: 6px;
  }

  .quantum-search-suggestions::-webkit-scrollbar-track {
    background: var(--quantum-bg-secondary);
  }

  .quantum-search-suggestions::-webkit-scrollbar-thumb {
    background: var(--quantum-border);
    border-radius: 3px;
  }

  .quantum-search-suggestions::-webkit-scrollbar-thumb:hover {
    background: var(--quantum-gold);
  }

  /* Responsividade */
  @media (max-width: 767px) {
    .quantum-suggestion-details {
      display: none;
    }

    .quantum-suggestion-name {
      font-size: 0.8rem;
    }

    .quantum-search-suggestions {
      max-height: 250px;
    }
  }
`;

// Adicionar estilos ao documento
if (typeof document !== 'undefined') {
  const styleSheet = document.createElement('style');
  styleSheet.textContent = stockSearchStyles;
  document.head.appendChild(styleSheet);
}

// Instância global para acesso nos event handlers inline
let stockSearchComponent = null;

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = StockSearchComponent;
} else {
  window.StockSearchComponent = StockSearchComponent;
}

