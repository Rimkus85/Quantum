/**
 * 📊 QUANTUM FINANCE - MARKET OVERVIEW COMPONENT
 * Componente para exibir visão geral do mercado brasileiro
 */

class MarketOverviewComponent {
  constructor(financialService) {
    this.financialService = financialService;
    this.container = document.getElementById('market-overview');
    this.data = null;
    this.onStockSelected = null; // Callback para seleção de ação
    
    this.init();
  }

  /**
   * Inicializar componente
   */
  init() {
    if (!this.container) {
      console.warn('[MarketOverview] Container not found');
      return;
    }
    
    console.log('[MarketOverview] Component initialized');
  }

  /**
   * Carregar dados do mercado
   */
  async loadData(forceRefresh = false) {
    if (!this.container) return;
    
    try {
      // Mostrar skeleton loading
      this.showLoading();
      
      // Buscar dados do mercado
      const marketData = await this.financialService.getMarketSummary();
      
      this.data = marketData;
      
      // Renderizar dados
      this.render();
      
      console.log('[MarketOverview] Data loaded successfully');
      
    } catch (error) {
      console.error('[MarketOverview] Failed to load data:', error);
      this.showError('Erro ao carregar dados do mercado');
    }
  }

  /**
   * Renderizar componente
   */
  render() {
    if (!this.data || !this.container) return;
    
    const { ibovespa, ifix, smallCap, timestamp } = this.data;
    
    this.container.innerHTML = `
      ${this.renderIndexCard('Ibovespa', ibovespa, 'IBOV', 'fas fa-chart-line')}
      ${this.renderIndexCard('IFIX', ifix, 'IFIX', 'fas fa-building')}
      ${this.renderIndexCard('Small Cap', smallCap, 'SMLL', 'fas fa-seedling')}
      ${this.renderSummaryCard()}
    `;
    
    // Adicionar event listeners
    this.setupEventListeners();
  }

  /**
   * Renderizar card de índice
   */
  renderIndexCard(name, data, symbol, icon) {
    if (!data) {
      return `
        <div class="quantum-card">
          <div class="quantum-error">
            <i class="fas fa-exclamation-triangle"></i>
            <div>Dados de ${name} indisponíveis</div>
          </div>
        </div>
      `;
    }

    const changeClass = data.change >= 0 ? 'quantum-text-positive' : 'quantum-text-negative';
    const changeIcon = data.change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
    const changePrefix = data.change >= 0 ? '+' : '';

    return `
      <div class="quantum-card quantum-card--clickable quantum-index-card" data-symbol="${symbol}">
        <div class="quantum-index-header">
          <div class="quantum-index-icon">
            <i class="${icon}"></i>
          </div>
          <div class="quantum-index-info">
            <h3 class="quantum-h3">${name}</h3>
            <span class="quantum-body-small">${symbol}</span>
          </div>
        </div>
        
        <div class="quantum-index-price">
          <div class="quantum-price-large">${this.formatPrice(data.price)}</div>
          <div class="quantum-index-change ${changeClass}">
            <i class="fas ${changeIcon}"></i>
            ${changePrefix}${this.formatChange(data.change)} (${this.formatPercent(data.changePercent)})
          </div>
        </div>
        
        <div class="quantum-index-details">
          <div class="quantum-detail-item">
            <span class="quantum-detail-label">Volume</span>
            <span class="quantum-detail-value">${this.formatVolume(data.volume)}</span>
          </div>
          <div class="quantum-detail-item">
            <span class="quantum-detail-label">Atualizado</span>
            <span class="quantum-detail-value">${this.formatTime(data.timestamp)}</span>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Renderizar card de resumo
   */
  renderSummaryCard() {
    if (!this.data) return '';

    const { ibovespa, timestamp } = this.data;
    const marketStatus = this.getMarketStatus();
    
    return `
      <div class="quantum-card quantum-summary-card">
        <div class="quantum-summary-header">
          <h3 class="quantum-h3">Resumo do Mercado</h3>
          <div class="quantum-market-status ${marketStatus.class}">
            <i class="fas ${marketStatus.icon}"></i>
            ${marketStatus.text}
          </div>
        </div>
        
        <div class="quantum-summary-content">
          <div class="quantum-summary-item">
            <span class="quantum-summary-label">Tendência Geral</span>
            <span class="quantum-summary-value ${ibovespa?.change >= 0 ? 'quantum-text-positive' : 'quantum-text-negative'}">
              ${ibovespa?.change >= 0 ? 'Alta' : 'Baixa'}
            </span>
          </div>
          
          <div class="quantum-summary-item">
            <span class="quantum-summary-label">Última Atualização</span>
            <span class="quantum-summary-value">${this.formatDateTime(timestamp)}</span>
          </div>
          
          <div class="quantum-summary-item">
            <span class="quantum-summary-label">Próxima Atualização</span>
            <span class="quantum-summary-value">${this.getNextUpdateTime()}</span>
          </div>
        </div>
        
        <div class="quantum-summary-actions">
          <button class="quantum-btn quantum-btn--secondary quantum-btn--small" onclick="this.refreshData()">
            <i class="fas fa-sync-alt"></i> Atualizar
          </button>
        </div>
      </div>
    `;
  }

  /**
   * Mostrar loading
   */
  showLoading() {
    if (!this.container) return;
    
    this.container.innerHTML = `
      <div class="quantum-card">
        <div class="quantum-skeleton quantum-skeleton--title"></div>
        <div class="quantum-skeleton quantum-skeleton--price"></div>
        <div class="quantum-skeleton quantum-skeleton--text"></div>
      </div>
      <div class="quantum-card">
        <div class="quantum-skeleton quantum-skeleton--title"></div>
        <div class="quantum-skeleton quantum-skeleton--price"></div>
        <div class="quantum-skeleton quantum-skeleton--text"></div>
      </div>
      <div class="quantum-card">
        <div class="quantum-skeleton quantum-skeleton--title"></div>
        <div class="quantum-skeleton quantum-skeleton--price"></div>
        <div class="quantum-skeleton quantum-skeleton--text"></div>
      </div>
      <div class="quantum-card">
        <div class="quantum-skeleton quantum-skeleton--title"></div>
        <div class="quantum-skeleton quantum-skeleton--text"></div>
        <div class="quantum-skeleton quantum-skeleton--text"></div>
      </div>
    `;
  }

  /**
   * Mostrar erro
   */
  showError(message) {
    if (!this.container) return;
    
    this.container.innerHTML = `
      <div class="quantum-card">
        <div class="quantum-error">
          <div class="quantum-error__icon">
            <i class="fas fa-exclamation-triangle"></i>
          </div>
          <div class="quantum-error__message">${message}</div>
          <button class="quantum-error__retry" onclick="this.loadData(true)">
            Tentar Novamente
          </button>
        </div>
      </div>
    `;
  }

  /**
   * Configurar event listeners
   */
  setupEventListeners() {
    const indexCards = this.container.querySelectorAll('.quantum-index-card');
    
    indexCards.forEach(card => {
      card.addEventListener('click', () => {
        const symbol = card.dataset.symbol;
        if (symbol && this.onStockSelected) {
          this.onStockSelected(symbol);
        }
      });
    });
  }

  /**
   * Obter status do mercado
   */
  getMarketStatus() {
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay();
    
    // Mercado brasileiro: Segunda a Sexta, 10h às 17h
    if (day >= 1 && day <= 5) {
      if (hour >= 10 && hour < 17) {
        return {
          text: 'Mercado Aberto',
          class: 'market-open',
          icon: 'fa-circle'
        };
      } else if (hour >= 9 && hour < 10) {
        return {
          text: 'Pré-Abertura',
          class: 'market-pre',
          icon: 'fa-clock'
        };
      } else if (hour >= 17 && hour < 18) {
        return {
          text: 'Pós-Fechamento',
          class: 'market-post',
          icon: 'fa-clock'
        };
      }
    }
    
    return {
      text: 'Mercado Fechado',
      class: 'market-closed',
      icon: 'fa-pause-circle'
    };
  }

  /**
   * Obter próximo horário de atualização
   */
  getNextUpdateTime() {
    const now = new Date();
    const nextUpdate = new Date(now.getTime() + 60000); // +1 minuto
    
    return this.formatTime(nextUpdate);
  }

  /**
   * Atualizar dados
   */
  async refreshData() {
    await this.loadData(true);
  }

  /**
   * Formatadores
   */
  formatPrice(price) {
    if (typeof price !== 'number') return 'N/A';
    return price.toLocaleString('pt-BR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    });
  }

  formatChange(change) {
    if (typeof change !== 'number') return 'N/A';
    return change.toLocaleString('pt-BR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    });
  }

  formatPercent(percent) {
    if (typeof percent !== 'number') return 'N/A';
    return percent.toFixed(2) + '%';
  }

  formatVolume(volume) {
    if (typeof volume !== 'number') return 'N/A';
    
    if (volume >= 1000000000) {
      return (volume / 1000000000).toFixed(1) + 'B';
    } else if (volume >= 1000000) {
      return (volume / 1000000).toFixed(1) + 'M';
    } else if (volume >= 1000) {
      return (volume / 1000).toFixed(1) + 'K';
    }
    
    return volume.toString();
  }

  formatTime(date) {
    if (!(date instanceof Date)) return 'N/A';
    
    return date.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  formatDateTime(date) {
    if (!(date instanceof Date)) return 'N/A';
    
    return date.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}

// Estilos específicos do componente
const marketOverviewStyles = `
  .quantum-index-card {
    transition: all 0.3s ease;
  }

  .quantum-index-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(255, 215, 0, 0.2);
  }

  .quantum-index-header {
    display: flex;
    align-items: center;
    gap: var(--space-md);
    margin-bottom: var(--space-md);
  }

  .quantum-index-icon {
    width: 48px;
    height: 48px;
    background: rgba(255, 215, 0, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--quantum-gold);
    font-size: 1.5rem;
  }

  .quantum-index-info h3 {
    margin: 0;
  }

  .quantum-index-price {
    margin-bottom: var(--space-md);
  }

  .quantum-index-change {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
    font-weight: 500;
    margin-top: var(--space-xs);
  }

  .quantum-index-details {
    display: flex;
    justify-content: space-between;
    gap: var(--space-md);
  }

  .quantum-detail-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .quantum-detail-label {
    font-size: 0.75rem;
    color: var(--quantum-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .quantum-detail-value {
    font-size: 0.875rem;
    font-weight: 500;
    color: var(--quantum-text-primary);
  }

  .quantum-summary-card {
    grid-column: 1 / -1;
  }

  .quantum-summary-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: var(--space-md);
  }

  .quantum-market-status {
    display: flex;
    align-items: center;
    gap: var(--space-xs);
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 500;
    text-transform: uppercase;
  }

  .quantum-market-status.market-open {
    background: rgba(40, 167, 69, 0.2);
    color: var(--quantum-success);
  }

  .quantum-market-status.market-closed {
    background: rgba(108, 117, 125, 0.2);
    color: var(--quantum-text-muted);
  }

  .quantum-market-status.market-pre,
  .quantum-market-status.market-post {
    background: rgba(255, 193, 7, 0.2);
    color: var(--quantum-warning);
  }

  .quantum-summary-content {
    display: grid;
    gap: var(--space-sm);
    margin-bottom: var(--space-md);
  }

  .quantum-summary-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .quantum-summary-label {
    color: var(--quantum-text-secondary);
  }

  .quantum-summary-value {
    font-weight: 500;
  }

  .quantum-summary-actions {
    display: flex;
    justify-content: flex-end;
  }

  @media (max-width: 767px) {
    .quantum-index-details {
      flex-direction: column;
      gap: var(--space-sm);
    }

    .quantum-summary-header {
      flex-direction: column;
      gap: var(--space-sm);
      align-items: flex-start;
    }
  }
`;

// Adicionar estilos ao documento
if (typeof document !== 'undefined') {
  const styleSheet = document.createElement('style');
  styleSheet.textContent = marketOverviewStyles;
  document.head.appendChild(styleSheet);
}

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = MarketOverviewComponent;
} else {
  window.MarketOverviewComponent = MarketOverviewComponent;
}

