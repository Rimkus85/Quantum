/**
 * 📈 QUANTUM FINANCE - STOCK CHART COMPONENT
 * Componente para exibir gráficos de ações usando Chart.js
 */

class StockChartComponent {
  constructor(financialService) {
    this.financialService = financialService;
    this.canvas = document.getElementById('main-chart');
    this.chart = null;
    this.currentSymbol = null;
    this.currentPeriod = '1M';
    this.data = null;
    
    this.init();
  }

  /**
   * Inicializar componente
   */
  async init() {
    try {
      console.log('[StockChart] Initializing component...');
      
      if (!this.canvas) {
        throw new Error('Canvas element not found');
      }
      
      // Garantir que Chart.js está carregado
      console.log('[StockChart] Loading Chart.js...');
      this.Chart = await ChartLoader.ensureChartJS();
      
      // Configurar defaults
      ChartLoader.setupDefaults();
      
      // Inicializar gráfico vazio
      this.initializeEmptyChart();
      
      console.log('[StockChart] Component initialized successfully');
      
    } catch (error) {
      console.error('[StockChart] Initialization failed:', error);
      this.showChartError(`Erro ao carregar gráficos: ${error.message}`);
    }
  }

  /**
   * Mostrar erro do gráfico
   */
  showChartError(message) {
    if (!this.canvas) return;
    
    const chartWrapper = this.canvas.parentElement;
    if (!chartWrapper) return;
    
    chartWrapper.innerHTML = `
      <div class="quantum-chart-error-static">
        <div class="quantum-chart-error-content">
          <i class="fas fa-exclamation-triangle"></i>
          <span>${message}</span>
        </div>
      </div>
    `;
  }

  /**
   * Configurar padrões do Chart.js
   */
  setupChartDefaults() {
    Chart.defaults.color = '#ffffff';
    Chart.defaults.borderColor = 'rgba(255, 215, 0, 0.2)';
    Chart.defaults.backgroundColor = 'rgba(255, 215, 0, 0.1)';
    
    Chart.defaults.font = {
      family: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      size: 12
    };
  }

  /**
   * Inicializar gráfico vazio
   */
  initializeEmptyChart() {
    if (!this.Chart || !this.canvas) {
      console.warn('[StockChart] Cannot initialize chart - Chart.js or canvas not available');
      return;
    }
    
    const ctx = this.canvas.getContext('2d');
    
    this.chart = new this.Chart(ctx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [{
          label: 'Preço',
          data: [],
          borderColor: '#FFD700',
          backgroundColor: 'rgba(255, 215, 0, 0.1)',
          borderWidth: 2,
          fill: true,
          tension: 0.1,
          pointRadius: 0,
          pointHoverRadius: 6,
          pointHoverBackgroundColor: '#FFD700',
          pointHoverBorderColor: '#ffffff',
          pointHoverBorderWidth: 2
        }]
      },
      options: this.getChartOptions()
    });
  }

  /**
   * Obter configurações do gráfico
   */
  getChartOptions() {
    return {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        intersect: false,
        mode: 'index'
      },
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          backgroundColor: 'rgba(26, 26, 46, 0.95)',
          titleColor: '#FFD700',
          bodyColor: '#ffffff',
          borderColor: '#FFD700',
          borderWidth: 1,
          cornerRadius: 8,
          displayColors: false,
          callbacks: {
            title: (context) => {
              const date = new Date(context[0].label);
              return date.toLocaleDateString('pt-BR', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              });
            },
            label: (context) => {
              const value = context.parsed.y;
              return `Preço: R$ ${value.toFixed(2)}`;
            },
            afterLabel: (context) => {
              if (this.data && this.data.length > 1) {
                const currentIndex = context.dataIndex;
                const previousIndex = Math.max(0, currentIndex - 1);
                
                if (currentIndex > 0) {
                  const current = this.data[currentIndex].close;
                  const previous = this.data[previousIndex].close;
                  const change = current - previous;
                  const changePercent = (change / previous) * 100;
                  
                  const changeText = change >= 0 ? '+' : '';
                  return [
                    `Variação: ${changeText}${change.toFixed(2)} (${changePercent.toFixed(2)}%)`,
                    `Volume: ${this.formatVolume(this.data[currentIndex].volume)}`
                  ];
                }
              }
              return '';
            }
          }
        }
      },
      scales: {
        x: {
          type: 'time',
          time: {
            displayFormats: {
              hour: 'HH:mm',
              day: 'dd/MM',
              week: 'dd/MM',
              month: 'MMM yy'
            }
          },
          grid: {
            color: 'rgba(255, 215, 0, 0.1)',
            drawBorder: false
          },
          ticks: {
            color: '#a0a0a0',
            maxTicksLimit: 8
          }
        },
        y: {
          position: 'right',
          grid: {
            color: 'rgba(255, 215, 0, 0.1)',
            drawBorder: false
          },
          ticks: {
            color: '#a0a0a0',
            callback: function(value) {
              return 'R$ ' + value.toFixed(2);
            }
          }
        }
      },
      elements: {
        point: {
          hoverRadius: 8
        }
      },
      animation: {
        duration: 750,
        easing: 'easeInOutQuart'
      }
    };
  }

  /**
   * Carregar dados de uma ação
   */
  async loadStockData(symbol, period = '1M', forceRefresh = false) {
    if (!symbol) return;
    
    this.currentSymbol = symbol;
    this.currentPeriod = period;
    
    try {
      // Mostrar loading
      this.showLoading();
      
      // Buscar dados históricos
      const historicalData = await this.financialService.getStockHistoryWithFallback(
        symbol, 
        period, 
        this.getPeriodInterval(period),
        { forceRefresh }
      );
      
      this.data = historicalData;
      
      // Atualizar gráfico
      this.updateChart(historicalData, symbol, period);
      
      console.log(`[StockChart] Loaded ${historicalData.length} data points for ${symbol}`);
      
    } catch (error) {
      console.error('[StockChart] Failed to load stock data:', error);
      this.showError(`Erro ao carregar dados de ${symbol}`);
    }
  }

  /**
   * Atualizar gráfico com novos dados
   */
  updateChart(data, symbol, period) {
    if (!this.chart || !data || data.length === 0) {
      this.showError('Dados insuficientes para exibir o gráfico');
      return;
    }

    // Preparar dados para o gráfico
    const labels = data.map(item => item.date);
    const prices = data.map(item => item.close);
    
    // Calcular cores baseadas na tendência
    const firstPrice = prices[0];
    const lastPrice = prices[prices.length - 1];
    const isPositive = lastPrice >= firstPrice;
    
    const borderColor = isPositive ? '#28a745' : '#dc3545';
    const backgroundColor = isPositive ? 'rgba(40, 167, 69, 0.1)' : 'rgba(220, 53, 69, 0.1)';
    
    // Atualizar dados do gráfico
    this.chart.data.labels = labels;
    this.chart.data.datasets[0].data = prices;
    this.chart.data.datasets[0].label = `${symbol} - ${period}`;
    this.chart.data.datasets[0].borderColor = borderColor;
    this.chart.data.datasets[0].backgroundColor = backgroundColor;
    
    // Configurar formato de tempo baseado no período
    this.updateTimeFormat(period);
    
    // Atualizar gráfico
    this.chart.update('active');
    
    // Mostrar estatísticas
    this.showStatistics(data, symbol);
  }

  /**
   * Atualizar formato de tempo baseado no período
   */
  updateTimeFormat(period) {
    let unit = 'day';
    let displayFormat = 'dd/MM';
    
    switch (period) {
      case '1D':
        unit = 'hour';
        displayFormat = 'HH:mm';
        break;
      case '5D':
        unit = 'day';
        displayFormat = 'dd/MM';
        break;
      case '1M':
      case '3M':
        unit = 'day';
        displayFormat = 'dd/MM';
        break;
      case '6M':
      case '1Y':
        unit = 'month';
        displayFormat = 'MMM yy';
        break;
      case '2Y':
      case '5Y':
        unit = 'month';
        displayFormat = 'MMM yy';
        break;
    }
    
    this.chart.options.scales.x.time.unit = unit;
    this.chart.options.scales.x.time.displayFormats[unit] = displayFormat;
  }

  /**
   * Mostrar estatísticas do período
   */
  showStatistics(data, symbol) {
    if (!data || data.length === 0) return;
    
    const firstPrice = data[0].close;
    const lastPrice = data[data.length - 1].close;
    const highPrice = Math.max(...data.map(d => d.high));
    const lowPrice = Math.min(...data.map(d => d.low));
    const totalVolume = data.reduce((sum, d) => sum + d.volume, 0);
    
    const change = lastPrice - firstPrice;
    const changePercent = (change / firstPrice) * 100;
    
    // Criar ou atualizar painel de estatísticas
    this.updateStatisticsPanel({
      symbol,
      firstPrice,
      lastPrice,
      highPrice,
      lowPrice,
      change,
      changePercent,
      totalVolume,
      dataPoints: data.length
    });
  }

  /**
   * Atualizar painel de estatísticas
   */
  updateStatisticsPanel(stats) {
    let statsPanel = document.querySelector('.quantum-chart-stats');
    
    if (!statsPanel) {
      // Criar painel se não existir
      const chartContainer = document.querySelector('.quantum-chart-container');
      if (!chartContainer) return;
      
      statsPanel = document.createElement('div');
      statsPanel.className = 'quantum-chart-stats';
      chartContainer.appendChild(statsPanel);
    }
    
    const changeClass = stats.change >= 0 ? 'quantum-text-positive' : 'quantum-text-negative';
    const changeIcon = stats.change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
    const changePrefix = stats.change >= 0 ? '+' : '';
    
    statsPanel.innerHTML = `
      <div class="quantum-stats-grid">
        <div class="quantum-stat-item">
          <span class="quantum-stat-label">Abertura</span>
          <span class="quantum-stat-value">R$ ${stats.firstPrice.toFixed(2)}</span>
        </div>
        <div class="quantum-stat-item">
          <span class="quantum-stat-label">Fechamento</span>
          <span class="quantum-stat-value">R$ ${stats.lastPrice.toFixed(2)}</span>
        </div>
        <div class="quantum-stat-item">
          <span class="quantum-stat-label">Máxima</span>
          <span class="quantum-stat-value">R$ ${stats.highPrice.toFixed(2)}</span>
        </div>
        <div class="quantum-stat-item">
          <span class="quantum-stat-label">Mínima</span>
          <span class="quantum-stat-value">R$ ${stats.lowPrice.toFixed(2)}</span>
        </div>
        <div class="quantum-stat-item">
          <span class="quantum-stat-label">Variação</span>
          <span class="quantum-stat-value ${changeClass}">
            <i class="fas ${changeIcon}"></i>
            ${changePrefix}${stats.change.toFixed(2)} (${stats.changePercent.toFixed(2)}%)
          </span>
        </div>
        <div class="quantum-stat-item">
          <span class="quantum-stat-label">Volume Total</span>
          <span class="quantum-stat-value">${this.formatVolume(stats.totalVolume)}</span>
        </div>
      </div>
    `;
  }

  /**
   * Obter intervalo baseado no período
   */
  getPeriodInterval(period) {
    const intervals = {
      '1D': '5m',
      '5D': '15m',
      '1M': '1d',
      '3M': '1d',
      '6M': '1d',
      '1Y': '1d',
      '2Y': '1wk',
      '5Y': '1mo'
    };
    
    return intervals[period] || '1d';
  }

  /**
   * Mostrar loading
   */
  showLoading() {
    if (!this.chart) return;
    
    // Limpar dados
    this.chart.data.labels = [];
    this.chart.data.datasets[0].data = [];
    this.chart.data.datasets[0].label = 'Carregando...';
    this.chart.update('none');
    
    // Mostrar indicador de loading
    this.showLoadingOverlay();
  }

  /**
   * Mostrar overlay de loading
   */
  showLoadingOverlay() {
    let overlay = document.querySelector('.quantum-chart-loading');
    
    if (!overlay) {
      const chartWrapper = document.querySelector('.quantum-chart-wrapper');
      if (!chartWrapper) return;
      
      overlay = document.createElement('div');
      overlay.className = 'quantum-chart-loading';
      overlay.innerHTML = `
        <div class="quantum-chart-loading-content">
          <div class="quantum-loading-spinner"></div>
          <span>Carregando dados...</span>
        </div>
      `;
      chartWrapper.appendChild(overlay);
    }
    
    overlay.style.display = 'flex';
  }

  /**
   * Esconder overlay de loading
   */
  hideLoadingOverlay() {
    const overlay = document.querySelector('.quantum-chart-loading');
    if (overlay) {
      overlay.style.display = 'none';
    }
  }

  /**
   * Mostrar erro
   */
  showError(message) {
    if (!this.chart) return;
    
    // Limpar dados
    this.chart.data.labels = [];
    this.chart.data.datasets[0].data = [];
    this.chart.data.datasets[0].label = 'Erro';
    this.chart.update('none');
    
    // Mostrar mensagem de erro
    this.showErrorOverlay(message);
  }

  /**
   * Mostrar overlay de erro
   */
  showErrorOverlay(message) {
    let overlay = document.querySelector('.quantum-chart-error');
    
    if (!overlay) {
      const chartWrapper = document.querySelector('.quantum-chart-wrapper');
      if (!chartWrapper) return;
      
      overlay = document.createElement('div');
      overlay.className = 'quantum-chart-error';
      chartWrapper.appendChild(overlay);
    }
    
    overlay.innerHTML = `
      <div class="quantum-chart-error-content">
        <i class="fas fa-exclamation-triangle"></i>
        <span>${message}</span>
        <button class="quantum-btn quantum-btn--secondary quantum-btn--small" onclick="this.retry()">
          Tentar Novamente
        </button>
      </div>
    `;
    
    overlay.style.display = 'flex';
  }

  /**
   * Esconder overlay de erro
   */
  hideErrorOverlay() {
    const overlay = document.querySelector('.quantum-chart-error');
    if (overlay) {
      overlay.style.display = 'none';
    }
  }

  /**
   * Tentar novamente
   */
  retry() {
    if (this.currentSymbol) {
      this.loadStockData(this.currentSymbol, this.currentPeriod, true);
    }
  }

  /**
   * Limpar gráfico
   */
  clearChart() {
    if (!this.chart) return;
    
    this.chart.data.labels = [];
    this.chart.data.datasets[0].data = [];
    this.chart.data.datasets[0].label = 'Preço';
    this.chart.data.datasets[0].borderColor = '#FFD700';
    this.chart.data.datasets[0].backgroundColor = 'rgba(255, 215, 0, 0.1)';
    this.chart.update('none');
    
    this.currentSymbol = null;
    this.data = null;
    
    // Remover painel de estatísticas
    const statsPanel = document.querySelector('.quantum-chart-stats');
    if (statsPanel) {
      statsPanel.remove();
    }
    
    // Esconder overlays
    this.hideLoadingOverlay();
    this.hideErrorOverlay();
  }

  /**
   * Redimensionar gráfico
   */
  resize() {
    if (this.chart) {
      this.chart.resize();
    }
  }

  /**
   * Destruir componente
   */
  destroy() {
    if (this.chart) {
      this.chart.destroy();
      this.chart = null;
    }
  }

  /**
   * Formatar volume
   */
  formatVolume(volume) {
    if (typeof volume !== 'number') return 'N/A';
    
    if (volume >= 1000000000) {
      return (volume / 1000000000).toFixed(1) + 'B';
    } else if (volume >= 1000000) {
      return (volume / 1000000).toFixed(1) + 'M';
    } else if (volume >= 1000) {
      return (volume / 1000).toFixed(1) + 'K';
    }
    
    return volume.toLocaleString('pt-BR');
  }
}

// Estilos específicos do componente
const stockChartStyles = `
  .quantum-chart-loading,
  .quantum-chart-error {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(26, 26, 46, 0.9);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 10;
    border-radius: 8px;
  }

  .quantum-chart-loading-content,
  .quantum-chart-error-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--space-md);
    color: var(--quantum-text-primary);
    text-align: center;
  }

  .quantum-chart-error-content {
    color: var(--quantum-danger);
  }

  .quantum-chart-stats {
    margin-top: var(--space-md);
    padding: var(--space-md);
    background: var(--quantum-bg-secondary);
    border-radius: 8px;
    border: 1px solid var(--quantum-border);
  }

  .quantum-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: var(--space-md);
  }

  .quantum-stat-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .quantum-stat-label {
    font-size: 0.75rem;
    color: var(--quantum-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .quantum-stat-value {
    font-size: 0.875rem;
    font-weight: 500;
    color: var(--quantum-text-primary);
    display: flex;
    align-items: center;
    gap: 4px;
  }

  /* Responsividade */
  @media (max-width: 767px) {
    .quantum-stats-grid {
      grid-template-columns: repeat(2, 1fr);
      gap: var(--space-sm);
    }

    .quantum-stat-item {
      gap: 2px;
    }

    .quantum-stat-label {
      font-size: 0.7rem;
    }

    .quantum-stat-value {
      font-size: 0.8rem;
    }
  }
`;

// Adicionar estilos ao documento
if (typeof document !== 'undefined') {
  const styleSheet = document.createElement('style');
  styleSheet.textContent = stockChartStyles;
  document.head.appendChild(styleSheet);
}

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = StockChartComponent;
} else {
  window.StockChartComponent = StockChartComponent;
}

