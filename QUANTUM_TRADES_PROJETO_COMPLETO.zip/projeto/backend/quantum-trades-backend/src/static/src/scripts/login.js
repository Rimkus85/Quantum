/**
 * Script de Login - Quantum Finance
 * Controla funcionalidades da página de login
 */

document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const passwordToggle = document.getElementById('passwordToggle');
    const rememberMeCheckbox = document.getElementById('rememberMe');
    const loginButton = loginForm.querySelector('.login-button');
    const buttonText = loginButton.querySelector('.button-text');
    const loadingSpinner = loginButton.querySelector('.loading-spinner');

    // Verificar se já está logado
    if (authService.isLoggedIn()) {
        toast.success(`Bem-vindo de volta, ${authService.getCurrentUser().name}!`);
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 2000);
        return;
    }

    // Carregar preferências salvas
    const rememberMe = localStorage.getItem('quantum_finance_remember');
    if (rememberMe === 'true') {
        rememberMeCheckbox.checked = true;
        const savedEmail = localStorage.getItem('quantum_finance_email');
        if (savedEmail) {
            emailInput.value = savedEmail;
            passwordInput.focus();
        }
    }

    // Toggle de visualização de senha
    passwordToggle.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        
        const icon = passwordToggle.querySelector('i');
        icon.classList.toggle('fa-eye');
        icon.classList.toggle('fa-eye-slash');
    });

    // Validação em tempo real
    emailInput.addEventListener('blur', validateEmail);
    passwordInput.addEventListener('blur', validatePassword);
    emailInput.addEventListener('input', clearEmailError);
    passwordInput.addEventListener('input', clearPasswordError);

    // Submissão do formulário
    loginForm.addEventListener('submit', handleLogin);

    // Função de validação de email
    function validateEmail() {
        const email = emailInput.value.trim();
        const errorElement = document.getElementById('emailError');
        
        if (!email) {
            showFieldError('emailError', 'E-mail é obrigatório');
            emailInput.classList.add('error');
            return false;
        }
        
        if (!authService.validateEmail(email)) {
            showFieldError('emailError', 'E-mail inválido');
            emailInput.classList.add('error');
            return false;
        }
        
        clearFieldError('emailError');
        emailInput.classList.remove('error');
        return true;
    }

    // Função de validação de senha
    function validatePassword() {
        const password = passwordInput.value;
        const errorElement = document.getElementById('passwordError');
        
        if (!password) {
            showFieldError('passwordError', 'Senha é obrigatória');
            passwordInput.classList.add('error');
            return false;
        }
        
        if (password.length < 6) {
            showFieldError('passwordError', 'Senha deve ter pelo menos 6 caracteres');
            passwordInput.classList.add('error');
            return false;
        }
        
        clearFieldError('passwordError');
        passwordInput.classList.remove('error');
        return true;
    }

    // Limpar erro do email
    function clearEmailError() {
        clearFieldError('emailError');
        emailInput.classList.remove('error');
    }

    // Limpar erro da senha
    function clearPasswordError() {
        clearFieldError('passwordError');
        passwordInput.classList.remove('error');
    }

    // Mostrar erro em campo específico
    function showFieldError(fieldId, message) {
        const errorElement = document.getElementById(fieldId);
        if (errorElement) {
            errorElement.textContent = message;
        }
    }

    // Limpar erro de campo específico
    function clearFieldError(fieldId) {
        const errorElement = document.getElementById(fieldId);
        if (errorElement) {
            errorElement.textContent = '';
        }
    }

    // Manipular submissão do login
    async function handleLogin(event) {
        event.preventDefault();
        
        // Validar campos
        const isEmailValid = validateEmail();
        const isPasswordValid = validatePassword();
        
        if (!isEmailValid || !isPasswordValid) {
            toast.error('Por favor, corrija os erros no formulário');
            return;
        }
        
        // Coletar dados do formulário
        const formData = {
            email: emailInput.value.trim(),
            password: passwordInput.value,
            rememberMe: rememberMeCheckbox.checked
        };
        
        // Mostrar loading
        setLoadingState(true);
        
        try {
            // Tentar fazer login
            const result = await authService.login(
                formData.email, 
                formData.password, 
                formData.rememberMe
            );
            
            if (result.success) {
                toast.success(result.message);
                
                // Salvar email se lembrar
                if (rememberMeCheckbox.checked) {
                    localStorage.setItem('quantum_finance_email', formData.email);
                } else {
                    localStorage.removeItem('quantum_finance_email');
                }
                
                // Redirecionar para dashboard
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 2000);
            } else {
                toast.error(result.message || 'Erro ao fazer login');
            }
        } catch (error) {
            console.error('Erro no login:', error);
            toast.error('Erro interno. Tente novamente.');
        } finally {
            setLoadingState(false);
        }
    }

    // Controlar estado de loading do botão
    function setLoadingState(loading) {
        if (loading) {
            loginButton.disabled = true;
            buttonText.style.opacity = '0';
            loadingSpinner.style.display = 'block';
        } else {
            loginButton.disabled = false;
            buttonText.style.opacity = '1';
            loadingSpinner.style.display = 'none';
        }
    }

    // Atalhos de teclado
    document.addEventListener('keydown', function(event) {
        // Enter para submeter formulário
        if (event.key === 'Enter' && (emailInput === document.activeElement || passwordInput === document.activeElement)) {
            event.preventDefault();
            loginForm.dispatchEvent(new Event('submit'));
        }
        
        // Escape para limpar formulário
        if (event.key === 'Escape') {
            emailInput.value = '';
            passwordInput.value = '';
            rememberMeCheckbox.checked = false;
            clearEmailError();
            clearPasswordError();
            emailInput.focus();
        }
    });

    // Focar no primeiro campo vazio
    if (!emailInput.value) {
        emailInput.focus();
    } else if (!passwordInput.value) {
        passwordInput.focus();
    }

    // Mensagem de boas-vindas
    setTimeout(() => {
        toast.info('Bem-vindo ao Quantum Finance! Use as credenciais demo para testar.', 8000);
    }, 1000);

    // Credenciais de demonstração (apenas para desenvolvimento)
    if (window.location.hostname === 'localhost' || window.location.hostname.includes('manus.space')) {
        const demoCredentials = document.createElement('div');
        demoCredentials.innerHTML = `
            <div style="
                position: fixed;
                bottom: 20px;
                left: 20px;
                background: var(--quantum-widget-bg);
                border: 1px solid var(--quantum-widget-border);
                border-radius: 8px;
                padding: 1rem;
                font-size: 0.8rem;
                color: var(--quantum-text-secondary);
                max-width: 250px;
                z-index: 1000;
            ">
                <strong style="color: var(--quantum-gold);">Credenciais Demo:</strong><br>
                admin@quantumfinance.com / admin123<br>
                demo@quantumfinance.com / demo123<br>
                user@quantumfinance.com / user123
            </div>
        `;
        document.body.appendChild(demoCredentials);
    }
});

// Função para preencher credenciais demo (desenvolvimento)
function fillDemoCredentials(type = 'demo') {
    const credentials = {
        admin: { email: 'admin@quantumfinance.com', password: 'admin123' },
        demo: { email: 'demo@quantumfinance.com', password: 'demo123' },
        user: { email: 'user@quantumfinance.com', password: 'user123' }
    };
    
    const cred = credentials[type];
    if (cred) {
        document.getElementById('email').value = cred.email;
        document.getElementById('password').value = cred.password;
        document.getElementById('rememberMe').checked = true;
    }
}

// Expor função globalmente para desenvolvimento
window.fillDemoCredentials = fillDemoCredentials;

