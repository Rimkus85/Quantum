/**
 * Módulo de Análise Técnica Quantum Trades
 * Integração com APIs da Sprint 4
 */

class TechnicalAnalysisManager {
    constructor() {
        this.apiBase = window.location.origin;
        this.strategies = {};
        this.indicators = {};
        this.currentSymbol = null;
        this.currentStrategy = 'swing_trading';
        this.isInitialized = false;
        
        this.init();
    }

    async init() {
        try {
            console.log('📊 Inicializando análise técnica...');
            
            // Carregar estratégias disponíveis
            await this.loadStrategies();
            
            this.isInitialized = true;
            console.log('✅ Análise técnica inicializada');
            
        } catch (error) {
            console.error('❌ Erro ao inicializar análise técnica:', error);
        }
    }

    async loadStrategies() {
        try {
            const response = await fetch(`${this.apiBase}/api/technical/strategies`);
            const data = await response.json();
            
            if (data.success) {
                this.strategies = data.data.strategies;
                console.log('📋 Estratégias carregadas:', Object.keys(this.strategies).length);
            }
        } catch (error) {
            console.error('Erro ao carregar estratégias:', error);
        }
    }

    async getIndicators(symbol, config = {}) {
        try {
            console.log(`📈 Buscando indicadores para ${symbol}...`);
            
            const params = new URLSearchParams();
            Object.entries(config).forEach(([key, value]) => {
                params.append(key, value);
            });
            
            const url = `${this.apiBase}/api/technical/indicators/${symbol}${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.success) {
                this.indicators[symbol] = data.data;
                return data.data;
            } else {
                throw new Error(data.message || 'Erro ao carregar indicadores');
            }
            
        } catch (error) {
            console.error('Erro ao carregar indicadores:', error);
            throw error;
        }
    }

    async getAnalysis(symbol, strategy = null) {
        try {
            console.log(`🔍 Analisando ${symbol} com estratégia ${strategy || this.currentStrategy}...`);
            
            const strategyParam = strategy || this.currentStrategy;
            const response = await fetch(`${this.apiBase}/api/technical/analysis/${symbol}?strategy=${strategyParam}`);
            const data = await response.json();
            
            if (data.success) {
                return data.data;
            } else {
                throw new Error(data.message || 'Erro ao carregar análise');
            }
            
        } catch (error) {
            console.error('Erro ao carregar análise:', error);
            throw error;
        }
    }

    async getSignals(symbol) {
        try {
            console.log(`🚦 Buscando sinais para ${symbol}...`);
            
            const response = await fetch(`${this.apiBase}/api/technical/signals/${symbol}`);
            const data = await response.json();
            
            if (data.success) {
                return data.data;
            } else {
                throw new Error(data.message || 'Erro ao carregar sinais');
            }
            
        } catch (error) {
            console.error('Erro ao carregar sinais:', error);
            throw error;
        }
    }

    async runBacktest(symbol, strategy, config = {}) {
        try {
            console.log(`⏮️ Executando backtesting para ${symbol}...`);
            
            const requestData = {
                strategy: strategy,
                ...config
            };
            
            const response = await fetch(`${this.apiBase}/api/technical/backtest/${symbol}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                return data.data;
            } else {
                throw new Error(data.message || 'Erro no backtesting');
            }
            
        } catch (error) {
            console.error('Erro no backtesting:', error);
            throw error;
        }
    }

    async runScreener(criteria) {
        try {
            console.log('🔍 Executando screener técnico...');
            
            const response = await fetch(`${this.apiBase}/api/technical/screener`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(criteria)
            });
            
            const data = await response.json();
            
            if (data.success) {
                return data.data;
            } else {
                throw new Error(data.message || 'Erro no screener');
            }
            
        } catch (error) {
            console.error('Erro no screener:', error);
            throw error;
        }
    }

    renderIndicators(container, indicators) {
        if (!container || !indicators) return;
        
        let html = '<div class="indicators-grid" style="display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">';
        
        Object.entries(indicators).forEach(([key, indicator]) => {
            const value = this.formatIndicatorValue(indicator);
            const signal = this.getIndicatorSignal(key, indicator);
            const signalClass = this.getSignalClass(signal);
            
            html += `
                <div class="indicator-card" style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <span style="font-weight: 600; font-size: 0.9rem;">${this.getIndicatorName(key)}</span>
                        <span class="${signalClass}" style="font-size: 0.8rem; font-weight: 500;">
                            ${signal}
                        </span>
                    </div>
                    <div style="font-size: 1.2rem; font-weight: 700; font-family: 'JetBrains Mono', monospace;">
                        ${value}
                    </div>
                    <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 0.25rem;">
                        ${this.getIndicatorDescription(key)}
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        container.innerHTML = html;
    }

    renderAnalysis(container, analysis) {
        if (!container || !analysis) return;
        
        const signals = analysis.trading_signals || {};
        const recommendation = analysis.recommendation || {};
        
        let html = `
            <div class="analysis-summary" style="margin-bottom: 1.5rem;">
                <div style="display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));">
                    <div class="signal-card" style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem; text-align: center;">
                        <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 0.5rem;">Sinal</div>
                        <div class="${this.getSignalClass(signals.action)}" style="font-size: 1.2rem; font-weight: 700;">
                            ${this.getActionLabel(signals.action)}
                        </div>
                    </div>
                    <div class="signal-card" style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem; text-align: center;">
                        <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 0.5rem;">Confiança</div>
                        <div style="font-size: 1.2rem; font-weight: 700; color: var(--accent-color);">
                            ${this.getConfidenceLabel(signals.confidence)}
                        </div>
                    </div>
                    <div class="signal-card" style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem; text-align: center;">
                        <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 0.5rem;">Força</div>
                        <div style="font-size: 1.2rem; font-weight: 700;">
                            ${signals.strength || 'N/A'}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        if (recommendation.summary) {
            html += `
                <div class="recommendation" style="background: var(--secondary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem;">
                    <h4 style="margin-bottom: 1rem; color: var(--accent-color);">
                        <i class="fas fa-lightbulb"></i> Recomendação
                    </h4>
                    <p style="line-height: 1.6; margin-bottom: 1rem;">${recommendation.summary}</p>
                    
                    ${recommendation.entry_point ? `
                        <div style="display: grid; gap: 0.5rem; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); margin-top: 1rem;">
                            <div>
                                <span style="color: var(--text-secondary); font-size: 0.9rem;">Entrada:</span>
                                <span style="font-weight: 600; margin-left: 0.5rem;">R$ ${recommendation.entry_point.toFixed(2)}</span>
                            </div>
                            ${recommendation.stop_loss ? `
                                <div>
                                    <span style="color: var(--text-secondary); font-size: 0.9rem;">Stop Loss:</span>
                                    <span style="font-weight: 600; margin-left: 0.5rem; color: var(--danger-color);">R$ ${recommendation.stop_loss.toFixed(2)}</span>
                                </div>
                            ` : ''}
                            ${recommendation.take_profit ? `
                                <div>
                                    <span style="color: var(--text-secondary); font-size: 0.9rem;">Take Profit:</span>
                                    <span style="font-weight: 600; margin-left: 0.5rem; color: var(--success-color);">R$ ${recommendation.take_profit.toFixed(2)}</span>
                                </div>
                            ` : ''}
                        </div>
                    ` : ''}
                </div>
            `;
        }
        
        container.innerHTML = html;
    }

    renderBacktestResults(container, results) {
        if (!container || !results) return;
        
        const totalReturn = results.total_return || 0;
        const returnClass = totalReturn >= 0 ? 'status-success' : 'status-danger';
        const winRate = results.total_trades > 0 ? (results.winning_trades / results.total_trades * 100) : 0;
        
        let html = `
            <div class="backtest-summary" style="margin-bottom: 1.5rem;">
                <h4 style="margin-bottom: 1rem; color: var(--accent-color);">
                    <i class="fas fa-chart-line"></i> Resultados do Backtesting
                </h4>
                
                <div style="display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); margin-bottom: 1rem;">
                    <div class="metric-card" style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem; text-align: center;">
                        <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 0.5rem;">Retorno Total</div>
                        <div class="${returnClass}" style="font-size: 1.2rem; font-weight: 700;">
                            ${totalReturn.toFixed(2)}%
                        </div>
                    </div>
                    
                    <div class="metric-card" style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem; text-align: center;">
                        <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 0.5rem;">Taxa de Acerto</div>
                        <div style="font-size: 1.2rem; font-weight: 700; color: var(--accent-color);">
                            ${winRate.toFixed(1)}%
                        </div>
                    </div>
                    
                    <div class="metric-card" style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem; text-align: center;">
                        <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 0.5rem;">Total de Trades</div>
                        <div style="font-size: 1.2rem; font-weight: 700;">
                            ${results.total_trades || 0}
                        </div>
                    </div>
                    
                    <div class="metric-card" style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem; text-align: center;">
                        <div style="font-size: 0.9rem; color: var(--text-secondary); margin-bottom: 0.5rem;">Max Drawdown</div>
                        <div style="font-size: 1.2rem; font-weight: 700; color: var(--danger-color);">
                            ${((results.max_drawdown || 0) * 100).toFixed(2)}%
                        </div>
                    </div>
                </div>
                
                <div style="display: grid; gap: 1rem; grid-template-columns: 1fr 1fr;">
                    <div>
                        <div style="color: var(--text-secondary); font-size: 0.9rem;">Capital Inicial:</div>
                        <div style="font-weight: 600;">R$ ${(results.initial_capital || 0).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</div>
                    </div>
                    <div>
                        <div style="color: var(--text-secondary); font-size: 0.9rem;">Capital Final:</div>
                        <div style="font-weight: 600;">R$ ${(results.final_capital || 0).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</div>
                    </div>
                </div>
            </div>
        `;
        
        if (results.trades && results.trades.length > 0) {
            html += `
                <div class="trades-history">
                    <h5 style="margin-bottom: 0.5rem;">Últimos Trades</h5>
                    <div style="max-height: 200px; overflow-y: auto;">
            `;
            
            results.trades.slice(-10).forEach(trade => {
                const profitClass = trade.profit >= 0 ? 'status-success' : 'status-danger';
                html += `
                    <div style="display: flex; justify-content: space-between; padding: 0.5rem; border-bottom: 1px solid var(--border-color);">
                        <span style="font-size: 0.9rem;">${trade.type}</span>
                        <span style="font-size: 0.9rem;">R$ ${trade.price.toFixed(2)}</span>
                        <span class="${profitClass}" style="font-size: 0.9rem; font-weight: 600;">
                            ${trade.profit >= 0 ? '+' : ''}${trade.profit.toFixed(2)}
                        </span>
                    </div>
                `;
            });
            
            html += '</div></div>';
        }
        
        container.innerHTML = html;
    }

    // Métodos auxiliares
    formatIndicatorValue(indicator) {
        if (!indicator || !indicator.values || indicator.values.length === 0) {
            return 'N/A';
        }
        
        const value = indicator.values[indicator.values.length - 1];
        
        if (typeof value === 'number') {
            return value.toFixed(2);
        }
        
        return value.toString();
    }

    getIndicatorSignal(key, indicator) {
        if (!indicator || !indicator.signals || indicator.signals.length === 0) {
            return 'Neutro';
        }
        
        const signal = indicator.signals[indicator.signals.length - 1];
        
        const signalMap = {
            'bullish': 'Compra',
            'bearish': 'Venda',
            'overbought': 'Sobrecomprado',
            'oversold': 'Sobrevendido',
            'neutral': 'Neutro'
        };
        
        return signalMap[signal] || signal;
    }

    getSignalClass(signal) {
        const classMap = {
            'buy': 'status-success',
            'sell': 'status-danger',
            'hold': 'status-warning',
            'Compra': 'status-success',
            'Venda': 'status-danger',
            'Neutro': 'status-warning',
            'Sobrecomprado': 'status-danger',
            'Sobrevendido': 'status-success'
        };
        
        return classMap[signal] || 'status-warning';
    }

    getIndicatorName(key) {
        const names = {
            'sma_short': 'SMA Curta',
            'sma_long': 'SMA Longa',
            'ema_fast': 'EMA Rápida',
            'ema_slow': 'EMA Lenta',
            'rsi': 'RSI',
            'macd': 'MACD',
            'bollinger': 'Bollinger',
            'stochastic': 'Stochastic',
            'williams_r': 'Williams %R',
            'atr': 'ATR',
            'adx': 'ADX'
        };
        
        return names[key] || key.toUpperCase();
    }

    getIndicatorDescription(key) {
        const descriptions = {
            'sma_short': 'Média móvel simples de curto prazo',
            'sma_long': 'Média móvel simples de longo prazo',
            'ema_fast': 'Média móvel exponencial rápida',
            'ema_slow': 'Média móvel exponencial lenta',
            'rsi': 'Índice de força relativa (0-100)',
            'macd': 'Convergência/divergência de médias',
            'bollinger': 'Bandas de Bollinger',
            'stochastic': 'Oscilador estocástico',
            'williams_r': 'Williams Percent Range',
            'atr': 'Average True Range',
            'adx': 'Average Directional Index'
        };
        
        return descriptions[key] || '';
    }

    getActionLabel(action) {
        const labels = {
            'buy': 'COMPRAR',
            'sell': 'VENDER',
            'hold': 'MANTER'
        };
        
        return labels[action] || action?.toUpperCase() || 'N/A';
    }

    getConfidenceLabel(confidence) {
        const labels = {
            'high': 'Alta',
            'medium': 'Média',
            'low': 'Baixa'
        };
        
        return labels[confidence] || confidence || 'N/A';
    }

    showNotification(message, type = 'info') {
        // Reutilizar sistema de notificações do AlertsManager
        if (window.alertsManager) {
            window.alertsManager.showNotification(message, type);
        } else {
            console.log(`[${type.toUpperCase()}] ${message}`);
        }
    }
}

// Instância global do gerenciador de análise técnica
let technicalAnalysisManager;

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    technicalAnalysisManager = new TechnicalAnalysisManager();
});

// Funções globais para integração com a interface
async function showTechnicalAnalysisFor(symbol) {
    if (!technicalAnalysisManager || !technicalAnalysisManager.isInitialized) {
        alert('Sistema de análise técnica não inicializado');
        return;
    }
    
    try {
        // Criar modal de análise técnica
        const modal = createTechnicalAnalysisModal(symbol);
        document.body.appendChild(modal);
        
        // Carregar dados
        await loadTechnicalAnalysisData(symbol);
        
    } catch (error) {
        console.error('Erro ao mostrar análise técnica:', error);
        alert('Erro ao carregar análise técnica');
    }
}

function createTechnicalAnalysisModal(symbol) {
    const modal = document.createElement('div');
    modal.id = 'technical-analysis-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.8);
        z-index: 1000;
        padding: 2rem;
        overflow-y: auto;
    `;
    
    modal.innerHTML = `
        <div style="background: var(--secondary-color); border-radius: 12px; max-width: 900px; margin: 0 auto; padding: 2rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2>Análise Técnica - ${symbol}</h2>
                <button onclick="closeTechnicalAnalysisModal()" style="background: none; border: none; color: var(--text-primary); font-size: 1.5rem; cursor: pointer;">×</button>
            </div>
            
            <div style="margin-bottom: 2rem;">
                <label style="display: block; margin-bottom: 0.5rem;">Estratégia:</label>
                <select id="strategy-select" onchange="changeStrategy()" class="search-input" style="width: 200px;">
                    <option value="swing_trading">Swing Trading</option>
                    <option value="day_trading">Day Trading</option>
                    <option value="long_term">Longo Prazo</option>
                    <option value="momentum">Momentum</option>
                    <option value="trend_following">Trend Following</option>
                </select>
            </div>
            
            <div id="analysis-content">
                <div class="loading">
                    <div class="spinner"></div>
                    Carregando análise técnica...
                </div>
            </div>
            
            <div style="margin-top: 2rem; display: flex; gap: 1rem;">
                <button class="btn btn-primary" onclick="runBacktestForSymbol()">
                    <i class="fas fa-chart-line"></i> Executar Backtesting
                </button>
                <button class="btn btn-secondary" onclick="createAlertFor('${symbol}')">
                    <i class="fas fa-bell"></i> Criar Alerta
                </button>
            </div>
            
            <div id="backtest-results" style="margin-top: 2rem;"></div>
        </div>
    `;
    
    return modal;
}

async function loadTechnicalAnalysisData(symbol) {
    const contentDiv = document.getElementById('analysis-content');
    const strategy = document.getElementById('strategy-select').value;
    
    try {
        // Carregar análise
        const analysis = await technicalAnalysisManager.getAnalysis(symbol, strategy);
        
        // Carregar indicadores
        const indicators = await technicalAnalysisManager.getIndicators(symbol);
        
        // Renderizar conteúdo
        let html = '<div style="display: grid; gap: 2rem;">';
        
        // Análise principal
        html += '<div id="main-analysis"></div>';
        
        // Indicadores
        html += '<div><h3 style="margin-bottom: 1rem;">Indicadores Técnicos</h3><div id="indicators-display"></div></div>';
        
        html += '</div>';
        
        contentDiv.innerHTML = html;
        
        // Renderizar componentes
        technicalAnalysisManager.renderAnalysis(document.getElementById('main-analysis'), analysis);
        technicalAnalysisManager.renderIndicators(document.getElementById('indicators-display'), indicators);
        
    } catch (error) {
        console.error('Erro ao carregar dados:', error);
        contentDiv.innerHTML = '<div class="error">Erro ao carregar análise técnica</div>';
    }
}

async function changeStrategy() {
    const symbol = technicalAnalysisManager.currentSymbol;
    if (symbol) {
        await loadTechnicalAnalysisData(symbol);
    }
}

async function runBacktestForSymbol() {
    const symbol = technicalAnalysisManager.currentSymbol;
    const strategy = document.getElementById('strategy-select').value;
    const resultsDiv = document.getElementById('backtest-results');
    
    if (!symbol) return;
    
    resultsDiv.innerHTML = '<div class="loading"><div class="spinner"></div>Executando backtesting...</div>';
    
    try {
        const results = await technicalAnalysisManager.runBacktest(symbol, strategy);
        technicalAnalysisManager.renderBacktestResults(resultsDiv, results);
        
    } catch (error) {
        console.error('Erro no backtesting:', error);
        resultsDiv.innerHTML = '<div class="error">Erro ao executar backtesting</div>';
    }
}

function closeTechnicalAnalysisModal() {
    const modal = document.getElementById('technical-analysis-modal');
    if (modal) {
        modal.remove();
    }
}

// Fechar modal ao clicar fora
document.addEventListener('click', function(event) {
    const modal = document.getElementById('technical-analysis-modal');
    if (event.target === modal) {
        closeTechnicalAnalysisModal();
    }
});

