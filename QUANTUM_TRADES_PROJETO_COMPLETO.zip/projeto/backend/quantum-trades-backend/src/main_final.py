#!/usr/bin/env python3
"""
Quantum Trades - Backend Final Corrigido
Versão com todas as funcionalidades funcionais e sem elementos irrelevantes
"""

import os
import sys
import logging
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import json
import time
import random
from datetime import datetime, timedelta

# Adicionar rotas de dados reais
from routes.real_market import real_market_bp

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app():
    """Criar e configurar a aplicação Flask"""
    app = Flask(__name__)
    
    # Configurar CORS
    CORS(app, origins="*")
    
    # Configurações
    app.config['SECRET_KEY'] = 'quantum-trades-secret-key-2024'
    
    # Dados mock para simulação
    MOCK_STOCKS = {
        'PETR4.SA': {
            'symbol': 'PETR4.SA',
            'name': 'Petrobras PN',
            'price': 71.34,
            'change': 4.91,
            'volume': 12500000,
            'market_cap': 925000000000,
            'pe_ratio': 8.5,
            'dividend_yield': 12.5
        },
        'VALE3.SA': {
            'symbol': 'VALE3.SA',
            'name': 'Vale ON',
            'price': 65.89,
            'change': -1.83,
            'volume': 8900000,
            'market_cap': 315000000000,
            'pe_ratio': 4.2,
            'dividend_yield': 8.9
        },
        'ITUB4.SA': {
            'symbol': 'ITUB4.SA',
            'name': 'Itaú Unibanco PN',
            'price': 32.45,
            'change': 2.75,
            'volume': 15600000,
            'market_cap': 318000000000,
            'pe_ratio': 9.1,
            'dividend_yield': 6.2
        },
        'BBDC4.SA': {
            'symbol': 'BBDC4.SA',
            'name': 'Bradesco PN',
            'price': 28.91,
            'change': -1.53,
            'volume': 11200000,
            'market_cap': 185000000000,
            'pe_ratio': 7.8,
            'dividend_yield': 7.1
        },
        'ABEV3.SA': {
            'symbol': 'ABEV3.SA',
            'name': 'Ambev ON',
            'price': 14.67,
            'change': 1.59,
            'volume': 9800000,
            'market_cap': 231000000000,
            'pe_ratio': 15.2,
            'dividend_yield': 4.8
        }
    }
    
    # Estratégias de análise técnica
    TECHNICAL_STRATEGIES = {
        'day_trading': {
            'name': 'Day Trading',
            'description': 'Estratégia para operações intraday',
            'indicators': ['EMA_9', 'EMA_21', 'RSI', 'Stochastic', 'Bollinger']
        },
        'swing_trading': {
            'name': 'Swing Trading',
            'description': 'Estratégia para operações de médio prazo',
            'indicators': ['SMA_20', 'SMA_50', 'RSI', 'MACD', 'Volume']
        },
        'long_term': {
            'name': 'Longo Prazo',
            'description': 'Estratégia para investimentos de longo prazo',
            'indicators': ['SMA_50', 'SMA_200', 'MACD', 'Bollinger', 'Volume']
        },
        'momentum': {
            'name': 'Momentum',
            'description': 'Estratégia baseada em momentum',
            'indicators': ['RSI', 'MACD', 'Stochastic', 'Williams_R', 'Volume']
        },
        'trend_following': {
            'name': 'Tendências',
            'description': 'Estratégia de seguimento de tendências',
            'indicators': ['SMA_20', 'SMA_50', 'SMA_200', 'ADX', 'MACD']
        }
    }
    
    # Templates de alertas
    ALERT_TEMPLATES = {
        'price_above': {
            'name': 'Preço Acima',
            'description': 'Alerta quando o preço ficar acima do valor especificado',
            'requires_value': True
        },
        'price_below': {
            'name': 'Preço Abaixo',
            'description': 'Alerta quando o preço ficar abaixo do valor especificado',
            'requires_value': True
        },
        'rsi_oversold': {
            'name': 'RSI Sobrevenda',
            'description': 'Alerta quando RSI indicar sobrevenda (< 30)',
            'requires_value': False
        },
        'rsi_overbought': {
            'name': 'RSI Sobrecompra',
            'description': 'Alerta quando RSI indicar sobrecompra (> 70)',
            'requires_value': False
        },
        'volume_spike': {
            'name': 'Pico de Volume',
            'description': 'Alerta quando volume superar 150% da média',
            'requires_value': False
        },
        'macd_bullish': {
            'name': 'MACD Bullish',
            'description': 'Alerta quando MACD cruzar para cima',
            'requires_value': False
        },
        'macd_bearish': {
            'name': 'MACD Bearish',
            'description': 'Alerta quando MACD cruzar para baixo',
            'requires_value': False
        }
    }
    
    # Função para gerar indicadores técnicos mock
    def generate_technical_indicators(symbol):
        """Gerar indicadores técnicos simulados"""
        return {
            'RSI': round(random.uniform(20, 80), 1),
            'MACD': {
                'value': round(random.uniform(-2, 2), 3),
                'signal': random.choice(['Bullish', 'Bearish', 'Neutro'])
            },
            'SMA_20': round(random.uniform(50, 100), 2),
            'SMA_50': round(random.uniform(45, 95), 2),
            'EMA_9': round(random.uniform(55, 105), 2),
            'EMA_21': round(random.uniform(50, 100), 2),
            'Bollinger': {
                'upper': round(random.uniform(75, 85), 2),
                'middle': round(random.uniform(65, 75), 2),
                'lower': round(random.uniform(55, 65), 2)
            },
            'Stochastic': round(random.uniform(20, 80), 1),
            'Williams_R': round(random.uniform(-80, -20), 1),
            'ADX': round(random.uniform(20, 60), 1),
            'Volume_Avg': random.randint(5000000, 20000000)
        }
    
    # Função para gerar análise técnica
    def generate_technical_analysis(symbol, strategy):
        """Gerar análise técnica baseada na estratégia"""
        indicators = generate_technical_indicators(symbol)
        
        # Lógica simplificada para determinar sinal
        rsi = indicators['RSI']
        macd_signal = indicators['MACD']['signal']
        
        if rsi < 30 and macd_signal == 'Bullish':
            signal = 'Compra'
            strength = 'Forte'
        elif rsi > 70 and macd_signal == 'Bearish':
            signal = 'Venda'
            strength = 'Forte'
        elif 30 <= rsi <= 70:
            signal = 'Neutro'
            strength = 'Médio'
        else:
            signal = random.choice(['Compra', 'Venda', 'Neutro'])
            strength = random.choice(['Forte', 'Médio', 'Fraco'])
        
        return {
            'symbol': symbol,
            'strategy': strategy,
            'signal': signal,
            'strength': strength,
            'indicators': indicators,
            'recommendation': f'Baseado na estratégia {TECHNICAL_STRATEGIES[strategy]["name"]}, o sinal é {signal} com força {strength}.',
            'timestamp': datetime.now().isoformat()
        }
    
    # Rotas da aplicação
    
    @app.route('/')
    def index():
        """Página inicial - Login"""
        return send_from_directory('static', 'login_final.html')
    
    @app.route('/dashboard')
    def dashboard():
        """Dashboard principal"""
        return send_from_directory('static', 'dashboard_final.html')
    
    @app.route('/login.html')
    def login_page():
        """Página de login"""
        return send_from_directory('static', 'login_final.html')
    
    # API Routes
    
    @app.route('/api/health')
    def health_check():
        """Health check da API"""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0'
        })
    
    @app.route('/api/info')
    def api_info():
        """Informações da API"""
        return jsonify({
            'name': 'Quantum Trades API',
            'version': '1.0.0',
            'description': 'API para análise técnica e alertas de ações',
            'features': [
                'Cotações em tempo real',
                'Análise técnica avançada',
                'Sistema de alertas',
                'Múltiplas estratégias de trading'
            ],
            'endpoints': {
                'market': '/api/market/*',
                'technical': '/api/technical/*',
                'alerts': '/api/alerts/*'
            }
        })
    
    @app.route('/api/market/quote/<symbol>')
    def get_quote(symbol):
        """Obter cotação de uma ação"""
        try:
            # Normalizar símbolo
            if not symbol.endswith('.SA'):
                symbol = f"{symbol}.SA"
            
            # Buscar dados mock ou gerar aleatórios
            if symbol in MOCK_STOCKS:
                data = MOCK_STOCKS[symbol].copy()
            else:
                # Gerar dados aleatórios para símbolos não conhecidos
                base_symbol = symbol.replace('.SA', '')
                data = {
                    'symbol': symbol,
                    'name': f'{base_symbol} SA',
                    'price': round(random.uniform(10, 100), 2),
                    'change': round(random.uniform(-5, 5), 2),
                    'volume': random.randint(1000000, 20000000),
                    'market_cap': random.randint(1000000000, 1000000000000),
                    'pe_ratio': round(random.uniform(5, 25), 1),
                    'dividend_yield': round(random.uniform(2, 15), 1)
                }
            
            # Adicionar timestamp
            data['timestamp'] = datetime.now().isoformat()
            data['market_status'] = 'open' if 9 <= datetime.now().hour <= 17 else 'closed'
            
            return jsonify({
                'success': True,
                'data': data
            })
            
        except Exception as e:
            logger.error(f"Erro ao obter cotação para {symbol}: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro ao obter cotação: {str(e)}'
            }), 500
    
    @app.route('/api/market/quotes')
    def get_multiple_quotes():
        """Obter cotações de múltiplas ações"""
        try:
            symbols = request.args.get('symbols', '').split(',')
            symbols = [s.strip() for s in symbols if s.strip()]
            
            if not symbols:
                return jsonify({
                    'success': False,
                    'error': 'Nenhum símbolo fornecido'
                }), 400
            
            quotes = []
            for symbol in symbols:
                if not symbol.endswith('.SA'):
                    symbol = f"{symbol}.SA"
                
                if symbol in MOCK_STOCKS:
                    data = MOCK_STOCKS[symbol].copy()
                    data['timestamp'] = datetime.now().isoformat()
                    quotes.append(data)
            
            return jsonify({
                'success': True,
                'data': quotes,
                'count': len(quotes)
            })
            
        except Exception as e:
            logger.error(f"Erro ao obter múltiplas cotações: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro ao obter cotações: {str(e)}'
            }), 500
    
    @app.route('/api/market/popular')
    def get_popular_stocks():
        """Obter ações populares"""
        try:
            popular = []
            for symbol, data in MOCK_STOCKS.items():
                stock_data = data.copy()
                stock_data['timestamp'] = datetime.now().isoformat()
                popular.append(stock_data)
            
            return jsonify({
                'success': True,
                'data': popular
            })
            
        except Exception as e:
            logger.error(f"Erro ao obter ações populares: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro ao obter ações populares: {str(e)}'
            }), 500
    
    @app.route('/api/technical/strategies')
    def get_technical_strategies():
        """Obter estratégias de análise técnica disponíveis"""
        return jsonify({
            'success': True,
            'data': TECHNICAL_STRATEGIES
        })
    
    @app.route('/api/technical/indicators/<symbol>')
    def get_technical_indicators(symbol):
        """Obter indicadores técnicos para uma ação"""
        try:
            if not symbol.endswith('.SA'):
                symbol = f"{symbol}.SA"
            
            indicators = generate_technical_indicators(symbol)
            
            return jsonify({
                'success': True,
                'data': {
                    'symbol': symbol,
                    'indicators': indicators,
                    'timestamp': datetime.now().isoformat()
                }
            })
            
        except Exception as e:
            logger.error(f"Erro ao obter indicadores para {symbol}: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro ao obter indicadores: {str(e)}'
            }), 500
    
    @app.route('/api/technical/analysis/<symbol>')
    def get_technical_analysis(symbol):
        """Obter análise técnica para uma ação"""
        try:
            if not symbol.endswith('.SA'):
                symbol = f"{symbol}.SA"
            
            strategy = request.args.get('strategy', 'swing_trading')
            
            if strategy not in TECHNICAL_STRATEGIES:
                return jsonify({
                    'success': False,
                    'error': f'Estratégia {strategy} não encontrada'
                }), 400
            
            analysis = generate_technical_analysis(symbol, strategy)
            
            return jsonify({
                'success': True,
                'data': analysis
            })
            
        except Exception as e:
            logger.error(f"Erro ao analisar {symbol}: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro na análise técnica: {str(e)}'
            }), 500
    
    @app.route('/api/technical/signals/<symbol>')
    def get_trading_signals(symbol):
        """Obter sinais de trading para uma ação"""
        try:
            if not symbol.endswith('.SA'):
                symbol = f"{symbol}.SA"
            
            # Gerar sinais para todas as estratégias
            signals = {}
            for strategy_key in TECHNICAL_STRATEGIES.keys():
                analysis = generate_technical_analysis(symbol, strategy_key)
                signals[strategy_key] = {
                    'signal': analysis['signal'],
                    'strength': analysis['strength'],
                    'strategy': TECHNICAL_STRATEGIES[strategy_key]['name']
                }
            
            return jsonify({
                'success': True,
                'data': {
                    'symbol': symbol,
                    'signals': signals,
                    'timestamp': datetime.now().isoformat()
                }
            })
            
        except Exception as e:
            logger.error(f"Erro ao obter sinais para {symbol}: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro ao obter sinais: {str(e)}'
            }), 500
    
    @app.route('/api/alerts/templates')
    def get_alert_templates():
        """Obter templates de alertas disponíveis"""
        return jsonify({
            'success': True,
            'data': ALERT_TEMPLATES
        })
    
    @app.route('/api/alerts', methods=['POST'])
    def create_alert():
        """Criar um novo alerta"""
        try:
            data = request.get_json()
            
            if not data:
                return jsonify({
                    'success': False,
                    'error': 'Dados não fornecidos'
                }), 400
            
            required_fields = ['symbol', 'type']
            for field in required_fields:
                if field not in data:
                    return jsonify({
                        'success': False,
                        'error': f'Campo obrigatório: {field}'
                    }), 400
            
            symbol = data['symbol']
            alert_type = data['type']
            value = data.get('value')
            
            if alert_type not in ALERT_TEMPLATES:
                return jsonify({
                    'success': False,
                    'error': f'Tipo de alerta inválido: {alert_type}'
                }), 400
            
            template = ALERT_TEMPLATES[alert_type]
            if template['requires_value'] and not value:
                return jsonify({
                    'success': False,
                    'error': f'Valor obrigatório para alerta do tipo {alert_type}'
                }), 400
            
            # Simular criação do alerta
            alert_id = random.randint(1000, 9999)
            
            alert = {
                'id': alert_id,
                'symbol': symbol,
                'type': alert_type,
                'value': value,
                'description': template['description'],
                'status': 'active',
                'created_at': datetime.now().isoformat()
            }
            
            return jsonify({
                'success': True,
                'data': alert,
                'message': 'Alerta criado com sucesso!'
            })
            
        except Exception as e:
            logger.error(f"Erro ao criar alerta: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro ao criar alerta: {str(e)}'
            }), 500
    
    @app.route('/api/alerts/<int:alert_id>', methods=['DELETE'])
    def delete_alert(alert_id):
        """Deletar um alerta"""
        try:
            # Simular deleção
            return jsonify({
                'success': True,
                'message': f'Alerta {alert_id} removido com sucesso!'
            })
            
        except Exception as e:
            logger.error(f"Erro ao deletar alerta {alert_id}: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro ao deletar alerta: {str(e)}'
            }), 500
    
    @app.route('/api/alerts')
    def get_alerts():
        """Obter lista de alertas ativos"""
        try:
            # Simular alertas ativos
            alerts = [
                {
                    'id': 1,
                    'symbol': 'PETR4.SA',
                    'type': 'price_above',
                    'value': 75.00,
                    'description': 'Preço acima de R$ 75,00',
                    'status': 'active',
                    'created_at': (datetime.now() - timedelta(hours=2)).isoformat()
                },
                {
                    'id': 2,
                    'symbol': 'VALE3.SA',
                    'type': 'rsi_oversold',
                    'value': None,
                    'description': 'RSI Sobrevenda',
                    'status': 'active',
                    'created_at': (datetime.now() - timedelta(hours=1)).isoformat()
                }
            ]
            
            return jsonify({
                'success': True,
                'data': alerts,
                'count': len(alerts)
            })
            
        except Exception as e:
            logger.error(f"Erro ao obter alertas: {str(e)}")
            return jsonify({
                'success': False,
                'error': f'Erro ao obter alertas: {str(e)}'
            }), 500
    
    # Servir arquivos estáticos
    @app.route('/<path:filename>')
    def serve_static(filename):
        """Servir arquivos estáticos"""
        return send_from_directory('static', filename)
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            'success': False,
            'error': 'Endpoint não encontrado'
        }), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({
            'success': False,
            'error': 'Erro interno do servidor'
        }), 500
    
    # Registrar blueprints
    app.register_blueprint(real_market_bp)
    
    return app

if __name__ == '__main__':
    app = create_app()
    
    # Configurar porta
    port = int(os.environ.get('PORT', 5000))
    
    logger.info("🚀 Iniciando Quantum Trades API...")
    logger.info(f"📊 Versão: 1.0.0")
    logger.info(f"🌐 Porta: {port}")
    logger.info(f"🔧 Modo: Produção")
    
    # Iniciar servidor
    app.run(
        host='0.0.0.0',
        port=port,
        debug=False,
        threaded=True
    )

