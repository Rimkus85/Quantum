#!/usr/bin/env python3
"""
Teste da API Yahoo Finance para ações brasileiras
"""

import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient
import json

def test_brazilian_stocks():
    """Testa a API com ações brasileiras populares"""
    client = ApiClient()
    
    # Lista de ações brasileiras para testar
    brazilian_stocks = [
        'PETR4.SA',  # Petrobras
        'VALE3.SA',  # Vale
        'ITUB4.SA',  # Itaú
        'BBDC4.SA',  # Bradesco
        'ABEV3.SA',  # Ambev
    ]
    
    print("🔍 Testando API Yahoo Finance com ações brasileiras...")
    print("=" * 60)
    
    for symbol in brazilian_stocks:
        try:
            print(f"\n📊 Buscando dados para {symbol}...")
            
            # Buscar dados do gráfico (inclui preço atual e meta dados)
            response = client.call_api('YahooFinance/get_stock_chart', query={
                'symbol': symbol,
                'region': 'BR',
                'interval': '1d',
                'range': '1d'
            })
            
            if response and 'chart' in response and response['chart']['result']:
                result = response['chart']['result'][0]
                meta = result['meta']
                
                print(f"✅ {symbol} - {meta.get('longName', 'N/A')}")
                print(f"   Preço: R$ {meta.get('regularMarketPrice', 0):.2f}")
                print(f"   Volume: {meta.get('regularMarketVolume', 0):,}")
                print(f"   Moeda: {meta.get('currency', 'N/A')}")
                print(f"   Bolsa: {meta.get('fullExchangeName', 'N/A')}")
                
                # Calcular variação percentual
                current_price = meta.get('regularMarketPrice', 0)
                previous_close = meta.get('chartPreviousClose', 0)
                if previous_close > 0:
                    change_percent = ((current_price - previous_close) / previous_close) * 100
                    print(f"   Variação: {change_percent:+.2f}%")
                
            else:
                print(f"❌ Erro ao buscar dados para {symbol}")
                
        except Exception as e:
            print(f"❌ Erro para {symbol}: {str(e)}")
    
    print("\n" + "=" * 60)
    print("✅ Teste concluído!")

if __name__ == "__main__":
    test_brazilian_stocks()

