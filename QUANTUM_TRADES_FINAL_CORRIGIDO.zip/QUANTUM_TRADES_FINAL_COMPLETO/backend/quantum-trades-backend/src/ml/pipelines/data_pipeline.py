"""
Pipeline de Dados para Machine Learning - Quantum Trades
Sprint 5 - Sistema de coleta, processamento e preparação de dados para IA
"""

import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import requests
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataPipeline:
    """
    Pipeline principal para coleta e processamento de dados financeiros para ML.
    """
    
    def __init__(self, cache_service=None):
        self.cache_service = cache_service
        self.data_sources = {
            'yahoo_finance': YahooFinanceCollector(),
            'brapi': BrapiCollector(),
            'news': NewsCollector(),
            'social': SocialMediaCollector()
        }
        self.processors = {
            'technical': TechnicalDataProcessor(),
            'fundamental': FundamentalDataProcessor(),
            'sentiment': SentimentDataProcessor(),
            'volume': VolumeDataProcessor()
        }
        
        logger.info("Pipeline de dados inicializado")
    
    def collect_training_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Coleta dados completos para treinamento de modelos.
        """
        try:
            logger.info(f"Coletando dados de treinamento para {symbol} de {start_date} até {end_date}")
            
            # Coletar dados de preços
            price_data = self._collect_price_data(symbol, start_date, end_date)
            if price_data.empty:
                logger.error(f"Nenhum dado de preço encontrado para {symbol}")
                return pd.DataFrame()
            
            # Processar indicadores técnicos
            technical_data = self.processors['technical'].process(price_data)
            
            # Coletar dados de volume
            volume_data = self.processors['volume'].process(price_data)
            
            # Combinar todos os dados
            combined_data = self._combine_datasets([technical_data, volume_data])
            
            # Coletar dados de sentimento (se disponível)
            try:
                sentiment_data = self._collect_sentiment_data(symbol, start_date, end_date)
                if not sentiment_data.empty:
                    combined_data = self._merge_sentiment_data(combined_data, sentiment_data)
            except Exception as e:
                logger.warning(f"Erro ao coletar dados de sentimento: {e}")
            
            # Limpeza final dos dados
            cleaned_data = self._clean_data(combined_data)
            
            logger.info(f"Dados coletados: {len(cleaned_data)} registros, {len(cleaned_data.columns)} features")
            return cleaned_data
            
        except Exception as e:
            logger.error(f"Erro na coleta de dados de treinamento: {e}")
            return pd.DataFrame()
    
    def collect_realtime_data(self, symbol: str) -> Dict[str, Any]:
        """
        Coleta dados em tempo real para predições.
        """
        try:
            # Verificar cache primeiro
            cache_key = f"realtime_data_{symbol}"
            if self.cache_service:
                cached_data = self.cache_service.get(cache_key)
                if cached_data:
                    return cached_data
            
            # Coletar dados recentes (últimos 100 períodos)
            end_date = datetime.now()
            start_date = end_date - timedelta(days=200)  # Margem para feriados/fins de semana
            
            recent_data = self.collect_training_data(symbol, start_date, end_date)
            if recent_data.empty:
                return {}
            
            # Pegar apenas os dados mais recentes necessários
            latest_data = recent_data.tail(100)
            
            # Preparar dados para predição
            realtime_features = self._prepare_realtime_features(latest_data)
            
            # Cache por 5 minutos
            if self.cache_service:
                self.cache_service.set(cache_key, realtime_features, timeout=300)
            
            return realtime_features
            
        except Exception as e:
            logger.error(f"Erro na coleta de dados em tempo real: {e}")
            return {}
    
    def _collect_price_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Coleta dados de preços de múltiplas fontes.
        """
        try:
            # Tentar Yahoo Finance primeiro
            yahoo_data = self.data_sources['yahoo_finance'].get_data(symbol, start_date, end_date)
            if not yahoo_data.empty:
                return yahoo_data
            
            # Fallback para Brapi
            brapi_data = self.data_sources['brapi'].get_data(symbol, start_date, end_date)
            return brapi_data
            
        except Exception as e:
            logger.error(f"Erro ao coletar dados de preços: {e}")
            return pd.DataFrame()
    
    def _collect_sentiment_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Coleta dados de sentimento para o período especificado.
        """
        try:
            # Coletar notícias
            news_data = self.data_sources['news'].get_data(symbol, start_date, end_date)
            
            # Coletar dados de redes sociais
            social_data = self.data_sources['social'].get_data(symbol, start_date, end_date)
            
            # Combinar e processar sentimento
            all_text_data = pd.concat([news_data, social_data], ignore_index=True)
            
            if not all_text_data.empty:
                sentiment_processed = self.processors['sentiment'].process(all_text_data)
                return sentiment_processed
            
            return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Erro ao coletar dados de sentimento: {e}")
            return pd.DataFrame()
    
    def _combine_datasets(self, datasets: List[pd.DataFrame]) -> pd.DataFrame:
        """
        Combina múltiplos datasets em um único DataFrame.
        """
        try:
            if not datasets or all(df.empty for df in datasets):
                return pd.DataFrame()
            
            # Filtrar datasets vazios
            valid_datasets = [df for df in datasets if not df.empty]
            
            if len(valid_datasets) == 1:
                return valid_datasets[0]
            
            # Combinar por timestamp/index
            combined = valid_datasets[0]
            for df in valid_datasets[1:]:
                combined = pd.merge(combined, df, left_index=True, right_index=True, how='outer')
            
            return combined
            
        except Exception as e:
            logger.error(f"Erro ao combinar datasets: {e}")
            return pd.DataFrame()
    
    def _merge_sentiment_data(self, price_data: pd.DataFrame, sentiment_data: pd.DataFrame) -> pd.DataFrame:
        """
        Mescla dados de sentimento com dados de preços.
        """
        try:
            # Agrupar sentimento por dia
            daily_sentiment = sentiment_data.groupby(sentiment_data.index.date).agg({
                'sentiment_score': 'mean',
                'confidence_score': 'mean',
                'impact_score': 'mean'
            })
            
            # Converter índice para datetime
            daily_sentiment.index = pd.to_datetime(daily_sentiment.index)
            
            # Merge com dados de preços
            merged = pd.merge(price_data, daily_sentiment, left_index=True, right_index=True, how='left')
            
            # Preencher valores ausentes de sentimento
            merged['sentiment_score'] = merged['sentiment_score'].fillna(0)
            merged['confidence_score'] = merged['confidence_score'].fillna(0.5)
            merged['impact_score'] = merged['impact_score'].fillna(0)
            
            return merged
            
        except Exception as e:
            logger.error(f"Erro ao mesclar dados de sentimento: {e}")
            return price_data
    
    def _clean_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Limpa e valida os dados coletados.
        """
        try:
            if data.empty:
                return data
            
            # Remover linhas com muitos valores ausentes
            threshold = len(data.columns) * 0.5  # 50% dos valores devem estar presentes
            cleaned = data.dropna(thresh=threshold)
            
            # Preencher valores ausentes restantes
            numeric_columns = cleaned.select_dtypes(include=[np.number]).columns
            cleaned[numeric_columns] = cleaned[numeric_columns].fillna(method='ffill').fillna(method='bfill')
            
            # Remover outliers extremos (valores > 5 desvios padrão)
            for col in numeric_columns:
                if col in ['volume', 'volume_ratio']:  # Pular colunas de volume que podem ter outliers legítimos
                    continue
                
                mean = cleaned[col].mean()
                std = cleaned[col].std()
                if std > 0:
                    outlier_mask = np.abs(cleaned[col] - mean) > 5 * std
                    cleaned.loc[outlier_mask, col] = np.nan
                    cleaned[col] = cleaned[col].fillna(method='ffill').fillna(method='bfill')
            
            # Remover linhas duplicadas
            cleaned = cleaned.drop_duplicates()
            
            # Ordenar por timestamp
            cleaned = cleaned.sort_index()
            
            logger.info(f"Dados limpos: {len(cleaned)} registros mantidos de {len(data)} originais")
            return cleaned
            
        except Exception as e:
            logger.error(f"Erro na limpeza de dados: {e}")
            return data
    
    def _prepare_realtime_features(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Prepara features para predição em tempo real.
        """
        try:
            if data.empty:
                return {}
            
            latest_row = data.iloc[-1]
            
            # Features básicas
            features = {
                'timestamp': latest_row.name.isoformat() if hasattr(latest_row.name, 'isoformat') else str(latest_row.name),
                'close': float(latest_row.get('close', 0)),
                'volume': float(latest_row.get('volume', 0)),
                'high': float(latest_row.get('high', 0)),
                'low': float(latest_row.get('low', 0)),
                'open': float(latest_row.get('open', 0))
            }
            
            # Indicadores técnicos
            technical_features = {}
            for col in data.columns:
                if any(indicator in col.lower() for indicator in ['sma', 'ema', 'rsi', 'macd', 'bb_']):
                    value = latest_row.get(col)
                    if pd.notna(value):
                        technical_features[col] = float(value)
            
            features['technical_indicators'] = technical_features
            
            # Features de sentimento (se disponíveis)
            sentiment_features = {}
            for col in data.columns:
                if 'sentiment' in col.lower():
                    value = latest_row.get(col)
                    if pd.notna(value):
                        sentiment_features[col] = float(value)
            
            if sentiment_features:
                features['sentiment'] = sentiment_features
            
            # Histórico recente para modelos sequenciais
            recent_history = data.tail(50)  # Últimos 50 períodos
            features['price_history'] = recent_history['close'].tolist()
            features['volume_history'] = recent_history['volume'].tolist()
            
            return features
            
        except Exception as e:
            logger.error(f"Erro ao preparar features em tempo real: {e}")
            return {}

class YahooFinanceCollector:
    """
    Coletor de dados do Yahoo Finance.
    """
    
    def __init__(self):
        self.base_url = "https://query1.finance.yahoo.com/v8/finance/chart/"
    
    def get_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Coleta dados do Yahoo Finance.
        """
        try:
            # Converter datas para timestamp
            start_timestamp = int(start_date.timestamp())
            end_timestamp = int(end_date.timestamp())
            
            # Construir URL
            url = f"{self.base_url}{symbol}"
            params = {
                'period1': start_timestamp,
                'period2': end_timestamp,
                'interval': '1d',
                'includePrePost': 'false'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if 'chart' not in data or not data['chart']['result']:
                logger.warning(f"Nenhum dado encontrado para {symbol}")
                return pd.DataFrame()
            
            result = data['chart']['result'][0]
            timestamps = result['timestamp']
            quotes = result['indicators']['quote'][0]
            
            # Criar DataFrame
            df = pd.DataFrame({
                'timestamp': pd.to_datetime(timestamps, unit='s'),
                'open': quotes['open'],
                'high': quotes['high'],
                'low': quotes['low'],
                'close': quotes['close'],
                'volume': quotes['volume']
            })
            
            # Limpar dados inválidos
            df = df.dropna()
            df = df.set_index('timestamp')
            
            return df
            
        except Exception as e:
            logger.error(f"Erro ao coletar dados do Yahoo Finance: {e}")
            return pd.DataFrame()

class BrapiCollector:
    """
    Coletor de dados da API Brapi (backup).
    """
    
    def __init__(self):
        self.base_url = "https://brapi.dev/api/quote/"
    
    def get_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Coleta dados da Brapi.
        """
        try:
            # Brapi tem limitações, então vamos coletar dados recentes
            url = f"{self.base_url}{symbol}"
            params = {
                'range': '1y',  # Último ano
                'interval': '1d'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if 'results' not in data or not data['results']:
                return pd.DataFrame()
            
            result = data['results'][0]
            if 'historicalDataPrice' not in result:
                return pd.DataFrame()
            
            historical_data = result['historicalDataPrice']
            
            # Converter para DataFrame
            df = pd.DataFrame(historical_data)
            df['timestamp'] = pd.to_datetime(df['date'])
            df = df.set_index('timestamp')
            
            # Filtrar por período solicitado
            df = df[(df.index >= start_date) & (df.index <= end_date)]
            
            return df
            
        except Exception as e:
            logger.error(f"Erro ao coletar dados da Brapi: {e}")
            return pd.DataFrame()

class NewsCollector:
    """
    Coletor de notícias financeiras.
    """
    
    def get_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Coleta notícias relacionadas ao símbolo.
        """
        try:
            # Implementação simplificada - em produção usaria APIs de notícias
            # Por enquanto, retorna DataFrame vazio
            logger.info(f"Coletando notícias para {symbol}")
            return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Erro ao coletar notícias: {e}")
            return pd.DataFrame()

class SocialMediaCollector:
    """
    Coletor de dados de redes sociais.
    """
    
    def get_data(self, symbol: str, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """
        Coleta dados de redes sociais.
        """
        try:
            # Implementação simplificada - em produção usaria APIs do Twitter, etc.
            logger.info(f"Coletando dados de redes sociais para {symbol}")
            return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Erro ao coletar dados de redes sociais: {e}")
            return pd.DataFrame()

class TechnicalDataProcessor:
    """
    Processador de dados técnicos.
    """
    
    def process(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Processa dados técnicos e calcula indicadores.
        """
        try:
            from ..engines.base_ml_engine import FeatureEngineer
            
            # Calcular indicadores técnicos
            processed_data = FeatureEngineer.calculate_technical_indicators(data)
            
            # Adicionar features de lag
            lag_columns = ['close', 'volume', 'rsi', 'macd']
            processed_data = FeatureEngineer.create_lag_features(
                processed_data, lag_columns, [1, 2, 3, 5, 10]
            )
            
            # Adicionar rolling features
            rolling_columns = ['close', 'volume']
            processed_data = FeatureEngineer.create_rolling_features(
                processed_data, rolling_columns, [5, 10, 20]
            )
            
            return processed_data
            
        except Exception as e:
            logger.error(f"Erro no processamento técnico: {e}")
            return data

class FundamentalDataProcessor:
    """
    Processador de dados fundamentais.
    """
    
    def process(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Processa dados fundamentais.
        """
        # Implementação futura para dados fundamentais
        return data

class SentimentDataProcessor:
    """
    Processador de dados de sentimento.
    """
    
    def process(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Processa dados de sentimento.
        """
        # Implementação futura para análise de sentimento
        return data

class VolumeDataProcessor:
    """
    Processador de dados de volume.
    """
    
    def process(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Processa dados de volume e adiciona indicadores relacionados.
        """
        try:
            df = data.copy()
            
            # Volume moving averages
            df['volume_sma_10'] = df['volume'].rolling(window=10).mean()
            df['volume_sma_20'] = df['volume'].rolling(window=20).mean()
            
            # Volume ratios
            df['volume_ratio_10'] = df['volume'] / df['volume_sma_10']
            df['volume_ratio_20'] = df['volume'] / df['volume_sma_20']
            
            # Price-Volume indicators
            df['price_volume'] = df['close'] * df['volume']
            df['vwap'] = df['price_volume'].rolling(window=20).sum() / df['volume'].rolling(window=20).sum()
            
            # Volume trend
            df['volume_trend'] = df['volume'].rolling(window=5).mean() / df['volume'].rolling(window=20).mean()
            
            return df
            
        except Exception as e:
            logger.error(f"Erro no processamento de volume: {e}")
            return data

