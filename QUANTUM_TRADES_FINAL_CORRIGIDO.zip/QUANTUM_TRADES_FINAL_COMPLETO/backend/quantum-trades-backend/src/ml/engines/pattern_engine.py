"""
Engine de Detecção de Padrões Técnicos - Quantum Trades
Sprint 5 - Épico 1: Detecção automática de padrões técnicos clássicos e novos
"""

import numpy as np
import pandas as pd
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from scipy import signal
from scipy.stats import linregress
import json

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    from sklearn.cluster import DBSCAN
    from sklearn.preprocessing import StandardScaler
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

from .base_ml_engine import BaseMLEngine
from ..pipelines.data_pipeline import DataPipeline

class PatternEngine(BaseMLEngine):
    """
    Engine para detecção automática de padrões técnicos em dados financeiros.
    """
    
    def __init__(self):
        super().__init__("PatternEngine", "1.0.0")
        self.data_pipeline = DataPipeline()
        
        # Configurações de padrões
        self.pattern_configs = {
            'support_resistance': {'min_touches': 3, 'tolerance': 0.02},
            'trend_lines': {'min_points': 5, 'r_squared_threshold': 0.7},
            'triangles': {'min_length': 20, 'convergence_threshold': 0.1},
            'head_shoulders': {'shoulder_tolerance': 0.05, 'neckline_tolerance': 0.02},
            'double_patterns': {'peak_tolerance': 0.03, 'valley_tolerance': 0.03},
            'flags_pennants': {'pole_min_length': 10, 'consolidation_max_length': 15},
            'wedges': {'min_length': 15, 'angle_threshold': 0.1},
            'channels': {'parallel_tolerance': 0.02, 'min_length': 20}
        }
        
        # Histórico de sucesso dos padrões
        self.pattern_success_rates = {
            'ascending_triangle': 0.72,
            'descending_triangle': 0.68,
            'symmetrical_triangle': 0.65,
            'head_and_shoulders': 0.78,
            'inverse_head_shoulders': 0.75,
            'double_top': 0.70,
            'double_bottom': 0.73,
            'bull_flag': 0.68,
            'bear_flag': 0.66,
            'rising_wedge': 0.64,
            'falling_wedge': 0.67,
            'ascending_channel': 0.60,
            'descending_channel': 0.62,
            'support_level': 0.75,
            'resistance_level': 0.73
        }
        
        logger.info("Engine de Detecção de Padrões inicializado")
    
    def prepare_features(self, data: pd.DataFrame) -> np.ndarray:
        """
        Prepara features para detecção de padrões.
        """
        try:
            # Features básicas para detecção de padrões
            features = []
            
            # Preços normalizados
            close_norm = (data['close'] - data['close'].min()) / (data['close'].max() - data['close'].min())
            features.extend(close_norm.values)
            
            # Volumes normalizados
            if 'volume' in data.columns:
                volume_norm = (data['volume'] - data['volume'].min()) / (data['volume'].max() - data['volume'].min())
                features.extend(volume_norm.values)
            
            return np.array(features).reshape(-1, 1)
            
        except Exception as e:
            logger.error(f"Erro ao preparar features para padrões: {e}")
            return np.array([])
    
    def train(self, training_data: pd.DataFrame, target: pd.Series) -> Dict[str, Any]:
        """
        Treina algoritmos de detecção de padrões.
        """
        try:
            logger.info("Treinando detectores de padrões")
            
            # Para padrões técnicos, o "treinamento" é mais sobre calibração
            # dos parâmetros de detecção baseado em dados históricos
            
            results = {}
            
            # Calibrar parâmetros de suporte e resistência
            sr_results = self._calibrate_support_resistance(training_data)
            results['support_resistance'] = sr_results
            
            # Calibrar detecção de tendências
            trend_results = self._calibrate_trend_detection(training_data)
            results['trend_detection'] = trend_results
            
            # Calibrar detecção de triângulos
            triangle_results = self._calibrate_triangle_detection(training_data)
            results['triangle_detection'] = triangle_results
            
            self.is_trained = True
            self.last_training_date = datetime.now()
            
            logger.info("Calibração de padrões concluída")
            return results
            
        except Exception as e:
            logger.error(f"Erro no treinamento de padrões: {e}")
            return {'error': str(e)}
    
    def predict(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Detecta padrões nos dados fornecidos.
        """
        try:
            if data.empty:
                return {'patterns': []}
            
            patterns = []
            
            # Detectar suporte e resistência
            sr_patterns = self._detect_support_resistance(data)
            patterns.extend(sr_patterns)
            
            # Detectar triângulos
            triangle_patterns = self._detect_triangles(data)
            patterns.extend(triangle_patterns)
            
            # Detectar padrões de cabeça e ombros
            hs_patterns = self._detect_head_shoulders(data)
            patterns.extend(hs_patterns)
            
            # Detectar padrões duplos
            double_patterns = self._detect_double_patterns(data)
            patterns.extend(double_patterns)
            
            # Detectar bandeiras e flâmulas
            flag_patterns = self._detect_flags_pennants(data)
            patterns.extend(flag_patterns)
            
            # Detectar cunhas
            wedge_patterns = self._detect_wedges(data)
            patterns.extend(wedge_patterns)
            
            # Detectar canais
            channel_patterns = self._detect_channels(data)
            patterns.extend(channel_patterns)
            
            return {'patterns': patterns}
            
        except Exception as e:
            logger.error(f"Erro na detecção de padrões: {e}")
            return {'error': str(e)}
    
    def detect_patterns(self, symbol: str, timeframe: str, confidence_threshold: float = 0.7) -> List[Dict[str, Any]]:
        """
        Detecta padrões para um símbolo específico.
        """
        try:
            # Coletar dados históricos
            end_date = datetime.now()
            start_date = end_date - timedelta(days=200)  # 200 dias de histórico
            
            training_data = self.data_pipeline.collect_training_data(symbol, start_date, end_date)
            if training_data.empty:
                return []
            
            # Detectar padrões
            detection_result = self.predict(training_data)
            
            if 'error' in detection_result:
                return []
            
            patterns = detection_result.get('patterns', [])
            
            # Filtrar por confiança
            filtered_patterns = [
                pattern for pattern in patterns 
                if pattern.get('confidence', 0) >= confidence_threshold
            ]
            
            # Adicionar informações adicionais
            for pattern in filtered_patterns:
                pattern['symbol'] = symbol
                pattern['timeframe'] = timeframe
                pattern['detected_at'] = datetime.now().isoformat()
                
                # Adicionar taxa de sucesso histórica
                pattern_type = pattern.get('type', 'unknown')
                pattern['historical_success_rate'] = self.pattern_success_rates.get(pattern_type, 0.5)
                
                # Calcular targets e stop-loss
                targets = self._calculate_pattern_targets(pattern, training_data)
                pattern.update(targets)
            
            return filtered_patterns
            
        except Exception as e:
            logger.error(f"Erro na detecção de padrões para {symbol}: {e}")
            return []
    
    def _detect_support_resistance(self, data: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Detecta níveis de suporte e resistência.
        """
        patterns = []
        
        try:
            prices = data['close'].values
            timestamps = data.index
            
            # Encontrar picos e vales
            peaks, _ = signal.find_peaks(prices, distance=5)
            valleys, _ = signal.find_peaks(-prices, distance=5)
            
            # Agrupar picos similares (resistência)
            if len(peaks) >= 3:
                peak_prices = prices[peaks]
                peak_times = timestamps[peaks]
                
                resistance_levels = self._find_similar_levels(peak_prices, peak_times, 'resistance')
                patterns.extend(resistance_levels)
            
            # Agrupar vales similares (suporte)
            if len(valleys) >= 3:
                valley_prices = prices[valleys]
                valley_times = timestamps[valleys]
                
                support_levels = self._find_similar_levels(valley_prices, valley_times, 'support')
                patterns.extend(support_levels)
            
        except Exception as e:
            logger.error(f"Erro na detecção de suporte/resistência: {e}")
        
        return patterns
    
    def _find_similar_levels(self, prices: np.ndarray, times: pd.DatetimeIndex, level_type: str) -> List[Dict[str, Any]]:
        """
        Encontra níveis similares de preço.
        """
        levels = []
        
        try:
            if not SKLEARN_AVAILABLE:
                return levels
            
            # Clustering de preços similares
            prices_reshaped = prices.reshape(-1, 1)
            scaler = StandardScaler()
            prices_scaled = scaler.fit_transform(prices_reshaped)
            
            clustering = DBSCAN(eps=0.3, min_samples=3).fit(prices_scaled)
            labels = clustering.labels_
            
            # Para cada cluster
            for label in set(labels):
                if label == -1:  # Ruído
                    continue
                
                cluster_mask = labels == label
                cluster_prices = prices[cluster_mask]
                cluster_times = times[cluster_mask]
                
                if len(cluster_prices) >= 3:  # Mínimo 3 toques
                    avg_price = np.mean(cluster_prices)
                    price_std = np.std(cluster_prices)
                    
                    # Calcular confiança baseada na consistência
                    confidence = max(0.5, 1.0 - (price_std / avg_price))
                    
                    levels.append({
                        'type': f'{level_type}_level',
                        'name': f'{level_type.title()} Level',
                        'price_level': float(avg_price),
                        'touches': len(cluster_prices),
                        'confidence': float(confidence),
                        'start_date': cluster_times.min().isoformat(),
                        'end_date': cluster_times.max().isoformat(),
                        'strength': 'strong' if len(cluster_prices) >= 5 else 'medium',
                        'key_levels': {
                            'level': float(avg_price),
                            'tolerance': float(price_std * 2)
                        }
                    })
        
        except Exception as e:
            logger.error(f"Erro ao encontrar níveis similares: {e}")
        
        return levels
    
    def _detect_triangles(self, data: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Detecta padrões de triângulos.
        """
        patterns = []
        
        try:
            if len(data) < 20:
                return patterns
            
            prices = data['close'].values
            timestamps = data.index
            
            # Encontrar picos e vales
            peaks, _ = signal.find_peaks(prices, distance=3)
            valleys, _ = signal.find_peaks(-prices, distance=3)
            
            if len(peaks) >= 2 and len(valleys) >= 2:
                # Analisar últimos pontos para formar triângulos
                recent_peaks = peaks[-4:] if len(peaks) >= 4 else peaks
                recent_valleys = valleys[-4:] if len(valleys) >= 4 else valleys
                
                # Verificar triângulo ascendente
                ascending = self._check_ascending_triangle(prices, recent_peaks, recent_valleys, timestamps)
                if ascending:
                    patterns.append(ascending)
                
                # Verificar triângulo descendente
                descending = self._check_descending_triangle(prices, recent_peaks, recent_valleys, timestamps)
                if descending:
                    patterns.append(descending)
                
                # Verificar triângulo simétrico
                symmetrical = self._check_symmetrical_triangle(prices, recent_peaks, recent_valleys, timestamps)
                if symmetrical:
                    patterns.append(symmetrical)
        
        except Exception as e:
            logger.error(f"Erro na detecção de triângulos: {e}")
        
        return patterns
    
    def _check_ascending_triangle(self, prices: np.ndarray, peaks: np.ndarray, 
                                valleys: np.ndarray, timestamps: pd.DatetimeIndex) -> Optional[Dict[str, Any]]:
        """
        Verifica padrão de triângulo ascendente.
        """
        try:
            if len(peaks) < 2 or len(valleys) < 2:
                return None
            
            # Linha de resistência horizontal (picos similares)
            peak_prices = prices[peaks]
            resistance_slope, _, r_value_resistance, _, _ = linregress(peaks, peak_prices)
            
            # Linha de suporte ascendente (vales crescentes)
            valley_prices = prices[valleys]
            support_slope, _, r_value_support, _, _ = linregress(valleys, valley_prices)
            
            # Critérios para triângulo ascendente
            if (abs(resistance_slope) < 0.1 and  # Resistência horizontal
                support_slope > 0.05 and         # Suporte ascendente
                r_value_resistance ** 2 > 0.5 and
                r_value_support ** 2 > 0.5):
                
                start_idx = min(peaks[0], valleys[0])
                end_idx = max(peaks[-1], valleys[-1])
                
                return {
                    'type': 'ascending_triangle',
                    'name': 'Ascending Triangle',
                    'confidence': float((r_value_resistance ** 2 + r_value_support ** 2) / 2),
                    'start_date': timestamps[start_idx].isoformat(),
                    'end_date': timestamps[end_idx].isoformat(),
                    'key_levels': {
                        'resistance': float(np.mean(peak_prices)),
                        'support_slope': float(support_slope),
                        'breakout_target': float(np.mean(peak_prices) * 1.05)
                    },
                    'expected_move': 5.0,  # 5% esperado
                    'risk_reward_ratio': 2.5
                }
        
        except Exception:
            pass
        
        return None
    
    def _check_descending_triangle(self, prices: np.ndarray, peaks: np.ndarray, 
                                 valleys: np.ndarray, timestamps: pd.DatetimeIndex) -> Optional[Dict[str, Any]]:
        """
        Verifica padrão de triângulo descendente.
        """
        try:
            if len(peaks) < 2 or len(valleys) < 2:
                return None
            
            # Linha de suporte horizontal (vales similares)
            valley_prices = prices[valleys]
            support_slope, _, r_value_support, _, _ = linregress(valleys, valley_prices)
            
            # Linha de resistência descendente (picos decrescentes)
            peak_prices = prices[peaks]
            resistance_slope, _, r_value_resistance, _, _ = linregress(peaks, peak_prices)
            
            # Critérios para triângulo descendente
            if (abs(support_slope) < 0.1 and      # Suporte horizontal
                resistance_slope < -0.05 and      # Resistência descendente
                r_value_support ** 2 > 0.5 and
                r_value_resistance ** 2 > 0.5):
                
                start_idx = min(peaks[0], valleys[0])
                end_idx = max(peaks[-1], valleys[-1])
                
                return {
                    'type': 'descending_triangle',
                    'name': 'Descending Triangle',
                    'confidence': float((r_value_resistance ** 2 + r_value_support ** 2) / 2),
                    'start_date': timestamps[start_idx].isoformat(),
                    'end_date': timestamps[end_idx].isoformat(),
                    'key_levels': {
                        'support': float(np.mean(valley_prices)),
                        'resistance_slope': float(resistance_slope),
                        'breakdown_target': float(np.mean(valley_prices) * 0.95)
                    },
                    'expected_move': -5.0,  # -5% esperado
                    'risk_reward_ratio': 2.5
                }
        
        except Exception:
            pass
        
        return None
    
    def _check_symmetrical_triangle(self, prices: np.ndarray, peaks: np.ndarray, 
                                  valleys: np.ndarray, timestamps: pd.DatetimeIndex) -> Optional[Dict[str, Any]]:
        """
        Verifica padrão de triângulo simétrico.
        """
        try:
            if len(peaks) < 2 or len(valleys) < 2:
                return None
            
            # Linha de resistência descendente
            peak_prices = prices[peaks]
            resistance_slope, _, r_value_resistance, _, _ = linregress(peaks, peak_prices)
            
            # Linha de suporte ascendente
            valley_prices = prices[valleys]
            support_slope, _, r_value_support, _, _ = linregress(valleys, valley_prices)
            
            # Critérios para triângulo simétrico
            if (resistance_slope < -0.02 and      # Resistência descendente
                support_slope > 0.02 and          # Suporte ascendente
                abs(resistance_slope + support_slope) < 0.05 and  # Convergência
                r_value_resistance ** 2 > 0.4 and
                r_value_support ** 2 > 0.4):
                
                start_idx = min(peaks[0], valleys[0])
                end_idx = max(peaks[-1], valleys[-1])
                
                # Ponto de convergência
                convergence_price = (np.mean(peak_prices) + np.mean(valley_prices)) / 2
                
                return {
                    'type': 'symmetrical_triangle',
                    'name': 'Symmetrical Triangle',
                    'confidence': float((r_value_resistance ** 2 + r_value_support ** 2) / 2),
                    'start_date': timestamps[start_idx].isoformat(),
                    'end_date': timestamps[end_idx].isoformat(),
                    'key_levels': {
                        'convergence_price': float(convergence_price),
                        'resistance_slope': float(resistance_slope),
                        'support_slope': float(support_slope)
                    },
                    'expected_move': 3.0,  # 3% em qualquer direção
                    'risk_reward_ratio': 2.0
                }
        
        except Exception:
            pass
        
        return None
    
    def _detect_head_shoulders(self, data: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Detecta padrões de cabeça e ombros.
        """
        patterns = []
        
        try:
            if len(data) < 30:
                return patterns
            
            prices = data['close'].values
            timestamps = data.index
            
            # Encontrar picos significativos
            peaks, properties = signal.find_peaks(prices, distance=5, prominence=np.std(prices) * 0.5)
            
            if len(peaks) >= 3:
                # Verificar padrão de cabeça e ombros nos últimos picos
                for i in range(len(peaks) - 2):
                    left_shoulder = peaks[i]
                    head = peaks[i + 1]
                    right_shoulder = peaks[i + 2]
                    
                    hs_pattern = self._check_head_shoulders_pattern(
                        prices, left_shoulder, head, right_shoulder, timestamps
                    )
                    
                    if hs_pattern:
                        patterns.append(hs_pattern)
        
        except Exception as e:
            logger.error(f"Erro na detecção de cabeça e ombros: {e}")
        
        return patterns
    
    def _check_head_shoulders_pattern(self, prices: np.ndarray, left_shoulder: int, 
                                    head: int, right_shoulder: int, 
                                    timestamps: pd.DatetimeIndex) -> Optional[Dict[str, Any]]:
        """
        Verifica se três picos formam um padrão de cabeça e ombros.
        """
        try:
            left_price = prices[left_shoulder]
            head_price = prices[head]
            right_price = prices[right_shoulder]
            
            # Critérios para cabeça e ombros
            shoulder_tolerance = 0.05  # 5% de tolerância entre ombros
            head_prominence = 0.03     # Cabeça deve ser 3% maior que ombros
            
            # Verificar se a cabeça é mais alta que os ombros
            if (head_price > left_price * (1 + head_prominence) and
                head_price > right_price * (1 + head_prominence)):
                
                # Verificar se os ombros são similares
                shoulder_diff = abs(left_price - right_price) / max(left_price, right_price)
                
                if shoulder_diff <= shoulder_tolerance:
                    # Encontrar linha do pescoço (vales entre os picos)
                    left_valley_idx = left_shoulder + np.argmin(prices[left_shoulder:head])
                    right_valley_idx = head + np.argmin(prices[head:right_shoulder])
                    
                    neckline_price = (prices[left_valley_idx] + prices[right_valley_idx]) / 2
                    
                    confidence = 1.0 - shoulder_diff  # Maior confiança com ombros mais similares
                    
                    return {
                        'type': 'head_and_shoulders',
                        'name': 'Head and Shoulders',
                        'confidence': float(confidence),
                        'start_date': timestamps[left_shoulder].isoformat(),
                        'end_date': timestamps[right_shoulder].isoformat(),
                        'key_levels': {
                            'left_shoulder': float(left_price),
                            'head': float(head_price),
                            'right_shoulder': float(right_price),
                            'neckline': float(neckline_price),
                            'target': float(neckline_price - (head_price - neckline_price))
                        },
                        'expected_move': float(-((head_price - neckline_price) / head_price) * 100),
                        'risk_reward_ratio': 3.0
                    }
        
        except Exception:
            pass
        
        return None
    
    def _detect_double_patterns(self, data: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Detecta padrões duplos (double top/bottom).
        """
        patterns = []
        
        try:
            prices = data['close'].values
            timestamps = data.index
            
            # Detectar double tops
            peaks, _ = signal.find_peaks(prices, distance=10, prominence=np.std(prices) * 0.3)
            if len(peaks) >= 2:
                double_top = self._check_double_top(prices, peaks, timestamps)
                if double_top:
                    patterns.append(double_top)
            
            # Detectar double bottoms
            valleys, _ = signal.find_peaks(-prices, distance=10, prominence=np.std(prices) * 0.3)
            if len(valleys) >= 2:
                double_bottom = self._check_double_bottom(prices, valleys, timestamps)
                if double_bottom:
                    patterns.append(double_bottom)
        
        except Exception as e:
            logger.error(f"Erro na detecção de padrões duplos: {e}")
        
        return patterns
    
    def _check_double_top(self, prices: np.ndarray, peaks: np.ndarray, 
                         timestamps: pd.DatetimeIndex) -> Optional[Dict[str, Any]]:
        """
        Verifica padrão de double top.
        """
        try:
            # Verificar os dois últimos picos
            if len(peaks) < 2:
                return None
            
            first_peak = peaks[-2]
            second_peak = peaks[-1]
            
            first_price = prices[first_peak]
            second_price = prices[second_peak]
            
            # Tolerância para considerar picos similares
            tolerance = 0.03  # 3%
            price_diff = abs(first_price - second_price) / max(first_price, second_price)
            
            if price_diff <= tolerance:
                # Encontrar vale entre os picos
                valley_idx = first_peak + np.argmin(prices[first_peak:second_peak])
                valley_price = prices[valley_idx]
                
                # Verificar se há uma correção significativa entre os picos
                correction = (max(first_price, second_price) - valley_price) / max(first_price, second_price)
                
                if correction >= 0.05:  # Correção mínima de 5%
                    confidence = 1.0 - price_diff
                    
                    return {
                        'type': 'double_top',
                        'name': 'Double Top',
                        'confidence': float(confidence),
                        'start_date': timestamps[first_peak].isoformat(),
                        'end_date': timestamps[second_peak].isoformat(),
                        'key_levels': {
                            'first_peak': float(first_price),
                            'second_peak': float(second_price),
                            'valley': float(valley_price),
                            'target': float(valley_price - (max(first_price, second_price) - valley_price))
                        },
                        'expected_move': float(-correction * 100),
                        'risk_reward_ratio': 2.5
                    }
        
        except Exception:
            pass
        
        return None
    
    def _check_double_bottom(self, prices: np.ndarray, valleys: np.ndarray, 
                           timestamps: pd.DatetimeIndex) -> Optional[Dict[str, Any]]:
        """
        Verifica padrão de double bottom.
        """
        try:
            # Verificar os dois últimos vales
            if len(valleys) < 2:
                return None
            
            first_valley = valleys[-2]
            second_valley = valleys[-1]
            
            first_price = prices[first_valley]
            second_price = prices[second_valley]
            
            # Tolerância para considerar vales similares
            tolerance = 0.03  # 3%
            price_diff = abs(first_price - second_price) / min(first_price, second_price)
            
            if price_diff <= tolerance:
                # Encontrar pico entre os vales
                peak_idx = first_valley + np.argmax(prices[first_valley:second_valley])
                peak_price = prices[peak_idx]
                
                # Verificar se há um rally significativo entre os vales
                rally = (peak_price - min(first_price, second_price)) / min(first_price, second_price)
                
                if rally >= 0.05:  # Rally mínimo de 5%
                    confidence = 1.0 - price_diff
                    
                    return {
                        'type': 'double_bottom',
                        'name': 'Double Bottom',
                        'confidence': float(confidence),
                        'start_date': timestamps[first_valley].isoformat(),
                        'end_date': timestamps[second_valley].isoformat(),
                        'key_levels': {
                            'first_bottom': float(first_price),
                            'second_bottom': float(second_price),
                            'peak': float(peak_price),
                            'target': float(peak_price + (peak_price - min(first_price, second_price)))
                        },
                        'expected_move': float(rally * 100),
                        'risk_reward_ratio': 2.5
                    }
        
        except Exception:
            pass
        
        return None
    
    def _detect_flags_pennants(self, data: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Detecta padrões de bandeiras e flâmulas.
        """
        patterns = []
        
        try:
            if len(data) < 30:
                return patterns
            
            prices = data['close'].values
            timestamps = data.index
            
            # Procurar por movimentos fortes seguidos de consolidação
            for i in range(20, len(prices) - 10):
                # Verificar movimento forte (pole)
                pole_start = i - 20
                pole_end = i
                pole_move = (prices[pole_end] - prices[pole_start]) / prices[pole_start]
                
                if abs(pole_move) >= 0.05:  # Movimento mínimo de 5%
                    # Verificar consolidação após o movimento
                    consolidation_end = min(i + 15, len(prices) - 1)
                    consolidation_prices = prices[pole_end:consolidation_end]
                    
                    if len(consolidation_prices) >= 5:
                        flag_pattern = self._check_flag_pattern(
                            prices, pole_start, pole_end, consolidation_end, 
                            pole_move, timestamps
                        )
                        
                        if flag_pattern:
                            patterns.append(flag_pattern)
        
        except Exception as e:
            logger.error(f"Erro na detecção de bandeiras: {e}")
        
        return patterns
    
    def _check_flag_pattern(self, prices: np.ndarray, pole_start: int, pole_end: int, 
                          consolidation_end: int, pole_move: float, 
                          timestamps: pd.DatetimeIndex) -> Optional[Dict[str, Any]]:
        """
        Verifica se há um padrão de bandeira.
        """
        try:
            consolidation_prices = prices[pole_end:consolidation_end]
            
            # Calcular volatilidade da consolidação
            consolidation_volatility = np.std(consolidation_prices) / np.mean(consolidation_prices)
            
            # Bandeira deve ter baixa volatilidade
            if consolidation_volatility < 0.02:  # Menos de 2% de volatilidade
                pattern_type = 'bull_flag' if pole_move > 0 else 'bear_flag'
                
                return {
                    'type': pattern_type,
                    'name': f'{"Bull" if pole_move > 0 else "Bear"} Flag',
                    'confidence': float(1.0 - consolidation_volatility * 10),
                    'start_date': timestamps[pole_start].isoformat(),
                    'end_date': timestamps[consolidation_end].isoformat(),
                    'key_levels': {
                        'pole_start': float(prices[pole_start]),
                        'pole_end': float(prices[pole_end]),
                        'consolidation_high': float(np.max(consolidation_prices)),
                        'consolidation_low': float(np.min(consolidation_prices)),
                        'target': float(prices[pole_end] + pole_move * prices[pole_end])
                    },
                    'expected_move': float(pole_move * 100),
                    'risk_reward_ratio': 2.0
                }
        
        except Exception:
            pass
        
        return None
    
    def _detect_wedges(self, data: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Detecta padrões de cunhas (wedges).
        """
        # Implementação simplificada - pode ser expandida
        return []
    
    def _detect_channels(self, data: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Detecta canais de preços.
        """
        # Implementação simplificada - pode ser expandida
        return []
    
    def _calculate_pattern_targets(self, pattern: Dict[str, Any], data: pd.DataFrame) -> Dict[str, Any]:
        """
        Calcula targets e stop-loss para um padrão.
        """
        try:
            pattern_type = pattern.get('type', '')
            key_levels = pattern.get('key_levels', {})
            
            targets = {}
            
            if 'triangle' in pattern_type:
                if 'resistance' in key_levels:
                    targets['target_price'] = key_levels['resistance'] * 1.05
                    targets['stop_loss'] = key_levels['resistance'] * 0.98
                elif 'support' in key_levels:
                    targets['target_price'] = key_levels['support'] * 0.95
                    targets['stop_loss'] = key_levels['support'] * 1.02
            
            elif 'head_and_shoulders' in pattern_type:
                if 'target' in key_levels:
                    targets['target_price'] = key_levels['target']
                    targets['stop_loss'] = key_levels['head']
            
            elif 'double' in pattern_type:
                if 'target' in key_levels:
                    targets['target_price'] = key_levels['target']
                    if pattern_type == 'double_top':
                        targets['stop_loss'] = max(key_levels['first_peak'], key_levels['second_peak'])
                    else:
                        targets['stop_loss'] = min(key_levels['first_bottom'], key_levels['second_bottom'])
            
            return targets
            
        except Exception as e:
            logger.error(f"Erro ao calcular targets: {e}")
            return {}
    
    def _calibrate_support_resistance(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Calibra parâmetros de detecção de suporte e resistência.
        """
        return {'calibrated': True, 'method': 'support_resistance'}
    
    def _calibrate_trend_detection(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Calibra parâmetros de detecção de tendências.
        """
        return {'calibrated': True, 'method': 'trend_detection'}
    
    def _calibrate_triangle_detection(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Calibra parâmetros de detecção de triângulos.
        """
        return {'calibrated': True, 'method': 'triangle_detection'}
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas de performance do engine de padrões.
        """
        return {
            'is_trained': self.is_trained,
            'last_training': self.last_training_date.isoformat() if self.last_training_date else None,
            'patterns_supported': len(self.pattern_success_rates),
            'sklearn_available': SKLEARN_AVAILABLE,
            'pattern_types': list(self.pattern_success_rates.keys())
        }

