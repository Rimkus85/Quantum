"""
Engine de Análise de Sentimento - Quantum Trades
Sprint 5 - Épico 2: NLP avançado para análise de sentimento de mercado
"""

import numpy as np
import pandas as pd
import logging
import re
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from collections import Counter
import requests
from urllib.parse import quote

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    import nltk
    from nltk.sentiment import SentimentIntensityAnalyzer
    from nltk.tokenize import word_tokenize, sent_tokenize
    from nltk.corpus import stopwords
    from nltk.stem import RSLPStemmer
    import spacy
    NLTK_AVAILABLE = True
    
    # Download necessário do NLTK
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        nltk.download('punkt')
    
    try:
        nltk.data.find('corpora/stopwords')
    except LookupError:
        nltk.download('stopwords')
    
    try:
        nltk.data.find('vader_lexicon')
    except LookupError:
        nltk.download('vader_lexicon')
        
except ImportError as e:
    logger.warning(f"NLTK não disponível: {e}")
    NLTK_AVAILABLE = False

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False

from .base_ml_engine import BaseMLEngine
from ..pipelines.data_pipeline import DataPipeline

class SentimentEngine(BaseMLEngine):
    """
    Engine para análise de sentimento de notícias e redes sociais.
    """
    
    def __init__(self):
        super().__init__("SentimentEngine", "1.0.0")
        self.data_pipeline = DataPipeline()
        
        # Inicializar ferramentas de NLP
        self.sentiment_analyzer = None
        self.stemmer = None
        self.stop_words = set()
        self.nlp_model = None
        
        # Dicionários de sentimento financeiro em português
        self.financial_sentiment_dict = {
            'positivo': {
                'alta', 'subida', 'crescimento', 'lucro', 'ganho', 'valorização',
                'otimista', 'bullish', 'compra', 'investir', 'oportunidade',
                'recuperação', 'melhora', 'positivo', 'forte', 'sólido',
                'expansão', 'aumento', 'elevação', 'boom', 'rally'
            },
            'negativo': {
                'queda', 'baixa', 'declínio', 'prejuízo', 'perda', 'desvalorização',
                'pessimista', 'bearish', 'venda', 'risco', 'crise',
                'recessão', 'piora', 'negativo', 'fraco', 'instável',
                'contração', 'diminuição', 'redução', 'crash', 'correção'
            },
            'neutro': {
                'estável', 'lateral', 'consolidação', 'neutro', 'manutenção',
                'aguardar', 'observar', 'monitorar', 'análise', 'avaliação'
            }
        }
        
        # Fontes de notícias financeiras brasileiras
        self.news_sources = {
            'infomoney': 'https://www.infomoney.com.br',
            'valor': 'https://valor.globo.com',
            'exame': 'https://exame.com',
            'estadao': 'https://economia.estadao.com.br',
            'g1': 'https://g1.globo.com/economia',
            'uol': 'https://economia.uol.com.br'
        }
        
        # Padrões para extração de entidades financeiras
        self.entity_patterns = {
            'empresa': r'\b[A-Z]{4}[0-9]{1,2}\b',  # Códigos de ações
            'valor': r'R\$\s*[\d.,]+',              # Valores em reais
            'percentual': r'\d+[,.]?\d*\s*%',       # Percentuais
            'data': r'\d{1,2}\/\d{1,2}\/\d{4}'     # Datas
        }
        
        self._initialize_nlp()
        logger.info("Engine de Análise de Sentimento inicializado")
    
    def _initialize_nlp(self):
        """
        Inicializa ferramentas de NLP.
        """
        try:
            if NLTK_AVAILABLE:
                self.sentiment_analyzer = SentimentIntensityAnalyzer()
                self.stemmer = RSLPStemmer()
                self.stop_words = set(stopwords.words('portuguese'))
                logger.info("NLTK inicializado com sucesso")
            
            # Tentar carregar modelo spaCy para português
            try:
                import spacy
                self.nlp_model = spacy.load('pt_core_news_sm')
                logger.info("Modelo spaCy carregado com sucesso")
            except (ImportError, OSError):
                logger.warning("Modelo spaCy para português não disponível")
                
        except Exception as e:
            logger.error(f"Erro ao inicializar NLP: {e}")
    
    def prepare_features(self, data: pd.DataFrame) -> np.ndarray:
        """
        Prepara features de texto para análise de sentimento.
        """
        try:
            if data.empty or 'text' not in data.columns:
                return np.array([])
            
            features = []
            
            for text in data['text']:
                if pd.isna(text):
                    features.append([0] * 10)  # Features padrão
                    continue
                
                # Features básicas de texto
                text_features = self._extract_text_features(str(text))
                features.append(text_features)
            
            return np.array(features)
            
        except Exception as e:
            logger.error(f"Erro ao preparar features de sentimento: {e}")
            return np.array([])
    
    def _extract_text_features(self, text: str) -> List[float]:
        """
        Extrai features básicas de um texto.
        """
        try:
            # Limpar texto
            clean_text = self._clean_text(text)
            
            # Features básicas
            features = [
                len(text),                          # Comprimento do texto
                len(clean_text.split()),           # Número de palavras
                text.count('!'),                   # Exclamações
                text.count('?'),                   # Interrogações
                text.count('.'),                   # Pontos
                len(re.findall(r'[A-Z]', text)),  # Letras maiúsculas
                self._count_financial_words(clean_text, 'positivo'),
                self._count_financial_words(clean_text, 'negativo'),
                self._count_financial_words(clean_text, 'neutro'),
                self._calculate_sentiment_score(clean_text)
            ]
            
            return features
            
        except Exception:
            return [0] * 10
    
    def _clean_text(self, text: str) -> str:
        """
        Limpa e normaliza texto.
        """
        try:
            # Converter para minúsculas
            text = text.lower()
            
            # Remover URLs
            text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
            
            # Remover menções e hashtags
            text = re.sub(r'@\w+|#\w+', '', text)
            
            # Remover caracteres especiais, manter apenas letras, números e espaços
            text = re.sub(r'[^a-záàâãéèêíìîóòôõúùûç\s]', ' ', text)
            
            # Remover espaços extras
            text = re.sub(r'\s+', ' ', text).strip()
            
            return text
            
        except Exception:
            return text
    
    def _count_financial_words(self, text: str, sentiment_type: str) -> int:
        """
        Conta palavras financeiras de um tipo de sentimento.
        """
        try:
            words = set(text.split())
            financial_words = self.financial_sentiment_dict.get(sentiment_type, set())
            return len(words.intersection(financial_words))
        except Exception:
            return 0
    
    def _calculate_sentiment_score(self, text: str) -> float:
        """
        Calcula score de sentimento básico.
        """
        try:
            if not NLTK_AVAILABLE or not self.sentiment_analyzer:
                return 0.0
            
            # Usar VADER para análise básica
            scores = self.sentiment_analyzer.polarity_scores(text)
            return scores['compound']
            
        except Exception:
            return 0.0
    
    def train(self, training_data: pd.DataFrame, target: pd.Series) -> Dict[str, Any]:
        """
        Treina modelos de análise de sentimento.
        """
        try:
            logger.info("Treinando modelos de análise de sentimento")
            
            # Para análise de sentimento, o "treinamento" é mais sobre
            # calibração de pesos e ajuste de dicionários
            
            results = {}
            
            # Calibrar dicionário de sentimento financeiro
            if not training_data.empty and 'text' in training_data.columns:
                calibration_results = self._calibrate_sentiment_dictionary(training_data, target)
                results['dictionary_calibration'] = calibration_results
            
            # Treinar classificador simples se houver dados suficientes
            if len(training_data) > 100:
                classifier_results = self._train_simple_classifier(training_data, target)
                results['classifier_training'] = classifier_results
            
            self.is_trained = True
            self.last_training_date = datetime.now()
            
            logger.info("Treinamento de sentimento concluído")
            return results
            
        except Exception as e:
            logger.error(f"Erro no treinamento de sentimento: {e}")
            return {'error': str(e)}
    
    def _calibrate_sentiment_dictionary(self, data: pd.DataFrame, target: pd.Series) -> Dict[str, Any]:
        """
        Calibra dicionário de sentimento baseado em dados históricos.
        """
        try:
            # Análise de correlação entre palavras e sentimento
            word_sentiment_correlation = {}
            
            for idx, text in data['text'].items():
                if pd.isna(text) or idx not in target.index:
                    continue
                
                clean_text = self._clean_text(str(text))
                words = clean_text.split()
                sentiment_value = target.loc[idx]
                
                for word in words:
                    if word not in word_sentiment_correlation:
                        word_sentiment_correlation[word] = []
                    word_sentiment_correlation[word].append(sentiment_value)
            
            # Calcular correlação média para cada palavra
            word_scores = {}
            for word, sentiments in word_sentiment_correlation.items():
                if len(sentiments) >= 3:  # Mínimo 3 ocorrências
                    word_scores[word] = np.mean(sentiments)
            
            return {
                'words_analyzed': len(word_scores),
                'top_positive_words': sorted(
                    [(w, s) for w, s in word_scores.items() if s > 0.5],
                    key=lambda x: x[1], reverse=True
                )[:10],
                'top_negative_words': sorted(
                    [(w, s) for w, s in word_scores.items() if s < -0.5],
                    key=lambda x: x[1]
                )[:10]
            }
            
        except Exception as e:
            logger.error(f"Erro na calibração do dicionário: {e}")
            return {'error': str(e)}
    
    def _train_simple_classifier(self, data: pd.DataFrame, target: pd.Series) -> Dict[str, Any]:
        """
        Treina classificador simples de sentimento.
        """
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.naive_bayes import MultinomialNB
            from sklearn.model_selection import train_test_split
            from sklearn.metrics import accuracy_score, classification_report
            
            # Preparar dados
            texts = data['text'].fillna('').astype(str)
            labels = target.fillna(0)
            
            # Converter sentimento contínuo para classes
            sentiment_classes = pd.cut(labels, bins=3, labels=['negativo', 'neutro', 'positivo'])
            
            # Vetorização TF-IDF
            vectorizer = TfidfVectorizer(
                max_features=1000,
                stop_words=list(self.stop_words),
                ngram_range=(1, 2)
            )
            
            X = vectorizer.fit_transform(texts)
            y = sentiment_classes
            
            # Split treino/teste
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Treinar Naive Bayes
            classifier = MultinomialNB()
            classifier.fit(X_train, y_train)
            
            # Avaliar
            y_pred = classifier.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            
            # Salvar modelo
            self.models = {
                'vectorizer': vectorizer,
                'classifier': classifier
            }
            
            return {
                'accuracy': float(accuracy),
                'features_count': X.shape[1],
                'training_samples': len(X_train),
                'test_samples': len(X_test)
            }
            
        except Exception as e:
            logger.error(f"Erro no treinamento do classificador: {e}")
            return {'error': str(e)}
    
    def predict(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Analisa sentimento de textos.
        """
        try:
            if data.empty or 'text' not in data.columns:
                return {'error': 'Dados de texto não fornecidos'}
            
            results = []
            
            for idx, row in data.iterrows():
                text = str(row.get('text', ''))
                if not text.strip():
                    continue
                
                # Análise de sentimento
                sentiment_analysis = self._analyze_text_sentiment(text)
                
                # Extração de entidades
                entities = self._extract_entities(text)
                
                # Keywords importantes
                keywords = self._extract_keywords(text)
                
                result = {
                    'text': text[:200] + '...' if len(text) > 200 else text,
                    'sentiment_score': sentiment_analysis['score'],
                    'sentiment_label': sentiment_analysis['label'],
                    'confidence': sentiment_analysis['confidence'],
                    'entities': entities,
                    'keywords': keywords,
                    'source_type': row.get('source_type', 'unknown'),
                    'timestamp': row.get('timestamp', datetime.now().isoformat())
                }
                
                results.append(result)
            
            # Análise agregada
            if results:
                overall_sentiment = self._calculate_overall_sentiment(results)
                return {
                    'overall_sentiment': overall_sentiment,
                    'total_analyzed': len(results),
                    'detailed_analysis': results
                }
            else:
                return {'error': 'Nenhum texto válido para análise'}
                
        except Exception as e:
            logger.error(f"Erro na análise de sentimento: {e}")
            return {'error': str(e)}
    
    def _analyze_text_sentiment(self, text: str) -> Dict[str, Any]:
        """
        Analisa sentimento de um texto específico.
        """
        try:
            clean_text = self._clean_text(text)
            
            # Análise usando dicionário financeiro
            financial_score = self._calculate_financial_sentiment(clean_text)
            
            # Análise usando VADER (se disponível)
            vader_score = 0.0
            if NLTK_AVAILABLE and self.sentiment_analyzer:
                vader_scores = self.sentiment_analyzer.polarity_scores(text)
                vader_score = vader_scores['compound']
            
            # Combinar scores
            combined_score = (financial_score * 0.7) + (vader_score * 0.3)
            
            # Determinar label e confiança
            if combined_score > 0.1:
                label = 'bullish'
                confidence = min(0.95, 0.5 + abs(combined_score))
            elif combined_score < -0.1:
                label = 'bearish'
                confidence = min(0.95, 0.5 + abs(combined_score))
            else:
                label = 'neutral'
                confidence = 0.6
            
            return {
                'score': float(combined_score),
                'label': label,
                'confidence': float(confidence),
                'financial_score': float(financial_score),
                'vader_score': float(vader_score)
            }
            
        except Exception as e:
            logger.error(f"Erro na análise de texto: {e}")
            return {
                'score': 0.0,
                'label': 'neutral',
                'confidence': 0.5,
                'financial_score': 0.0,
                'vader_score': 0.0
            }
    
    def _calculate_financial_sentiment(self, text: str) -> float:
        """
        Calcula sentimento baseado em dicionário financeiro.
        """
        try:
            words = set(text.split())
            
            positive_count = len(words.intersection(self.financial_sentiment_dict['positivo']))
            negative_count = len(words.intersection(self.financial_sentiment_dict['negativo']))
            neutral_count = len(words.intersection(self.financial_sentiment_dict['neutro']))
            
            total_financial_words = positive_count + negative_count + neutral_count
            
            if total_financial_words == 0:
                return 0.0
            
            # Score normalizado
            score = (positive_count - negative_count) / total_financial_words
            return float(np.clip(score, -1.0, 1.0))
            
        except Exception:
            return 0.0
    
    def _extract_entities(self, text: str) -> Dict[str, List[str]]:
        """
        Extrai entidades financeiras do texto.
        """
        entities = {}
        
        try:
            for entity_type, pattern in self.entity_patterns.items():
                matches = re.findall(pattern, text)
                if matches:
                    entities[entity_type] = list(set(matches))
            
            # Usar spaCy se disponível
            if self.nlp_model:
                doc = self.nlp_model(text)
                
                organizations = [ent.text for ent in doc.ents if ent.label_ == 'ORG']
                if organizations:
                    entities['organizacoes'] = organizations
                
                persons = [ent.text for ent in doc.ents if ent.label_ == 'PER']
                if persons:
                    entities['pessoas'] = persons
            
            return entities
            
        except Exception as e:
            logger.error(f"Erro na extração de entidades: {e}")
            return {}
    
    def _extract_keywords(self, text: str) -> List[str]:
        """
        Extrai palavras-chave importantes do texto.
        """
        try:
            clean_text = self._clean_text(text)
            words = clean_text.split()
            
            # Remover stop words
            filtered_words = [word for word in words if word not in self.stop_words and len(word) > 3]
            
            # Contar frequência
            word_freq = Counter(filtered_words)
            
            # Retornar top 5 palavras mais frequentes
            return [word for word, count in word_freq.most_common(5)]
            
        except Exception:
            return []
    
    def _calculate_overall_sentiment(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Calcula sentimento geral de múltiplas análises.
        """
        try:
            if not results:
                return {}
            
            scores = [r['sentiment_score'] for r in results]
            confidences = [r['confidence'] for r in results]
            labels = [r['sentiment_label'] for r in results]
            
            # Média ponderada por confiança
            weighted_score = np.average(scores, weights=confidences)
            avg_confidence = np.mean(confidences)
            
            # Label mais comum
            label_counts = Counter(labels)
            most_common_label = label_counts.most_common(1)[0][0]
            
            # Tendência
            if len(scores) >= 3:
                recent_scores = scores[-3:]
                trend = 'improving' if recent_scores[-1] > recent_scores[0] else 'declining'
            else:
                trend = 'stable'
            
            return {
                'weighted_score': float(weighted_score),
                'average_confidence': float(avg_confidence),
                'dominant_sentiment': most_common_label,
                'trend': trend,
                'distribution': dict(label_counts),
                'total_sources': len(results)
            }
            
        except Exception as e:
            logger.error(f"Erro no cálculo de sentimento geral: {e}")
            return {}
    
    def analyze_sentiment(self, symbol: str, days_back: int = 7, sources: List[str] = None) -> Dict[str, Any]:
        """
        Analisa sentimento para um símbolo específico.
        """
        try:
            if sources is None:
                sources = ['news', 'social']
            
            # Coletar dados de texto
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            all_texts = []
            
            # Coletar notícias
            if 'news' in sources:
                news_data = self._collect_news_data(symbol, start_date, end_date)
                all_texts.extend(news_data)
            
            # Coletar dados de redes sociais
            if 'social' in sources:
                social_data = self._collect_social_data(symbol, start_date, end_date)
                all_texts.extend(social_data)
            
            if not all_texts:
                return {
                    'error': 'Nenhum dado de texto encontrado',
                    'symbol': symbol,
                    'period_days': days_back
                }
            
            # Converter para DataFrame
            df = pd.DataFrame(all_texts)
            
            # Analisar sentimento
            sentiment_results = self.predict(df)
            
            # Adicionar informações específicas do símbolo
            sentiment_results['symbol'] = symbol
            sentiment_results['period_days'] = days_back
            sentiment_results['sources_used'] = sources
            sentiment_results['analysis_date'] = datetime.now().isoformat()
            
            return sentiment_results
            
        except Exception as e:
            logger.error(f"Erro na análise de sentimento para {symbol}: {e}")
            return {'error': str(e), 'symbol': symbol}
    
    def _collect_news_data(self, symbol: str, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """
        Coleta dados de notícias para um símbolo.
        """
        news_data = []
        
        try:
            # Implementação simplificada - busca por notícias relacionadas ao símbolo
            # Em produção, usaria APIs específicas de notícias
            
            search_terms = [symbol, symbol.replace('.SA', ''), symbol[:4]]
            
            for term in search_terms:
                # Simular coleta de notícias
                fake_news = self._generate_sample_news(term, start_date, end_date)
                news_data.extend(fake_news)
            
            return news_data
            
        except Exception as e:
            logger.error(f"Erro na coleta de notícias: {e}")
            return []
    
    def _collect_social_data(self, symbol: str, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """
        Coleta dados de redes sociais para um símbolo.
        """
        social_data = []
        
        try:
            # Implementação simplificada - em produção usaria APIs do Twitter, etc.
            fake_social = self._generate_sample_social(symbol, start_date, end_date)
            social_data.extend(fake_social)
            
            return social_data
            
        except Exception as e:
            logger.error(f"Erro na coleta de dados sociais: {e}")
            return []
    
    def _generate_sample_news(self, symbol: str, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """
        Gera notícias de exemplo para demonstração.
        """
        sample_news = [
            {
                'text': f'{symbol} apresenta crescimento sólido no último trimestre com aumento de receita e lucro líquido.',
                'source_type': 'news',
                'source_url': 'https://example.com/news1',
                'timestamp': (start_date + timedelta(days=1)).isoformat()
            },
            {
                'text': f'Analistas recomendam compra de {symbol} devido ao forte desempenho operacional e perspectivas positivas.',
                'source_type': 'news',
                'source_url': 'https://example.com/news2',
                'timestamp': (start_date + timedelta(days=2)).isoformat()
            },
            {
                'text': f'Mercado demonstra otimismo com {symbol} após divulgação de resultados acima do esperado.',
                'source_type': 'news',
                'source_url': 'https://example.com/news3',
                'timestamp': (start_date + timedelta(days=3)).isoformat()
            }
        ]
        
        return sample_news
    
    def _generate_sample_social(self, symbol: str, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """
        Gera dados de redes sociais de exemplo.
        """
        sample_social = [
            {
                'text': f'Muito bullish em {symbol}! Fundamentos sólidos e boa gestão. #investimentos',
                'source_type': 'social',
                'source_url': 'https://twitter.com/example1',
                'timestamp': (start_date + timedelta(days=1, hours=2)).isoformat()
            },
            {
                'text': f'{symbol} pode ser uma boa oportunidade de entrada. Preço atrativo no momento.',
                'source_type': 'social',
                'source_url': 'https://twitter.com/example2',
                'timestamp': (start_date + timedelta(days=2, hours=5)).isoformat()
            },
            {
                'text': f'Acompanhando {symbol} de perto. Resultados promissores e potencial de valorização.',
                'source_type': 'social',
                'source_url': 'https://twitter.com/example3',
                'timestamp': (start_date + timedelta(days=3, hours=8)).isoformat()
            }
        ]
        
        return sample_social
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas de performance do engine de sentimento.
        """
        return {
            'is_trained': self.is_trained,
            'last_training': self.last_training_date.isoformat() if self.last_training_date else None,
            'nltk_available': NLTK_AVAILABLE,
            'bs4_available': BS4_AVAILABLE,
            'financial_words_count': sum(len(words) for words in self.financial_sentiment_dict.values()),
            'news_sources_count': len(self.news_sources),
            'entity_patterns_count': len(self.entity_patterns)
        }

