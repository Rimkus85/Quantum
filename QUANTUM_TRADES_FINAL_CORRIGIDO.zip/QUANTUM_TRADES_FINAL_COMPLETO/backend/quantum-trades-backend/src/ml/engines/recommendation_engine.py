"""
Engine de Recomendações Inteligentes - Quantum Trades
Sprint 5 - Épico 3: Sistema de recomendações personalizadas usando ML
"""

import numpy as np
import pandas as pd
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import json
from collections import defaultdict, Counter
import math

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.decomposition import TruncatedSVD
    from sklearn.preprocessing import StandardScaler
    from sklearn.cluster import KMeans
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

from .base_ml_engine import BaseMLEngine
from ..pipelines.data_pipeline import DataPipeline

class RecommendationEngine(BaseMLEngine):
    """
    Engine para recomendações personalizadas de investimentos.
    """
    
    def __init__(self):
        super().__init__("RecommendationEngine", "1.0.0")
        self.data_pipeline = DataPipeline()
        
        # Matrizes de dados
        self.user_item_matrix = None
        self.item_features_matrix = None
        self.user_profiles = {}
        self.item_profiles = {}
        
        # Modelos treinados
        self.collaborative_model = None
        self.content_model = None
        self.hybrid_weights = {'collaborative': 0.6, 'content': 0.4}
        
        # Configurações de recomendação
        self.min_interactions = 3
        self.max_recommendations = 20
        self.similarity_threshold = 0.1
        
        # Categorias de ativos
        self.asset_categories = {
            'ações': ['PETR4', 'VALE3', 'ITUB4', 'BBDC4', 'ABEV3'],
            'fiis': ['HGLG11', 'XPML11', 'KNRI11', 'BCFF11'],
            'etfs': ['BOVA11', 'IVVB11', 'SMAL11'],
            'cripto': ['BTC', 'ETH', 'ADA'],
            'renda_fixa': ['TESOURO_SELIC', 'TESOURO_IPCA', 'CDB']
        }
        
        # Perfis de risco
        self.risk_profiles = {
            'conservador': {
                'renda_fixa': 0.7,
                'ações': 0.2,
                'fiis': 0.1,
                'etfs': 0.0,
                'cripto': 0.0
            },
            'moderado': {
                'renda_fixa': 0.4,
                'ações': 0.4,
                'fiis': 0.15,
                'etfs': 0.05,
                'cripto': 0.0
            },
            'arrojado': {
                'renda_fixa': 0.1,
                'ações': 0.5,
                'fiis': 0.2,
                'etfs': 0.15,
                'cripto': 0.05
            },
            'agressivo': {
                'renda_fixa': 0.05,
                'ações': 0.4,
                'fiis': 0.15,
                'etfs': 0.25,
                'cripto': 0.15
            }
        }
        
        # Features de ativos
        self.asset_features = [
            'volatility', 'return_1m', 'return_3m', 'return_6m', 'return_1y',
            'market_cap', 'pe_ratio', 'dividend_yield', 'beta', 'sector_score'
        ]
        
        logger.info("Engine de Recomendações inicializado")
    
    def prepare_features(self, data: pd.DataFrame) -> np.ndarray:
        """
        Prepara features para o sistema de recomendações.
        """
        try:
            if data.empty:
                return np.array([])
            
            # Features básicas para recomendações
            features = []
            
            for _, row in data.iterrows():
                user_features = self._extract_user_features(row)
                features.append(user_features)
            
            return np.array(features)
            
        except Exception as e:
            logger.error(f"Erro ao preparar features de recomendação: {e}")
            return np.array([])
    
    def _extract_user_features(self, user_data: pd.Series) -> List[float]:
        """
        Extrai features de um usuário.
        """
        try:
            features = [
                user_data.get('age', 30) / 100,  # Idade normalizada
                user_data.get('income', 5000) / 50000,  # Renda normalizada
                user_data.get('investment_experience', 1) / 10,  # Experiência
                user_data.get('risk_tolerance', 5) / 10,  # Tolerância ao risco
                user_data.get('investment_horizon', 12) / 120,  # Horizonte (meses)
                len(user_data.get('current_portfolio', [])) / 20,  # Diversificação
                user_data.get('total_invested', 10000) / 100000,  # Capital investido
                user_data.get('monthly_contribution', 500) / 5000,  # Aporte mensal
                user_data.get('financial_goals_count', 1) / 5,  # Número de objetivos
                user_data.get('market_knowledge', 3) / 10  # Conhecimento de mercado
            ]
            
            return features
            
        except Exception:
            return [0.5] * 10  # Features padrão
    
    def train(self, training_data: pd.DataFrame, target: pd.Series) -> Dict[str, Any]:
        """
        Treina modelos de recomendação.
        """
        try:
            logger.info("Treinando sistema de recomendações")
            
            if training_data.empty:
                return {'error': 'Dados de treinamento vazios'}
            
            results = {}
            
            # Treinar modelo colaborativo
            collaborative_results = self._train_collaborative_filtering(training_data)
            results['collaborative_filtering'] = collaborative_results
            
            # Treinar modelo baseado em conteúdo
            content_results = self._train_content_based(training_data)
            results['content_based'] = content_results
            
            # Treinar modelo híbrido
            hybrid_results = self._train_hybrid_model(training_data)
            results['hybrid_model'] = hybrid_results
            
            # Criar perfis de usuários
            user_profiles_results = self._create_user_profiles(training_data)
            results['user_profiles'] = user_profiles_results
            
            self.is_trained = True
            self.last_training_date = datetime.now()
            
            logger.info("Treinamento de recomendações concluído")
            return results
            
        except Exception as e:
            logger.error(f"Erro no treinamento de recomendações: {e}")
            return {'error': str(e)}
    
    def _train_collaborative_filtering(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Treina modelo de filtragem colaborativa.
        """
        try:
            if not SKLEARN_AVAILABLE:
                return {'error': 'Scikit-learn não disponível'}
            
            # Simular matriz usuário-item
            users = data.get('user_id', pd.Series(range(len(data)))).unique()
            items = []
            
            # Extrair itens dos portfolios
            for portfolio in data.get('current_portfolio', []):
                if isinstance(portfolio, list):
                    items.extend(portfolio)
                elif isinstance(portfolio, str):
                    items.extend(portfolio.split(','))
            
            unique_items = list(set(items)) if items else ['PETR4', 'VALE3', 'ITUB4']
            
            # Criar matriz usuário-item
            user_item_matrix = np.random.rand(len(users), len(unique_items))
            
            # Aplicar SVD para redução de dimensionalidade
            svd = TruncatedSVD(n_components=min(10, len(unique_items) - 1))
            user_factors = svd.fit_transform(user_item_matrix)
            item_factors = svd.components_.T
            
            self.collaborative_model = {
                'svd': svd,
                'user_factors': user_factors,
                'item_factors': item_factors,
                'users': users,
                'items': unique_items
            }
            
            return {
                'users_count': len(users),
                'items_count': len(unique_items),
                'factors': svd.n_components,
                'explained_variance': float(svd.explained_variance_ratio_.sum())
            }
            
        except Exception as e:
            logger.error(f"Erro na filtragem colaborativa: {e}")
            return {'error': str(e)}
    
    def _train_content_based(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Treina modelo baseado em conteúdo.
        """
        try:
            # Criar perfis de itens baseados em características
            item_profiles = {}
            
            # Para cada categoria de ativo, criar perfil
            for category, assets in self.asset_categories.items():
                for asset in assets:
                    profile = self._create_asset_profile(asset, category)
                    item_profiles[asset] = profile
            
            self.item_profiles = item_profiles
            
            # Criar matriz de features de itens
            if item_profiles:
                items = list(item_profiles.keys())
                features_matrix = np.array([list(profile.values()) for profile in item_profiles.values()])
                
                # Normalizar features
                scaler = StandardScaler()
                features_matrix_scaled = scaler.fit_transform(features_matrix)
                
                self.content_model = {
                    'items': items,
                    'features_matrix': features_matrix_scaled,
                    'scaler': scaler,
                    'feature_names': list(next(iter(item_profiles.values())).keys())
                }
                
                return {
                    'items_profiled': len(items),
                    'features_count': features_matrix.shape[1],
                    'categories': len(self.asset_categories)
                }
            else:
                return {'error': 'Nenhum perfil de item criado'}
                
        except Exception as e:
            logger.error(f"Erro no modelo baseado em conteúdo: {e}")
            return {'error': str(e)}
    
    def _create_asset_profile(self, asset: str, category: str) -> Dict[str, float]:
        """
        Cria perfil de características de um ativo.
        """
        try:
            # Perfil baseado na categoria e características simuladas
            base_profiles = {
                'ações': {
                    'volatility': 0.7,
                    'expected_return': 0.12,
                    'liquidity': 0.8,
                    'dividend_yield': 0.05,
                    'growth_potential': 0.8,
                    'risk_level': 0.7
                },
                'fiis': {
                    'volatility': 0.4,
                    'expected_return': 0.08,
                    'liquidity': 0.6,
                    'dividend_yield': 0.08,
                    'growth_potential': 0.4,
                    'risk_level': 0.4
                },
                'etfs': {
                    'volatility': 0.5,
                    'expected_return': 0.10,
                    'liquidity': 0.9,
                    'dividend_yield': 0.03,
                    'growth_potential': 0.6,
                    'risk_level': 0.5
                },
                'cripto': {
                    'volatility': 0.9,
                    'expected_return': 0.25,
                    'liquidity': 0.7,
                    'dividend_yield': 0.0,
                    'growth_potential': 0.9,
                    'risk_level': 0.9
                },
                'renda_fixa': {
                    'volatility': 0.1,
                    'expected_return': 0.06,
                    'liquidity': 0.5,
                    'dividend_yield': 0.06,
                    'growth_potential': 0.1,
                    'risk_level': 0.1
                }
            }
            
            base_profile = base_profiles.get(category, base_profiles['ações'])
            
            # Adicionar variação específica do ativo
            asset_hash = hash(asset) % 100
            variation = (asset_hash - 50) / 1000  # Variação de -0.05 a +0.05
            
            profile = {}
            for feature, value in base_profile.items():
                profile[feature] = max(0, min(1, value + variation))
            
            return profile
            
        except Exception:
            return {
                'volatility': 0.5,
                'expected_return': 0.1,
                'liquidity': 0.7,
                'dividend_yield': 0.04,
                'growth_potential': 0.6,
                'risk_level': 0.5
            }
    
    def _train_hybrid_model(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Treina modelo híbrido combinando colaborativo e conteúdo.
        """
        try:
            # Ajustar pesos baseado na performance dos modelos individuais
            if self.collaborative_model and self.content_model:
                # Simular avaliação de performance
                collaborative_score = 0.75
                content_score = 0.65
                
                total_score = collaborative_score + content_score
                self.hybrid_weights = {
                    'collaborative': collaborative_score / total_score,
                    'content': content_score / total_score
                }
                
                return {
                    'collaborative_weight': self.hybrid_weights['collaborative'],
                    'content_weight': self.hybrid_weights['content'],
                    'collaborative_score': collaborative_score,
                    'content_score': content_score
                }
            else:
                return {'error': 'Modelos individuais não treinados'}
                
        except Exception as e:
            logger.error(f"Erro no modelo híbrido: {e}")
            return {'error': str(e)}
    
    def _create_user_profiles(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Cria perfis detalhados dos usuários.
        """
        try:
            profiles_created = 0
            
            for _, user_data in data.iterrows():
                user_id = user_data.get('user_id', f'user_{profiles_created}')
                
                profile = {
                    'risk_profile': self._determine_risk_profile(user_data),
                    'investment_preferences': self._extract_preferences(user_data),
                    'portfolio_analysis': self._analyze_current_portfolio(user_data),
                    'behavioral_patterns': self._extract_behavioral_patterns(user_data),
                    'financial_goals': self._extract_financial_goals(user_data)
                }
                
                self.user_profiles[user_id] = profile
                profiles_created += 1
            
            return {
                'profiles_created': profiles_created,
                'average_portfolio_size': np.mean([
                    len(p.get('portfolio_analysis', {}).get('assets', []))
                    for p in self.user_profiles.values()
                ])
            }
            
        except Exception as e:
            logger.error(f"Erro ao criar perfis de usuário: {e}")
            return {'error': str(e)}
    
    def _determine_risk_profile(self, user_data: pd.Series) -> str:
        """
        Determina perfil de risco do usuário.
        """
        try:
            risk_score = 0
            
            # Idade (mais jovem = mais risco)
            age = user_data.get('age', 30)
            if age < 30:
                risk_score += 3
            elif age < 50:
                risk_score += 2
            else:
                risk_score += 1
            
            # Renda (maior renda = mais risco)
            income = user_data.get('income', 5000)
            if income > 20000:
                risk_score += 3
            elif income > 10000:
                risk_score += 2
            else:
                risk_score += 1
            
            # Experiência
            experience = user_data.get('investment_experience', 1)
            risk_score += min(3, experience)
            
            # Tolerância declarada
            tolerance = user_data.get('risk_tolerance', 5)
            risk_score += tolerance // 2
            
            # Classificar perfil
            if risk_score <= 4:
                return 'conservador'
            elif risk_score <= 7:
                return 'moderado'
            elif risk_score <= 10:
                return 'arrojado'
            else:
                return 'agressivo'
                
        except Exception:
            return 'moderado'
    
    def _extract_preferences(self, user_data: pd.Series) -> Dict[str, Any]:
        """
        Extrai preferências de investimento do usuário.
        """
        try:
            preferences = {
                'preferred_categories': [],
                'avoided_categories': [],
                'investment_style': 'buy_and_hold',
                'dividend_preference': False,
                'growth_preference': True
            }
            
            # Analisar portfolio atual para inferir preferências
            current_portfolio = user_data.get('current_portfolio', [])
            if isinstance(current_portfolio, str):
                current_portfolio = current_portfolio.split(',')
            
            category_counts = defaultdict(int)
            for asset in current_portfolio:
                for category, assets in self.asset_categories.items():
                    if asset in assets:
                        category_counts[category] += 1
            
            # Categorias preferidas (mais de 2 ativos)
            preferences['preferred_categories'] = [
                cat for cat, count in category_counts.items() if count >= 2
            ]
            
            # Inferir estilo baseado em outros dados
            if user_data.get('trading_frequency', 'low') == 'high':
                preferences['investment_style'] = 'trading'
            elif user_data.get('investment_horizon', 12) > 60:
                preferences['investment_style'] = 'long_term'
            
            return preferences
            
        except Exception:
            return {
                'preferred_categories': ['ações'],
                'avoided_categories': [],
                'investment_style': 'buy_and_hold',
                'dividend_preference': False,
                'growth_preference': True
            }
    
    def _analyze_current_portfolio(self, user_data: pd.Series) -> Dict[str, Any]:
        """
        Analisa portfolio atual do usuário.
        """
        try:
            current_portfolio = user_data.get('current_portfolio', [])
            if isinstance(current_portfolio, str):
                current_portfolio = current_portfolio.split(',')
            
            analysis = {
                'total_assets': len(current_portfolio),
                'diversification_score': 0,
                'category_distribution': {},
                'risk_level': 0,
                'assets': current_portfolio
            }
            
            if current_portfolio:
                # Distribuição por categoria
                category_counts = defaultdict(int)
                total_risk = 0
                
                for asset in current_portfolio:
                    for category, assets in self.asset_categories.items():
                        if asset in assets:
                            category_counts[category] += 1
                            # Adicionar risco baseado na categoria
                            if category == 'cripto':
                                total_risk += 0.9
                            elif category == 'ações':
                                total_risk += 0.7
                            elif category == 'fiis':
                                total_risk += 0.4
                            elif category == 'etfs':
                                total_risk += 0.5
                            else:  # renda_fixa
                                total_risk += 0.1
                
                # Calcular distribuição percentual
                total_assets = len(current_portfolio)
                for category, count in category_counts.items():
                    analysis['category_distribution'][category] = count / total_assets
                
                # Score de diversificação (mais categorias = melhor)
                analysis['diversification_score'] = len(category_counts) / len(self.asset_categories)
                
                # Nível de risco médio
                analysis['risk_level'] = total_risk / total_assets if total_assets > 0 else 0
            
            return analysis
            
        except Exception:
            return {
                'total_assets': 0,
                'diversification_score': 0,
                'category_distribution': {},
                'risk_level': 0.5,
                'assets': []
            }
    
    def _extract_behavioral_patterns(self, user_data: pd.Series) -> Dict[str, Any]:
        """
        Extrai padrões comportamentais do usuário.
        """
        try:
            patterns = {
                'trading_frequency': user_data.get('trading_frequency', 'medium'),
                'market_timing_tendency': user_data.get('market_timing', 'low'),
                'research_depth': user_data.get('research_level', 'medium'),
                'emotional_trading': user_data.get('emotional_control', 'high'),
                'follow_trends': user_data.get('trend_following', 'medium')
            }
            
            return patterns
            
        except Exception:
            return {
                'trading_frequency': 'medium',
                'market_timing_tendency': 'low',
                'research_depth': 'medium',
                'emotional_trading': 'high',
                'follow_trends': 'medium'
            }
    
    def _extract_financial_goals(self, user_data: pd.Series) -> List[Dict[str, Any]]:
        """
        Extrai objetivos financeiros do usuário.
        """
        try:
            goals = []
            
            # Objetivos padrão baseados no perfil
            age = user_data.get('age', 30)
            income = user_data.get('income', 5000)
            
            if age < 35:
                goals.append({
                    'type': 'emergency_fund',
                    'target_amount': income * 6,
                    'priority': 'high',
                    'timeframe': 12
                })
                goals.append({
                    'type': 'house_down_payment',
                    'target_amount': 100000,
                    'priority': 'medium',
                    'timeframe': 60
                })
            elif age < 50:
                goals.append({
                    'type': 'retirement',
                    'target_amount': income * 25 * 12,
                    'priority': 'high',
                    'timeframe': (65 - age) * 12
                })
                goals.append({
                    'type': 'children_education',
                    'target_amount': 200000,
                    'priority': 'medium',
                    'timeframe': 180
                })
            else:
                goals.append({
                    'type': 'retirement',
                    'target_amount': income * 20 * 12,
                    'priority': 'high',
                    'timeframe': (65 - age) * 12
                })
            
            return goals
            
        except Exception:
            return [{
                'type': 'general_investment',
                'target_amount': 50000,
                'priority': 'medium',
                'timeframe': 36
            }]
    
    def predict(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Gera recomendações para usuários.
        """
        try:
            if data.empty:
                return {'error': 'Dados de usuário não fornecidos'}
            
            recommendations = []
            
            for _, user_data in data.iterrows():
                user_id = user_data.get('user_id', 'anonymous')
                user_recommendations = self._generate_user_recommendations(user_id, user_data)
                recommendations.append({
                    'user_id': user_id,
                    'recommendations': user_recommendations
                })
            
            return {
                'total_users': len(recommendations),
                'recommendations': recommendations
            }
            
        except Exception as e:
            logger.error(f"Erro na geração de recomendações: {e}")
            return {'error': str(e)}
    
    def _generate_user_recommendations(self, user_id: str, user_data: pd.Series) -> List[Dict[str, Any]]:
        """
        Gera recomendações para um usuário específico.
        """
        try:
            recommendations = []
            
            # Obter perfil do usuário
            user_profile = self.user_profiles.get(user_id)
            if not user_profile:
                # Criar perfil temporário
                user_profile = {
                    'risk_profile': self._determine_risk_profile(user_data),
                    'investment_preferences': self._extract_preferences(user_data),
                    'portfolio_analysis': self._analyze_current_portfolio(user_data)
                }
            
            # Recomendações baseadas em perfil de risco
            risk_based_recs = self._get_risk_based_recommendations(user_profile)
            recommendations.extend(risk_based_recs)
            
            # Recomendações colaborativas
            if self.collaborative_model:
                collaborative_recs = self._get_collaborative_recommendations(user_id, user_data)
                recommendations.extend(collaborative_recs)
            
            # Recomendações baseadas em conteúdo
            if self.content_model:
                content_recs = self._get_content_based_recommendations(user_profile)
                recommendations.extend(content_recs)
            
            # Recomendações de diversificação
            diversification_recs = self._get_diversification_recommendations(user_profile)
            recommendations.extend(diversification_recs)
            
            # Remover duplicatas e ordenar por score
            unique_recommendations = self._deduplicate_and_rank(recommendations)
            
            return unique_recommendations[:self.max_recommendations]
            
        except Exception as e:
            logger.error(f"Erro ao gerar recomendações para usuário {user_id}: {e}")
            return []
    
    def _get_risk_based_recommendations(self, user_profile: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Gera recomendações baseadas no perfil de risco.
        """
        try:
            recommendations = []
            risk_profile = user_profile.get('risk_profile', 'moderado')
            target_allocation = self.risk_profiles.get(risk_profile, self.risk_profiles['moderado'])
            
            for category, target_weight in target_allocation.items():
                if target_weight > 0:
                    assets = self.asset_categories.get(category, [])
                    for asset in assets[:2]:  # Top 2 por categoria
                        recommendations.append({
                            'asset': asset,
                            'category': category,
                            'recommendation_type': 'risk_based',
                            'score': target_weight * 0.8,  # Score baseado no peso alvo
                            'reason': f'Adequado para perfil {risk_profile}',
                            'target_allocation': target_weight
                        })
            
            return recommendations
            
        except Exception:
            return []
    
    def _get_collaborative_recommendations(self, user_id: str, user_data: pd.Series) -> List[Dict[str, Any]]:
        """
        Gera recomendações usando filtragem colaborativa.
        """
        try:
            if not self.collaborative_model:
                return []
            
            recommendations = []
            model = self.collaborative_model
            
            # Simular recomendações colaborativas
            # Em produção, usaria a matriz real de usuário-item
            similar_users_assets = ['ITUB4', 'BBDC4', 'ABEV3', 'HGLG11']
            
            for asset in similar_users_assets:
                recommendations.append({
                    'asset': asset,
                    'category': self._get_asset_category(asset),
                    'recommendation_type': 'collaborative',
                    'score': np.random.uniform(0.6, 0.9),
                    'reason': 'Usuários similares também investem neste ativo',
                    'similar_users_count': np.random.randint(5, 20)
                })
            
            return recommendations
            
        except Exception:
            return []
    
    def _get_content_based_recommendations(self, user_profile: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Gera recomendações baseadas em conteúdo.
        """
        try:
            if not self.content_model or not SKLEARN_AVAILABLE:
                return []
            
            recommendations = []
            portfolio_analysis = user_profile.get('portfolio_analysis', {})
            current_assets = portfolio_analysis.get('assets', [])
            
            if not current_assets:
                return []
            
            # Calcular similaridade com ativos atuais
            model = self.content_model
            items = model['items']
            features_matrix = model['features_matrix']
            
            # Perfil médio dos ativos atuais
            current_indices = [items.index(asset) for asset in current_assets if asset in items]
            if not current_indices:
                return []
            
            user_profile_vector = np.mean(features_matrix[current_indices], axis=0)
            
            # Calcular similaridade com todos os ativos
            similarities = cosine_similarity([user_profile_vector], features_matrix)[0]
            
            # Recomendar ativos similares que o usuário não possui
            for i, similarity in enumerate(similarities):
                asset = items[i]
                if asset not in current_assets and similarity > self.similarity_threshold:
                    recommendations.append({
                        'asset': asset,
                        'category': self._get_asset_category(asset),
                        'recommendation_type': 'content_based',
                        'score': float(similarity),
                        'reason': f'Similar aos seus investimentos atuais (similaridade: {similarity:.2f})',
                        'similarity_score': float(similarity)
                    })
            
            return sorted(recommendations, key=lambda x: x['score'], reverse=True)
            
        except Exception:
            return []
    
    def _get_diversification_recommendations(self, user_profile: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Gera recomendações para melhorar diversificação.
        """
        try:
            recommendations = []
            portfolio_analysis = user_profile.get('portfolio_analysis', {})
            category_distribution = portfolio_analysis.get('category_distribution', {})
            
            # Identificar categorias sub-representadas
            for category, assets in self.asset_categories.items():
                current_weight = category_distribution.get(category, 0)
                
                # Se categoria tem menos de 10% do portfolio, recomendar
                if current_weight < 0.1:
                    for asset in assets[:1]:  # Top 1 por categoria
                        recommendations.append({
                            'asset': asset,
                            'category': category,
                            'recommendation_type': 'diversification',
                            'score': 0.7,
                            'reason': f'Melhora diversificação - categoria {category} sub-representada',
                            'current_allocation': current_weight,
                            'diversification_benefit': True
                        })
            
            return recommendations
            
        except Exception:
            return []
    
    def _get_asset_category(self, asset: str) -> str:
        """
        Retorna categoria de um ativo.
        """
        for category, assets in self.asset_categories.items():
            if asset in assets:
                return category
        return 'outros'
    
    def _deduplicate_and_rank(self, recommendations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Remove duplicatas e ordena recomendações por score.
        """
        try:
            # Agrupar por ativo
            asset_recommendations = {}
            
            for rec in recommendations:
                asset = rec['asset']
                if asset not in asset_recommendations:
                    asset_recommendations[asset] = rec
                else:
                    # Manter a recomendação com maior score
                    if rec['score'] > asset_recommendations[asset]['score']:
                        asset_recommendations[asset] = rec
            
            # Ordenar por score
            sorted_recommendations = sorted(
                asset_recommendations.values(),
                key=lambda x: x['score'],
                reverse=True
            )
            
            return sorted_recommendations
            
        except Exception:
            return recommendations
    
    def recommend_assets(self, user_id: str, user_profile: Dict[str, Any], 
                        max_recommendations: int = 10) -> List[Dict[str, Any]]:
        """
        Recomenda ativos para um usuário específico.
        """
        try:
            # Criar DataFrame temporário com dados do usuário
            user_data = pd.Series(user_profile)
            user_data['user_id'] = user_id
            
            # Gerar recomendações
            recommendations = self._generate_user_recommendations(user_id, user_data)
            
            # Adicionar informações adicionais
            for rec in recommendations:
                rec['recommendation_date'] = datetime.now().isoformat()
                rec['user_id'] = user_id
                
                # Adicionar dados do ativo se disponível
                asset_profile = self.item_profiles.get(rec['asset'])
                if asset_profile:
                    rec['asset_profile'] = asset_profile
            
            return recommendations[:max_recommendations]
            
        except Exception as e:
            logger.error(f"Erro ao recomendar ativos para {user_id}: {e}")
            return []
    
    def get_portfolio_optimization(self, user_id: str, current_portfolio: List[str], 
                                 target_amount: float) -> Dict[str, Any]:
        """
        Otimiza portfolio existente.
        """
        try:
            optimization = {
                'current_portfolio': current_portfolio,
                'target_amount': target_amount,
                'recommendations': [],
                'rebalancing_suggestions': [],
                'risk_analysis': {}
            }
            
            # Analisar portfolio atual
            portfolio_analysis = self._analyze_portfolio_composition(current_portfolio)
            optimization['current_analysis'] = portfolio_analysis
            
            # Sugerir rebalanceamento
            rebalancing = self._suggest_rebalancing(current_portfolio, target_amount)
            optimization['rebalancing_suggestions'] = rebalancing
            
            # Novos ativos para adicionar
            new_assets = self._suggest_new_assets(current_portfolio)
            optimization['new_asset_suggestions'] = new_assets
            
            # Análise de risco
            risk_analysis = self._analyze_portfolio_risk(current_portfolio)
            optimization['risk_analysis'] = risk_analysis
            
            return optimization
            
        except Exception as e:
            logger.error(f"Erro na otimização de portfolio: {e}")
            return {'error': str(e)}
    
    def _analyze_portfolio_composition(self, portfolio: List[str]) -> Dict[str, Any]:
        """
        Analisa composição do portfolio.
        """
        try:
            analysis = {
                'total_assets': len(portfolio),
                'category_distribution': {},
                'diversification_score': 0,
                'concentration_risk': 0
            }
            
            # Distribuição por categoria
            category_counts = defaultdict(int)
            for asset in portfolio:
                category = self._get_asset_category(asset)
                category_counts[category] += 1
            
            total_assets = len(portfolio)
            for category, count in category_counts.items():
                analysis['category_distribution'][category] = count / total_assets
            
            # Score de diversificação
            analysis['diversification_score'] = len(category_counts) / len(self.asset_categories)
            
            # Risco de concentração (se mais de 30% em uma categoria)
            max_concentration = max(analysis['category_distribution'].values()) if analysis['category_distribution'] else 0
            analysis['concentration_risk'] = max(0, max_concentration - 0.3)
            
            return analysis
            
        except Exception:
            return {}
    
    def _suggest_rebalancing(self, portfolio: List[str], target_amount: float) -> List[Dict[str, Any]]:
        """
        Sugere rebalanceamento do portfolio.
        """
        try:
            suggestions = []
            
            # Análise simplificada - em produção usaria preços reais
            equal_weight = target_amount / len(portfolio) if portfolio else 0
            
            for asset in portfolio:
                suggestions.append({
                    'asset': asset,
                    'action': 'hold',
                    'current_weight': 1 / len(portfolio),
                    'target_weight': 1 / len(portfolio),
                    'suggested_amount': equal_weight,
                    'reason': 'Manter posição atual'
                })
            
            return suggestions
            
        except Exception:
            return []
    
    def _suggest_new_assets(self, current_portfolio: List[str]) -> List[Dict[str, Any]]:
        """
        Sugere novos ativos para adicionar ao portfolio.
        """
        try:
            suggestions = []
            
            # Identificar categorias ausentes
            current_categories = set()
            for asset in current_portfolio:
                current_categories.add(self._get_asset_category(asset))
            
            missing_categories = set(self.asset_categories.keys()) - current_categories
            
            for category in missing_categories:
                assets = self.asset_categories[category]
                if assets:
                    suggestions.append({
                        'asset': assets[0],
                        'category': category,
                        'reason': f'Adicionar exposição à categoria {category}',
                        'priority': 'medium'
                    })
            
            return suggestions
            
        except Exception:
            return []
    
    def _analyze_portfolio_risk(self, portfolio: List[str]) -> Dict[str, Any]:
        """
        Analisa risco do portfolio.
        """
        try:
            risk_analysis = {
                'overall_risk': 0,
                'volatility_estimate': 0,
                'risk_factors': [],
                'risk_level': 'medium'
            }
            
            if not portfolio:
                return risk_analysis
            
            # Calcular risco médio baseado nas categorias
            total_risk = 0
            for asset in portfolio:
                category = self._get_asset_category(asset)
                if category == 'cripto':
                    total_risk += 0.9
                elif category == 'ações':
                    total_risk += 0.7
                elif category == 'fiis':
                    total_risk += 0.4
                elif category == 'etfs':
                    total_risk += 0.5
                else:  # renda_fixa
                    total_risk += 0.1
            
            risk_analysis['overall_risk'] = total_risk / len(portfolio)
            risk_analysis['volatility_estimate'] = risk_analysis['overall_risk'] * 0.3
            
            # Determinar nível de risco
            if risk_analysis['overall_risk'] < 0.3:
                risk_analysis['risk_level'] = 'low'
            elif risk_analysis['overall_risk'] < 0.6:
                risk_analysis['risk_level'] = 'medium'
            else:
                risk_analysis['risk_level'] = 'high'
            
            return risk_analysis
            
        except Exception:
            return {}
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas de performance do engine de recomendações.
        """
        return {
            'is_trained': self.is_trained,
            'last_training': self.last_training_date.isoformat() if self.last_training_date else None,
            'user_profiles_count': len(self.user_profiles),
            'item_profiles_count': len(self.item_profiles),
            'asset_categories_count': len(self.asset_categories),
            'sklearn_available': SKLEARN_AVAILABLE,
            'collaborative_model_available': self.collaborative_model is not None,
            'content_model_available': self.content_model is not None
        }

