"""
Engine Base de Machine Learning para Quantum Trades
Sprint 5 - Infraestrutura fundamental para todos os modelos de ML
"""

import logging
import pickle
import json
import os
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import pandas as pd

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BaseMLEngine(ABC):
    """
    Classe base abstrata para todos os engines de ML do Quantum Trades.
    Define interface comum e funcionalidades compartilhadas.
    """
    
    def __init__(self, model_name: str, version: str = "1.0.0"):
        self.model_name = model_name
        self.version = version
        self.model = None
        self.is_trained = False
        self.last_training_date = None
        self.performance_metrics = {}
        self.feature_names = []
        self.model_path = f"models/{model_name}_v{version}.pkl"
        
        # Criar diretório de modelos se não existir
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        
        logger.info(f"Inicializando {model_name} v{version}")
    
    @abstractmethod
    def prepare_features(self, data: pd.DataFrame) -> np.ndarray:
        """
        Prepara features para o modelo.
        Deve ser implementado por cada engine específico.
        """
        pass
    
    @abstractmethod
    def train(self, training_data: pd.DataFrame, target: pd.Series) -> Dict[str, Any]:
        """
        Treina o modelo com os dados fornecidos.
        Retorna métricas de performance.
        """
        pass
    
    @abstractmethod
    def predict(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Faz predições usando o modelo treinado.
        Retorna predições com intervalos de confiança.
        """
        pass
    
    def validate_data(self, data: pd.DataFrame) -> bool:
        """
        Valida se os dados estão no formato correto.
        """
        if data is None or data.empty:
            logger.error("Dados vazios ou None fornecidos")
            return False
        
        required_columns = self.get_required_columns()
        missing_columns = set(required_columns) - set(data.columns)
        
        if missing_columns:
            logger.error(f"Colunas obrigatórias ausentes: {missing_columns}")
            return False
        
        # Verificar se há dados suficientes
        if len(data) < self.get_minimum_data_points():
            logger.error(f"Dados insuficientes. Mínimo: {self.get_minimum_data_points()}, Fornecido: {len(data)}")
            return False
        
        return True
    
    def get_required_columns(self) -> List[str]:
        """
        Retorna lista de colunas obrigatórias.
        Pode ser sobrescrito por engines específicos.
        """
        return ['timestamp', 'close', 'volume']
    
    def get_minimum_data_points(self) -> int:
        """
        Retorna número mínimo de pontos de dados necessários.
        Pode ser sobrescrito por engines específicos.
        """
        return 100
    
    def save_model(self) -> bool:
        """
        Salva o modelo treinado em disco.
        """
        try:
            if self.model is None:
                logger.error("Nenhum modelo para salvar")
                return False
            
            model_data = {
                'model': self.model,
                'model_name': self.model_name,
                'version': self.version,
                'is_trained': self.is_trained,
                'last_training_date': self.last_training_date,
                'performance_metrics': self.performance_metrics,
                'feature_names': self.feature_names
            }
            
            with open(self.model_path, 'wb') as f:
                pickle.dump(model_data, f)
            
            logger.info(f"Modelo salvo em {self.model_path}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao salvar modelo: {e}")
            return False
    
    def load_model(self) -> bool:
        """
        Carrega modelo salvo do disco.
        """
        try:
            if not os.path.exists(self.model_path):
                logger.warning(f"Arquivo de modelo não encontrado: {self.model_path}")
                return False
            
            with open(self.model_path, 'rb') as f:
                model_data = pickle.load(f)
            
            self.model = model_data['model']
            self.model_name = model_data['model_name']
            self.version = model_data['version']
            self.is_trained = model_data['is_trained']
            self.last_training_date = model_data['last_training_date']
            self.performance_metrics = model_data['performance_metrics']
            self.feature_names = model_data['feature_names']
            
            logger.info(f"Modelo carregado de {self.model_path}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao carregar modelo: {e}")
            return False
    
    def needs_retraining(self, max_age_days: int = 7) -> bool:
        """
        Verifica se o modelo precisa ser retreinado.
        """
        if not self.is_trained or self.last_training_date is None:
            return True
        
        age = datetime.now() - self.last_training_date
        return age.days > max_age_days
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Retorna informações sobre o modelo.
        """
        return {
            'model_name': self.model_name,
            'version': self.version,
            'is_trained': self.is_trained,
            'last_training_date': self.last_training_date.isoformat() if self.last_training_date else None,
            'performance_metrics': self.performance_metrics,
            'feature_count': len(self.feature_names),
            'feature_names': self.feature_names
        }
    
    def calculate_confidence_interval(self, predictions: np.ndarray, confidence_level: float = 0.95) -> Tuple[np.ndarray, np.ndarray]:
        """
        Calcula intervalos de confiança para as predições.
        """
        try:
            # Método simples usando desvio padrão
            std = np.std(predictions)
            z_score = 1.96 if confidence_level == 0.95 else 2.576  # 95% ou 99%
            
            margin = z_score * std
            lower_bound = predictions - margin
            upper_bound = predictions + margin
            
            return lower_bound, upper_bound
            
        except Exception as e:
            logger.error(f"Erro ao calcular intervalos de confiança: {e}")
            return predictions, predictions
    
    def log_prediction(self, symbol: str, prediction_data: Dict[str, Any]) -> None:
        """
        Log de predições para monitoramento.
        """
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'model_name': self.model_name,
            'version': self.version,
            'symbol': symbol,
            'prediction_data': prediction_data
        }
        
        logger.info(f"Predição: {json.dumps(log_entry, indent=2)}")

class FeatureEngineer:
    """
    Classe para engenharia de features financeiras.
    """
    
    @staticmethod
    def calculate_technical_indicators(data: pd.DataFrame) -> pd.DataFrame:
        """
        Calcula indicadores técnicos básicos.
        """
        df = data.copy()
        
        # Moving Averages
        df['sma_10'] = df['close'].rolling(window=10).mean()
        df['sma_20'] = df['close'].rolling(window=20).mean()
        df['sma_50'] = df['close'].rolling(window=50).mean()
        
        # Exponential Moving Averages
        df['ema_12'] = df['close'].ewm(span=12).mean()
        df['ema_26'] = df['close'].ewm(span=26).mean()
        
        # MACD
        df['macd'] = df['ema_12'] - df['ema_26']
        df['macd_signal'] = df['macd'].ewm(span=9).mean()
        df['macd_histogram'] = df['macd'] - df['macd_signal']
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # Bollinger Bands
        df['bb_middle'] = df['close'].rolling(window=20).mean()
        bb_std = df['close'].rolling(window=20).std()
        df['bb_upper'] = df['bb_middle'] + (bb_std * 2)
        df['bb_lower'] = df['bb_middle'] - (bb_std * 2)
        df['bb_width'] = df['bb_upper'] - df['bb_lower']
        df['bb_position'] = (df['close'] - df['bb_lower']) / df['bb_width']
        
        # Volume indicators
        df['volume_sma'] = df['volume'].rolling(window=20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_sma']
        
        # Price features
        df['price_change'] = df['close'].pct_change()
        df['price_change_abs'] = df['price_change'].abs()
        df['high_low_ratio'] = df['high'] / df['low']
        df['close_open_ratio'] = df['close'] / df['open']
        
        # Volatility
        df['volatility'] = df['price_change'].rolling(window=20).std()
        
        return df
    
    @staticmethod
    def create_lag_features(data: pd.DataFrame, columns: List[str], lags: List[int]) -> pd.DataFrame:
        """
        Cria features de lag para séries temporais.
        """
        df = data.copy()
        
        for col in columns:
            for lag in lags:
                df[f'{col}_lag_{lag}'] = df[col].shift(lag)
        
        return df
    
    @staticmethod
    def create_rolling_features(data: pd.DataFrame, columns: List[str], windows: List[int]) -> pd.DataFrame:
        """
        Cria features de rolling statistics.
        """
        df = data.copy()
        
        for col in columns:
            for window in windows:
                df[f'{col}_mean_{window}'] = df[col].rolling(window=window).mean()
                df[f'{col}_std_{window}'] = df[col].rolling(window=window).std()
                df[f'{col}_min_{window}'] = df[col].rolling(window=window).min()
                df[f'{col}_max_{window}'] = df[col].rolling(window=window).max()
        
        return df

class ModelValidator:
    """
    Classe para validação de modelos de ML.
    """
    
    @staticmethod
    def calculate_regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
        """
        Calcula métricas para problemas de regressão.
        """
        from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
        
        mse = mean_squared_error(y_true, y_pred)
        rmse = np.sqrt(mse)
        mae = mean_absolute_error(y_true, y_pred)
        r2 = r2_score(y_true, y_pred)
        
        # Métricas específicas para finanças
        directional_accuracy = np.mean(np.sign(y_true) == np.sign(y_pred))
        
        return {
            'mse': mse,
            'rmse': rmse,
            'mae': mae,
            'r2': r2,
            'directional_accuracy': directional_accuracy
        }
    
    @staticmethod
    def calculate_classification_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
        """
        Calcula métricas para problemas de classificação.
        """
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average='weighted')
        recall = recall_score(y_true, y_pred, average='weighted')
        f1 = f1_score(y_true, y_pred, average='weighted')
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1
        }
    
    @staticmethod
    def backtest_predictions(predictions: pd.DataFrame, actual_prices: pd.DataFrame) -> Dict[str, Any]:
        """
        Realiza backtesting das predições.
        """
        results = {}
        
        # Calcular accuracy por timeframe
        for timeframe in ['1d', '5d', '10d', '20d']:
            if timeframe in predictions.columns:
                pred_col = f'predicted_{timeframe}'
                actual_col = f'actual_{timeframe}'
                
                if pred_col in predictions.columns and actual_col in actual_prices.columns:
                    pred_values = predictions[pred_col].dropna()
                    actual_values = actual_prices[actual_col].dropna()
                    
                    # Alinhar índices
                    common_index = pred_values.index.intersection(actual_values.index)
                    pred_aligned = pred_values.loc[common_index]
                    actual_aligned = actual_values.loc[common_index]
                    
                    if len(pred_aligned) > 0:
                        metrics = ModelValidator.calculate_regression_metrics(
                            actual_aligned.values, pred_aligned.values
                        )
                        results[timeframe] = metrics
        
        return results

# Cache para modelos
class ModelCache:
    """
    Sistema de cache para modelos e predições.
    """
    
    def __init__(self):
        self.cache = {}
        self.cache_timeout = 3600  # 1 hora
    
    def get(self, key: str) -> Optional[Any]:
        """
        Recupera item do cache.
        """
        if key in self.cache:
            item, timestamp = self.cache[key]
            if datetime.now().timestamp() - timestamp < self.cache_timeout:
                return item
            else:
                del self.cache[key]
        return None
    
    def set(self, key: str, value: Any) -> None:
        """
        Armazena item no cache.
        """
        self.cache[key] = (value, datetime.now().timestamp())
    
    def clear(self) -> None:
        """
        Limpa o cache.
        """
        self.cache.clear()

# Instância global do cache
model_cache = ModelCache()

