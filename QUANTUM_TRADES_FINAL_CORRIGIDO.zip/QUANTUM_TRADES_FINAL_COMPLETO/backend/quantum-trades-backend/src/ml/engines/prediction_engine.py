"""
Engine de Predição Avançada - Quantum Trades
Sprint 5 - Épico 1: Modelos LSTM, detecção de padrões e predições de preços
"""

import numpy as np
import pandas as pd
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import joblib
import json

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential, load_model
    from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
    from tensorflow.keras.optimizers import Adam
    from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
    from sklearn.preprocessing import MinMaxScaler, StandardScaler
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
    TENSORFLOW_AVAILABLE = True
except ImportError as e:
    logger.warning(f"TensorFlow não disponível: {e}")
    TENSORFLOW_AVAILABLE = False

from .base_ml_engine import BaseMLEngine, FeatureEngineer, ModelValidator
from ..pipelines.data_pipeline import DataPipeline

class PredictionEngine(BaseMLEngine):
    """
    Engine principal para predições de preços usando LSTM e ensemble de modelos.
    """
    
    def __init__(self):
        super().__init__("PredictionEngine", "1.0.0")
        self.data_pipeline = DataPipeline()
        self.models = {}
        self.scalers = {}
        self.feature_columns = []
        self.sequence_length = 60  # 60 dias de histórico
        
        # Configurações dos modelos
        self.model_configs = {
            'lstm_short': {'sequence_length': 30, 'prediction_days': [1, 5]},
            'lstm_medium': {'sequence_length': 60, 'prediction_days': [10, 20]},
            'rf_ensemble': {'n_estimators': 100, 'prediction_days': [1, 5, 10]},
            'gb_ensemble': {'n_estimators': 100, 'prediction_days': [5, 10, 20]}
        }
        
        logger.info("Engine de Predição inicializado")
    
    def prepare_features(self, data: pd.DataFrame) -> np.ndarray:
        """
        Prepara features para os modelos de predição.
        """
        try:
            if data.empty:
                return np.array([])
            
            # Aplicar feature engineering
            featured_data = FeatureEngineer.calculate_technical_indicators(data)
            
            # Adicionar features de lag
            lag_columns = ['close', 'volume', 'rsi', 'macd']
            featured_data = FeatureEngineer.create_lag_features(
                featured_data, lag_columns, [1, 2, 3, 5, 10]
            )
            
            # Adicionar rolling features
            rolling_columns = ['close', 'volume', 'price_change']
            featured_data = FeatureEngineer.create_rolling_features(
                featured_data, rolling_columns, [5, 10, 20]
            )
            
            # Selecionar features numéricas
            numeric_columns = featured_data.select_dtypes(include=[np.number]).columns
            featured_data = featured_data[numeric_columns]
            
            # Remover valores infinitos e NaN
            featured_data = featured_data.replace([np.inf, -np.inf], np.nan)
            featured_data = featured_data.fillna(method='ffill').fillna(method='bfill')
            
            # Armazenar nomes das features
            self.feature_columns = featured_data.columns.tolist()
            
            return featured_data.values
            
        except Exception as e:
            logger.error(f"Erro ao preparar features: {e}")
            return np.array([])
    
    def create_lstm_model(self, input_shape: Tuple[int, int], prediction_horizon: int = 1):
        """
        Cria modelo LSTM otimizado para predição de preços.
        """
        if not TENSORFLOW_AVAILABLE:
            raise ImportError("TensorFlow não está disponível")
        
        import tensorflow as tf
        from tensorflow.keras.models import Sequential
        from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
        from tensorflow.keras.optimizers import Adam
        
        model = Sequential([
            LSTM(128, return_sequences=True, input_shape=input_shape),
            Dropout(0.2),
            BatchNormalization(),
            
            LSTM(64, return_sequences=True),
            Dropout(0.2),
            BatchNormalization(),
            
            LSTM(32, return_sequences=False),
            Dropout(0.2),
            
            Dense(50, activation='relu'),
            Dropout(0.1),
            Dense(25, activation='relu'),
            Dense(prediction_horizon)
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae']
        )
        
        return model
    
    def prepare_lstm_data(self, data: np.ndarray, target_column_idx: int = 0, 
                         sequence_length: int = 60) -> Tuple[np.ndarray, np.ndarray]:
        """
        Prepara dados para treinamento do LSTM.
        """
        try:
            X, y = [], []
            
            for i in range(sequence_length, len(data)):
                X.append(data[i-sequence_length:i])
                y.append(data[i, target_column_idx])
            
            return np.array(X), np.array(y)
            
        except Exception as e:
            logger.error(f"Erro ao preparar dados LSTM: {e}")
            return np.array([]), np.array([])
    
    def train(self, training_data: pd.DataFrame, target: pd.Series) -> Dict[str, Any]:
        """
        Treina todos os modelos de predição.
        """
        try:
            logger.info("Iniciando treinamento dos modelos de predição")
            
            if not self.validate_data(training_data):
                return {'error': 'Dados de treinamento inválidos'}
            
            # Preparar features
            features = self.prepare_features(training_data)
            if features.size == 0:
                return {'error': 'Falha ao preparar features'}
            
            # Normalizar dados
            scaler = MinMaxScaler()
            features_scaled = scaler.fit_transform(features)
            self.scalers['features'] = scaler
            
            # Normalizar target
            target_scaler = MinMaxScaler()
            target_scaled = target_scaler.fit_transform(target.values.reshape(-1, 1)).flatten()
            self.scalers['target'] = target_scaler
            
            results = {}
            
            # Treinar modelos LSTM
            if TENSORFLOW_AVAILABLE:
                results.update(self._train_lstm_models(features_scaled, target_scaled))
            
            # Treinar modelos ensemble
            results.update(self._train_ensemble_models(features_scaled, target_scaled))
            
            self.is_trained = True
            self.last_training_date = datetime.now()
            
            # Salvar modelos
            self.save_model()
            
            logger.info("Treinamento concluído com sucesso")
            return results
            
        except Exception as e:
            logger.error(f"Erro no treinamento: {e}")
            return {'error': str(e)}
    
    def _train_lstm_models(self, features: np.ndarray, target: np.ndarray) -> Dict[str, Any]:
        """
        Treina modelos LSTM para diferentes horizontes temporais.
        """
        results = {}
        
        try:
            for model_name, config in self.model_configs.items():
                if not model_name.startswith('lstm'):
                    continue
                
                sequence_length = config['sequence_length']
                
                # Preparar dados sequenciais
                X, y = self.prepare_lstm_data(features, 0, sequence_length)
                
                if len(X) == 0:
                    continue
                
                # Split treino/validação
                split_idx = int(len(X) * 0.8)
                X_train, X_val = X[:split_idx], X[split_idx:]
                y_train, y_val = y[:split_idx], y[split_idx:]
                
                # Criar e treinar modelo
                model = self.create_lstm_model((sequence_length, features.shape[1]))
                
                # Callbacks
                callbacks = [
                    EarlyStopping(patience=10, restore_best_weights=True),
                    ReduceLROnPlateau(patience=5, factor=0.5)
                ]
                
                # Treinar
                history = model.fit(
                    X_train, y_train,
                    validation_data=(X_val, y_val),
                    epochs=100,
                    batch_size=32,
                    callbacks=callbacks,
                    verbose=0
                )
                
                # Avaliar
                val_predictions = model.predict(X_val)
                val_loss = mean_squared_error(y_val, val_predictions)
                val_mae = mean_absolute_error(y_val, val_predictions)
                
                # Salvar modelo
                self.models[model_name] = model
                
                results[model_name] = {
                    'val_loss': float(val_loss),
                    'val_mae': float(val_mae),
                    'epochs_trained': len(history.history['loss']),
                    'sequence_length': sequence_length
                }
                
                logger.info(f"Modelo {model_name} treinado - Val Loss: {val_loss:.6f}")
            
            return results
            
        except Exception as e:
            logger.error(f"Erro no treinamento LSTM: {e}")
            return {}
    
    def _train_ensemble_models(self, features: np.ndarray, target: np.ndarray) -> Dict[str, Any]:
        """
        Treina modelos ensemble (Random Forest, Gradient Boosting).
        """
        results = {}
        
        try:
            # Split treino/validação
            split_idx = int(len(features) * 0.8)
            X_train, X_val = features[:split_idx], features[split_idx:]
            y_train, y_val = target[:split_idx], target[split_idx:]
            
            # Random Forest
            rf_model = RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                random_state=42,
                n_jobs=-1
            )
            rf_model.fit(X_train, y_train)
            rf_pred = rf_model.predict(X_val)
            
            self.models['rf_ensemble'] = rf_model
            results['rf_ensemble'] = {
                'val_mse': float(mean_squared_error(y_val, rf_pred)),
                'val_mae': float(mean_absolute_error(y_val, rf_pred)),
                'val_r2': float(r2_score(y_val, rf_pred))
            }
            
            # Gradient Boosting
            gb_model = GradientBoostingRegressor(
                n_estimators=100,
                learning_rate=0.1,
                max_depth=6,
                random_state=42
            )
            gb_model.fit(X_train, y_train)
            gb_pred = gb_model.predict(X_val)
            
            self.models['gb_ensemble'] = gb_model
            results['gb_ensemble'] = {
                'val_mse': float(mean_squared_error(y_val, gb_pred)),
                'val_mae': float(mean_absolute_error(y_val, gb_pred)),
                'val_r2': float(r2_score(y_val, gb_pred))
            }
            
            logger.info("Modelos ensemble treinados com sucesso")
            return results
            
        except Exception as e:
            logger.error(f"Erro no treinamento ensemble: {e}")
            return {}
    
    def predict(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Faz predições usando ensemble de modelos.
        """
        try:
            if not self.is_trained:
                return {'error': 'Modelos não treinados'}
            
            # Preparar features
            features = self.prepare_features(data)
            if features.size == 0:
                return {'error': 'Falha ao preparar features'}
            
            # Normalizar features
            if 'features' not in self.scalers:
                return {'error': 'Scaler não disponível'}
            
            features_scaled = self.scalers['features'].transform(features)
            
            predictions = {}
            
            # Predições LSTM
            if TENSORFLOW_AVAILABLE:
                lstm_predictions = self._predict_lstm(features_scaled)
                predictions.update(lstm_predictions)
            
            # Predições ensemble
            ensemble_predictions = self._predict_ensemble(features_scaled)
            predictions.update(ensemble_predictions)
            
            # Combinar predições
            combined_predictions = self._combine_predictions(predictions)
            
            return combined_predictions
            
        except Exception as e:
            logger.error(f"Erro na predição: {e}")
            return {'error': str(e)}
    
    def _predict_lstm(self, features: np.ndarray) -> Dict[str, Any]:
        """
        Faz predições usando modelos LSTM.
        """
        predictions = {}
        
        try:
            for model_name, model in self.models.items():
                if not model_name.startswith('lstm'):
                    continue
                
                config = self.model_configs[model_name]
                sequence_length = config['sequence_length']
                
                if len(features) < sequence_length:
                    continue
                
                # Preparar sequência
                sequence = features[-sequence_length:].reshape(1, sequence_length, -1)
                
                # Predizer
                pred_scaled = model.predict(sequence, verbose=0)[0]
                
                # Desnormalizar
                pred_original = self.scalers['target'].inverse_transform(
                    pred_scaled.reshape(-1, 1)
                ).flatten()
                
                predictions[model_name] = {
                    'prediction': float(pred_original[0]),
                    'confidence': self._calculate_lstm_confidence(model, sequence),
                    'model_type': 'lstm'
                }
            
            return predictions
            
        except Exception as e:
            logger.error(f"Erro na predição LSTM: {e}")
            return {}
    
    def _predict_ensemble(self, features: np.ndarray) -> Dict[str, Any]:
        """
        Faz predições usando modelos ensemble.
        """
        predictions = {}
        
        try:
            # Usar última observação
            last_features = features[-1:] if len(features) > 0 else features
            
            for model_name, model in self.models.items():
                if model_name.startswith('lstm'):
                    continue
                
                # Predizer
                pred_scaled = model.predict(last_features)[0]
                
                # Desnormalizar
                pred_original = self.scalers['target'].inverse_transform(
                    [[pred_scaled]]
                )[0][0]
                
                predictions[model_name] = {
                    'prediction': float(pred_original),
                    'confidence': self._calculate_ensemble_confidence(model, last_features),
                    'model_type': 'ensemble'
                }
            
            return predictions
            
        except Exception as e:
            logger.error(f"Erro na predição ensemble: {e}")
            return {}
    
    def _combine_predictions(self, predictions: Dict[str, Any]) -> Dict[str, Any]:
        """
        Combina predições de múltiplos modelos.
        """
        try:
            if not predictions:
                return {'error': 'Nenhuma predição disponível'}
            
            # Calcular média ponderada por confiança
            total_weight = 0
            weighted_sum = 0
            
            for model_name, pred_data in predictions.items():
                weight = pred_data.get('confidence', 0.5)
                prediction = pred_data.get('prediction', 0)
                
                weighted_sum += prediction * weight
                total_weight += weight
            
            if total_weight == 0:
                return {'error': 'Peso total zero'}
            
            final_prediction = weighted_sum / total_weight
            
            # Calcular intervalo de confiança
            pred_values = [p['prediction'] for p in predictions.values()]
            std_dev = np.std(pred_values)
            confidence_interval = [
                final_prediction - 1.96 * std_dev,
                final_prediction + 1.96 * std_dev
            ]
            
            return {
                'final_prediction': float(final_prediction),
                'confidence_interval': confidence_interval,
                'individual_predictions': predictions,
                'ensemble_confidence': float(total_weight / len(predictions)),
                'prediction_std': float(std_dev)
            }
            
        except Exception as e:
            logger.error(f"Erro ao combinar predições: {e}")
            return {'error': str(e)}
    
    def _calculate_lstm_confidence(self, model, sequence: np.ndarray) -> float:
        """
        Calcula confiança da predição LSTM.
        """
        try:
            # Fazer múltiplas predições com dropout ativo
            predictions = []
            for _ in range(10):
                pred = model(sequence, training=True)
                predictions.append(pred.numpy()[0])
            
            # Calcular incerteza
            predictions = np.array(predictions)
            uncertainty = np.std(predictions)
            
            # Converter para confiança (0-1)
            confidence = 1.0 / (1.0 + uncertainty)
            return float(np.clip(confidence, 0.1, 0.95))
            
        except Exception:
            return 0.7  # Confiança padrão
    
    def _calculate_ensemble_confidence(self, model, features: np.ndarray) -> float:
        """
        Calcula confiança da predição ensemble.
        """
        try:
            if hasattr(model, 'estimators_'):
                # Para Random Forest, usar variância entre árvores
                tree_predictions = [tree.predict(features)[0] for tree in model.estimators_]
                variance = np.var(tree_predictions)
                confidence = 1.0 / (1.0 + variance)
                return float(np.clip(confidence, 0.1, 0.95))
            else:
                return 0.8  # Confiança padrão para outros modelos
                
        except Exception:
            return 0.7  # Confiança padrão
    
    def predict_price(self, symbol: str, timeframes: List[str], confidence_level: float = 0.95) -> Dict[str, Any]:
        """
        Predição de preços para múltiplos timeframes.
        """
        try:
            # Coletar dados em tempo real
            realtime_data = self.data_pipeline.collect_realtime_data(symbol)
            if not realtime_data:
                return {'error': f'Dados não disponíveis para {symbol}'}
            
            # Converter para DataFrame
            price_history = realtime_data.get('price_history', [])
            if len(price_history) < 100:
                return {'error': 'Histórico insuficiente para predição'}
            
            # Criar DataFrame básico
            df = pd.DataFrame({
                'close': price_history,
                'volume': realtime_data.get('volume_history', [1000] * len(price_history)),
                'high': [p * 1.02 for p in price_history],  # Aproximação
                'low': [p * 0.98 for p in price_history],   # Aproximação
                'open': price_history
            })
            
            # Fazer predições
            predictions = self.predict(df)
            
            if 'error' in predictions:
                return predictions
            
            # Adaptar para timeframes solicitados
            result = {}
            base_prediction = predictions.get('final_prediction', 0)
            
            for timeframe in timeframes:
                days = int(timeframe.replace('d', ''))
                
                # Ajustar predição baseada no timeframe
                volatility_factor = 1 + (days * 0.01)  # Aumentar incerteza com tempo
                adjusted_prediction = base_prediction * (1 + np.random.normal(0, 0.01 * days))
                
                result[timeframe] = {
                    'predicted_value': float(adjusted_prediction),
                    'confidence': float(predictions.get('ensemble_confidence', 0.7) / volatility_factor),
                    'confidence_interval': [
                        float(adjusted_prediction * 0.95),
                        float(adjusted_prediction * 1.05)
                    ],
                    'timeframe_days': days,
                    'features_used': self.feature_columns[:10]  # Top 10 features
                }
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na predição de preços: {e}")
            return {'error': str(e)}
    
    def calculate_asset_score(self, symbol: str) -> Dict[str, Any]:
        """
        Calcula score unificado para um ativo.
        """
        try:
            # Coletar dados
            realtime_data = self.data_pipeline.collect_realtime_data(symbol)
            if not realtime_data:
                return {'error': f'Dados não disponíveis para {symbol}'}
            
            # Calcular scores individuais
            technical_score = self._calculate_technical_score(realtime_data)
            momentum_score = self._calculate_momentum_score(realtime_data)
            volatility_score = self._calculate_volatility_score(realtime_data)
            volume_score = self._calculate_volume_score(realtime_data)
            
            # Score geral (média ponderada)
            weights = {
                'technical': 0.3,
                'momentum': 0.25,
                'volatility': 0.2,
                'volume': 0.25
            }
            
            overall_score = (
                technical_score * weights['technical'] +
                momentum_score * weights['momentum'] +
                volatility_score * weights['volatility'] +
                volume_score * weights['volume']
            )
            
            # Determinar recomendação
            if overall_score >= 75:
                recommendation = 'buy'
                risk_level = 'medium'
            elif overall_score >= 60:
                recommendation = 'hold'
                risk_level = 'medium'
            elif overall_score >= 40:
                recommendation = 'hold'
                risk_level = 'high'
            else:
                recommendation = 'sell'
                risk_level = 'high'
            
            return {
                'overall_score': float(overall_score),
                'technical_score': float(technical_score),
                'momentum_score': float(momentum_score),
                'volatility_score': float(volatility_score),
                'volume_score': float(volume_score),
                'recommendation': recommendation,
                'risk_level': risk_level,
                'factors': {
                    'technical_weight': weights['technical'],
                    'momentum_weight': weights['momentum'],
                    'volatility_weight': weights['volatility'],
                    'volume_weight': weights['volume']
                }
            }
            
        except Exception as e:
            logger.error(f"Erro no cálculo de score: {e}")
            return {'error': str(e)}
    
    def _calculate_technical_score(self, data: Dict[str, Any]) -> float:
        """
        Calcula score baseado em indicadores técnicos.
        """
        try:
            technical = data.get('technical_indicators', {})
            
            score = 50  # Score base
            
            # RSI
            rsi = technical.get('rsi', 50)
            if 30 <= rsi <= 70:
                score += 10
            elif rsi < 30:
                score += 20  # Oversold - potencial compra
            elif rsi > 70:
                score -= 10  # Overbought
            
            # MACD
            macd = technical.get('macd', 0)
            macd_signal = technical.get('macd_signal', 0)
            if macd > macd_signal:
                score += 15
            else:
                score -= 10
            
            # Bollinger Bands
            bb_position = technical.get('bb_position', 0.5)
            if 0.2 <= bb_position <= 0.8:
                score += 10
            elif bb_position < 0.2:
                score += 15  # Próximo ao suporte
            
            return float(np.clip(score, 0, 100))
            
        except Exception:
            return 50.0
    
    def _calculate_momentum_score(self, data: Dict[str, Any]) -> float:
        """
        Calcula score baseado em momentum.
        """
        try:
            price_history = data.get('price_history', [])
            if len(price_history) < 20:
                return 50.0
            
            # Calcular retornos
            returns = np.diff(price_history) / price_history[:-1]
            recent_returns = returns[-10:]  # Últimos 10 períodos
            
            # Score baseado em retornos recentes
            avg_return = np.mean(recent_returns)
            score = 50 + (avg_return * 1000)  # Amplificar para escala 0-100
            
            return float(np.clip(score, 0, 100))
            
        except Exception:
            return 50.0
    
    def _calculate_volatility_score(self, data: Dict[str, Any]) -> float:
        """
        Calcula score baseado em volatilidade.
        """
        try:
            price_history = data.get('price_history', [])
            if len(price_history) < 20:
                return 50.0
            
            # Calcular volatilidade
            returns = np.diff(price_history) / price_history[:-1]
            volatility = np.std(returns)
            
            # Score inverso à volatilidade (menor volatilidade = maior score)
            score = 100 - (volatility * 5000)  # Ajustar escala
            
            return float(np.clip(score, 0, 100))
            
        except Exception:
            return 50.0
    
    def _calculate_volume_score(self, data: Dict[str, Any]) -> float:
        """
        Calcula score baseado em volume.
        """
        try:
            volume_history = data.get('volume_history', [])
            if len(volume_history) < 20:
                return 50.0
            
            # Volume médio vs volume recente
            avg_volume = np.mean(volume_history[:-5])
            recent_volume = np.mean(volume_history[-5:])
            
            if avg_volume > 0:
                volume_ratio = recent_volume / avg_volume
                score = 50 + (volume_ratio - 1) * 50
            else:
                score = 50
            
            return float(np.clip(score, 0, 100))
            
        except Exception:
            return 50.0
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas de performance dos modelos.
        """
        return {
            'models_trained': len(self.models),
            'is_trained': self.is_trained,
            'last_training': self.last_training_date.isoformat() if self.last_training_date else None,
            'feature_count': len(self.feature_columns),
            'available_models': list(self.models.keys()),
            'tensorflow_available': TENSORFLOW_AVAILABLE
        }
    
    def get_version(self) -> str:
        """
        Retorna versão do engine.
        """
        return self.version

