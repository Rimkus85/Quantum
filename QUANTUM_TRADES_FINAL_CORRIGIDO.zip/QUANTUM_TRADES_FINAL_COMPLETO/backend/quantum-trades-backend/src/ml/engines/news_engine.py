"""
Engine de Coleta de Notícias - Quantum Trades
Sprint 5 - Épico 2: Coleta automática de notícias financeiras brasileiras
"""

import requests
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import json
import time
from urllib.parse import quote, urljoin
import re

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False

from .base_ml_engine import BaseMLEngine

class NewsEngine(BaseMLEngine):
    """
    Engine para coleta automática de notícias financeiras.
    """
    
    def __init__(self):
        super().__init__("NewsEngine", "1.0.0")
        
        # Configurações de coleta
        self.request_timeout = 10
        self.max_retries = 3
        self.delay_between_requests = 1
        
        # Headers para requisições
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        
        # Fontes de notícias brasileiras
        self.news_sources = {
            'infomoney': {
                'base_url': 'https://www.infomoney.com.br',
                'search_url': 'https://www.infomoney.com.br/busca/?q={query}',
                'selectors': {
                    'title': 'h1, h2, .title',
                    'content': '.content, .article-content, p',
                    'date': '.date, .published, time'
                }
            },
            'valor': {
                'base_url': 'https://valor.globo.com',
                'search_url': 'https://valor.globo.com/busca/?q={query}',
                'selectors': {
                    'title': 'h1, h2, .title',
                    'content': '.content, .article-content, p',
                    'date': '.date, .published, time'
                }
            },
            'exame': {
                'base_url': 'https://exame.com',
                'search_url': 'https://exame.com/busca/?q={query}',
                'selectors': {
                    'title': 'h1, h2, .title',
                    'content': '.content, .article-content, p',
                    'date': '.date, .published, time'
                }
            },
            'estadao': {
                'base_url': 'https://economia.estadao.com.br',
                'search_url': 'https://economia.estadao.com.br/busca/?q={query}',
                'selectors': {
                    'title': 'h1, h2, .title',
                    'content': '.content, .article-content, p',
                    'date': '.date, .published, time'
                }
            },
            'g1': {
                'base_url': 'https://g1.globo.com/economia',
                'search_url': 'https://g1.globo.com/busca/?q={query}',
                'selectors': {
                    'title': 'h1, h2, .title',
                    'content': '.content, .article-content, p',
                    'date': '.date, .published, time'
                }
            }
        }
        
        # APIs de notícias alternativas
        self.news_apis = {
            'newsapi': {
                'url': 'https://newsapi.org/v2/everything',
                'params': {
                    'language': 'pt',
                    'domains': 'infomoney.com.br,valor.globo.com,exame.com',
                    'sortBy': 'publishedAt'
                }
            }
        }
        
        # Cache de notícias
        self.news_cache = {}
        self.cache_duration = 3600  # 1 hora
        
        logger.info("Engine de Coleta de Notícias inicializado")
    
    def prepare_features(self, data) -> Any:
        """
        Não aplicável para engine de coleta.
        """
        return None
    
    def train(self, training_data, target) -> Dict[str, Any]:
        """
        Não aplicável para engine de coleta.
        """
        self.is_trained = True
        self.last_training_date = datetime.now()
        return {'status': 'News engine ready'}
    
    def predict(self, data) -> Dict[str, Any]:
        """
        Não aplicável para engine de coleta.
        """
        return {'status': 'Use collect_news method instead'}
    
    def collect_news(self, symbol: str, days_back: int = 7, max_articles: int = 50) -> List[Dict[str, Any]]:
        """
        Coleta notícias para um símbolo específico.
        """
        try:
            logger.info(f"Coletando notícias para {symbol}")
            
            # Verificar cache
            cache_key = f"{symbol}_{days_back}_{max_articles}"
            if self._is_cache_valid(cache_key):
                logger.info("Retornando notícias do cache")
                return self.news_cache[cache_key]['data']
            
            all_articles = []
            
            # Preparar termos de busca
            search_terms = self._prepare_search_terms(symbol)
            
            # Coletar de cada fonte
            for source_name, source_config in self.news_sources.items():
                try:
                    articles = self._collect_from_source(
                        source_name, source_config, search_terms, days_back, max_articles // len(self.news_sources)
                    )
                    all_articles.extend(articles)
                    
                    # Delay entre fontes
                    time.sleep(self.delay_between_requests)
                    
                except Exception as e:
                    logger.error(f"Erro ao coletar de {source_name}: {e}")
                    continue
            
            # Tentar APIs de notícias se disponível
            try:
                api_articles = self._collect_from_apis(search_terms, days_back, max_articles // 2)
                all_articles.extend(api_articles)
            except Exception as e:
                logger.warning(f"APIs de notícias não disponíveis: {e}")
            
            # Remover duplicatas e ordenar
            unique_articles = self._remove_duplicates(all_articles)
            sorted_articles = sorted(unique_articles, key=lambda x: x.get('published_date', ''), reverse=True)
            
            # Limitar quantidade
            final_articles = sorted_articles[:max_articles]
            
            # Salvar no cache
            self.news_cache[cache_key] = {
                'data': final_articles,
                'timestamp': datetime.now()
            }
            
            logger.info(f"Coletadas {len(final_articles)} notícias para {symbol}")
            return final_articles
            
        except Exception as e:
            logger.error(f"Erro na coleta de notícias: {e}")
            return []
    
    def _prepare_search_terms(self, symbol: str) -> List[str]:
        """
        Prepara termos de busca baseados no símbolo.
        """
        terms = [symbol]
        
        # Remover sufixo .SA se presente
        if symbol.endswith('.SA'):
            base_symbol = symbol[:-3]
            terms.append(base_symbol)
        
        # Adicionar variações comuns
        if len(symbol) >= 4:
            terms.append(symbol[:4])  # Código base da ação
        
        return list(set(terms))
    
    def _collect_from_source(self, source_name: str, source_config: Dict[str, Any], 
                           search_terms: List[str], days_back: int, max_articles: int) -> List[Dict[str, Any]]:
        """
        Coleta notícias de uma fonte específica.
        """
        articles = []
        
        try:
            if not BS4_AVAILABLE:
                logger.warning("BeautifulSoup não disponível para scraping")
                return []
            
            for term in search_terms:
                try:
                    # Construir URL de busca
                    search_url = source_config['search_url'].format(query=quote(term))
                    
                    # Fazer requisição
                    response = self._make_request(search_url)
                    if not response:
                        continue
                    
                    # Parse HTML
                    soup = BeautifulSoup(response.text, 'html.parser')
                    
                    # Extrair artigos
                    source_articles = self._extract_articles_from_page(
                        soup, source_name, source_config, term
                    )
                    
                    articles.extend(source_articles)
                    
                    if len(articles) >= max_articles:
                        break
                        
                except Exception as e:
                    logger.error(f"Erro ao buscar '{term}' em {source_name}: {e}")
                    continue
            
            return articles[:max_articles]
            
        except Exception as e:
            logger.error(f"Erro na coleta de {source_name}: {e}")
            return []
    
    def _make_request(self, url: str) -> Optional[requests.Response]:
        """
        Faz requisição HTTP com retry.
        """
        for attempt in range(self.max_retries):
            try:
                response = requests.get(
                    url,
                    headers=self.headers,
                    timeout=self.request_timeout,
                    allow_redirects=True
                )
                
                if response.status_code == 200:
                    return response
                else:
                    logger.warning(f"Status {response.status_code} para {url}")
                    
            except requests.RequestException as e:
                logger.warning(f"Tentativa {attempt + 1} falhou para {url}: {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)  # Backoff exponencial
        
        return None
    
    def _extract_articles_from_page(self, soup: BeautifulSoup, source_name: str, 
                                  source_config: Dict[str, Any], search_term: str) -> List[Dict[str, Any]]:
        """
        Extrai artigos de uma página HTML.
        """
        articles = []
        
        try:
            # Buscar elementos de artigos (implementação genérica)
            article_elements = soup.find_all(['article', 'div'], class_=re.compile(r'(article|news|post|item)'))
            
            if not article_elements:
                # Fallback: buscar por links com títulos
                article_elements = soup.find_all('a', href=True)
            
            for element in article_elements[:10]:  # Limitar a 10 por página
                try:
                    article = self._extract_article_data(element, source_name, source_config, search_term)
                    if article and self._is_relevant_article(article, search_term):
                        articles.append(article)
                        
                except Exception as e:
                    logger.debug(f"Erro ao extrair artigo: {e}")
                    continue
            
            return articles
            
        except Exception as e:
            logger.error(f"Erro na extração de artigos: {e}")
            return []
    
    def _extract_article_data(self, element, source_name: str, source_config: Dict[str, Any], 
                            search_term: str) -> Optional[Dict[str, Any]]:
        """
        Extrai dados de um elemento de artigo.
        """
        try:
            # Extrair título
            title_element = element.find(['h1', 'h2', 'h3', 'a'])
            title = title_element.get_text(strip=True) if title_element else ''
            
            if not title or len(title) < 10:
                return None
            
            # Extrair URL
            url = ''
            if element.name == 'a' and element.get('href'):
                url = element['href']
            else:
                link_element = element.find('a', href=True)
                if link_element:
                    url = link_element['href']
            
            # Converter URL relativa para absoluta
            if url and not url.startswith('http'):
                base_url = source_config.get('base_url', '')
                url = urljoin(base_url, url)
            
            # Extrair resumo/conteúdo
            content_element = element.find(['p', 'div'], class_=re.compile(r'(summary|excerpt|content)'))
            content = content_element.get_text(strip=True) if content_element else ''
            
            # Extrair data (implementação básica)
            date_element = element.find(['time', 'span'], class_=re.compile(r'(date|time|published)'))
            published_date = ''
            if date_element:
                published_date = date_element.get_text(strip=True)
                # Tentar extrair datetime
                datetime_attr = date_element.get('datetime')
                if datetime_attr:
                    published_date = datetime_attr
            
            # Se não encontrou data, usar data atual
            if not published_date:
                published_date = datetime.now().isoformat()
            
            return {
                'title': title,
                'url': url,
                'content': content,
                'published_date': published_date,
                'source': source_name,
                'search_term': search_term,
                'collected_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.debug(f"Erro ao extrair dados do artigo: {e}")
            return None
    
    def _is_relevant_article(self, article: Dict[str, Any], search_term: str) -> bool:
        """
        Verifica se o artigo é relevante para o termo de busca.
        """
        try:
            title = article.get('title', '').lower()
            content = article.get('content', '').lower()
            search_term_lower = search_term.lower()
            
            # Verificar se o termo aparece no título ou conteúdo
            if search_term_lower in title or search_term_lower in content:
                return True
            
            # Verificar palavras-chave financeiras
            financial_keywords = ['ação', 'ações', 'bolsa', 'investimento', 'mercado', 'economia', 'financeiro']
            text_combined = f"{title} {content}"
            
            if any(keyword in text_combined for keyword in financial_keywords):
                return True
            
            return False
            
        except Exception:
            return False
    
    def _collect_from_apis(self, search_terms: List[str], days_back: int, max_articles: int) -> List[Dict[str, Any]]:
        """
        Coleta notícias usando APIs externas.
        """
        articles = []
        
        try:
            # Implementação para NewsAPI (requer chave API)
            # Por enquanto, retorna artigos de exemplo
            
            for term in search_terms:
                sample_articles = self._generate_sample_api_articles(term, days_back)
                articles.extend(sample_articles)
            
            return articles[:max_articles]
            
        except Exception as e:
            logger.error(f"Erro na coleta via APIs: {e}")
            return []
    
    def _generate_sample_api_articles(self, search_term: str, days_back: int) -> List[Dict[str, Any]]:
        """
        Gera artigos de exemplo para demonstração.
        """
        base_date = datetime.now() - timedelta(days=days_back)
        
        sample_articles = [
            {
                'title': f'{search_term} registra alta de 3% em sessão positiva na bolsa',
                'url': f'https://example.com/news/{search_term.lower()}-alta-bolsa',
                'content': f'As ações da {search_term} fecharam em alta de 3% na sessão de hoje, impulsionadas por resultados positivos e perspectivas otimistas do mercado.',
                'published_date': (base_date + timedelta(days=1)).isoformat(),
                'source': 'api_sample',
                'search_term': search_term,
                'collected_at': datetime.now().isoformat()
            },
            {
                'title': f'Analistas elevam recomendação para {search_term}',
                'url': f'https://example.com/news/{search_term.lower()}-recomendacao',
                'content': f'Casas de análise elevaram a recomendação para {search_term} de neutro para compra, citando fundamentos sólidos e potencial de crescimento.',
                'published_date': (base_date + timedelta(days=2)).isoformat(),
                'source': 'api_sample',
                'search_term': search_term,
                'collected_at': datetime.now().isoformat()
            },
            {
                'title': f'{search_term} anuncia expansão de operações no Brasil',
                'url': f'https://example.com/news/{search_term.lower()}-expansao',
                'content': f'A empresa {search_term} anunciou planos de expansão significativa de suas operações no mercado brasileiro, com investimentos previstos para os próximos anos.',
                'published_date': (base_date + timedelta(days=3)).isoformat(),
                'source': 'api_sample',
                'search_term': search_term,
                'collected_at': datetime.now().isoformat()
            }
        ]
        
        return sample_articles
    
    def _remove_duplicates(self, articles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Remove artigos duplicados baseado no título.
        """
        seen_titles = set()
        unique_articles = []
        
        for article in articles:
            title = article.get('title', '').strip().lower()
            if title and title not in seen_titles:
                seen_titles.add(title)
                unique_articles.append(article)
        
        return unique_articles
    
    def _is_cache_valid(self, cache_key: str) -> bool:
        """
        Verifica se o cache é válido.
        """
        if cache_key not in self.news_cache:
            return False
        
        cache_time = self.news_cache[cache_key]['timestamp']
        return (datetime.now() - cache_time).seconds < self.cache_duration
    
    def get_trending_topics(self, days_back: int = 3) -> List[Dict[str, Any]]:
        """
        Identifica tópicos em alta nas notícias financeiras.
        """
        try:
            # Coletar notícias gerais
            general_terms = ['mercado', 'bolsa', 'economia', 'investimentos']
            all_articles = []
            
            for term in general_terms:
                articles = self.collect_news(term, days_back, 20)
                all_articles.extend(articles)
            
            # Analisar frequência de palavras-chave
            word_frequency = {}
            
            for article in all_articles:
                title = article.get('title', '').lower()
                content = article.get('content', '').lower()
                
                # Extrair palavras relevantes
                words = re.findall(r'\b[a-záàâãéèêíìîóòôõúùûç]{4,}\b', f"{title} {content}")
                
                for word in words:
                    if word not in ['para', 'com', 'por', 'em', 'de', 'da', 'do', 'na', 'no']:
                        word_frequency[word] = word_frequency.get(word, 0) + 1
            
            # Ordenar por frequência
            trending = sorted(word_frequency.items(), key=lambda x: x[1], reverse=True)[:10]
            
            return [
                {
                    'topic': word,
                    'frequency': count,
                    'relevance_score': min(100, count * 10)
                }
                for word, count in trending
            ]
            
        except Exception as e:
            logger.error(f"Erro ao identificar tópicos em alta: {e}")
            return []
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Retorna métricas de performance do engine de notícias.
        """
        return {
            'is_trained': self.is_trained,
            'sources_count': len(self.news_sources),
            'apis_count': len(self.news_apis),
            'cache_entries': len(self.news_cache),
            'bs4_available': BS4_AVAILABLE,
            'last_collection': self.last_training_date.isoformat() if self.last_training_date else None
        }

