"""
Modelos de banco de dados para funcionalidades de Machine Learning
Sprint 5 - Quantum Trades
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Decimal, DateTime, Text, Boolean, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from src.models.user import db

class MLPrediction(db.Model):
    """Modelo para armazenar predições de ML"""
    __tablename__ = 'ml_predictions'
    
    id = Column(Integer, primary_key=True)
    symbol = Column(String(50), nullable=False, index=True)
    model_type = Column(String(50), nullable=False)
    prediction_type = Column(String(50), nullable=False)
    predicted_value = Column(Decimal(15, 6), nullable=False)
    confidence_score = Column(Decimal(5, 4), nullable=False)
    prediction_date = Column(DateTime, nullable=False, default=datetime.utcnow)
    target_date = Column(DateTime, nullable=False)
    actual_value = Column(Decimal(15, 6), nullable=True)
    accuracy_score = Column(Decimal(5, 4), nullable=True)
    features_used = Column(JSON, nullable=True)
    model_version = Column(String(20), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<MLPrediction {self.symbol} - {self.prediction_type}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'symbol': self.symbol,
            'model_type': self.model_type,
            'prediction_type': self.prediction_type,
            'predicted_value': float(self.predicted_value),
            'confidence_score': float(self.confidence_score),
            'prediction_date': self.prediction_date.isoformat(),
            'target_date': self.target_date.isoformat(),
            'actual_value': float(self.actual_value) if self.actual_value else None,
            'accuracy_score': float(self.accuracy_score) if self.accuracy_score else None,
            'features_used': self.features_used,
            'model_version': self.model_version,
            'created_at': self.created_at.isoformat()
        }

class SentimentAnalysis(db.Model):
    """Modelo para análise de sentimento"""
    __tablename__ = 'sentiment_analysis'
    
    id = Column(Integer, primary_key=True)
    symbol = Column(String(50), nullable=False, index=True)
    source_type = Column(String(50), nullable=False)  # news, social, earnings, etc.
    source_url = Column(Text, nullable=True)
    content_text = Column(Text, nullable=True)
    sentiment_score = Column(Decimal(5, 4), nullable=False)  # -1 to 1
    sentiment_label = Column(String(20), nullable=False)  # bullish, bearish, neutral
    confidence_score = Column(Decimal(5, 4), nullable=False)
    entities_extracted = Column(JSON, nullable=True)
    keywords = Column(JSON, nullable=True)
    impact_score = Column(Decimal(5, 4), nullable=True)
    analyzed_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<SentimentAnalysis {self.symbol} - {self.sentiment_label}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'symbol': self.symbol,
            'source_type': self.source_type,
            'source_url': self.source_url,
            'sentiment_score': float(self.sentiment_score),
            'sentiment_label': self.sentiment_label,
            'confidence_score': float(self.confidence_score),
            'entities_extracted': self.entities_extracted,
            'keywords': self.keywords,
            'impact_score': float(self.impact_score) if self.impact_score else None,
            'analyzed_at': self.analyzed_at.isoformat(),
            'created_at': self.created_at.isoformat()
        }

class UserMLProfile(db.Model):
    """Perfil de usuário para Machine Learning"""
    __tablename__ = 'user_ml_profiles'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), unique=True, nullable=False)
    risk_tolerance = Column(Decimal(3, 2), nullable=False, default=0.5)  # 0-1
    investment_horizon = Column(String(20), nullable=False, default='medium')  # short, medium, long
    preferred_sectors = Column(JSON, nullable=True)
    trading_frequency = Column(String(20), nullable=True)  # daily, weekly, monthly
    behavioral_patterns = Column(JSON, nullable=True)
    performance_metrics = Column(JSON, nullable=True)
    learning_preferences = Column(JSON, nullable=True)
    notification_preferences = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamento com usuário
    user = relationship("User", backref="ml_profile")
    
    def __repr__(self):
        return f'<UserMLProfile user_id={self.user_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'risk_tolerance': float(self.risk_tolerance),
            'investment_horizon': self.investment_horizon,
            'preferred_sectors': self.preferred_sectors,
            'trading_frequency': self.trading_frequency,
            'behavioral_patterns': self.behavioral_patterns,
            'performance_metrics': self.performance_metrics,
            'learning_preferences': self.learning_preferences,
            'notification_preferences': self.notification_preferences,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class MLRecommendation(db.Model):
    """Recomendações geradas por ML"""
    __tablename__ = 'ml_recommendations'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    recommendation_type = Column(String(50), nullable=False)  # asset, strategy, alert_config
    recommended_item = Column(String(100), nullable=False)
    score = Column(Decimal(5, 4), nullable=False)
    reasoning = Column(JSON, nullable=True)
    confidence_level = Column(String(20), nullable=True)  # high, medium, low
    category = Column(String(50), nullable=True)
    priority = Column(Integer, nullable=True, default=1)
    is_active = Column(Boolean, default=True)
    user_feedback = Column(String(20), nullable=True)  # liked, disliked, ignored
    feedback_date = Column(DateTime, nullable=True)
    generated_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)
    
    # Relacionamento com usuário
    user = relationship("User", backref="ml_recommendations")
    
    def __repr__(self):
        return f'<MLRecommendation {self.recommendation_type} for user {self.user_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'recommendation_type': self.recommendation_type,
            'recommended_item': self.recommended_item,
            'score': float(self.score),
            'reasoning': self.reasoning,
            'confidence_level': self.confidence_level,
            'category': self.category,
            'priority': self.priority,
            'is_active': self.is_active,
            'user_feedback': self.user_feedback,
            'feedback_date': self.feedback_date.isoformat() if self.feedback_date else None,
            'generated_at': self.generated_at.isoformat(),
            'expires_at': self.expires_at.isoformat() if self.expires_at else None
        }

class MLFeedback(db.Model):
    """Feedback de usuários sobre predições e recomendações de ML"""
    __tablename__ = 'ml_feedback'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    prediction_id = Column(Integer, ForeignKey('ml_predictions.id'), nullable=True)
    recommendation_id = Column(Integer, ForeignKey('ml_recommendations.id'), nullable=True)
    feedback_type = Column(String(50), nullable=False)  # accuracy, relevance, usefulness
    rating = Column(Integer, nullable=False)  # 1-5
    comments = Column(Text, nullable=True)
    action_taken = Column(String(100), nullable=True)
    outcome = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    user = relationship("User", backref="ml_feedback")
    prediction = relationship("MLPrediction", backref="feedback")
    recommendation = relationship("MLRecommendation", backref="feedback")
    
    def __repr__(self):
        return f'<MLFeedback {self.feedback_type} by user {self.user_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'prediction_id': self.prediction_id,
            'recommendation_id': self.recommendation_id,
            'feedback_type': self.feedback_type,
            'rating': self.rating,
            'comments': self.comments,
            'action_taken': self.action_taken,
            'outcome': self.outcome,
            'created_at': self.created_at.isoformat()
        }

class PatternDetection(db.Model):
    """Detecção de padrões técnicos"""
    __tablename__ = 'pattern_detections'
    
    id = Column(Integer, primary_key=True)
    symbol = Column(String(50), nullable=False, index=True)
    pattern_type = Column(String(50), nullable=False)
    pattern_name = Column(String(100), nullable=False)
    confidence_score = Column(Decimal(5, 4), nullable=False)
    timeframe = Column(String(20), nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=True)
    key_levels = Column(JSON, nullable=True)  # support, resistance, targets
    historical_success_rate = Column(Decimal(5, 4), nullable=True)
    expected_move = Column(Decimal(10, 4), nullable=True)
    risk_reward_ratio = Column(Decimal(5, 2), nullable=True)
    status = Column(String(20), default='active')  # active, completed, failed
    detected_at = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<PatternDetection {self.pattern_name} on {self.symbol}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'symbol': self.symbol,
            'pattern_type': self.pattern_type,
            'pattern_name': self.pattern_name,
            'confidence_score': float(self.confidence_score),
            'timeframe': self.timeframe,
            'start_date': self.start_date.isoformat(),
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'key_levels': self.key_levels,
            'historical_success_rate': float(self.historical_success_rate) if self.historical_success_rate else None,
            'expected_move': float(self.expected_move) if self.expected_move else None,
            'risk_reward_ratio': float(self.risk_reward_ratio) if self.risk_reward_ratio else None,
            'status': self.status,
            'detected_at': self.detected_at.isoformat()
        }

class AssetScoring(db.Model):
    """Sistema de scoring de ativos"""
    __tablename__ = 'asset_scoring'
    
    id = Column(Integer, primary_key=True)
    symbol = Column(String(50), nullable=False, index=True)
    overall_score = Column(Decimal(5, 2), nullable=False)  # 0-100
    technical_score = Column(Decimal(5, 2), nullable=True)
    fundamental_score = Column(Decimal(5, 2), nullable=True)
    sentiment_score = Column(Decimal(5, 2), nullable=True)
    momentum_score = Column(Decimal(5, 2), nullable=True)
    volatility_score = Column(Decimal(5, 2), nullable=True)
    volume_score = Column(Decimal(5, 2), nullable=True)
    scoring_factors = Column(JSON, nullable=True)
    risk_level = Column(String(20), nullable=True)  # low, medium, high
    recommendation = Column(String(20), nullable=True)  # buy, hold, sell
    target_price = Column(Decimal(15, 6), nullable=True)
    stop_loss = Column(Decimal(15, 6), nullable=True)
    calculated_at = Column(DateTime, default=datetime.utcnow)
    valid_until = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f'<AssetScoring {self.symbol} - {self.overall_score}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'symbol': self.symbol,
            'overall_score': float(self.overall_score),
            'technical_score': float(self.technical_score) if self.technical_score else None,
            'fundamental_score': float(self.fundamental_score) if self.fundamental_score else None,
            'sentiment_score': float(self.sentiment_score) if self.sentiment_score else None,
            'momentum_score': float(self.momentum_score) if self.momentum_score else None,
            'volatility_score': float(self.volatility_score) if self.volatility_score else None,
            'volume_score': float(self.volume_score) if self.volume_score else None,
            'scoring_factors': self.scoring_factors,
            'risk_level': self.risk_level,
            'recommendation': self.recommendation,
            'target_price': float(self.target_price) if self.target_price else None,
            'stop_loss': float(self.stop_loss) if self.stop_loss else None,
            'calculated_at': self.calculated_at.isoformat(),
            'valid_until': self.valid_until.isoformat() if self.valid_until else None
        }

