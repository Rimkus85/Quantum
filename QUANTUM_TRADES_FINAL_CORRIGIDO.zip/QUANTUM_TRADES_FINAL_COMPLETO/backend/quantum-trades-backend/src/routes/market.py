from flask import Blueprint, request, jsonify
from datetime import datetime
from src.services.financial_data_service import FinancialDataService
from src.services.cache_service import cache_service
from src.services.auth_service import optional_token
import logging

logger = logging.getLogger(__name__)

market_bp = Blueprint('market', __name__)

# Inicializar serviço de dados financeiros
financial_service = FinancialDataService(cache_service)

@market_bp.route('/quote/<symbol>', methods=['GET'])
@optional_token
def get_quote(current_user, symbol):
    """Obtém cotação atual de um ativo"""
    try:
        symbol = symbol.upper().strip()
        
        if not symbol:
            return jsonify({'message': 'Símbolo é obrigatório'}), 400
        
        quote_data = financial_service.get_stock_quote_with_fallback(symbol)
        
        # Sempre retornar dados (reais ou mockados)
        return jsonify({
            'success': True,
            'data': quote_data
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter cotação para {symbol}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@market_bp.route('/historical/<symbol>', methods=['GET'])
@optional_token
def get_historical(current_user, symbol):
    """Obtém dados históricos de um ativo"""
    try:
        symbol = symbol.upper().strip()
        period = request.args.get('period', '1y')
        
        if not symbol:
            return jsonify({'message': 'Símbolo é obrigatório'}), 400
        
        # Validar período
        valid_periods = ['1d', '5d', '1m', '3m', '6m', '1y', '2y', '5y', '10y']
        if period not in valid_periods:
            return jsonify({
                'message': f'Período inválido. Use um dos: {", ".join(valid_periods)}'
            }), 400
        
        historical_data = financial_service.get_historical_data(symbol, period)
        
        if not historical_data:
            return jsonify({'message': f'Dados históricos não encontrados para {symbol}'}), 404
        
        return jsonify({
            'success': True,
            'data': historical_data
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter dados históricos para {symbol}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@market_bp.route('/search', methods=['GET'])
@optional_token
def search_symbols(current_user):
    """Busca símbolos de ativos"""
    try:
        query = request.args.get('q', '').strip()
        
        if not query:
            return jsonify({'message': 'Parâmetro de busca "q" é obrigatório'}), 400
        
        if len(query) < 2:
            return jsonify({'message': 'Busca deve ter pelo menos 2 caracteres'}), 400
        
        results = financial_service.search_symbols(query)
        
        return jsonify({
            'success': True,
            'data': results,
            'count': len(results)
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao buscar símbolos: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@market_bp.route('/summary', methods=['GET'])
@optional_token
def get_market_summary(current_user):
    """Obtém resumo do mercado (principais índices)"""
    try:
        summary = financial_service.get_market_summary_with_fallback()
        
        # Sempre retornar dados (reais ou mockados)
        return jsonify({
            'success': True,
            'data': summary,
            'timestamp': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter resumo do mercado: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@market_bp.route('/multiple-quotes', methods=['POST'])
@optional_token
def get_multiple_quotes(current_user):
    """Obtém cotações de múltiplos ativos"""
    try:
        data = request.get_json()
        
        if not data or 'symbols' not in data:
            return jsonify({'message': 'Lista de símbolos é obrigatória'}), 400
        
        symbols = data['symbols']
        
        if not isinstance(symbols, list):
            return jsonify({'message': 'Símbolos deve ser uma lista'}), 400
        
        if len(symbols) > 50:  # Limitar para evitar sobrecarga
            return jsonify({'message': 'Máximo de 50 símbolos por requisição'}), 400
        
        quotes = {}
        errors = []
        
        for symbol in symbols:
            try:
                symbol = symbol.upper().strip()
                quote_data = financial_service.get_stock_quote(symbol)
                if quote_data:
                    quotes[symbol] = quote_data
                else:
                    errors.append(f"Dados não encontrados para {symbol}")
            except Exception as e:
                errors.append(f"Erro ao obter dados para {symbol}: {str(e)}")
        
        return jsonify({
            'success': True,
            'data': quotes,
            'errors': errors,
            'count': len(quotes)
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter múltiplas cotações: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@market_bp.route('/cache/stats', methods=['GET'])
@optional_token
def get_cache_stats(current_user):
    """Obtém estatísticas do cache (para monitoramento)"""
    try:
        stats = cache_service.get_cache_stats()
        
        return jsonify({
            'success': True,
            'data': stats
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas do cache: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@market_bp.route('/cache/warm', methods=['POST'])
@optional_token
def warm_cache(current_user):
    """Pré-carrega o cache com símbolos populares"""
    try:
        # Símbolos populares brasileiros e internacionais
        popular_symbols = [
            'PETR4.SA', 'VALE3.SA', 'ITUB4.SA', 'BBDC4.SA', 'ABEV3.SA',
            'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'TSLA',
            '^BVSP', '^GSPC', '^DJI', '^IXIC', 'BRL=X'
        ]
        
        # Permitir símbolos customizados
        data = request.get_json()
        if data and 'symbols' in data:
            custom_symbols = data['symbols']
            if isinstance(custom_symbols, list):
                popular_symbols.extend(custom_symbols)
        
        # Executar warm-up em background (simulado)
        cache_service.warm_cache(popular_symbols, financial_service)
        
        return jsonify({
            'success': True,
            'message': f'Cache aquecido com {len(popular_symbols)} símbolos',
            'symbols': popular_symbols
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao aquecer cache: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@market_bp.route('/health', methods=['GET'])
def health_check():
    """Verifica saúde do serviço de mercado"""
    try:
        # Testar uma cotação simples
        test_quote = financial_service.get_stock_quote('AAPL')
        
        cache_stats = cache_service.get_cache_stats()
        
        return jsonify({
            'success': True,
            'status': 'healthy',
            'services': {
                'financial_data': 'ok' if test_quote else 'degraded',
                'cache': 'ok'
            },
            'cache_stats': cache_stats
        }), 200
        
    except Exception as e:
        logger.error(f"Erro no health check: {e}")
        return jsonify({
            'success': False,
            'status': 'unhealthy',
            'error': str(e)
        }), 500

