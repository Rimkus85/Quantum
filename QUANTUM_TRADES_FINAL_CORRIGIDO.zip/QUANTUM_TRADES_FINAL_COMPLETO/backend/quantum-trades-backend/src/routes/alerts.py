from flask import Blueprint, request, jsonify
from datetime import datetime
from src.services.alerts_engine import alerts_engine, AlertType, AlertCondition, AlertPriority, AlertStatus
from src.services.auth_service import token_required, optional_token
import logging

logger = logging.getLogger(__name__)

alerts_bp = Blueprint('alerts', __name__)

@alerts_bp.route('/', methods=['POST'])
@token_required
def create_alert(current_user):
    """Cria um novo alerta"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'Dados são obrigatórios'}), 400
        
        # Validar campos obrigatórios
        required_fields = ['symbol', 'alert_type', 'condition', 'value', 'message']
        for field in required_fields:
            if field not in data:
                return jsonify({'message': f'Campo {field} é obrigatório'}), 400
        
        # Validar e converter enums
        try:
            alert_type = AlertType(data['alert_type'])
            condition = AlertCondition(data['condition'])
            priority = AlertPriority(data.get('priority', 'medium'))
        except ValueError as e:
            return jsonify({'message': f'Valor inválido: {str(e)}'}), 400
        
        # Validar valor
        try:
            value = float(data['value'])
        except (ValueError, TypeError):
            return jsonify({'message': 'Valor deve ser um número'}), 400
        
        # Parâmetros opcionais
        expires_in_hours = data.get('expires_in_hours')
        max_triggers = int(data.get('max_triggers', 1))
        cooldown_minutes = int(data.get('cooldown_minutes', 5))
        metadata = data.get('metadata', {})
        
        # Validar limites
        if max_triggers < 1 or max_triggers > 100:
            return jsonify({'message': 'max_triggers deve estar entre 1 e 100'}), 400
        
        if cooldown_minutes < 1 or cooldown_minutes > 1440:  # Máximo 24 horas
            return jsonify({'message': 'cooldown_minutes deve estar entre 1 e 1440'}), 400
        
        if expires_in_hours and (expires_in_hours < 1 or expires_in_hours > 8760):  # Máximo 1 ano
            return jsonify({'message': 'expires_in_hours deve estar entre 1 e 8760'}), 400
        
        # Verificar limite de alertas por usuário
        user_alerts = alerts_engine.get_user_alerts(current_user['id'], AlertStatus.ACTIVE)
        if len(user_alerts) >= 100:  # Limite de 100 alertas ativos por usuário
            return jsonify({'message': 'Limite de alertas ativos atingido (100)'}), 400
        
        # Criar alerta
        alert_id = alerts_engine.create_alert(
            user_id=current_user['id'],
            symbol=data['symbol'].upper(),
            alert_type=alert_type,
            condition=condition,
            value=value,
            priority=priority,
            message=data['message'],
            expires_in_hours=expires_in_hours,
            max_triggers=max_triggers,
            cooldown_minutes=cooldown_minutes,
            metadata=metadata
        )
        
        return jsonify({
            'success': True,
            'data': {
                'alert_id': alert_id,
                'message': 'Alerta criado com sucesso'
            }
        }), 201
        
    except Exception as e:
        logger.error(f"Erro ao criar alerta: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/', methods=['GET'])
@token_required
def get_user_alerts(current_user):
    """Obtém alertas do usuário"""
    try:
        # Parâmetros de filtro
        status_filter = request.args.get('status')
        symbol_filter = request.args.get('symbol')
        alert_type_filter = request.args.get('type')
        
        # Validar status se fornecido
        status_enum = None
        if status_filter:
            try:
                status_enum = AlertStatus(status_filter)
            except ValueError:
                return jsonify({'message': f'Status inválido: {status_filter}'}), 400
        
        # Obter alertas
        alerts = alerts_engine.get_user_alerts(current_user['id'], status_enum)
        
        # Aplicar filtros adicionais
        if symbol_filter:
            alerts = [alert for alert in alerts if alert['symbol'].upper() == symbol_filter.upper()]
        
        if alert_type_filter:
            alerts = [alert for alert in alerts if alert['alert_type'] == alert_type_filter]
        
        # Converter datetime para string
        for alert in alerts:
            alert['created_at'] = alert['created_at'].isoformat() if isinstance(alert['created_at'], datetime) else alert['created_at']
            if alert['expires_at']:
                alert['expires_at'] = alert['expires_at'].isoformat() if isinstance(alert['expires_at'], datetime) else alert['expires_at']
            if alert['triggered_at']:
                alert['triggered_at'] = alert['triggered_at'].isoformat() if isinstance(alert['triggered_at'], datetime) else alert['triggered_at']
            if alert['last_triggered']:
                alert['last_triggered'] = alert['last_triggered'].isoformat() if isinstance(alert['last_triggered'], datetime) else alert['last_triggered']
        
        return jsonify({
            'success': True,
            'data': {
                'alerts': alerts,
                'count': len(alerts),
                'filters': {
                    'status': status_filter,
                    'symbol': symbol_filter,
                    'type': alert_type_filter
                }
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter alertas do usuário: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/<alert_id>', methods=['GET'])
@token_required
def get_alert_details(current_user, alert_id):
    """Obtém detalhes de um alerta específico"""
    try:
        # Verificar se alerta existe e pertence ao usuário
        user_alerts = alerts_engine.get_user_alerts(current_user['id'])
        alert = next((a for a in user_alerts if a['id'] == alert_id), None)
        
        if not alert:
            return jsonify({'message': 'Alerta não encontrado'}), 404
        
        # Converter datetime para string
        alert['created_at'] = alert['created_at'].isoformat() if isinstance(alert['created_at'], datetime) else alert['created_at']
        if alert['expires_at']:
            alert['expires_at'] = alert['expires_at'].isoformat() if isinstance(alert['expires_at'], datetime) else alert['expires_at']
        if alert['triggered_at']:
            alert['triggered_at'] = alert['triggered_at'].isoformat() if isinstance(alert['triggered_at'], datetime) else alert['triggered_at']
        if alert['last_triggered']:
            alert['last_triggered'] = alert['last_triggered'].isoformat() if isinstance(alert['last_triggered'], datetime) else alert['last_triggered']
        
        return jsonify({
            'success': True,
            'data': alert
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter detalhes do alerta {alert_id}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/<alert_id>', methods=['DELETE'])
@token_required
def delete_alert(current_user, alert_id):
    """Remove um alerta"""
    try:
        # Verificar se alerta existe e pertence ao usuário
        user_alerts = alerts_engine.get_user_alerts(current_user['id'])
        alert = next((a for a in user_alerts if a['id'] == alert_id), None)
        
        if not alert:
            return jsonify({'message': 'Alerta não encontrado'}), 404
        
        # Remover alerta
        success = alerts_engine.delete_alert(alert_id)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Alerta removido com sucesso'
            }), 200
        else:
            return jsonify({'message': 'Erro ao remover alerta'}), 500
        
    except Exception as e:
        logger.error(f"Erro ao remover alerta {alert_id}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/<alert_id>/pause', methods=['POST'])
@token_required
def pause_alert(current_user, alert_id):
    """Pausa um alerta"""
    try:
        # Verificar se alerta existe e pertence ao usuário
        user_alerts = alerts_engine.get_user_alerts(current_user['id'])
        alert = next((a for a in user_alerts if a['id'] == alert_id), None)
        
        if not alert:
            return jsonify({'message': 'Alerta não encontrado'}), 404
        
        # Pausar alerta
        if alert_id in alerts_engine.alerts:
            alerts_engine.alerts[alert_id].status = AlertStatus.PAUSED
            
            return jsonify({
                'success': True,
                'message': 'Alerta pausado com sucesso'
            }), 200
        else:
            return jsonify({'message': 'Alerta não encontrado'}), 404
        
    except Exception as e:
        logger.error(f"Erro ao pausar alerta {alert_id}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/<alert_id>/resume', methods=['POST'])
@token_required
def resume_alert(current_user, alert_id):
    """Retoma um alerta pausado"""
    try:
        # Verificar se alerta existe e pertence ao usuário
        user_alerts = alerts_engine.get_user_alerts(current_user['id'])
        alert = next((a for a in user_alerts if a['id'] == alert_id), None)
        
        if not alert:
            return jsonify({'message': 'Alerta não encontrado'}), 404
        
        # Retomar alerta
        if alert_id in alerts_engine.alerts:
            alerts_engine.alerts[alert_id].status = AlertStatus.ACTIVE
            
            return jsonify({
                'success': True,
                'message': 'Alerta retomado com sucesso'
            }), 200
        else:
            return jsonify({'message': 'Alerta não encontrado'}), 404
        
    except Exception as e:
        logger.error(f"Erro ao retomar alerta {alert_id}: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/triggered', methods=['GET'])
@token_required
def get_triggered_alerts(current_user):
    """Obtém histórico de alertas disparados"""
    try:
        limit = int(request.args.get('limit', 50))
        
        if limit > 200:  # Limitar para evitar sobrecarga
            limit = 200
        
        triggered_alerts = alerts_engine.get_triggered_alerts(current_user['id'], limit)
        
        return jsonify({
            'success': True,
            'data': {
                'triggered_alerts': triggered_alerts,
                'count': len(triggered_alerts)
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter alertas disparados: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/templates', methods=['GET'])
@optional_token
def get_alert_templates(current_user):
    """Obtém templates de alertas pré-configurados"""
    try:
        templates = {
            'price_alerts': [
                {
                    'name': 'Preço acima de valor',
                    'alert_type': 'price',
                    'condition': 'above',
                    'description': 'Alerta quando o preço ficar acima de um valor específico',
                    'example': {'symbol': 'PETR4.SA', 'value': 30.0}
                },
                {
                    'name': 'Preço abaixo de valor',
                    'alert_type': 'price',
                    'condition': 'below',
                    'description': 'Alerta quando o preço ficar abaixo de um valor específico',
                    'example': {'symbol': 'PETR4.SA', 'value': 25.0}
                },
                {
                    'name': 'Variação percentual',
                    'alert_type': 'price',
                    'condition': 'change_percent',
                    'description': 'Alerta quando a variação percentual atingir um valor',
                    'example': {'symbol': 'PETR4.SA', 'value': 5.0}
                }
            ],
            'technical_alerts': [
                {
                    'name': 'RSI Sobrecomprado',
                    'alert_type': 'technical',
                    'condition': 'rsi_overbought',
                    'description': 'Alerta quando RSI indicar sobrecompra',
                    'example': {'symbol': 'PETR4.SA', 'value': 70.0}
                },
                {
                    'name': 'RSI Sobrevendido',
                    'alert_type': 'technical',
                    'condition': 'rsi_oversold',
                    'description': 'Alerta quando RSI indicar sobrevenda',
                    'example': {'symbol': 'PETR4.SA', 'value': 30.0}
                },
                {
                    'name': 'MACD Bullish',
                    'alert_type': 'technical',
                    'condition': 'macd_bullish',
                    'description': 'Alerta quando MACD cruzar acima da linha de sinal',
                    'example': {'symbol': 'PETR4.SA', 'value': 0.0}
                },
                {
                    'name': 'MACD Bearish',
                    'alert_type': 'technical',
                    'condition': 'macd_bearish',
                    'description': 'Alerta quando MACD cruzar abaixo da linha de sinal',
                    'example': {'symbol': 'PETR4.SA', 'value': 0.0}
                }
            ],
            'volume_alerts': [
                {
                    'name': 'Pico de Volume',
                    'alert_type': 'volume',
                    'condition': 'volume_spike',
                    'description': 'Alerta quando volume for X vezes maior que a média',
                    'example': {'symbol': 'PETR4.SA', 'value': 2.0}
                }
            ]
        }
        
        return jsonify({
            'success': True,
            'data': templates
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter templates de alertas: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/bulk', methods=['POST'])
@token_required
def create_bulk_alerts(current_user):
    """Cria múltiplos alertas de uma vez"""
    try:
        data = request.get_json()
        
        if not data or 'alerts' not in data:
            return jsonify({'message': 'Lista de alertas é obrigatória'}), 400
        
        alerts_data = data['alerts']
        
        if len(alerts_data) > 20:  # Limitar para evitar sobrecarga
            return jsonify({'message': 'Máximo 20 alertas por vez'}), 400
        
        # Verificar limite total de alertas
        user_alerts = alerts_engine.get_user_alerts(current_user['id'], AlertStatus.ACTIVE)
        if len(user_alerts) + len(alerts_data) > 100:
            return jsonify({'message': 'Limite total de alertas seria excedido'}), 400
        
        created_alerts = []
        errors = []
        
        for i, alert_data in enumerate(alerts_data):
            try:
                # Validar campos obrigatórios
                required_fields = ['symbol', 'alert_type', 'condition', 'value', 'message']
                for field in required_fields:
                    if field not in alert_data:
                        errors.append(f'Alerta {i+1}: Campo {field} é obrigatório')
                        continue
                
                # Validar e converter enums
                alert_type = AlertType(alert_data['alert_type'])
                condition = AlertCondition(alert_data['condition'])
                priority = AlertPriority(alert_data.get('priority', 'medium'))
                value = float(alert_data['value'])
                
                # Criar alerta
                alert_id = alerts_engine.create_alert(
                    user_id=current_user['id'],
                    symbol=alert_data['symbol'].upper(),
                    alert_type=alert_type,
                    condition=condition,
                    value=value,
                    priority=priority,
                    message=alert_data['message'],
                    expires_in_hours=alert_data.get('expires_in_hours'),
                    max_triggers=int(alert_data.get('max_triggers', 1)),
                    cooldown_minutes=int(alert_data.get('cooldown_minutes', 5)),
                    metadata=alert_data.get('metadata', {})
                )
                
                created_alerts.append(alert_id)
                
            except Exception as e:
                errors.append(f'Alerta {i+1}: {str(e)}')
        
        return jsonify({
            'success': True,
            'data': {
                'created_alerts': created_alerts,
                'created_count': len(created_alerts),
                'errors': errors,
                'error_count': len(errors)
            }
        }), 201 if created_alerts else 400
        
    except Exception as e:
        logger.error(f"Erro ao criar alertas em lote: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/stats', methods=['GET'])
@token_required
def get_user_alert_stats(current_user):
    """Obtém estatísticas de alertas do usuário"""
    try:
        all_alerts = alerts_engine.get_user_alerts(current_user['id'])
        triggered_alerts = alerts_engine.get_triggered_alerts(current_user['id'])
        
        # Calcular estatísticas
        stats = {
            'total_alerts': len(all_alerts),
            'active_alerts': len([a for a in all_alerts if a['status'] == 'active']),
            'paused_alerts': len([a for a in all_alerts if a['status'] == 'paused']),
            'triggered_alerts': len([a for a in all_alerts if a['status'] == 'triggered']),
            'expired_alerts': len([a for a in all_alerts if a['status'] == 'expired']),
            'total_triggers': len(triggered_alerts),
            'alerts_by_type': {},
            'alerts_by_symbol': {},
            'alerts_by_priority': {}
        }
        
        # Estatísticas por tipo
        for alert in all_alerts:
            alert_type = alert['alert_type']
            stats['alerts_by_type'][alert_type] = stats['alerts_by_type'].get(alert_type, 0) + 1
        
        # Estatísticas por símbolo
        for alert in all_alerts:
            symbol = alert['symbol']
            stats['alerts_by_symbol'][symbol] = stats['alerts_by_symbol'].get(symbol, 0) + 1
        
        # Estatísticas por prioridade
        for alert in all_alerts:
            priority = alert['priority']
            stats['alerts_by_priority'][priority] = stats['alerts_by_priority'].get(priority, 0) + 1
        
        return jsonify({
            'success': True,
            'data': stats
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas de alertas: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

@alerts_bp.route('/engine/metrics', methods=['GET'])
@optional_token
def get_engine_metrics(current_user):
    """Obtém métricas do engine de alertas (admin)"""
    try:
        metrics = alerts_engine.get_metrics()
        
        return jsonify({
            'success': True,
            'data': metrics
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter métricas do engine: {e}")
        return jsonify({'message': 'Erro interno do servidor'}), 500

