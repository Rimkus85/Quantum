"""
Rotas de Machine Learning para Quantum Trades
Sprint 5 - APIs para funcionalidades de IA
"""

from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
import logging
import traceback
from typing import Dict, Any

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Criar blueprint para rotas de ML
ml_bp = Blueprint('ml', __name__)

# Importações dos engines (serão criados nos próximos épicos)
try:
    from ...ml.engines.prediction_engine import PredictionEngine
    from ...ml.engines.sentiment_engine import SentimentEngine
    from ...ml.engines.news_engine import NewsEngine
    from ...ml.engines.recommendation_engine import RecommendationEngine
    from ...ml.engines.pattern_engine import PatternEngine
    from ...ml.pipelines.data_pipeline import DataPipeline
    from ...models.ml_models import MLPrediction, SentimentAnalysis, MLRecommendation, PatternDetection, AssetScoring
    from ...models.user import db
except ImportError as e:
    logger.warning(f"Alguns módulos de ML ainda não estão disponíveis: {e}")
    # Engines serão implementados nos próximos épicos
    PredictionEngine = None
    SentimentEngine = None
    NewsEngine = None
    RecommendationEngine = None
    PatternEngine = None

# Instâncias globais dos engines
prediction_engine = None
sentiment_engine = None
news_engine = None
recommendation_engine = None
pattern_engine = None
data_pipeline = None

def initialize_ml_engines():
    """
    Inicializa os engines de ML.
    """
    global prediction_engine, sentiment_engine, news_engine, recommendation_engine, pattern_engine, data_pipeline
    
    try:
        data_pipeline = DataPipeline()
        
        if PredictionEngine:
            prediction_engine = PredictionEngine()
        if SentimentEngine:
            sentiment_engine = SentimentEngine()
        if NewsEngine:
            news_engine = NewsEngine()
        if RecommendationEngine:
            recommendation_engine = RecommendationEngine()
        if PatternEngine:
            pattern_engine = PatternEngine()
            
        logger.info("Engines de ML inicializados com sucesso")
    except Exception as e:
        logger.error(f"Erro ao inicializar engines de ML: {e}")

@ml_bp.route('/health', methods=['GET'])
def ml_health_check():
    """
    Health check específico para módulos de ML.
    """
    try:
        status = {
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0',
            'engines': {
                'prediction': prediction_engine is not None,
                'sentiment': sentiment_engine is not None,
                'news': news_engine is not None,
                'recommendation': recommendation_engine is not None,
                'pattern': pattern_engine is not None,
                'data_pipeline': data_pipeline is not None
            }
        }
        
        return jsonify(status), 200
        
    except Exception as e:
        logger.error(f"Erro no health check de ML: {e}")
        return jsonify({'error': 'Erro interno no módulo de ML'}), 500

@ml_bp.route('/info', methods=['GET'])
def ml_info():
    """
    Informações sobre as funcionalidades de ML disponíveis.
    """
    try:
        info = {
            'name': 'Quantum Trades ML API',
            'version': '1.0.0',
            'description': 'APIs de Machine Learning e Inteligência Artificial',
            'endpoints': {
                'predictions': '/api/ml/predict',
                'sentiment': '/api/ml/sentiment',
                'recommendations': '/api/ml/recommendations',
                'patterns': '/api/ml/patterns',
                'scoring': '/api/ml/scoring'
            },
            'features': {
                'price_prediction': 'Predição de preços usando LSTM e ensemble',
                'pattern_detection': 'Detecção automática de padrões técnicos',
                'sentiment_analysis': 'Análise de sentimento de notícias e redes sociais',
                'personalized_recommendations': 'Recomendações personalizadas por usuário',
                'asset_scoring': 'Sistema de scoring unificado de ativos'
            },
            'models': {
                'lstm_price_predictor': 'Ativo' if prediction_engine else 'Não disponível',
                'pattern_detector': 'Ativo' if pattern_engine else 'Não disponível',
                'sentiment_analyzer': 'Ativo' if sentiment_engine else 'Não disponível',
                'recommendation_system': 'Ativo' if recommendation_engine else 'Não disponível'
            }
        }
        
        return jsonify(info), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter informações de ML: {e}")
        return jsonify({'error': 'Erro interno'}), 500

# ÉPICO 1: PREDIÇÕES DE PREÇOS
@ml_bp.route('/predict/price/<symbol>', methods=['POST'])
def predict_price(symbol):
    """
    Predição de preços para um ativo específico.
    """
    try:
        if not prediction_engine:
            return jsonify({'error': 'Engine de predição não disponível'}), 503
        
        data = request.get_json() or {}
        timeframes = data.get('timeframes', ['1d', '5d', '10d', '20d'])
        confidence_level = data.get('confidence_level', 0.95)
        
        # Coletar dados em tempo real
        realtime_data = data_pipeline.collect_realtime_data(symbol)
        if not realtime_data:
            return jsonify({'error': 'Dados não disponíveis para o símbolo'}), 404
        
        # Fazer predições
        predictions = prediction_engine.predict_price(symbol, timeframes, confidence_level)
        
        # Salvar predições no banco
        for timeframe, pred_data in predictions.items():
            prediction = MLPrediction(
                symbol=symbol,
                model_type='lstm_ensemble',
                prediction_type=f'price_{timeframe}',
                predicted_value=pred_data['predicted_value'],
                confidence_score=pred_data['confidence'],
                prediction_date=datetime.utcnow(),
                target_date=datetime.utcnow() + timedelta(days=int(timeframe.replace('d', ''))),
                features_used=pred_data.get('features_used')
            )
            db.session.add(prediction)
        
        db.session.commit()
        
        response = {
            'symbol': symbol,
            'predictions': predictions,
            'timestamp': datetime.utcnow().isoformat(),
            'model_version': prediction_engine.get_version()
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"Erro na predição de preços: {e}")
        logger.error(traceback.format_exc())
        return jsonify({'error': 'Erro interno na predição'}), 500

@ml_bp.route('/patterns/<symbol>', methods=['GET'])
def detect_patterns(symbol):
    """
    Detecção de padrões técnicos para um ativo.
    """
    try:
        if not pattern_engine:
            return jsonify({'error': 'Engine de padrões não disponível'}), 503
        
        timeframe = request.args.get('timeframe', '1d')
        confidence_threshold = float(request.args.get('confidence_threshold', 0.7))
        
        # Detectar padrões
        patterns = pattern_engine.detect_patterns(symbol, timeframe, confidence_threshold)
        
        # Salvar padrões detectados no banco
        for pattern in patterns:
            pattern_detection = PatternDetection(
                symbol=symbol,
                pattern_type=pattern['type'],
                pattern_name=pattern['name'],
                confidence_score=pattern['confidence'],
                timeframe=timeframe,
                start_date=datetime.fromisoformat(pattern['start_date']),
                end_date=datetime.fromisoformat(pattern['end_date']) if pattern.get('end_date') else None,
                key_levels=pattern.get('key_levels'),
                historical_success_rate=pattern.get('success_rate'),
                expected_move=pattern.get('expected_move'),
                risk_reward_ratio=pattern.get('risk_reward')
            )
            db.session.add(pattern_detection)
        
        db.session.commit()
        
        response = {
            'symbol': symbol,
            'timeframe': timeframe,
            'patterns_detected': len(patterns),
            'patterns': patterns,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"Erro na detecção de padrões: {e}")
        return jsonify({'error': 'Erro interno na detecção de padrões'}), 500

# ÉPICO 2: ANÁLISE DE SENTIMENTO
@ml_bp.route('/sentiment/<symbol>', methods=['GET'])
def analyze_sentiment_old(symbol):
    """
    Análise de sentimento para um ativo (versão antiga).
    """
    try:
        if not sentiment_engine:
            return jsonify({'error': 'Engine de sentimento não disponível'}), 503
        
        days_back = int(request.args.get('days', 7))
        sources = request.args.getlist('sources') or ['news', 'social']
        
        # Analisar sentimento
        sentiment_data = sentiment_engine.analyze_sentiment(symbol, days_back, sources)
        
        # Salvar análise no banco
        for analysis in sentiment_data.get('detailed_analysis', []):
            sentiment_analysis = SentimentAnalysis(
                symbol=symbol,
                source_type=analysis['source_type'],
                source_url=analysis.get('source_url'),
                sentiment_score=analysis['sentiment_score'],
                sentiment_label=analysis['sentiment_label'],
                confidence_score=analysis['confidence'],
                entities_extracted=analysis.get('entities'),
                keywords=analysis.get('keywords'),
                impact_score=analysis.get('impact_score')
            )
            db.session.add(sentiment_analysis)
        
        db.session.commit()
        
        response = {
            'symbol': symbol,
            'period_days': days_back,
            'overall_sentiment': sentiment_data.get('overall_sentiment'),
            'sentiment_trend': sentiment_data.get('trend'),
            'sources_analyzed': sentiment_data.get('sources_count'),
            'detailed_analysis': sentiment_data.get('detailed_analysis', []),
            'timestamp': datetime.utcnow().isoformat()
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"Erro na análise de sentimento: {e}")
        return jsonify({'error': 'Erro interno na análise de sentimento'}), 500

# ÉPICO 3: RECOMENDAÇÕES PERSONALIZADAS
@ml_bp.route('/recommendations/<int:user_id>', methods=['GET'])
def get_recommendations(user_id):
    """
    Recomendações personalizadas para um usuário.
    """
    try:
        if not recommendation_engine:
            return jsonify({'error': 'Engine de recomendações não disponível'}), 503
        
        recommendation_type = request.args.get('type', 'all')  # assets, strategies, alerts
        limit = int(request.args.get('limit', 10))
        
        # Gerar recomendações
        recommendations = recommendation_engine.generate_recommendations(
            user_id, recommendation_type, limit
        )
        
        # Salvar recomendações no banco
        for rec in recommendations:
            recommendation = MLRecommendation(
                user_id=user_id,
                recommendation_type=rec['type'],
                recommended_item=rec['item'],
                score=rec['score'],
                reasoning=rec.get('reasoning'),
                confidence_level=rec.get('confidence_level'),
                category=rec.get('category'),
                priority=rec.get('priority', 1)
            )
            db.session.add(recommendation)
        
        db.session.commit()
        
        response = {
            'user_id': user_id,
            'recommendation_type': recommendation_type,
            'recommendations_count': len(recommendations),
            'recommendations': recommendations,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"Erro nas recomendações: {e}")
        return jsonify({'error': 'Erro interno nas recomendações'}), 500

@ml_bp.route('/scoring/<symbol>', methods=['GET'])
def get_asset_scoring(symbol):
    """
    Sistema de scoring unificado para um ativo.
    """
    try:
        if not prediction_engine:
            return jsonify({'error': 'Engine de scoring não disponível'}), 503
        
        # Calcular scoring
        scoring_data = prediction_engine.calculate_asset_score(symbol)
        
        # Salvar scoring no banco
        asset_score = AssetScoring(
            symbol=symbol,
            overall_score=scoring_data['overall_score'],
            technical_score=scoring_data.get('technical_score'),
            fundamental_score=scoring_data.get('fundamental_score'),
            sentiment_score=scoring_data.get('sentiment_score'),
            momentum_score=scoring_data.get('momentum_score'),
            volatility_score=scoring_data.get('volatility_score'),
            volume_score=scoring_data.get('volume_score'),
            scoring_factors=scoring_data.get('factors'),
            risk_level=scoring_data.get('risk_level'),
            recommendation=scoring_data.get('recommendation'),
            target_price=scoring_data.get('target_price'),
            stop_loss=scoring_data.get('stop_loss'),
            valid_until=datetime.utcnow() + timedelta(hours=24)
        )
        db.session.add(asset_score)
        db.session.commit()
        
        response = {
            'symbol': symbol,
            'scoring': scoring_data,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"Erro no scoring de ativo: {e}")
        return jsonify({'error': 'Erro interno no scoring'}), 500

# FEEDBACK E APRENDIZADO
@ml_bp.route('/feedback', methods=['POST'])
def submit_feedback():
    """
    Submete feedback sobre predições e recomendações.
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados de feedback não fornecidos'}), 400
        
        from ...models.ml_models import MLFeedback
        
        feedback = MLFeedback(
            user_id=data['user_id'],
            prediction_id=data.get('prediction_id'),
            recommendation_id=data.get('recommendation_id'),
            feedback_type=data['feedback_type'],
            rating=data['rating'],
            comments=data.get('comments'),
            action_taken=data.get('action_taken'),
            outcome=data.get('outcome')
        )
        
        db.session.add(feedback)
        db.session.commit()
        
        # Processar feedback para melhoria dos modelos
        if recommendation_engine:
            recommendation_engine.process_feedback(feedback)
        
        return jsonify({
            'message': 'Feedback recebido com sucesso',
            'feedback_id': feedback.id
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao processar feedback: {e}")
        return jsonify({'error': 'Erro interno no processamento de feedback'}), 500

# MÉTRICAS E MONITORAMENTO
@ml_bp.route('/metrics', methods=['GET'])
def get_ml_metrics():
    """
    Métricas de performance dos modelos de ML.
    """
    try:
        metrics = {}
        
        # Métricas de predições
        if prediction_engine:
            metrics['predictions'] = prediction_engine.get_performance_metrics()
        
        # Métricas de sentimento
        if sentiment_engine:
            metrics['sentiment'] = sentiment_engine.get_performance_metrics()
        
        # Métricas de recomendações
        if recommendation_engine:
            metrics['recommendations'] = recommendation_engine.get_performance_metrics()
        
        # Métricas gerais do sistema
        metrics['system'] = {
            'total_predictions': MLPrediction.query.count(),
            'total_sentiment_analyses': SentimentAnalysis.query.count(),
            'total_recommendations': MLRecommendation.query.count(),
            'total_patterns_detected': PatternDetection.query.count()
        }
        
        return jsonify(metrics), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter métricas: {e}")
        return jsonify({'error': 'Erro interno nas métricas'}), 500

# Inicializar engines quando o blueprint for registrado
@ml_bp.before_app_request
def setup_ml():
    """
    Setup inicial dos módulos de ML.
    """
    global prediction_engine, sentiment_engine, news_engine, recommendation_engine, pattern_engine, data_pipeline
    
    if prediction_engine is None:
        initialize_ml_engines()

# ==================== ROTAS DE ANÁLISE DE SENTIMENTO ====================

@ml_bp.route('/sentiment/<symbol>', methods=['GET'])
def analyze_sentiment(symbol):
    """
    Analisa sentimento para um símbolo específico.
    """
    try:
        if not sentiment_engine:
            return jsonify({'error': 'Engine de sentimento não disponível'}), 503
        
        # Parâmetros opcionais
        days_back = request.args.get('days', 7, type=int)
        sources = request.args.getlist('sources') or ['news', 'social']
        
        # Validar parâmetros
        if days_back < 1 or days_back > 30:
            return jsonify({'error': 'Período deve estar entre 1 e 30 dias'}), 400
        
        # Analisar sentimento
        result = sentiment_engine.analyze_sentiment(symbol, days_back, sources)
        
        if 'error' in result:
            return jsonify(result), 400
        
        # Salvar no banco de dados
        try:
            sentiment_record = SentimentAnalysis(
                symbol=symbol,
                sentiment_score=result.get('overall_sentiment', {}).get('weighted_score', 0),
                confidence=result.get('overall_sentiment', {}).get('average_confidence', 0),
                sources_analyzed=result.get('total_analyzed', 0),
                analysis_data=json.dumps(result),
                created_at=datetime.utcnow()
            )
            db.session.add(sentiment_record)
            db.session.commit()
        except Exception as e:
            logger.warning(f"Erro ao salvar análise de sentimento: {e}")
        
        return jsonify(result), 200
        
    except Exception as e:
        logger.error(f"Erro na análise de sentimento: {e}")
        return jsonify({'error': 'Erro interno na análise de sentimento'}), 500

@ml_bp.route('/sentiment/batch', methods=['POST'])
def analyze_sentiment_batch():
    """
    Analisa sentimento para múltiplos símbolos.
    """
    try:
        if not sentiment_engine:
            return jsonify({'error': 'Engine de sentimento não disponível'}), 503
        
        data = request.get_json()
        if not data or 'symbols' not in data:
            return jsonify({'error': 'Lista de símbolos é obrigatória'}), 400
        
        symbols = data['symbols']
        days_back = data.get('days', 7)
        sources = data.get('sources', ['news', 'social'])
        
        if not isinstance(symbols, list) or len(symbols) == 0:
            return jsonify({'error': 'Lista de símbolos inválida'}), 400
        
        if len(symbols) > 10:
            return jsonify({'error': 'Máximo 10 símbolos por requisição'}), 400
        
        results = {}
        
        for symbol in symbols:
            try:
                result = sentiment_engine.analyze_sentiment(symbol, days_back, sources)
                results[symbol] = result
            except Exception as e:
                logger.error(f"Erro ao analisar {symbol}: {e}")
                results[symbol] = {'error': str(e)}
        
        return jsonify({
            'batch_results': results,
            'total_symbols': len(symbols),
            'successful_analyses': len([r for r in results.values() if 'error' not in r])
        }), 200
        
    except Exception as e:
        logger.error(f"Erro na análise batch de sentimento: {e}")
        return jsonify({'error': 'Erro interno na análise batch'}), 500

@ml_bp.route('/sentiment/text', methods=['POST'])
def analyze_text_sentiment():
    """
    Analisa sentimento de texto fornecido.
    """
    try:
        if not sentiment_engine:
            return jsonify({'error': 'Engine de sentimento não disponível'}), 503
        
        data = request.get_json()
        if not data or 'text' not in data:
            return jsonify({'error': 'Texto é obrigatório'}), 400
        
        text = data['text']
        if not text.strip():
            return jsonify({'error': 'Texto não pode estar vazio'}), 400
        
        # Criar DataFrame com o texto
        df = pd.DataFrame([{
            'text': text,
            'source_type': data.get('source_type', 'user_input'),
            'timestamp': datetime.now().isoformat()
        }])
        
        # Analisar sentimento
        result = sentiment_engine.predict(df)
        
        return jsonify(result), 200
        
    except Exception as e:
        logger.error(f"Erro na análise de texto: {e}")
        return jsonify({'error': 'Erro interno na análise de texto'}), 500

# ==================== ROTAS DE NOTÍCIAS ====================

@ml_bp.route('/news/<symbol>', methods=['GET'])
def collect_news(symbol):
    """
    Coleta notícias para um símbolo específico.
    """
    try:
        if not news_engine:
            return jsonify({'error': 'Engine de notícias não disponível'}), 503
        
        # Parâmetros opcionais
        days_back = request.args.get('days', 7, type=int)
        max_articles = request.args.get('max_articles', 20, type=int)
        
        # Validar parâmetros
        if days_back < 1 or days_back > 30:
            return jsonify({'error': 'Período deve estar entre 1 e 30 dias'}), 400
        
        if max_articles < 1 or max_articles > 100:
            return jsonify({'error': 'Número de artigos deve estar entre 1 e 100'}), 400
        
        # Coletar notícias
        articles = news_engine.collect_news(symbol, days_back, max_articles)
        
        return jsonify({
            'symbol': symbol,
            'articles_found': len(articles),
            'period_days': days_back,
            'articles': articles
        }), 200
        
    except Exception as e:
        logger.error(f"Erro na coleta de notícias: {e}")
        return jsonify({'error': 'Erro interno na coleta de notícias'}), 500

@ml_bp.route('/news/trending', methods=['GET'])
def get_trending_topics():
    """
    Retorna tópicos em alta nas notícias financeiras.
    """
    try:
        if not news_engine:
            return jsonify({'error': 'Engine de notícias não disponível'}), 503
        
        days_back = request.args.get('days', 3, type=int)
        
        if days_back < 1 or days_back > 7:
            return jsonify({'error': 'Período deve estar entre 1 e 7 dias'}), 400
        
        trending = news_engine.get_trending_topics(days_back)
        
        return jsonify({
            'trending_topics': trending,
            'period_days': days_back,
            'analysis_date': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter tópicos em alta: {e}")
        return jsonify({'error': 'Erro interno ao obter tópicos'}), 500

@ml_bp.route('/sentiment/news/<symbol>', methods=['GET'])
def analyze_news_sentiment(symbol):
    """
    Combina coleta de notícias com análise de sentimento.
    """
    try:
        if not news_engine or not sentiment_engine:
            return jsonify({'error': 'Engines de notícias ou sentimento não disponíveis'}), 503
        
        days_back = request.args.get('days', 7, type=int)
        max_articles = request.args.get('max_articles', 20, type=int)
        
        # Coletar notícias
        articles = news_engine.collect_news(symbol, days_back, max_articles)
        
        if not articles:
            return jsonify({
                'symbol': symbol,
                'error': 'Nenhuma notícia encontrada',
                'articles_found': 0
            }), 404
        
        # Preparar dados para análise de sentimento
        news_data = []
        for article in articles:
            news_data.append({
                'text': f"{article.get('title', '')} {article.get('content', '')}",
                'source_type': 'news',
                'timestamp': article.get('published_date', datetime.now().isoformat()),
                'url': article.get('url', ''),
                'source': article.get('source', 'unknown')
            })
        
        # Analisar sentimento
        df = pd.DataFrame(news_data)
        sentiment_result = sentiment_engine.predict(df)
        
        # Combinar resultados
        combined_result = {
            'symbol': symbol,
            'period_days': days_back,
            'articles_analyzed': len(articles),
            'news_sentiment': sentiment_result,
            'top_articles': articles[:5],  # Top 5 artigos
            'analysis_date': datetime.now().isoformat()
        }
        
        return jsonify(combined_result), 200
        
    except Exception as e:
        logger.error(f"Erro na análise de sentimento de notícias: {e}")
        return jsonify({'error': 'Erro interno na análise'}), 500


# ==================== ROTAS DE RECOMENDAÇÕES INTELIGENTES ====================

@ml_bp.route('/recommendations/<user_id>', methods=['GET'])
def get_user_recommendations(user_id):
    """
    Obtém recomendações personalizadas para um usuário.
    """
    try:
        if not recommendation_engine:
            return jsonify({'error': 'Engine de recomendações não disponível'}), 503
        
        # Parâmetros opcionais
        max_recommendations = request.args.get('max_recommendations', 10, type=int)
        risk_profile = request.args.get('risk_profile', 'moderado')
        
        # Validar parâmetros
        if max_recommendations < 1 or max_recommendations > 50:
            return jsonify({'error': 'Número de recomendações deve estar entre 1 e 50'}), 400
        
        # Perfil básico do usuário (em produção viria do banco de dados)
        user_profile = {
            'user_id': user_id,
            'risk_profile': risk_profile,
            'age': 35,
            'income': 8000,
            'investment_experience': 3,
            'risk_tolerance': 6,
            'investment_horizon': 60,
            'current_portfolio': ['PETR4', 'VALE3'],
            'total_invested': 50000,
            'monthly_contribution': 1000
        }
        
        # Gerar recomendações
        recommendations = recommendation_engine.recommend_assets(
            user_id, user_profile, max_recommendations
        )
        
        # Salvar recomendações no banco
        try:
            for rec in recommendations:
                recommendation_record = MLRecommendation(
                    user_id=user_id,
                    asset_symbol=rec['asset'],
                    recommendation_type=rec['recommendation_type'],
                    score=rec['score'],
                    reason=rec['reason'],
                    created_at=datetime.utcnow()
                )
                db.session.add(recommendation_record)
            db.session.commit()
        except Exception as e:
            logger.warning(f"Erro ao salvar recomendações: {e}")
        
        return jsonify({
            'user_id': user_id,
            'recommendations_count': len(recommendations),
            'recommendations': recommendations,
            'generated_at': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao gerar recomendações: {e}")
        return jsonify({'error': 'Erro interno nas recomendações'}), 500

@ml_bp.route('/recommendations/portfolio/optimize', methods=['POST'])
def optimize_portfolio():
    """
    Otimiza portfolio existente do usuário.
    """
    try:
        if not recommendation_engine:
            return jsonify({'error': 'Engine de recomendações não disponível'}), 503
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Dados do portfolio são obrigatórios'}), 400
        
        user_id = data.get('user_id')
        current_portfolio = data.get('current_portfolio', [])
        target_amount = data.get('target_amount', 10000)
        
        if not user_id:
            return jsonify({'error': 'ID do usuário é obrigatório'}), 400
        
        if not isinstance(current_portfolio, list):
            return jsonify({'error': 'Portfolio deve ser uma lista de ativos'}), 400
        
        if target_amount <= 0:
            return jsonify({'error': 'Valor alvo deve ser positivo'}), 400
        
        # Otimizar portfolio
        optimization = recommendation_engine.get_portfolio_optimization(
            user_id, current_portfolio, target_amount
        )
        
        if 'error' in optimization:
            return jsonify(optimization), 400
        
        return jsonify({
            'user_id': user_id,
            'optimization': optimization,
            'optimized_at': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro na otimização de portfolio: {e}")
        return jsonify({'error': 'Erro interno na otimização'}), 500

@ml_bp.route('/recommendations/batch', methods=['POST'])
def get_batch_recommendations():
    """
    Gera recomendações para múltiplos usuários.
    """
    try:
        if not recommendation_engine:
            return jsonify({'error': 'Engine de recomendações não disponível'}), 503
        
        data = request.get_json()
        if not data or 'users' not in data:
            return jsonify({'error': 'Lista de usuários é obrigatória'}), 400
        
        users = data['users']
        max_recommendations = data.get('max_recommendations', 5)
        
        if not isinstance(users, list) or len(users) == 0:
            return jsonify({'error': 'Lista de usuários inválida'}), 400
        
        if len(users) > 20:
            return jsonify({'error': 'Máximo 20 usuários por requisição'}), 400
        
        batch_results = {}
        
        for user_data in users:
            user_id = user_data.get('user_id')
            if not user_id:
                continue
            
            try:
                # Usar dados fornecidos ou padrões
                user_profile = {
                    'user_id': user_id,
                    'risk_profile': user_data.get('risk_profile', 'moderado'),
                    'age': user_data.get('age', 35),
                    'income': user_data.get('income', 5000),
                    'current_portfolio': user_data.get('current_portfolio', []),
                    'investment_experience': user_data.get('investment_experience', 2),
                    'risk_tolerance': user_data.get('risk_tolerance', 5)
                }
                
                recommendations = recommendation_engine.recommend_assets(
                    user_id, user_profile, max_recommendations
                )
                
                batch_results[user_id] = {
                    'recommendations': recommendations,
                    'count': len(recommendations)
                }
                
            except Exception as e:
                logger.error(f"Erro ao processar usuário {user_id}: {e}")
                batch_results[user_id] = {'error': str(e)}
        
        return jsonify({
            'batch_results': batch_results,
            'total_users': len(users),
            'successful_recommendations': len([r for r in batch_results.values() if 'error' not in r]),
            'generated_at': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro nas recomendações em lote: {e}")
        return jsonify({'error': 'Erro interno nas recomendações em lote'}), 500

@ml_bp.route('/recommendations/similar-users/<user_id>', methods=['GET'])
def get_similar_users(user_id):
    """
    Encontra usuários similares para filtragem colaborativa.
    """
    try:
        if not recommendation_engine:
            return jsonify({'error': 'Engine de recomendações não disponível'}), 503
        
        # Simular usuários similares (em produção usaria algoritmo real)
        similar_users = [
            {
                'user_id': f'user_{i}',
                'similarity_score': np.random.uniform(0.6, 0.95),
                'common_assets': np.random.randint(2, 8),
                'risk_profile': np.random.choice(['conservador', 'moderado', 'arrojado'])
            }
            for i in range(1, 6)
        ]
        
        # Ordenar por similaridade
        similar_users.sort(key=lambda x: x['similarity_score'], reverse=True)
        
        return jsonify({
            'user_id': user_id,
            'similar_users': similar_users,
            'total_found': len(similar_users),
            'analysis_date': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao encontrar usuários similares: {e}")
        return jsonify({'error': 'Erro interno na busca de usuários similares'}), 500

@ml_bp.route('/recommendations/trending-assets', methods=['GET'])
def get_trending_assets():
    """
    Retorna ativos em alta baseado em recomendações.
    """
    try:
        if not recommendation_engine:
            return jsonify({'error': 'Engine de recomendações não disponível'}), 503
        
        days_back = request.args.get('days', 7, type=int)
        
        # Simular ativos em alta (em produção analisaria recomendações reais)
        trending_assets = [
            {
                'asset': 'PETR4',
                'category': 'ações',
                'recommendation_count': 45,
                'average_score': 0.85,
                'trend': 'up',
                'reasons': ['Fundamentos sólidos', 'Preço atrativo', 'Dividendos']
            },
            {
                'asset': 'HGLG11',
                'category': 'fiis',
                'recommendation_count': 38,
                'average_score': 0.78,
                'trend': 'up',
                'reasons': ['Alto dividend yield', 'Gestão eficiente']
            },
            {
                'asset': 'BOVA11',
                'category': 'etfs',
                'recommendation_count': 32,
                'average_score': 0.72,
                'trend': 'stable',
                'reasons': ['Diversificação', 'Baixo custo']
            }
        ]
        
        return jsonify({
            'trending_assets': trending_assets,
            'period_days': days_back,
            'total_assets': len(trending_assets),
            'analysis_date': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter ativos em alta: {e}")
        return jsonify({'error': 'Erro interno nos ativos em alta'}), 500

@ml_bp.route('/recommendations/risk-analysis/<user_id>', methods=['GET'])
def analyze_user_risk(user_id):
    """
    Analisa perfil de risco do usuário.
    """
    try:
        if not recommendation_engine:
            return jsonify({'error': 'Engine de recomendações não disponível'}), 503
        
        # Perfil simulado do usuário
        user_profile = {
            'age': 35,
            'income': 8000,
            'investment_experience': 3,
            'risk_tolerance': 6,
            'current_portfolio': ['PETR4', 'VALE3', 'HGLG11']
        }
        
        # Analisar risco do portfolio atual
        portfolio_risk = recommendation_engine._analyze_portfolio_risk(
            user_profile['current_portfolio']
        )
        
        # Determinar perfil de risco
        risk_profile = recommendation_engine._determine_risk_profile(
            pd.Series(user_profile)
        )
        
        # Sugestões de ajuste
        risk_suggestions = []
        if portfolio_risk.get('overall_risk', 0) > 0.7:
            risk_suggestions.append({
                'type': 'reduce_risk',
                'message': 'Considere adicionar mais renda fixa ao portfolio',
                'priority': 'high'
            })
        elif portfolio_risk.get('overall_risk', 0) < 0.3:
            risk_suggestions.append({
                'type': 'increase_return',
                'message': 'Portfolio muito conservador, considere mais ações',
                'priority': 'medium'
            })
        
        return jsonify({
            'user_id': user_id,
            'risk_profile': risk_profile,
            'portfolio_risk_analysis': portfolio_risk,
            'risk_suggestions': risk_suggestions,
            'analysis_date': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro na análise de risco: {e}")
        return jsonify({'error': 'Erro interno na análise de risco'}), 500

@ml_bp.route('/recommendations/diversification/<user_id>', methods=['GET'])
def analyze_diversification(user_id):
    """
    Analisa diversificação do portfolio do usuário.
    """
    try:
        if not recommendation_engine:
            return jsonify({'error': 'Engine de recomendações não disponível'}), 503
        
        # Portfolio simulado
        current_portfolio = ['PETR4', 'VALE3', 'ITUB4']
        
        # Analisar composição atual
        composition = recommendation_engine._analyze_portfolio_composition(current_portfolio)
        
        # Sugerir melhorias de diversificação
        diversification_suggestions = recommendation_engine._suggest_new_assets(current_portfolio)
        
        # Calcular score de diversificação
        diversification_score = composition.get('diversification_score', 0) * 100
        
        # Recomendações específicas
        recommendations = []
        if diversification_score < 50:
            recommendations.append({
                'type': 'add_category',
                'message': 'Adicione FIIs para melhor diversificação',
                'suggested_assets': ['HGLG11', 'XPML11'],
                'priority': 'high'
            })
        
        if diversification_score < 70:
            recommendations.append({
                'type': 'add_international',
                'message': 'Considere ETFs internacionais',
                'suggested_assets': ['IVVB11'],
                'priority': 'medium'
            })
        
        return jsonify({
            'user_id': user_id,
            'current_portfolio': current_portfolio,
            'diversification_score': diversification_score,
            'composition_analysis': composition,
            'diversification_suggestions': diversification_suggestions,
            'improvement_recommendations': recommendations,
            'analysis_date': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Erro na análise de diversificação: {e}")
        return jsonify({'error': 'Erro interno na análise de diversificação'}), 500

