#!/usr/bin/env python3
"""
Rotas para dados reais de mercado
"""

from flask import Blueprint, jsonify, request
from services.real_market_data_service import market_service
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Criar blueprint
real_market_bp = Blueprint('real_market', __name__)

@real_market_bp.route('/api/real-market/stock/<symbol>', methods=['GET'])
def get_stock(symbol):
    """Obtém dados de uma ação específica"""
    try:
        data = market_service.get_stock_data(symbol.upper())
        if data:
            return jsonify({
                'success': True,
                'data': data
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Ação não encontrada'
            }), 404
            
    except Exception as e:
        logger.error(f"Erro ao buscar ação {symbol}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Erro interno do servidor'
        }), 500

@real_market_bp.route('/api/real-market/popular', methods=['GET'])
def get_popular_stocks():
    """Obtém ações populares"""
    try:
        data = market_service.get_popular_stocks()
        return jsonify({
            'success': True,
            'data': data
        })
        
    except Exception as e:
        logger.error(f"Erro ao buscar ações populares: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Erro interno do servidor'
        }), 500

@real_market_bp.route('/api/real-market/search', methods=['GET'])
def search_stocks():
    """Busca ações por termo"""
    try:
        query = request.args.get('q', '').strip()
        if not query:
            return jsonify({
                'success': False,
                'error': 'Parâmetro de busca obrigatório'
            }), 400
        
        data = market_service.search_stocks(query)
        return jsonify({
            'success': True,
            'data': data
        })
        
    except Exception as e:
        logger.error(f"Erro ao buscar ações: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Erro interno do servidor'
        }), 500

@real_market_bp.route('/api/real-market/status', methods=['GET'])
def get_market_status():
    """Obtém status do mercado"""
    try:
        data = market_service.get_market_status()
        return jsonify({
            'success': True,
            'data': data
        })
        
    except Exception as e:
        logger.error(f"Erro ao buscar status do mercado: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Erro interno do servidor'
        }), 500

@real_market_bp.route('/api/real-market/multiple', methods=['POST'])
def get_multiple_stocks():
    """Obtém dados de múltiplas ações"""
    try:
        data = request.get_json()
        if not data or 'symbols' not in data:
            return jsonify({
                'success': False,
                'error': 'Lista de símbolos obrigatória'
            }), 400
        
        symbols = data['symbols']
        if not isinstance(symbols, list):
            return jsonify({
                'success': False,
                'error': 'Símbolos devem ser uma lista'
            }), 400
        
        results = market_service.get_multiple_stocks(symbols)
        return jsonify({
            'success': True,
            'data': results
        })
        
    except Exception as e:
        logger.error(f"Erro ao buscar múltiplas ações: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Erro interno do servidor'
        }), 500

