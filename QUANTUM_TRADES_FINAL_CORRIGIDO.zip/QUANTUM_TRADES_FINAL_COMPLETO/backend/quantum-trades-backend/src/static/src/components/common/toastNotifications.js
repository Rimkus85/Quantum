/**
 * Sistema de Notificações Toast - Quantum Finance
 * Gerencia exibição de mensagens de feedback para o usuário
 */

class ToastNotifications {
    constructor() {
        this.container = null;
        this.toasts = new Map();
        this.defaultDuration = 5000;
        this.maxToasts = 5;
        
        this.init();
    }

    /**
     * Inicializa o sistema de toast
     */
    init() {
        // Criar container se não existir
        this.container = document.getElementById('toastContainer');
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = 'toastContainer';
            this.container.className = 'toast-container';
            document.body.appendChild(this.container);
        }
    }

    /**
     * Exibe toast de sucesso
     * @param {string} message 
     * @param {number} duration 
     * @returns {string} toastId
     */
    success(message, duration = this.defaultDuration) {
        return this.show(message, 'success', duration);
    }

    /**
     * Exibe toast de erro
     * @param {string} message 
     * @param {number} duration 
     * @returns {string} toastId
     */
    error(message, duration = this.defaultDuration) {
        return this.show(message, 'error', duration);
    }

    /**
     * Exibe toast de aviso
     * @param {string} message 
     * @param {number} duration 
     * @returns {string} toastId
     */
    warning(message, duration = this.defaultDuration) {
        return this.show(message, 'warning', duration);
    }

    /**
     * Exibe toast de informação
     * @param {string} message 
     * @param {number} duration 
     * @returns {string} toastId
     */
    info(message, duration = this.defaultDuration) {
        return this.show(message, 'info', duration);
    }

    /**
     * Exibe toast genérico
     * @param {string} message 
     * @param {string} type 
     * @param {number} duration 
     * @returns {string} toastId
     */
    show(message, type = 'info', duration = this.defaultDuration) {
        const toastId = this.generateId();
        
        // Limitar número de toasts
        if (this.toasts.size >= this.maxToasts) {
            const oldestToast = this.toasts.keys().next().value;
            this.hide(oldestToast);
        }
        
        // Criar elemento do toast
        const toastElement = this.createToastElement(toastId, message, type);
        
        // Adicionar ao container
        this.container.appendChild(toastElement);
        
        // Armazenar referência
        this.toasts.set(toastId, {
            element: toastElement,
            type,
            message,
            createdAt: Date.now()
        });
        
        // Animar entrada
        requestAnimationFrame(() => {
            toastElement.classList.add('show');
        });
        
        // Auto-hide se duration > 0
        if (duration > 0) {
            setTimeout(() => {
                this.hide(toastId);
            }, duration);
        }
        
        return toastId;
    }

    /**
     * Oculta toast específico
     * @param {string} toastId 
     */
    hide(toastId) {
        const toast = this.toasts.get(toastId);
        if (!toast) return;
        
        const element = toast.element;
        
        // Animar saída
        element.classList.remove('show');
        element.classList.add('hide');
        
        // Remover após animação
        setTimeout(() => {
            if (element.parentNode) {
                element.parentNode.removeChild(element);
            }
            this.toasts.delete(toastId);
        }, 300);
    }

    /**
     * Oculta todos os toasts
     */
    hideAll() {
        const toastIds = Array.from(this.toasts.keys());
        toastIds.forEach(id => this.hide(id));
    }

    /**
     * Cria elemento HTML do toast
     * @param {string} toastId 
     * @param {string} message 
     * @param {string} type 
     * @returns {HTMLElement}
     */
    createToastElement(toastId, message, type) {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.setAttribute('data-toast-id', toastId);
        
        // Ícone baseado no tipo
        const icon = this.getIconForType(type);
        
        toast.innerHTML = `
            <div class="toast-content">
                <div class="toast-icon">
                    <i class="${icon}"></i>
                </div>
                <div class="toast-message">${message}</div>
                <button class="toast-close" onclick="window.toast.hide('${toastId}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        return toast;
    }

    /**
     * Retorna ícone baseado no tipo
     * @param {string} type 
     * @returns {string}
     */
    getIconForType(type) {
        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };
        
        return icons[type] || icons.info;
    }

    /**
     * Gera ID único para toast
     * @returns {string}
     */
    generateId() {
        return 'toast_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    /**
     * Obtém toast por ID
     * @param {string} toastId 
     * @returns {Object|null}
     */
    getToast(toastId) {
        return this.toasts.get(toastId) || null;
    }

    /**
     * Obtém todos os toasts ativos
     * @returns {Array}
     */
    getAllToasts() {
        return Array.from(this.toasts.values());
    }

    /**
     * Limpa toasts expirados
     */
    cleanup() {
        const now = Date.now();
        const expiredToasts = [];
        
        this.toasts.forEach((toast, id) => {
            if (now - toast.createdAt > 30000) { // 30 segundos
                expiredToasts.push(id);
            }
        });
        
        expiredToasts.forEach(id => this.hide(id));
    }

    /**
     * Configura limpeza automática
     */
    startAutoCleanup() {
        setInterval(() => {
            this.cleanup();
        }, 10000); // A cada 10 segundos
    }
}

// CSS adicional para toasts (se não estiver no CSS principal)
const toastStyles = `
.toast {
    background: var(--quantum-widget-bg, #232340);
    border: 1px solid var(--quantum-widget-border, #3a3a5c);
    border-radius: 8px;
    color: var(--quantum-text, #ffffff);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    transform: translateX(100%);
    transition: transform 0.3s ease, opacity 0.3s ease;
    max-width: 400px;
    margin-bottom: 10px;
    opacity: 0;
}

.toast.show {
    transform: translateX(0);
    opacity: 1;
}

.toast.hide {
    transform: translateX(100%);
    opacity: 0;
}

.toast-content {
    display: flex;
    align-items: flex-start;
    padding: 1rem;
    gap: 12px;
}

.toast-icon {
    flex-shrink: 0;
    font-size: 1.2rem;
    margin-top: 2px;
}

.toast-success {
    border-left: 4px solid var(--quantum-success, #00D4AA);
}

.toast-success .toast-icon {
    color: var(--quantum-success, #00D4AA);
}

.toast-error {
    border-left: 4px solid var(--quantum-error, #FF6B6B);
}

.toast-error .toast-icon {
    color: var(--quantum-error, #FF6B6B);
}

.toast-warning {
    border-left: 4px solid var(--quantum-warning, #FFB347);
}

.toast-warning .toast-icon {
    color: var(--quantum-warning, #FFB347);
}

.toast-info {
    border-left: 4px solid var(--quantum-info, #4ECDC4);
}

.toast-info .toast-icon {
    color: var(--quantum-info, #4ECDC4);
}

.toast-message {
    flex: 1;
    line-height: 1.4;
    font-size: 0.9rem;
}

.toast-close {
    background: none;
    border: none;
    color: var(--quantum-text-secondary, #b8b8b8);
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    transition: color 0.2s ease;
    flex-shrink: 0;
}

.toast-close:hover {
    color: var(--quantum-text, #ffffff);
}

@media (max-width: 480px) {
    .toast-container {
        left: 10px;
        right: 10px;
    }
    
    .toast {
        max-width: none;
    }
}
`;

// Adicionar estilos se não existirem
if (!document.getElementById('toast-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'toast-styles';
    styleSheet.textContent = toastStyles;
    document.head.appendChild(styleSheet);
}

// Instância global do sistema de toast
window.toast = new ToastNotifications();

// Iniciar limpeza automática
window.toast.startAutoCleanup();

