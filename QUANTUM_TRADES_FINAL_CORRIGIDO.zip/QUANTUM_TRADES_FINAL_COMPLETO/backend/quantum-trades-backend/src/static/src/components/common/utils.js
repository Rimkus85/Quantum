/**
 * 🛠️ QUANTUM FINANCE - COMMON UTILITIES
 * Utilitários comuns para toda a aplicação
 */

/**
 * Utilitários de formatação
 */
const FormatUtils = {
  /**
   * Formatar preço em reais
   */
  formatPrice(price, decimals = 2) {
    if (typeof price !== 'number' || isNaN(price)) return 'R$ 0,00';
    
    return price.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  },

  /**
   * Formatar número
   */
  formatNumber(number, decimals = 0) {
    if (typeof number !== 'number' || isNaN(number)) return '0';
    
    return number.toLocaleString('pt-BR', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  },

  /**
   * Formatar percentual
   */
  formatPercent(percent, decimals = 2) {
    if (typeof percent !== 'number' || isNaN(percent)) return '0%';
    
    return percent.toLocaleString('pt-BR', {
      style: 'percent',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  },

  /**
   * Formatar volume
   */
  formatVolume(volume) {
    if (typeof volume !== 'number' || isNaN(volume)) return '0';
    
    if (volume >= 1000000000) {
      return (volume / 1000000000).toFixed(1) + 'B';
    } else if (volume >= 1000000) {
      return (volume / 1000000).toFixed(1) + 'M';
    } else if (volume >= 1000) {
      return (volume / 1000).toFixed(1) + 'K';
    }
    
    return volume.toLocaleString('pt-BR');
  },

  /**
   * Formatar data
   */
  formatDate(date, options = {}) {
    if (!(date instanceof Date) || isNaN(date)) return 'Data inválida';
    
    const defaultOptions = {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    };
    
    return date.toLocaleDateString('pt-BR', { ...defaultOptions, ...options });
  },

  /**
   * Formatar hora
   */
  formatTime(date, options = {}) {
    if (!(date instanceof Date) || isNaN(date)) return 'Hora inválida';
    
    const defaultOptions = {
      hour: '2-digit',
      minute: '2-digit'
    };
    
    return date.toLocaleTimeString('pt-BR', { ...defaultOptions, ...options });
  },

  /**
   * Formatar data e hora
   */
  formatDateTime(date, options = {}) {
    if (!(date instanceof Date) || isNaN(date)) return 'Data/hora inválida';
    
    const defaultOptions = {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    
    return date.toLocaleString('pt-BR', { ...defaultOptions, ...options });
  },

  /**
   * Formatar tempo relativo (ex: "há 5 minutos")
   */
  formatRelativeTime(date) {
    if (!(date instanceof Date) || isNaN(date)) return 'Data inválida';
    
    const now = new Date();
    const diffMs = now - date;
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffSecs < 60) {
      return 'agora mesmo';
    } else if (diffMins < 60) {
      return `há ${diffMins} minuto${diffMins > 1 ? 's' : ''}`;
    } else if (diffHours < 24) {
      return `há ${diffHours} hora${diffHours > 1 ? 's' : ''}`;
    } else if (diffDays < 7) {
      return `há ${diffDays} dia${diffDays > 1 ? 's' : ''}`;
    } else {
      return this.formatDate(date);
    }
  }
};

/**
 * Utilitários de validação
 */
const ValidationUtils = {
  /**
   * Validar símbolo de ação brasileira
   */
  isValidBrazilianStock(symbol) {
    if (typeof symbol !== 'string') return false;
    
    // Formato: 4 letras + 1-2 números (ex: PETR4, VALE3, BBDC11)
    return /^[A-Z]{4}[0-9]{1,2}$/.test(symbol.toUpperCase());
  },

  /**
   * Validar email
   */
  isValidEmail(email) {
    if (typeof email !== 'string') return false;
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  /**
   * Validar número
   */
  isValidNumber(value) {
    return typeof value === 'number' && !isNaN(value) && isFinite(value);
  },

  /**
   * Validar data
   */
  isValidDate(date) {
    return date instanceof Date && !isNaN(date);
  },

  /**
   * Validar string não vazia
   */
  isNonEmptyString(value) {
    return typeof value === 'string' && value.trim().length > 0;
  }
};

/**
 * Utilitários de DOM
 */
const DOMUtils = {
  /**
   * Criar elemento com atributos
   */
  createElement(tag, attributes = {}, children = []) {
    const element = document.createElement(tag);
    
    // Adicionar atributos
    Object.entries(attributes).forEach(([key, value]) => {
      if (key === 'className') {
        element.className = value;
      } else if (key === 'innerHTML') {
        element.innerHTML = value;
      } else if (key === 'textContent') {
        element.textContent = value;
      } else {
        element.setAttribute(key, value);
      }
    });
    
    // Adicionar filhos
    children.forEach(child => {
      if (typeof child === 'string') {
        element.appendChild(document.createTextNode(child));
      } else if (child instanceof Node) {
        element.appendChild(child);
      }
    });
    
    return element;
  },

  /**
   * Adicionar classe com animação
   */
  addClassWithAnimation(element, className, duration = 300) {
    element.classList.add(className);
    
    return new Promise(resolve => {
      setTimeout(() => {
        resolve();
      }, duration);
    });
  },

  /**
   * Remover classe com animação
   */
  removeClassWithAnimation(element, className, duration = 300) {
    element.classList.add('quantum-fade-out');
    
    return new Promise(resolve => {
      setTimeout(() => {
        element.classList.remove(className, 'quantum-fade-out');
        resolve();
      }, duration);
    });
  },

  /**
   * Scroll suave para elemento
   */
  scrollToElement(element, options = {}) {
    const defaultOptions = {
      behavior: 'smooth',
      block: 'start',
      inline: 'nearest'
    };
    
    element.scrollIntoView({ ...defaultOptions, ...options });
  },

  /**
   * Verificar se elemento está visível
   */
  isElementVisible(element) {
    const rect = element.getBoundingClientRect();
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    const windowWidth = window.innerWidth || document.documentElement.clientWidth;
    
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= windowHeight &&
      rect.right <= windowWidth
    );
  },

  /**
   * Debounce de função
   */
  debounce(func, wait, immediate = false) {
    let timeout;
    
    return function executedFunction(...args) {
      const later = () => {
        timeout = null;
        if (!immediate) func(...args);
      };
      
      const callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      
      if (callNow) func(...args);
    };
  },

  /**
   * Throttle de função
   */
  throttle(func, limit) {
    let inThrottle;
    
    return function(...args) {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }
};

/**
 * Utilitários de dados
 */
const DataUtils = {
  /**
   * Deep clone de objeto
   */
  deepClone(obj) {
    if (obj === null || typeof obj !== 'object') return obj;
    if (obj instanceof Date) return new Date(obj.getTime());
    if (obj instanceof Array) return obj.map(item => this.deepClone(item));
    if (typeof obj === 'object') {
      const clonedObj = {};
      Object.keys(obj).forEach(key => {
        clonedObj[key] = this.deepClone(obj[key]);
      });
      return clonedObj;
    }
  },

  /**
   * Merge profundo de objetos
   */
  deepMerge(target, source) {
    const result = { ...target };
    
    Object.keys(source).forEach(key => {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        result[key] = this.deepMerge(result[key] || {}, source[key]);
      } else {
        result[key] = source[key];
      }
    });
    
    return result;
  },

  /**
   * Agrupar array por propriedade
   */
  groupBy(array, key) {
    return array.reduce((groups, item) => {
      const group = item[key];
      groups[group] = groups[group] || [];
      groups[group].push(item);
      return groups;
    }, {});
  },

  /**
   * Ordenar array por múltiplas propriedades
   */
  sortBy(array, ...keys) {
    return array.sort((a, b) => {
      for (const key of keys) {
        const aVal = a[key];
        const bVal = b[key];
        
        if (aVal < bVal) return -1;
        if (aVal > bVal) return 1;
      }
      return 0;
    });
  },

  /**
   * Remover duplicatas de array
   */
  unique(array, key = null) {
    if (key) {
      const seen = new Set();
      return array.filter(item => {
        const value = item[key];
        if (seen.has(value)) {
          return false;
        }
        seen.add(value);
        return true;
      });
    }
    
    return [...new Set(array)];
  },

  /**
   * Calcular média de array
   */
  average(array, key = null) {
    if (array.length === 0) return 0;
    
    const values = key ? array.map(item => item[key]) : array;
    const sum = values.reduce((acc, val) => acc + (val || 0), 0);
    
    return sum / values.length;
  },

  /**
   * Encontrar valor mínimo e máximo
   */
  minMax(array, key = null) {
    if (array.length === 0) return { min: 0, max: 0 };
    
    const values = key ? array.map(item => item[key]) : array;
    
    return {
      min: Math.min(...values),
      max: Math.max(...values)
    };
  }
};

/**
 * Utilitários de performance
 */
const PerformanceUtils = {
  /**
   * Medir tempo de execução
   */
  measureTime(func, label = 'Function') {
    return async function(...args) {
      const start = performance.now();
      const result = await func(...args);
      const end = performance.now();
      
      console.log(`[Performance] ${label}: ${(end - start).toFixed(2)}ms`);
      return result;
    };
  },

  /**
   * Cache simples com TTL
   */
  createCache(ttlMs = 300000) { // 5 minutos por padrão
    const cache = new Map();
    const timestamps = new Map();
    
    return {
      get(key) {
        const timestamp = timestamps.get(key);
        if (timestamp && Date.now() - timestamp < ttlMs) {
          return cache.get(key);
        }
        
        // Expirou
        cache.delete(key);
        timestamps.delete(key);
        return null;
      },
      
      set(key, value) {
        cache.set(key, value);
        timestamps.set(key, Date.now());
      },
      
      has(key) {
        return this.get(key) !== null;
      },
      
      delete(key) {
        cache.delete(key);
        timestamps.delete(key);
      },
      
      clear() {
        cache.clear();
        timestamps.clear();
      },
      
      size() {
        return cache.size;
      }
    };
  },

  /**
   * Lazy loading de imagens
   */
  lazyLoadImages(selector = 'img[data-src]') {
    const images = document.querySelectorAll(selector);
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.classList.remove('lazy');
          observer.unobserve(img);
        }
      });
    });
    
    images.forEach(img => imageObserver.observe(img));
  }
};

/**
 * Utilitários de erro
 */
const ErrorUtils = {
  /**
   * Wrapper para try-catch com logging
   */
  safeExecute(func, fallback = null, context = 'Unknown') {
    return async function(...args) {
      try {
        return await func(...args);
      } catch (error) {
        console.error(`[${context}] Error:`, error);
        
        if (typeof fallback === 'function') {
          return fallback(error);
        }
        
        return fallback;
      }
    };
  },

  /**
   * Retry com backoff exponencial
   */
  retry(func, maxAttempts = 3, baseDelay = 1000) {
    return async function(...args) {
      let lastError;
      
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          return await func(...args);
        } catch (error) {
          lastError = error;
          
          if (attempt === maxAttempts) {
            throw error;
          }
          
          const delay = baseDelay * Math.pow(2, attempt - 1);
          console.warn(`[Retry] Attempt ${attempt} failed, retrying in ${delay}ms...`);
          
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
      
      throw lastError;
    };
  }
};

// Exportar utilitários
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    FormatUtils,
    ValidationUtils,
    DOMUtils,
    DataUtils,
    PerformanceUtils,
    ErrorUtils
  };
} else {
  // Disponibilizar globalmente no browser
  window.FormatUtils = FormatUtils;
  window.ValidationUtils = ValidationUtils;
  window.DOMUtils = DOMUtils;
  window.DataUtils = DataUtils;
  window.PerformanceUtils = PerformanceUtils;
  window.ErrorUtils = ErrorUtils;
}

// Adicionar estilos para animações
const utilityStyles = `
  .quantum-fade-out {
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  .quantum-fade-in {
    opacity: 1;
    transition: opacity 0.3s ease;
  }

  .lazy {
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  .lazy.loaded {
    opacity: 1;
  }
`;

// Adicionar estilos ao documento
if (typeof document !== 'undefined') {
  const styleSheet = document.createElement('style');
  styleSheet.textContent = utilityStyles;
  document.head.appendChild(styleSheet);
}

