/**
 * 🚀 QUANTUM FINANCE - PROGRESSIVE LOADER
 * Sistema de carregamento progressivo para melhor performance
 */

class ProgressiveLoader {
  constructor() {
    this.phases = new Map();
    this.currentPhase = 0;
    this.isLoading = false;
    this.loadingElement = null;
    this.progressBar = null;
    
    this.setupLoadingUI();
  }
  
  /**
   * Configurar interface de loading
   */
  setupLoadingUI() {
    this.loadingElement = document.getElementById('loading-screen');
    this.progressBar = document.querySelector('.quantum-progress-bar');
    
    if (!this.loadingElement) {
      console.warn('[ProgressiveLoader] Loading screen element not found');
    }
  }
  
  /**
   * Registrar fase de carregamento
   */
  registerPhase(id, config) {
    this.phases.set(id, {
      id,
      name: config.name,
      weight: config.weight || 1,
      timeout: config.timeout || 10000,
      loader: config.loader,
      dependencies: config.dependencies || [],
      completed: false,
      error: null
    });
  }
  
  /**
   * Inicializar carregamento progressivo
   */
  async start() {
    if (this.isLoading) {
      console.warn('[ProgressiveLoader] Already loading');
      return;
    }
    
    this.isLoading = true;
    this.currentPhase = 0;
    
    console.log('[ProgressiveLoader] Starting progressive loading...');
    
    try {
      // Ordenar fases por dependências
      const orderedPhases = this.resolveDependencies();
      
      for (const phase of orderedPhases) {
        await this.executePhase(phase);
      }
      
      console.log('[ProgressiveLoader] All phases completed successfully');
      this.hideLoading();
      
    } catch (error) {
      console.error('[ProgressiveLoader] Loading failed:', error);
      this.showError(error);
    } finally {
      this.isLoading = false;
    }
  }
  
  /**
   * Executar uma fase
   */
  async executePhase(phase) {
    console.log(`[ProgressiveLoader] Executing phase: ${phase.name}`);
    
    this.updateLoadingText(phase.name);
    this.updateProgress();
    
    try {
      // Executar com timeout
      const result = await Promise.race([
        phase.loader(),
        this.createTimeout(phase.timeout, `Phase "${phase.name}" timeout`)
      ]);
      
      phase.completed = true;
      phase.result = result;
      
      console.log(`[ProgressiveLoader] Phase "${phase.name}" completed`);
      
    } catch (error) {
      phase.error = error;
      console.error(`[ProgressiveLoader] Phase "${phase.name}" failed:`, error);
      
      // Decidir se deve continuar ou parar
      if (phase.critical !== false) {
        throw error;
      }
    }
    
    this.currentPhase++;
  }
  
  /**
   * Resolver dependências das fases
   */
  resolveDependencies() {
    const phases = Array.from(this.phases.values());
    const resolved = [];
    const visited = new Set();
    
    const visit = (phase) => {
      if (visited.has(phase.id)) return;
      
      // Visitar dependências primeiro
      for (const depId of phase.dependencies) {
        const dependency = this.phases.get(depId);
        if (dependency) {
          visit(dependency);
        }
      }
      
      visited.add(phase.id);
      resolved.push(phase);
    };
    
    for (const phase of phases) {
      visit(phase);
    }
    
    return resolved;
  }
  
  /**
   * Criar timeout promise
   */
  createTimeout(ms, message) {
    return new Promise((_, reject) => {
      setTimeout(() => reject(new Error(message)), ms);
    });
  }
  
  /**
   * Atualizar texto de loading
   */
  updateLoadingText(text) {
    const textElement = document.querySelector('.quantum-loading-text');
    if (textElement) {
      textElement.textContent = text;
    }
  }
  
  /**
   * Atualizar barra de progresso
   */
  updateProgress() {
    if (!this.progressBar) return;
    
    const totalPhases = this.phases.size;
    const progress = (this.currentPhase / totalPhases) * 100;
    
    this.progressBar.style.width = `${progress}%`;
  }
  
  /**
   * Esconder loading
   */
  hideLoading() {
    if (this.loadingElement) {
      this.loadingElement.style.opacity = '0';
      setTimeout(() => {
        this.loadingElement.style.display = 'none';
      }, 500);
    }
  }
  
  /**
   * Mostrar erro
   */
  showError(error) {
    const textElement = document.querySelector('.quantum-loading-text');
    if (textElement) {
      textElement.textContent = `Erro: ${error.message}`;
      textElement.style.color = '#DC3545';
    }
    
    // Esconder loading após 3 segundos
    setTimeout(() => {
      this.hideLoading();
    }, 3000);
  }
  
  /**
   * Obter resultado de uma fase
   */
  getPhaseResult(phaseId) {
    const phase = this.phases.get(phaseId);
    return phase ? phase.result : null;
  }
  
  /**
   * Verificar se fase foi completada
   */
  isPhaseCompleted(phaseId) {
    const phase = this.phases.get(phaseId);
    return phase ? phase.completed : false;
  }
  
  /**
   * Obter estatísticas de carregamento
   */
  getStats() {
    const phases = Array.from(this.phases.values());
    const completed = phases.filter(p => p.completed).length;
    const failed = phases.filter(p => p.error).length;
    const total = phases.length;
    
    return {
      total,
      completed,
      failed,
      success: completed - failed,
      progress: (completed / total) * 100
    };
  }
}

// Configuração padrão das fases
const defaultPhases = {
  'ui-basic': {
    name: 'Carregando interface...',
    weight: 1,
    timeout: 2000,
    loader: async () => {
      // UI básica já está carregada
      return true;
    }
  },
  
  'chart-js': {
    name: 'Carregando gráficos...',
    weight: 2,
    timeout: 10000,
    loader: async () => {
      return await ChartLoader.ensureChartJS();
    }
  },
  
  'services': {
    name: 'Configurando serviços...',
    weight: 1,
    timeout: 3000,
    dependencies: ['chart-js'],
    loader: async () => {
      // Inicializar serviços
      if (typeof FinancialDataService !== 'undefined') {
        const service = new FinancialDataService();
        service.configure();
        return service;
      }
      return null;
    }
  },
  
  'market-data': {
    name: 'Carregando dados do mercado...',
    weight: 3,
    timeout: 8000,
    dependencies: ['services'],
    loader: async () => {
      // Carregar dados essenciais do mercado
      const app = window.app;
      if (app && app.financialService) {
        return await app.financialService.getMarketOverviewWithFallback({
          timeout: 5000
        });
      }
      return null;
    }
  },
  
  'components': {
    name: 'Inicializando componentes...',
    weight: 2,
    timeout: 5000,
    dependencies: ['services', 'chart-js'],
    loader: async () => {
      // Inicializar componentes principais
      const app = window.app;
      if (app) {
        await app.initializeComponents();
        return true;
      }
      return false;
    }
  },
  
  'featured-stocks': {
    name: 'Carregando ações em destaque...',
    weight: 2,
    timeout: 8000,
    dependencies: ['services'],
    critical: false, // Não crítico - pode falhar
    loader: async () => {
      const app = window.app;
      if (app && app.financialService) {
        return await app.financialService.getMultipleStockPricesWithFallback([
          'PETR4', 'VALE3', 'ITUB4', 'BBDC4'
        ], { timeout: 5000 });
      }
      return null;
    }
  }
};

// Exportar para uso global
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { ProgressiveLoader, defaultPhases };
} else {
  window.ProgressiveLoader = ProgressiveLoader;
  window.defaultPhases = defaultPhases;
}

