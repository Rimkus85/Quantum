/**
 * ⚠️ QUANTUM FINANCE - ERROR MANAGER
 * Sistema centralizado de tratamento de erros com UX otimizada
 */

class ErrorManager {
  static instance = null;
  
  constructor() {
    this.errorQueue = [];
    this.userNotifications = new Set();
    this.errorCounts = new Map();
    this.suppressedErrors = new Set();
    this.retryAttempts = new Map();
    
    this.setupGlobalHandlers();
    this.setupNotificationContainer();
  }
  
  /**
   * Singleton pattern
   */
  static getInstance() {
    if (!this.instance) {
      this.instance = new ErrorManager();
    }
    return this.instance;
  }
  
  /**
   * Configurar handlers globais
   */
  setupGlobalHandlers() {
    // Capturar erros JavaScript não tratados
    window.addEventListener('error', (event) => {
      this.handleError(event.error || new Error(event.message), 'global', {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno
      });
    });
    
    // Capturar promises rejeitadas
    window.addEventListener('unhandledrejection', (event) => {
      this.handleError(event.reason, 'promise');
      event.preventDefault(); // Prevenir log no console
    });
    
    // Capturar erros de recursos
    window.addEventListener('error', (event) => {
      if (event.target !== window) {
        this.handleError(new Error(`Resource failed to load: ${event.target.src || event.target.href}`), 'resource');
      }
    }, true);
  }
  
  /**
   * Configurar container de notificações
   */
  setupNotificationContainer() {
    if (!document.getElementById('quantum-error-notifications')) {
      const container = document.createElement('div');
      container.id = 'quantum-error-notifications';
      container.className = 'quantum-error-notifications';
      container.innerHTML = `
        <style>
          .quantum-error-notifications {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            max-width: 400px;
          }
          
          .quantum-error-notification {
            background: linear-gradient(135deg, #DC3545, #C82333);
            color: white;
            padding: 16px;
            margin-bottom: 12px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(220, 53, 69, 0.3);
            border-left: 4px solid #FFD700;
            animation: slideIn 0.3s ease-out;
            position: relative;
            overflow: hidden;
          }
          
          .quantum-error-notification.warning {
            background: linear-gradient(135deg, #FFC107, #E0A800);
            color: #1A1A2E;
            box-shadow: 0 4px 12px rgba(255, 193, 7, 0.3);
          }
          
          .quantum-error-notification.info {
            background: linear-gradient(135deg, #17A2B8, #138496);
            box-shadow: 0 4px 12px rgba(23, 162, 184, 0.3);
          }
          
          .quantum-error-content {
            display: flex;
            align-items: flex-start;
            gap: 12px;
          }
          
          .quantum-error-icon {
            font-size: 18px;
            margin-top: 2px;
            flex-shrink: 0;
          }
          
          .quantum-error-message {
            flex: 1;
            font-size: 14px;
            line-height: 1.4;
          }
          
          .quantum-error-title {
            font-weight: 600;
            margin-bottom: 4px;
          }
          
          .quantum-error-description {
            opacity: 0.9;
            font-size: 13px;
          }
          
          .quantum-error-actions {
            margin-top: 12px;
            display: flex;
            gap: 8px;
          }
          
          .quantum-error-button {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: inherit;
            padding: 6px 12px;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
            transition: background 0.2s;
          }
          
          .quantum-error-button:hover {
            background: rgba(255, 255, 255, 0.3);
          }
          
          .quantum-error-close {
            position: absolute;
            top: 8px;
            right: 8px;
            background: none;
            border: none;
            color: inherit;
            font-size: 16px;
            cursor: pointer;
            opacity: 0.7;
            transition: opacity 0.2s;
          }
          
          .quantum-error-close:hover {
            opacity: 1;
          }
          
          .quantum-error-progress {
            position: absolute;
            bottom: 0;
            left: 0;
            height: 3px;
            background: rgba(255, 255, 255, 0.3);
            animation: progress 5s linear;
          }
          
          @keyframes slideIn {
            from {
              transform: translateX(100%);
              opacity: 0;
            }
            to {
              transform: translateX(0);
              opacity: 1;
            }
          }
          
          @keyframes progress {
            from { width: 100%; }
            to { width: 0%; }
          }
        </style>
      `;
      document.body.appendChild(container);
    }
  }
  
  /**
   * Tratar erro principal
   */
  handleError(error, context = 'unknown', metadata = {}) {
    const errorInfo = {
      id: this.generateErrorId(),
      type: this.categorizeError(error),
      message: error.message || 'Unknown error',
      stack: error.stack,
      context,
      metadata,
      timestamp: new Date(),
      userAgent: navigator.userAgent,
      url: window.location.href,
      userId: this.getUserId()
    };
    
    // Verificar se deve suprimir erro repetitivo
    if (this.shouldSuppressError(errorInfo)) {
      return errorInfo.id;
    }
    
    // Log estruturado para desenvolvimento
    this.logError(errorInfo);
    
    // Adicionar à fila
    this.errorQueue.push(errorInfo);
    
    // Atualizar contadores
    this.updateErrorCounts(errorInfo);
    
    // Mostrar notificação para usuário
    this.showUserNotification(errorInfo);
    
    // Reportar se crítico
    if (this.isCriticalError(errorInfo)) {
      this.reportError(errorInfo);
    }
    
    // Tentar recuperação automática
    this.attemptAutoRecovery(errorInfo);
    
    return errorInfo.id;
  }
  
  /**
   * Categorizar erro
   */
  categorizeError(error) {
    // Erros de rede
    if (error.name === 'TypeError' && error.message.includes('fetch')) {
      return 'NetworkError';
    }
    
    if (error.message.includes('timeout')) {
      return 'TimeoutError';
    }
    
    if (error.message.includes('CORS')) {
      return 'CORSError';
    }
    
    // Erros de API
    if (error.status) {
      if (error.status >= 400 && error.status < 500) {
        return 'ClientError';
      }
      if (error.status >= 500) {
        return 'ServerError';
      }
    }
    
    // Erros de Chart.js
    if (error.message.includes('Chart') || error.message.includes('canvas')) {
      return 'ChartError';
    }
    
    // Erros de dados
    if (error.message.includes('JSON') || error.message.includes('parse')) {
      return 'DataError';
    }
    
    // Erros de permissão
    if (error.message.includes('permission') || error.message.includes('denied')) {
      return 'PermissionError';
    }
    
    return 'UnknownError';
  }
  
  /**
   * Verificar se deve suprimir erro
   */
  shouldSuppressError(errorInfo) {
    const errorKey = `${errorInfo.type}:${errorInfo.message}`;
    const count = this.errorCounts.get(errorKey) || 0;
    
    // Suprimir se já ocorreu muitas vezes
    if (count > 5) {
      this.suppressedErrors.add(errorKey);
      return true;
    }
    
    return false;
  }
  
  /**
   * Atualizar contadores de erro
   */
  updateErrorCounts(errorInfo) {
    const errorKey = `${errorInfo.type}:${errorInfo.message}`;
    const count = this.errorCounts.get(errorKey) || 0;
    this.errorCounts.set(errorKey, count + 1);
  }
  
  /**
   * Log estruturado
   */
  logError(errorInfo) {
    const logLevel = this.getLogLevel(errorInfo.type);
    const logMethod = console[logLevel] || console.error;
    
    logMethod('[Quantum Error]', {
      id: errorInfo.id,
      type: errorInfo.type,
      message: errorInfo.message,
      context: errorInfo.context,
      timestamp: errorInfo.timestamp.toISOString(),
      stack: errorInfo.stack
    });
  }
  
  /**
   * Obter nível de log
   */
  getLogLevel(errorType) {
    const levels = {
      'NetworkError': 'warn',
      'TimeoutError': 'warn',
      'CORSError': 'error',
      'ClientError': 'warn',
      'ServerError': 'error',
      'ChartError': 'warn',
      'DataError': 'warn',
      'PermissionError': 'error',
      'UnknownError': 'error'
    };
    
    return levels[errorType] || 'error';
  }
  
  /**
   * Mostrar notificação para usuário
   */
  showUserNotification(errorInfo) {
    const config = this.getNotificationConfig(errorInfo);
    
    // Evitar spam de notificações
    if (this.userNotifications.has(config.message)) return;
    
    this.userNotifications.add(config.message);
    
    const notification = this.createNotificationElement(config, errorInfo);
    const container = document.getElementById('quantum-error-notifications');
    
    if (container) {
      container.appendChild(notification);
      
      // Auto-remove
      setTimeout(() => {
        this.removeNotification(notification, config.message);
      }, config.duration);
    }
  }
  
  /**
   * Obter configuração de notificação
   */
  getNotificationConfig(errorInfo) {
    const configs = {
      'NetworkError': {
        type: 'warning',
        icon: '🌐',
        title: 'Problema de Conexão',
        message: 'Verificando conexão automaticamente...',
        duration: 4000,
        showRetry: true
      },
      'TimeoutError': {
        type: 'warning',
        icon: '⏱️',
        title: 'Operação Demorada',
        message: 'Tentando novamente...',
        duration: 3000,
        showRetry: true
      },
      'CORSError': {
        type: 'error',
        icon: '🔒',
        title: 'Erro de Segurança',
        message: 'Problema de configuração detectado.',
        duration: 6000,
        showRetry: false
      },
      'ChartError': {
        type: 'warning',
        icon: '📊',
        title: 'Erro nos Gráficos',
        message: 'Recarregando componentes...',
        duration: 4000,
        showRetry: true
      },
      'ServerError': {
        type: 'error',
        icon: '🔧',
        title: 'Serviço Indisponível',
        message: 'Nossos serviços estão temporariamente indisponíveis.',
        duration: 5000,
        showRetry: true
      },
      'DataError': {
        type: 'warning',
        icon: '📄',
        title: 'Erro nos Dados',
        message: 'Problema ao processar informações.',
        duration: 4000,
        showRetry: false
      }
    };
    
    return configs[errorInfo.type] || {
      type: 'error',
      icon: '⚠️',
      title: 'Erro Inesperado',
      message: 'Algo deu errado. Nossa equipe foi notificada.',
      duration: 5000,
      showRetry: false
    };
  }
  
  /**
   * Criar elemento de notificação
   */
  createNotificationElement(config, errorInfo) {
    const notification = document.createElement('div');
    notification.className = `quantum-error-notification ${config.type}`;
    
    notification.innerHTML = `
      <div class="quantum-error-content">
        <div class="quantum-error-icon">${config.icon}</div>
        <div class="quantum-error-message">
          <div class="quantum-error-title">${config.title}</div>
          <div class="quantum-error-description">${config.message}</div>
          ${config.showRetry ? `
            <div class="quantum-error-actions">
              <button class="quantum-error-button" onclick="window.ErrorManager.getInstance().retryOperation('${errorInfo.id}')">
                Tentar Novamente
              </button>
            </div>
          ` : ''}
        </div>
      </div>
      <button class="quantum-error-close" onclick="this.parentElement.remove()">×</button>
      <div class="quantum-error-progress"></div>
    `;
    
    return notification;
  }
  
  /**
   * Remover notificação
   */
  removeNotification(notification, message) {
    if (notification.parentElement) {
      notification.remove();
      this.userNotifications.delete(message);
    }
  }
  
  /**
   * Verificar se é erro crítico
   */
  isCriticalError(errorInfo) {
    const criticalTypes = ['CORSError', 'PermissionError', 'ServerError'];
    return criticalTypes.includes(errorInfo.type);
  }
  
  /**
   * Reportar erro
   */
  reportError(errorInfo) {
    // Em produção, enviar para serviço de monitoramento
    console.error('[Critical Error Reported]', errorInfo);
    
    // Simular envio para Sentry, LogRocket, etc.
    if (typeof gtag !== 'undefined') {
      gtag('event', 'exception', {
        description: errorInfo.message,
        fatal: this.isCriticalError(errorInfo)
      });
    }
  }
  
  /**
   * Tentar recuperação automática
   */
  attemptAutoRecovery(errorInfo) {
    const recoveryStrategies = {
      'NetworkError': () => this.retryWithBackoff(errorInfo),
      'TimeoutError': () => this.retryWithBackoff(errorInfo),
      'ChartError': () => this.reloadChartComponents(),
      'DataError': () => this.clearCacheAndRetry(errorInfo)
    };
    
    const strategy = recoveryStrategies[errorInfo.type];
    if (strategy) {
      setTimeout(strategy, 1000); // Delay para evitar loops
    }
  }
  
  /**
   * Retry com backoff exponencial
   */
  retryWithBackoff(errorInfo) {
    const retryKey = `${errorInfo.type}:${errorInfo.context}`;
    const attempts = this.retryAttempts.get(retryKey) || 0;
    
    if (attempts >= 3) {
      console.warn('[ErrorManager] Max retry attempts reached for:', retryKey);
      return;
    }
    
    const delay = Math.pow(2, attempts) * 1000; // 1s, 2s, 4s
    this.retryAttempts.set(retryKey, attempts + 1);
    
    setTimeout(() => {
      console.log(`[ErrorManager] Retrying operation (attempt ${attempts + 1}):`, retryKey);
      // Trigger retry event
      window.dispatchEvent(new CustomEvent('quantum-retry', {
        detail: { errorInfo, attempt: attempts + 1 }
      }));
    }, delay);
  }
  
  /**
   * Recarregar componentes de gráfico
   */
  reloadChartComponents() {
    console.log('[ErrorManager] Reloading chart components...');
    
    // Reset Chart.js loader
    if (window.ChartLoader) {
      window.ChartLoader.reset();
    }
    
    // Trigger chart reload event
    window.dispatchEvent(new CustomEvent('quantum-reload-charts'));
  }
  
  /**
   * Limpar cache e tentar novamente
   */
  clearCacheAndRetry(errorInfo) {
    console.log('[ErrorManager] Clearing cache and retrying...');
    
    // Limpar cache se disponível
    if (window.app && window.app.cache) {
      window.app.cache.clear();
    }
    
    // Trigger data reload
    window.dispatchEvent(new CustomEvent('quantum-reload-data'));
  }
  
  /**
   * Retry manual de operação
   */
  retryOperation(errorId) {
    const errorInfo = this.errorQueue.find(e => e.id === errorId);
    if (errorInfo) {
      this.attemptAutoRecovery(errorInfo);
    }
  }
  
  /**
   * Gerar ID único para erro
   */
  generateErrorId() {
    return `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  
  /**
   * Obter ID do usuário (se disponível)
   */
  getUserId() {
    // Em produção, obter do sistema de autenticação
    return localStorage.getItem('quantum_user_id') || 'anonymous';
  }
  
  /**
   * Obter estatísticas de erros
   */
  getErrorStats() {
    const typeStats = new Map();
    
    for (const error of this.errorQueue) {
      const count = typeStats.get(error.type) || 0;
      typeStats.set(error.type, count + 1);
    }
    
    return {
      totalErrors: this.errorQueue.length,
      suppressedErrors: this.suppressedErrors.size,
      typeBreakdown: Object.fromEntries(typeStats),
      recentErrors: this.errorQueue.slice(-10)
    };
  }
  
  /**
   * Limpar histórico de erros
   */
  clearErrorHistory() {
    this.errorQueue = [];
    this.errorCounts.clear();
    this.suppressedErrors.clear();
    this.retryAttempts.clear();
    console.log('[ErrorManager] Error history cleared');
  }
}

// Inicializar automaticamente
document.addEventListener('DOMContentLoaded', () => {
  window.ErrorManager = ErrorManager;
  ErrorManager.getInstance();
});

// Exportar para uso global
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ErrorManager;
} else {
  window.ErrorManager = ErrorManager;
}

