/**
 * 🇧🇷 QUANTUM FINANCE - BRAPI ADAPTER
 * Adaptador para BRAPI - API Brasileira Especializada
 */

class BrapiAPI extends BaseAPI {
  constructor() {
    super('https://brapi.dev/api');
    this.rateLimiter = new RateLimiter(1000, 3600000); // 1000 req/hora (estimativa)
  }

  /**
   * Obter preço atual de uma ação
   */
  async getStockPrice(symbol) {
    const brapiSymbol = this.formatSymbol(symbol);
    
    try {
      const response = await this.request(`/quote/${brapiSymbol}`);
      
      if (!response.results || !response.results.length) {
        throw new Error(`No data found for symbol ${symbol}`);
      }

      const stockData = response.results[0];
      return this.transformBrapiStockData(stockData, symbol);
      
    } catch (error) {
      console.error(`[BRAPI] Error fetching price for ${symbol}:`, error);
      throw error;
    }
  }

  /**
   * Obter múltiplas ações de uma vez
   */
  async getMultipleStockPrices(symbols) {
    const brapiSymbols = symbols.map(s => this.formatSymbol(s)).join(',');
    
    try {
      const response = await this.request(`/quote/${brapiSymbols}`);
      
      if (!response.results) {
        return [];
      }

      return response.results.map((stockData, index) => 
        this.transformBrapiStockData(stockData, symbols[index])
      );
      
    } catch (error) {
      console.error('[BRAPI] Error fetching multiple prices:', error);
      throw error;
    }
  }

  /**
   * Obter histórico de preços
   */
  async getStockHistory(symbol, period = '1M', interval = '1d') {
    const brapiSymbol = this.formatSymbol(symbol);
    const params = this.formatHistoryParams(period, interval);
    
    try {
      const response = await this.request(`/quote/${brapiSymbol}`, { params });
      
      if (!response.results || !response.results.length) {
        throw new Error(`No historical data found for symbol ${symbol}`);
      }

      const stockData = response.results[0];
      return this.transformBrapiHistoricalData(stockData, symbol);
      
    } catch (error) {
      console.error(`[BRAPI] Error fetching history for ${symbol}:`, error);
      throw error;
    }
  }

  /**
   * Buscar ações por nome ou símbolo
   */
  async searchStocks(query, limit = 10) {
    if (query.length < 2) return [];
    
    try {
      const response = await this.request('/available', {
        params: { search: query }
      });

      if (!response.stocks) {
        return [];
      }

      return response.stocks
        .filter(stock => stock.type === 'stock')
        .map(stock => this.transformBrapiSearchResult(stock))
        .slice(0, limit);
        
    } catch (error) {
      console.error(`[BRAPI] Error searching for "${query}":`, error);
      return [];
    }
  }

  /**
   * Obter informações de dividendos
   */
  async getDividends(symbol) {
    const brapiSymbol = this.formatSymbol(symbol);
    
    try {
      const response = await this.request(`/quote/${brapiSymbol}`, {
        params: { dividends: true }
      });
      
      if (!response.results || !response.results.length) {
        return [];
      }

      const stockData = response.results[0];
      return stockData.dividendsData || [];
      
    } catch (error) {
      console.error(`[BRAPI] Error fetching dividends for ${symbol}:`, error);
      return [];
    }
  }

  /**
   * Obter visão geral do mercado brasileiro
   */
  async getMarketOverview() {
    const indices = ['IBOV', 'IFIX', 'SMLL'];
    
    try {
      const promises = indices.map(index => this.getStockPrice(index));
      const results = await Promise.all(promises);
      
      return {
        ibovespa: results[0],
        ifix: results[1],
        smallCap: results[2],
        timestamp: new Date()
      };
      
    } catch (error) {
      console.error('[BRAPI] Error fetching market overview:', error);
      throw error;
    }
  }

  /**
   * Formatar símbolo para BRAPI
   */
  formatSymbol(symbol) {
    // BRAPI usa símbolos brasileiros sem sufixo
    if (symbol.endsWith('.SA')) {
      return symbol.replace('.SA', '');
    }
    
    // Índices brasileiros
    if (symbol === '^BVSP') return 'IBOV';
    if (symbol === '^IFIX') return 'IFIX';
    if (symbol === '^SMLL') return 'SMLL';
    
    return symbol.toUpperCase();
  }

  /**
   * Formatar parâmetros para histórico
   */
  formatHistoryParams(period, interval) {
    const params = {};
    
    // BRAPI usa range para período
    const ranges = {
      '1D': '1d',
      '5D': '5d',
      '1M': '1mo',
      '3M': '3mo',
      '6M': '6mo',
      '1Y': '1y',
      '2Y': '2y',
      '5Y': '5y'
    };
    
    params.range = ranges[period] || '1mo';
    
    // BRAPI usa interval
    const intervals = {
      '1d': '1d',
      '5d': '5d',
      '1wk': '1wk',
      '1mo': '1mo'
    };
    
    params.interval = intervals[interval] || '1d';
    
    return params;
  }

  /**
   * Transformar dados de preço do BRAPI
   */
  transformBrapiStockData(stockData, originalSymbol) {
    const price = stockData.regularMarketPrice || 0;
    const change = stockData.regularMarketChange || 0;
    const changePercent = stockData.regularMarketChangePercent || 0;

    return {
      symbol: originalSymbol,
      price: parseFloat(price.toFixed(2)),
      change: parseFloat(change.toFixed(2)),
      changePercent: parseFloat(changePercent.toFixed(2)),
      volume: parseInt(stockData.regularMarketVolume || 0),
      marketCap: stockData.marketCap || null,
      timestamp: new Date(stockData.regularMarketTime || Date.now()),
      currency: stockData.currency || 'BRL',
      exchange: 'B3',
      source: 'brapi',
      // Dados específicos do BRAPI
      longName: stockData.longName,
      shortName: stockData.shortName,
      logoUrl: stockData.logourl
    };
  }

  /**
   * Transformar dados históricos do BRAPI
   */
  transformBrapiHistoricalData(stockData, originalSymbol) {
    if (!stockData.historicalDataPrice || !stockData.historicalDataPrice.length) {
      return [];
    }

    return stockData.historicalDataPrice.map(item => ({
      date: new Date(item.date * 1000),
      open: parseFloat((item.open || 0).toFixed(2)),
      high: parseFloat((item.high || 0).toFixed(2)),
      low: parseFloat((item.low || 0).toFixed(2)),
      close: parseFloat((item.close || 0).toFixed(2)),
      adjClose: parseFloat((item.adjClose || item.close || 0).toFixed(2)),
      volume: parseInt(item.volume || 0),
      symbol: originalSymbol
    })).filter(item => item.close > 0);
  }

  /**
   * Transformar resultado de busca do BRAPI
   */
  transformBrapiSearchResult(stock) {
    return {
      symbol: stock.stock,
      name: stock.name,
      exchange: 'B3',
      type: stock.type,
      currency: 'BRL',
      source: 'brapi'
    };
  }

  /**
   * Validar dados específicos do BRAPI
   */
  validateResponseData(data) {
    if (!super.validateResponseData(data)) {
      return false;
    }

    // Validações específicas para BRAPI
    if (data.error) {
      console.error('[BRAPI] API Error:', data.error);
      return false;
    }

    return true;
  }
}

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = BrapiAPI;
} else {
  window.BrapiAPI = BrapiAPI;
}

