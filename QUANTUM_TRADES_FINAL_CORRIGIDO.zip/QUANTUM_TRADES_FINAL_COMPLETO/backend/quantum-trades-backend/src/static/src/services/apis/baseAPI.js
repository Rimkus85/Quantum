/**
 * 🔧 QUANTUM FINANCE - BASE API CLASS
 * Classe base para todos os adaptadores de API
 */

class BaseAPI {
  constructor(baseURL, apiKey = null) {
    this.baseURL = baseURL;
    this.apiKey = apiKey;
    this.rateLimiter = new RateLimiter();
    this.retryCount = 0;
    this.maxRetries = 3;
  }

  /**
   * Método principal para fazer requisições HTTP
   */
  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'QuantumFinance/1.0',
        ...options.headers
      },
      ...options
    };

    // Adicionar API key se disponível
    if (this.apiKey) {
      if (options.params) {
        options.params.apikey = this.apiKey;
      } else {
        config.headers['X-API-Key'] = this.apiKey;
      }
    }

    // Verificar rate limiting
    if (!this.rateLimiter.canMakeRequest()) {
      throw new Error('Rate limit exceeded');
    }

    try {
      console.log(`[API Request] ${config.method} ${url}`);
      const startTime = Date.now();
      
      const response = await fetch(url + this.buildQueryString(options.params), config);
      const latency = Date.now() - startTime;
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log(`[API Response] ${response.status} - ${latency}ms`);
      
      this.rateLimiter.recordRequest();
      return data;

    } catch (error) {
      console.error(`[API Error] ${error.message}`, { url, config });
      
      // Retry logic para erros transientes
      if (this.isRetryableError(error) && this.retryCount < this.maxRetries) {
        this.retryCount++;
        const delay = this.calculateBackoffDelay(this.retryCount);
        console.warn(`[API Retry] Attempt ${this.retryCount} in ${delay}ms`);
        
        await this.sleep(delay);
        return this.request(endpoint, options);
      }
      
      this.retryCount = 0;
      throw error;
    }
  }

  /**
   * Construir query string a partir de parâmetros
   */
  buildQueryString(params) {
    if (!params) return '';
    
    const queryString = Object.entries(params)
      .filter(([key, value]) => value !== undefined && value !== null)
      .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
      .join('&');
    
    return queryString ? `?${queryString}` : '';
  }

  /**
   * Verificar se o erro é retryable
   */
  isRetryableError(error) {
    // Erros de rede são retryable
    if (error.name === 'TypeError' && error.message.includes('fetch')) {
      return true;
    }
    
    // Status HTTP 5xx são retryable
    if (error.message.includes('HTTP 5')) {
      return true;
    }
    
    // Rate limit pode ser retryable com delay maior
    if (error.message.includes('429') || error.message.includes('Rate limit')) {
      return true;
    }
    
    return false;
  }

  /**
   * Calcular delay para backoff exponencial
   */
  calculateBackoffDelay(attempt) {
    const baseDelay = 1000; // 1 segundo
    const maxDelay = 10000; // 10 segundos
    const backoffMultiplier = 2;
    
    let delay = baseDelay * Math.pow(backoffMultiplier, attempt - 1);
    delay = Math.min(delay, maxDelay);
    
    // Adicionar jitter para evitar thundering herd
    delay = delay * (0.5 + Math.random() * 0.5);
    
    return Math.floor(delay);
  }

  /**
   * Sleep utility
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Métodos abstratos que devem ser implementados pelas subclasses
   */
  async getStockPrice(symbol) {
    throw new Error('getStockPrice must be implemented by subclass');
  }

  async getStockHistory(symbol, period, interval) {
    throw new Error('getStockHistory must be implemented by subclass');
  }

  async searchStocks(query, limit) {
    throw new Error('searchStocks must be implemented by subclass');
  }

  /**
   * Validar estrutura de dados de resposta
   */
  validateResponseData(data) {
    if (!data || typeof data !== 'object') {
      return false;
    }
    
    // Validações específicas podem ser implementadas nas subclasses
    return true;
  }

  /**
   * Transformar dados para formato padrão
   */
  transformStockData(rawData) {
    // Implementação padrão - pode ser sobrescrita
    return {
      symbol: rawData.symbol || 'UNKNOWN',
      price: parseFloat(rawData.price || 0),
      change: parseFloat(rawData.change || 0),
      changePercent: parseFloat(rawData.changePercent || 0),
      volume: parseInt(rawData.volume || 0),
      timestamp: new Date(rawData.timestamp || Date.now()),
      currency: rawData.currency || 'BRL'
    };
  }
}

/**
 * 🚦 RATE LIMITER
 * Controla a frequência de requisições
 */
class RateLimiter {
  constructor(maxRequests = 60, windowMs = 60000) { // 60 req/min por padrão
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
    this.requests = [];
  }

  canMakeRequest() {
    const now = Date.now();
    
    // Remover requisições antigas
    this.requests = this.requests.filter(time => now - time < this.windowMs);
    
    return this.requests.length < this.maxRequests;
  }

  recordRequest() {
    this.requests.push(Date.now());
  }

  getRequestsInWindow() {
    const now = Date.now();
    this.requests = this.requests.filter(time => now - time < this.windowMs);
    return this.requests.length;
  }

  getTimeUntilReset() {
    if (this.requests.length === 0) return 0;
    
    const oldestRequest = Math.min(...this.requests);
    const resetTime = oldestRequest + this.windowMs;
    return Math.max(0, resetTime - Date.now());
  }
}

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { BaseAPI, RateLimiter };
} else {
  window.BaseAPI = BaseAPI;
  window.RateLimiter = RateLimiter;
}

