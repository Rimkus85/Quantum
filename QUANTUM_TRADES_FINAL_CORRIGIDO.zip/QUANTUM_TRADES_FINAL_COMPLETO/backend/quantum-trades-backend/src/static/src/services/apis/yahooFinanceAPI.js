/**
 * 📈 QUANTUM FINANCE - YAHOO FINANCE API ADAPTER
 * Adaptador para Yahoo Finance API - API Principal
 */

class YahooFinanceAPI extends BaseAPI {
  constructor() {
    super('https://query1.finance.yahoo.com');
    this.rateLimiter = new RateLimiter(2000, 3600000); // 2000 req/hora
  }

  /**
   * Obter preço atual de uma ação
   */
  async getStockPrice(symbol) {
    const yahooSymbol = this.formatSymbol(symbol);
    
    try {
      const response = await this.request(`/v8/finance/chart/${yahooSymbol}`);
      
      if (!response.chart || !response.chart.result || !response.chart.result.length) {
        throw new Error(`No data found for symbol ${symbol}`);
      }

      const result = response.chart.result[0];
      const meta = result.meta;
      
      if (!meta) {
        throw new Error(`Invalid data structure for symbol ${symbol}`);
      }

      return this.transformYahooStockData(meta, symbol);
      
    } catch (error) {
      console.error(`[Yahoo Finance] Error fetching price for ${symbol}:`, error);
      throw error;
    }
  }

  /**
   * Obter histórico de preços
   */
  async getStockHistory(symbol, period = '1M', interval = '1d') {
    const yahooSymbol = this.formatSymbol(symbol);
    const params = {
      period1: this.getPeriodStart(period),
      period2: Math.floor(Date.now() / 1000),
      interval: this.formatInterval(interval)
    };

    try {
      const response = await this.request(`/v8/finance/chart/${yahooSymbol}`, { params });
      
      if (!response.chart || !response.chart.result || !response.chart.result.length) {
        throw new Error(`No historical data found for symbol ${symbol}`);
      }

      return this.transformYahooHistoricalData(response.chart.result[0], symbol);
      
    } catch (error) {
      console.error(`[Yahoo Finance] Error fetching history for ${symbol}:`, error);
      throw error;
    }
  }

  /**
   * Buscar ações por nome ou símbolo
   */
  async searchStocks(query, limit = 10) {
    if (query.length < 2) return [];
    
    try {
      const response = await this.request('/v1/finance/search', {
        params: {
          q: query,
          quotesCount: limit,
          newsCount: 0
        }
      });

      if (!response.quotes) {
        return [];
      }

      return response.quotes
        .filter(quote => quote.typeDisp === 'Equity' && quote.exchange)
        .map(quote => this.transformYahooSearchResult(quote))
        .slice(0, limit);
        
    } catch (error) {
      console.error(`[Yahoo Finance] Error searching for "${query}":`, error);
      return [];
    }
  }

  /**
   * Obter visão geral do mercado (índices principais)
   */
  async getMarketOverview() {
    const indices = ['^BVSP', '^IFIX', '^SMLL']; // Ibovespa, IFIX, Small Cap
    
    try {
      const promises = indices.map(index => this.getStockPrice(index));
      const results = await Promise.all(promises);
      
      return {
        ibovespa: results[0],
        ifix: results[1],
        smallCap: results[2],
        timestamp: new Date()
      };
      
    } catch (error) {
      console.error('[Yahoo Finance] Error fetching market overview:', error);
      throw error;
    }
  }

  /**
   * Formatar símbolo para Yahoo Finance
   */
  formatSymbol(symbol) {
    // Converter símbolos brasileiros para formato Yahoo (.SA)
    if (symbol.match(/^[A-Z]{4}[0-9]{1,2}$/)) {
      return `${symbol}.SA`;
    }
    
    // Índices brasileiros
    if (symbol === 'IBOV') return '^BVSP';
    if (symbol === 'IFIX') return '^IFIX';
    if (symbol === 'SMLL') return '^SMLL';
    
    return symbol;
  }

  /**
   * Calcular timestamp de início do período
   */
  getPeriodStart(period) {
    const now = new Date();
    const periods = {
      '1D': 1,
      '5D': 5,
      '1M': 30,
      '3M': 90,
      '6M': 180,
      '1Y': 365,
      '2Y': 730,
      '5Y': 1825
    };
    
    const days = periods[period] || 30;
    const startDate = new Date(now.getTime() - (days * 24 * 60 * 60 * 1000));
    return Math.floor(startDate.getTime() / 1000);
  }

  /**
   * Formatar intervalo para Yahoo Finance
   */
  formatInterval(interval) {
    const intervals = {
      '1m': '1m',
      '5m': '5m',
      '15m': '15m',
      '30m': '30m',
      '1h': '1h',
      '1d': '1d',
      '5d': '5d',
      '1wk': '1wk',
      '1mo': '1mo',
      '3mo': '3mo'
    };
    
    return intervals[interval] || '1d';
  }

  /**
   * Transformar dados de preço do Yahoo Finance
   */
  transformYahooStockData(meta, originalSymbol) {
    const price = meta.regularMarketPrice || meta.previousClose || 0;
    const previousClose = meta.previousClose || price;
    const change = price - previousClose;
    const changePercent = previousClose !== 0 ? (change / previousClose) * 100 : 0;

    return {
      symbol: originalSymbol,
      price: parseFloat(price.toFixed(2)),
      change: parseFloat(change.toFixed(2)),
      changePercent: parseFloat(changePercent.toFixed(2)),
      volume: parseInt(meta.regularMarketVolume || 0),
      marketCap: meta.marketCap || null,
      timestamp: new Date((meta.regularMarketTime || Date.now() / 1000) * 1000),
      currency: meta.currency || 'BRL',
      exchange: meta.exchangeName || 'B3',
      source: 'yahoo_finance'
    };
  }

  /**
   * Transformar dados históricos do Yahoo Finance
   */
  transformYahooHistoricalData(result, originalSymbol) {
    const timestamps = result.timestamp || [];
    const indicators = result.indicators;
    
    if (!indicators || !indicators.quote || !indicators.quote[0]) {
      return [];
    }

    const quote = indicators.quote[0];
    const adjClose = indicators.adjclose ? indicators.adjclose[0].adjclose : null;

    return timestamps.map((timestamp, index) => ({
      date: new Date(timestamp * 1000),
      open: parseFloat((quote.open[index] || 0).toFixed(2)),
      high: parseFloat((quote.high[index] || 0).toFixed(2)),
      low: parseFloat((quote.low[index] || 0).toFixed(2)),
      close: parseFloat((quote.close[index] || 0).toFixed(2)),
      adjClose: adjClose ? parseFloat((adjClose[index] || 0).toFixed(2)) : null,
      volume: parseInt(quote.volume[index] || 0),
      symbol: originalSymbol
    })).filter(item => item.close > 0); // Filtrar dados inválidos
  }

  /**
   * Transformar resultado de busca do Yahoo Finance
   */
  transformYahooSearchResult(quote) {
    return {
      symbol: quote.symbol.replace('.SA', ''), // Remover .SA para símbolos brasileiros
      name: quote.longname || quote.shortname || quote.symbol,
      exchange: quote.exchange,
      type: quote.typeDisp,
      currency: quote.currency || 'BRL',
      source: 'yahoo_finance'
    };
  }

  /**
   * Validar dados específicos do Yahoo Finance
   */
  validateResponseData(data) {
    if (!super.validateResponseData(data)) {
      return false;
    }

    // Validações específicas para Yahoo Finance
    if (data.chart && data.chart.error) {
      console.error('[Yahoo Finance] API Error:', data.chart.error);
      return false;
    }

    return true;
  }
}

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = YahooFinanceAPI;
} else {
  window.YahooFinanceAPI = YahooFinanceAPI;
}

