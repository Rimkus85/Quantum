/**
 * 🚀 QUANTUM FINANCE - APPLICATION MAIN
 * Aplicação principal com sistemas otimizados
 */

class QuantumFinanceApp {
  constructor() {
    this.financialService = null;
    this.cache = null;
    this.errorManager = null;
    this.progressiveLoader = null;
    this.components = new Map();
    this.isInitialized = false;
    this.currentUser = null;
    
    console.log('[QuantumApp] Application starting...');
  }
  
  /**
   * Inicializar aplicação com carregamento progressivo
   */
  async init() {
    try {
      // Verificar autenticação primeiro
      if (!this.checkAuthentication()) {
        return; // Redirecionamento já foi feito
      }
      
      // Inicializar error manager primeiro
      this.errorManager = ErrorManager.getInstance();
      
      // Configurar progressive loader
      this.setupProgressiveLoader();
      
      // Iniciar carregamento progressivo
      await this.progressiveLoader.start();
      
      // Configurar interface do usuário
      this.setupUserInterface();
      
      this.isInitialized = true;
      console.log('[QuantumApp] Application initialized successfully');
      
    } catch (error) {
      console.error('[QuantumApp] Initialization failed:', error);
      this.errorManager.handleError(error, 'app-init');
      this.showFallbackUI();
    }
  }
  
  /**
   * Verificar autenticação do usuário
   */
  checkAuthentication() {
    // Verificar sessão salva pelo login
    const session = localStorage.getItem('quantum_trades_session') || 
                   sessionStorage.getItem('quantum_trades_session');
    
    if (!session) {
      console.log('[QuantumApp] User not authenticated, redirecting to login');
      window.location.href = 'login.html';
      return false;
    }
    
    try {
      const sessionData = JSON.parse(session);
      this.currentUser = sessionData.user;
      console.log('[QuantumApp] User authenticated:', this.currentUser.name);
      return true;
    } catch (error) {
      console.error('[QuantumApp] Invalid session data, redirecting to login');
      localStorage.removeItem('quantum_trades_session');
      sessionStorage.removeItem('quantum_trades_session');
      window.location.href = 'login.html';
      return false;
    }
  }
  
  /**
   * Configurar interface do usuário autenticado
   */
  setupUserInterface() {
    const userInfo = document.getElementById('user-info');
    const userName = document.getElementById('user-name');
    
    if (userInfo && userName && this.currentUser) {
      userName.textContent = this.currentUser.name;
      userInfo.style.display = 'flex';
    }
  }
  
  /**
   * Configurar progressive loader
   */
  setupProgressiveLoader() {
    this.progressiveLoader = new ProgressiveLoader();
    
    // Registrar fases de carregamento
    this.progressiveLoader.registerPhase('ui-basic', {
      name: 'Carregando interface...',
      weight: 1,
      timeout: 2000,
      loader: () => this.loadBasicUI()
    });
    
    this.progressiveLoader.registerPhase('error-manager', {
      name: 'Configurando sistema de erros...',
      weight: 1,
      timeout: 3000,
      dependencies: ['ui-basic'],
      loader: () => this.initializeErrorManager()
    });
    
    this.progressiveLoader.registerPhase('chart-js', {
      name: 'Carregando gráficos...',
      weight: 2,
      timeout: 10000,
      dependencies: ['error-manager'],
      loader: () => this.loadChartJS()
    });
    
    this.progressiveLoader.registerPhase('cache-system', {
      name: 'Configurando cache...',
      weight: 1,
      timeout: 3000,
      dependencies: ['error-manager'],
      loader: () => this.initializeCache()
    });
    
    this.progressiveLoader.registerPhase('services', {
      name: 'Configurando serviços...',
      weight: 2,
      timeout: 5000,
      dependencies: ['cache-system'],
      loader: () => this.initializeServices()
    });
    
    this.progressiveLoader.registerPhase('components', {
      name: 'Inicializando componentes...',
      weight: 2,
      timeout: 5000,
      dependencies: ['services', 'chart-js'],
      loader: () => this.initializeComponents()
    });
    
    this.progressiveLoader.registerPhase('market-data', {
      name: 'Carregando dados do mercado...',
      weight: 3,
      timeout: 8000,
      dependencies: ['services'],
      loader: () => this.loadMarketData()
    });
    
    this.progressiveLoader.registerPhase('featured-stocks', {
      name: 'Carregando ações em destaque...',
      weight: 2,
      timeout: 8000,
      dependencies: ['services'],
      critical: false,
      loader: () => this.loadFeaturedStocks()
    });
  }
  
  /**
   * Carregar UI básica
   */
  async loadBasicUI() {
    // UI básica já está carregada no HTML
    console.log('[QuantumApp] Basic UI loaded');
    return true;
  }
  
  /**
   * Inicializar error manager
   */
  async initializeErrorManager() {
    // Error manager já foi inicializado no constructor
    console.log('[QuantumApp] Error manager initialized');
    return true;
  }
  
  /**
   * Carregar Chart.js
   */
  async loadChartJS() {
    try {
      const Chart = await ChartLoader.ensureChartJS();
      ChartLoader.setupDefaults();
      console.log('[QuantumApp] Chart.js loaded and configured');
      return Chart;
    } catch (error) {
      console.error('[QuantumApp] Failed to load Chart.js:', error);
      throw error;
    }
  }
  
  /**
   * Inicializar sistema de cache
   */
  async initializeCache() {
    try {
      this.cache = new IntelligentCacheManager();
      console.log('[QuantumApp] Intelligent cache system initialized');
      return this.cache;
    } catch (error) {
      console.error('[QuantumApp] Failed to initialize cache:', error);
      throw error;
    }
  }
  
  /**
   * Inicializar serviços
   */
  async initializeServices() {
    try {
      // Inicializar serviço de dados financeiros moderno (usando backend)
      this.financialService = window.modernFinancialService;
      
      console.log('[QuantumApp] Modern financial services initialized');
      return this.financialService;
    } catch (error) {
      console.error('[QuantumApp] Failed to initialize services:', error);
      throw error;
    }
  }
  
  /**
   * Inicializar componentes
   */
  async initializeComponents() {
    try {
      const componentConfigs = [
        { name: 'marketOverview', selector: '#market-overview', class: MarketOverviewComponent },
        { name: 'stockSearch', selector: '#stock-search', class: StockSearchComponent },
        { name: 'stockChart', selector: '#stock-chart', class: StockChartComponent },
        { name: 'systemMetrics', selector: '#system-metrics', class: SystemMetricsComponent }
      ];
      
      for (const config of componentConfigs) {
        try {
          const element = document.querySelector(config.selector);
          if (element && config.class) {
            const component = new config.class(element);
            component.financialService = this.financialService;
            component.cache = this.cache;
            component.errorManager = this.errorManager;
            
            // Inicializar componente se tiver método init
            if (typeof component.init === 'function') {
              await component.init();
            }
            
            this.components.set(config.name, component);
            console.log(`[QuantumApp] Component ${config.name} initialized`);
          }
        } catch (error) {
          console.warn(`[QuantumApp] Failed to initialize component ${config.name}:`, error);
          this.errorManager.handleError(error, `component-init-${config.name}`);
        }
      }
      
      console.log('[QuantumApp] All components initialized');
      return true;
    } catch (error) {
      console.error('[QuantumApp] Failed to initialize components:', error);
      throw error;
    }
  }
  
  /**
   * Carregar dados do mercado
   */
  async loadMarketData() {
    try {
      const marketOverview = this.components.get('marketOverview');
      if (marketOverview) {
        await marketOverview.loadData();
        console.log('[QuantumApp] Market data loaded');
      }
      return true;
    } catch (error) {
      console.error('[QuantumApp] Failed to load market data:', error);
      this.errorManager.handleError(error, 'market-data-load');
      return false; // Não crítico
    }
  }
  
  /**
   * Carregar ações em destaque
   */
  async loadFeaturedStocks() {
    try {
      const featuredSymbols = ['PETR4.SA', 'VALE3.SA', 'ITUB4.SA', 'BBDC4.SA'];
      const stocksData = await this.financialService.getMultipleStocks(featuredSymbols);
      
      // Atualizar componentes com dados das ações
      this.updateFeaturedStocksDisplay(stocksData);
      
      console.log('[QuantumApp] Featured stocks loaded');
      return stocksData;
    } catch (error) {
      console.warn('[QuantumApp] Failed to load featured stocks:', error);
      this.errorManager.handleError(error, 'featured-stocks-load');
      return null; // Não crítico
    }
  }
  
  /**
   * Atualizar exibição de ações em destaque
   */
  updateFeaturedStocksDisplay(stocksData) {
    const container = document.querySelector('.quantum-featured-stocks');
    if (!container || !stocksData) return;
    
    container.innerHTML = stocksData.map(stock => `
      <div class="quantum-stock-card" data-symbol="${stock.symbol}">
        <div class="quantum-stock-symbol">${stock.symbol}</div>
        <div class="quantum-stock-price">R$ ${stock.price?.toFixed(2) || 'N/A'}</div>
        <div class="quantum-stock-change ${(stock.changePercent || 0) >= 0 ? 'positive' : 'negative'}">
          ${(stock.changePercent || 0) >= 0 ? '+' : ''}${stock.changePercent?.toFixed(2) || '0.00'}%
        </div>
      </div>
    `).join('');
  }
  
  /**
   * Mostrar UI de fallback em caso de erro crítico
   */
  showFallbackUI() {
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) {
      loadingScreen.innerHTML = `
        <div class="quantum-fallback-ui">
          <div class="quantum-logo">
            <img src="src/assets/logo_quantum_oficial.png" alt="Quantum Finance" />
          </div>
          <h2>Quantum Finance</h2>
          <p>Ocorreu um problema ao carregar a aplicação.</p>
          <button onclick="window.location.reload()" class="quantum-button">
            Recarregar Página
          </button>
        </div>
      `;
    }
  }
  
  /**
   * Configurar event listeners globais
   */
  setupEventListeners() {
    // Listener para retry de operações
    window.addEventListener('quantum-retry', (event) => {
      const { errorInfo, attempt } = event.detail;
      console.log(`[QuantumApp] Retrying operation for error: ${errorInfo.type}`);
      
      // Implementar lógica de retry específica baseada no tipo de erro
      this.handleRetryOperation(errorInfo, attempt);
    });
    
    // Listener para reload de gráficos
    window.addEventListener('quantum-reload-charts', () => {
      console.log('[QuantumApp] Reloading chart components');
      this.reloadChartComponents();
    });
    
    // Listener para reload de dados
    window.addEventListener('quantum-reload-data', () => {
      console.log('[QuantumApp] Reloading data');
      this.reloadData();
    });
    
    // Listener para mudanças de visibilidade da página
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && this.isInitialized) {
        this.handlePageVisible();
      }
    });
  }
  
  /**
   * Tratar retry de operação
   */
  async handleRetryOperation(errorInfo, attempt) {
    try {
      switch (errorInfo.type) {
        case 'NetworkError':
        case 'TimeoutError':
          await this.retryDataLoad();
          break;
        case 'ChartError':
          await this.reloadChartComponents();
          break;
        default:
          console.warn(`[QuantumApp] No retry handler for error type: ${errorInfo.type}`);
      }
    } catch (error) {
      console.error('[QuantumApp] Retry operation failed:', error);
    }
  }
  
  /**
   * Retry carregamento de dados
   */
  async retryDataLoad() {
    const marketOverview = this.components.get('marketOverview');
    if (marketOverview) {
      await marketOverview.loadData(true); // Force refresh
    }
  }
  
  /**
   * Recarregar componentes de gráfico
   */
  async reloadChartComponents() {
    const stockChart = this.components.get('stockChart');
    if (stockChart && typeof stockChart.init === 'function') {
      await stockChart.init();
    }
  }
  
  /**
   * Recarregar todos os dados
   */
  async reloadData() {
    if (this.cache) {
      this.cache.clear();
    }
    
    await this.loadMarketData();
    await this.loadFeaturedStocks();
  }
  
  /**
   * Tratar página ficando visível
   */
  handlePageVisible() {
    // Atualizar dados se a página ficou invisível por mais de 5 minutos
    const lastUpdate = localStorage.getItem('quantum_last_update');
    const now = Date.now();
    
    if (!lastUpdate || (now - parseInt(lastUpdate)) > 300000) { // 5 minutos
      console.log('[QuantumApp] Page visible after long absence, refreshing data');
      this.reloadData();
      localStorage.setItem('quantum_last_update', now.toString());
    }
  }
  
  /**
   * Obter estatísticas da aplicação
   */
  getAppStats() {
    return {
      initialized: this.isInitialized,
      components: Array.from(this.components.keys()),
      cacheStats: this.cache ? this.cache.getDetailedStats() : null,
      errorStats: this.errorManager ? this.errorManager.getErrorStats() : null,
      loadingStats: this.progressiveLoader ? this.progressiveLoader.getStats() : null
    };
  }
}

// Função global de logout
function logout() {
  if (window.authService) {
    authService.logout();
  } else {
    window.location.href = 'login.html';
  }
}

// Inicializar aplicação quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', async () => {
  try {
    window.app = new QuantumFinanceApp();
    window.app.setupEventListeners();
    await window.app.init();
  } catch (error) {
    console.error('[QuantumApp] Failed to start application:', error);
  }
});

