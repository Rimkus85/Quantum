/**
 * Script Principal do Portfólio - Quantum Finance
 */

document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticação
    if (!window.authService || !authService.isLoggedIn()) {
        window.location.href = 'login.html';
        return;
    }

    // Configurar interface do usuário
    setupUserInterface();
    
    // Carregar dados do portfólio
    loadPortfolioData();
    
    // Configurar event listeners
    setupEventListeners();
    
    // Ocultar loading screen
    setTimeout(() => {
        const loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) {
            loadingScreen.style.display = 'none';
        }
    }, 1000);
});

/**
 * Configura interface do usuário
 */
function setupUserInterface() {
    const currentUser = authService.getCurrentUser();
    const userInfo = document.getElementById('user-info');
    const userName = document.getElementById('user-name');
    
    if (userInfo && userName && currentUser) {
        userName.textContent = currentUser.name;
        userInfo.style.display = 'flex';
    }
}

/**
 * Carrega dados do portfólio
 */
function loadPortfolioData() {
    const portfolio = portfolioService.getPortfolio();
    
    // Atualizar métricas
    updatePortfolioMetrics(portfolio);
    
    // Atualizar lista de ativos
    updateAssetsList(portfolio.assets);
    
    // Atualizar transações
    updateTransactionsList(portfolio.transactions);
    
    // Carregar gráficos
    loadPortfolioCharts();
}

/**
 * Atualiza métricas do portfólio
 */
function updatePortfolioMetrics(portfolio) {
    // Valor total
    const totalValueElement = document.getElementById('total-value');
    if (totalValueElement) {
        totalValueElement.textContent = formatCurrency(portfolio.totalValue);
    }
    
    // Rentabilidade
    const totalReturnElement = document.getElementById('total-return');
    const returnPercentageElement = document.getElementById('return-percentage');
    if (totalReturnElement && returnPercentageElement) {
        totalReturnElement.textContent = formatCurrency(portfolio.totalReturn);
        returnPercentageElement.textContent = formatPercentage(portfolio.returnPercentage);
        returnPercentageElement.className = `metric-change ${getChangeClass(portfolio.returnPercentage)}`;
    }
    
    // Valor investido
    const investedAmountElement = document.getElementById('invested-amount');
    const investedCountElement = document.getElementById('invested-count');
    if (investedAmountElement && investedCountElement) {
        investedAmountElement.textContent = formatCurrency(portfolio.totalInvested);
        investedCountElement.textContent = `${portfolio.assets.length} ativos`;
    }
    
    // Dividend Yield médio
    const dividendYieldElement = document.getElementById('dividend-yield');
    const dividendAmountElement = document.getElementById('dividend-amount');
    if (dividendYieldElement && dividendAmountElement) {
        const avgDividendYield = portfolio.assets.reduce((sum, asset) => sum + (asset.dividendYield || 0), 0) / portfolio.assets.length;
        const monthlyDividends = portfolio.totalValue * (avgDividendYield / 100) / 12;
        
        dividendYieldElement.textContent = formatPercentage(avgDividendYield);
        dividendAmountElement.textContent = formatCurrency(monthlyDividends) + '/mês';
    }
    
    // Variação total
    const totalChangeElement = document.getElementById('total-change');
    if (totalChangeElement) {
        totalChangeElement.textContent = formatPercentage(portfolio.returnPercentage);
        totalChangeElement.className = `metric-change ${getChangeClass(portfolio.returnPercentage)}`;
    }
}

/**
 * Atualiza lista de ativos
 */
function updateAssetsList(assets) {
    // Tabela desktop
    const tableBody = document.getElementById('assets-table-body');
    if (tableBody) {
        tableBody.innerHTML = assets.map(asset => `
            <tr>
                <td>
                    <div>
                        <div class="asset-symbol">${asset.symbol}</div>
                        <div style="font-size: 0.75rem; color: var(--quantum-text-secondary);">${asset.name}</div>
                    </div>
                </td>
                <td>${asset.quantity}</td>
                <td>${formatCurrency(asset.averagePrice)}</td>
                <td>${formatCurrency(asset.currentPrice)}</td>
                <td>${formatCurrency(asset.totalValue)}</td>
                <td>
                    <span class="metric-change ${getChangeClass(asset.returnPercentage)}">
                        ${formatPercentage(asset.returnPercentage)}
                    </span>
                </td>
                <td>${formatPercentage((asset.totalValue / portfolioService.getPortfolio().totalValue) * 100)}</td>
                <td>
                    <div class="asset-actions">
                        <button class="asset-action-btn" onclick="editAsset(${asset.id})" title="Editar">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="asset-action-btn" onclick="removeAsset(${asset.id})" title="Remover">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    // Cards mobile
    const cardsContainer = document.getElementById('assets-cards');
    if (cardsContainer) {
        cardsContainer.innerHTML = assets.map(asset => `
            <div class="asset-card">
                <div class="asset-card-header">
                    <div class="asset-card-symbol">${asset.symbol}</div>
                    <div class="asset-card-change ${getChangeClass(asset.returnPercentage)}">
                        ${formatPercentage(asset.returnPercentage)}
                    </div>
                </div>
                <div class="asset-card-details">
                    <div class="asset-card-detail">
                        <span>Quantidade:</span>
                        <span>${asset.quantity}</span>
                    </div>
                    <div class="asset-card-detail">
                        <span>Preço Médio:</span>
                        <span>${formatCurrency(asset.averagePrice)}</span>
                    </div>
                    <div class="asset-card-detail">
                        <span>Preço Atual:</span>
                        <span>${formatCurrency(asset.currentPrice)}</span>
                    </div>
                    <div class="asset-card-detail">
                        <span>Valor Total:</span>
                        <span>${formatCurrency(asset.totalValue)}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }
}

/**
 * Atualiza lista de transações
 */
function updateTransactionsList(transactions) {
    const transactionsList = document.getElementById('transactions-list');
    if (transactionsList) {
        transactionsList.innerHTML = transactions.slice(0, 10).map(transaction => `
            <div class="transaction-item">
                <div class="transaction-info">
                    <div class="transaction-icon ${transaction.type}">
                        <i class="fas fa-${transaction.type === 'buy' ? 'plus' : 'minus'}"></i>
                    </div>
                    <div class="transaction-details">
                        <h4>${transaction.type === 'buy' ? 'Compra' : 'Venda'} - ${transaction.symbol}</h4>
                        <p>${transaction.quantity} unidades a ${formatCurrency(transaction.price)}</p>
                    </div>
                </div>
                <div class="transaction-amount">
                    <div class="amount">${formatCurrency(transaction.total)}</div>
                    <div class="date">${formatDate(transaction.date)}</div>
                </div>
            </div>
        `).join('');
    }
}

/**
 * Carrega gráficos do portfólio
 */
function loadPortfolioCharts() {
    // Gráfico de setores
    const sectorData = portfolioService.getSectorDiversification();
    createSectorChart(sectorData);
    
    // Gráfico de ativos
    const assetData = portfolioService.getAssetAllocation();
    createAssetChart(assetData);
}

/**
 * Cria gráfico de setores
 */
function createSectorChart(data) {
    const ctx = document.getElementById('sectorChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.map(item => item.sector),
            datasets: [{
                data: data.map(item => item.percentage),
                backgroundColor: [
                    '#FFD700',
                    '#FFF4A3',
                    '#E6C200',
                    '#B8860B',
                    '#DAA520',
                    '#F0E68C'
                ],
                borderWidth: 2,
                borderColor: '#1a1a2e'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        padding: 20
                    }
                }
            }
        }
    });
}

/**
 * Cria gráfico de ativos
 */
function createAssetChart(data) {
    const ctx = document.getElementById('assetChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: data.map(item => item.symbol),
            datasets: [{
                data: data.map(item => item.percentage),
                backgroundColor: [
                    '#FFD700',
                    '#FFF4A3',
                    '#E6C200',
                    '#B8860B',
                    '#DAA520',
                    '#F0E68C',
                    '#FFFF99',
                    '#FFFACD'
                ],
                borderWidth: 2,
                borderColor: '#1a1a2e'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        padding: 20
                    }
                }
            }
        }
    });
}

/**
 * Configura event listeners
 */
function setupEventListeners() {
    // Busca de ativos
    const assetSearch = document.getElementById('asset-search');
    if (assetSearch) {
        assetSearch.addEventListener('input', function() {
            const filteredAssets = portfolioService.searchAssets(this.value);
            updateAssetsList(filteredAssets);
        });
    }
    
    // Filtro de ativos
    const assetFilter = document.getElementById('asset-filter');
    if (assetFilter) {
        assetFilter.addEventListener('change', function() {
            const filteredAssets = portfolioService.filterAssets(this.value);
            updateAssetsList(filteredAssets);
        });
    }
    
    // Formulário de adicionar ativo
    const addAssetForm = document.getElementById('addAssetForm');
    if (addAssetForm) {
        addAssetForm.addEventListener('submit', handleAddAsset);
    }
}

/**
 * Manipula adição de ativo
 */
async function handleAddAsset(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const assetData = {
        symbol: formData.get('asset-symbol') || document.getElementById('asset-symbol').value,
        quantity: parseInt(formData.get('asset-quantity') || document.getElementById('asset-quantity').value),
        price: parseFloat(formData.get('asset-price') || document.getElementById('asset-price').value),
        date: formData.get('transaction-date') || document.getElementById('transaction-date').value
    };
    
    // Validar dados
    if (!assetData.symbol || !assetData.quantity || !assetData.price || !assetData.date) {
        toast.error('Preencha todos os campos obrigatórios');
        return;
    }
    
    // Mostrar loading
    const submitButton = event.target.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Adicionando...';
    submitButton.disabled = true;
    
    try {
        const result = await portfolioService.addAsset(assetData);
        
        if (result.success) {
            toast.success(result.message);
            closeModal('addAssetModal');
            loadPortfolioData();
            event.target.reset();
        } else {
            toast.error(result.message);
        }
    } catch (error) {
        toast.error('Erro ao adicionar ativo');
    } finally {
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    }
}

/**
 * Funções globais
 */

// Função de logout
function logout() {
    if (window.authService) {
        authService.logout();
    } else {
        window.location.href = 'login.html';
    }
}

// Atualizar portfólio
async function refreshPortfolio() {
    toast.info('Atualizando preços...');
    const result = await portfolioService.updatePrices();
    
    if (result.success) {
        toast.success(result.message);
        loadPortfolioData();
    } else {
        toast.error(result.message);
    }
}

// Abrir modal de adicionar ativo
function openAddAssetModal() {
    const modal = document.getElementById('addAssetModal');
    if (modal) {
        modal.classList.add('show');
        
        // Definir data padrão como hoje
        const dateInput = document.getElementById('transaction-date');
        if (dateInput) {
            dateInput.value = new Date().toISOString().split('T')[0];
        }
    }
}

// Fechar modal
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
    }
}

// Exportar portfólio
function exportPortfolio() {
    portfolioService.exportToCSV();
    toast.success('Portfólio exportado com sucesso!');
}

// Remover ativo
function removeAsset(assetId) {
    if (confirm('Tem certeza que deseja remover este ativo?')) {
        const result = portfolioService.removeAsset(assetId);
        
        if (result.success) {
            toast.success(result.message);
            loadPortfolioData();
        } else {
            toast.error(result.message);
        }
    }
}

// Funções de formatação
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function formatPercentage(value) {
    return (value >= 0 ? '+' : '') + value.toFixed(2) + '%';
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('pt-BR');
}

function getChangeClass(value) {
    if (value > 0) return 'positive';
    if (value < 0) return 'negative';
    return 'neutral';
}

// Fechar modais clicando fora
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('show');
    }
});

