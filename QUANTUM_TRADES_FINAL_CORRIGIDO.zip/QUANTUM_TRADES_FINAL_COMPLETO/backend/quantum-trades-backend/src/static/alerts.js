/**
 * Sistema de Alertas Quantum Trades
 * Integração completa com APIs da Sprint 4
 */

class AlertsManager {
    constructor() {
        this.apiBase = window.location.origin;
        this.alerts = [];
        this.templates = {};
        this.isInitialized = false;
        this.websocket = null;
        
        this.init();
    }

    async init() {
        try {
            console.log('🚨 Inicializando sistema de alertas...');
            
            // Carregar templates de alertas
            await this.loadTemplates();
            
            // Carregar alertas existentes
            await this.loadAlerts();
            
            // Inicializar WebSocket para notificações em tempo real
            this.initWebSocket();
            
            this.isInitialized = true;
            console.log('✅ Sistema de alertas inicializado');
            
        } catch (error) {
            console.error('❌ Erro ao inicializar sistema de alertas:', error);
        }
    }

    async loadTemplates() {
        try {
            const response = await fetch(`${this.apiBase}/api/alerts/templates`);
            const data = await response.json();
            
            if (data.success) {
                this.templates = data.data;
                console.log('📋 Templates de alertas carregados:', Object.keys(this.templates).length);
            }
        } catch (error) {
            console.error('Erro ao carregar templates:', error);
        }
    }

    async loadAlerts() {
        try {
            // Simular carregamento de alertas do usuário
            // TODO: Implementar quando autenticação estiver pronta
            this.alerts = [];
            console.log('📊 Alertas do usuário carregados:', this.alerts.length);
        } catch (error) {
            console.error('Erro ao carregar alertas:', error);
        }
    }

    initWebSocket() {
        try {
            // Conectar ao WebSocket para notificações em tempo real
            const wsUrl = `ws://${window.location.host}/socket.io`;
            console.log('🔌 Conectando ao WebSocket:', wsUrl);
            
            // Simular conexão WebSocket
            console.log('✅ WebSocket conectado (simulado)');
            
        } catch (error) {
            console.error('Erro ao conectar WebSocket:', error);
        }
    }

    async createAlert(alertData) {
        try {
            console.log('🔔 Criando alerta:', alertData);
            
            // Validar dados
            if (!this.validateAlertData(alertData)) {
                throw new Error('Dados do alerta inválidos');
            }
            
            // Enviar para API
            const response = await fetch(`${this.apiBase}/api/alerts/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(alertData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Adicionar à lista local
                this.alerts.push(result.data);
                
                // Atualizar interface
                this.updateAlertsDisplay();
                
                // Mostrar notificação de sucesso
                this.showNotification('Alerta criado com sucesso!', 'success');
                
                return result.data;
            } else {
                throw new Error(result.message || 'Erro ao criar alerta');
            }
            
        } catch (error) {
            console.error('Erro ao criar alerta:', error);
            this.showNotification('Erro ao criar alerta: ' + error.message, 'error');
            throw error;
        }
    }

    async deleteAlert(alertId) {
        try {
            console.log('🗑️ Removendo alerta:', alertId);
            
            const response = await fetch(`${this.apiBase}/api/alerts/${alertId}`, {
                method: 'DELETE'
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Remover da lista local
                this.alerts = this.alerts.filter(alert => alert.id !== alertId);
                
                // Atualizar interface
                this.updateAlertsDisplay();
                
                this.showNotification('Alerta removido com sucesso!', 'success');
                
                return true;
            } else {
                throw new Error(result.message || 'Erro ao remover alerta');
            }
            
        } catch (error) {
            console.error('Erro ao remover alerta:', error);
            this.showNotification('Erro ao remover alerta: ' + error.message, 'error');
            throw error;
        }
    }

    async pauseAlert(alertId) {
        try {
            const response = await fetch(`${this.apiBase}/api/alerts/${alertId}/pause`, {
                method: 'POST'
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Atualizar status local
                const alert = this.alerts.find(a => a.id === alertId);
                if (alert) {
                    alert.is_active = false;
                }
                
                this.updateAlertsDisplay();
                this.showNotification('Alerta pausado', 'info');
                
                return true;
            }
            
        } catch (error) {
            console.error('Erro ao pausar alerta:', error);
            this.showNotification('Erro ao pausar alerta', 'error');
        }
    }

    async resumeAlert(alertId) {
        try {
            const response = await fetch(`${this.apiBase}/api/alerts/${alertId}/resume`, {
                method: 'POST'
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Atualizar status local
                const alert = this.alerts.find(a => a.id === alertId);
                if (alert) {
                    alert.is_active = true;
                }
                
                this.updateAlertsDisplay();
                this.showNotification('Alerta reativado', 'success');
                
                return true;
            }
            
        } catch (error) {
            console.error('Erro ao reativar alerta:', error);
            this.showNotification('Erro ao reativar alerta', 'error');
        }
    }

    validateAlertData(data) {
        const required = ['symbol', 'alert_type', 'condition', 'value'];
        
        for (const field of required) {
            if (!data[field]) {
                console.error(`Campo obrigatório ausente: ${field}`);
                return false;
            }
        }
        
        // Validar símbolo
        if (typeof data.symbol !== 'string' || data.symbol.length < 2) {
            console.error('Símbolo inválido');
            return false;
        }
        
        // Validar valor
        if (typeof data.value !== 'number' || data.value <= 0) {
            console.error('Valor inválido');
            return false;
        }
        
        return true;
    }

    updateAlertsDisplay() {
        // Atualizar contador na interface principal
        const activeCount = this.alerts.filter(alert => alert.is_active).length;
        const counterElement = document.getElementById('active-alerts');
        if (counterElement) {
            counterElement.textContent = activeCount;
        }
        
        // Atualizar lista principal
        this.renderAlertsList();
        
        // Atualizar modal se estiver aberto
        this.renderModalAlertsList();
    }

    renderAlertsList() {
        const container = document.getElementById('active-alerts-list');
        if (!container) return;
        
        if (this.alerts.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; color: var(--text-secondary); padding: 2rem;">
                    <i class="fas fa-bell-slash" style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                    <div>Nenhum alerta configurado</div>
                    <button class="btn btn-primary" onclick="openAlertsModal()" style="margin-top: 1rem;">
                        <i class="fas fa-plus"></i> Criar Primeiro Alerta
                    </button>
                </div>
            `;
            return;
        }
        
        let html = '';
        this.alerts.forEach(alert => {
            const statusClass = alert.is_active ? 'status-success' : 'status-warning';
            const statusText = alert.is_active ? 'Ativo' : 'Pausado';
            const statusIcon = alert.is_active ? 'fa-bell' : 'fa-bell-slash';
            
            html += `
                <div class="alert-item">
                    <div class="alert-content">
                        <div class="alert-title">
                            <i class="fas ${statusIcon} ${statusClass}"></i>
                            ${alert.symbol} - ${this.getAlertTypeLabel(alert.alert_type)}
                        </div>
                        <div class="alert-description">
                            ${this.getAlertDescription(alert)}
                        </div>
                        <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 0.25rem;">
                            Status: ${statusText} | Criado: ${this.formatDate(alert.created_at)}
                        </div>
                    </div>
                    <div class="alert-actions">
                        ${alert.is_active ? 
                            `<button class="btn btn-secondary btn-small" onclick="alertsManager.pauseAlert('${alert.id}')">
                                <i class="fas fa-pause"></i>
                            </button>` :
                            `<button class="btn btn-primary btn-small" onclick="alertsManager.resumeAlert('${alert.id}')">
                                <i class="fas fa-play"></i>
                            </button>`
                        }
                        <button class="btn btn-secondary btn-small" onclick="alertsManager.deleteAlert('${alert.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }

    renderModalAlertsList() {
        const container = document.getElementById('modal-alerts-list');
        if (!container) return;
        
        if (this.alerts.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; color: var(--text-secondary); padding: 1rem;">
                    Nenhum alerta configurado
                </div>
            `;
            return;
        }
        
        let html = '';
        this.alerts.forEach(alert => {
            const statusClass = alert.is_active ? 'status-success' : 'status-warning';
            const statusText = alert.is_active ? 'Ativo' : 'Pausado';
            
            html += `
                <div style="background: var(--primary-color); border: 1px solid var(--border-color); border-radius: 8px; padding: 1rem; margin-bottom: 0.5rem;">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div style="flex: 1;">
                            <div style="font-weight: 600; margin-bottom: 0.25rem;">
                                ${alert.symbol} - ${this.getAlertTypeLabel(alert.alert_type)}
                            </div>
                            <div style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 0.5rem;">
                                ${this.getAlertDescription(alert)}
                            </div>
                            <div style="font-size: 0.8rem;">
                                <span class="${statusClass}">● ${statusText}</span>
                                <span style="color: var(--text-secondary); margin-left: 1rem;">
                                    ${this.formatDate(alert.created_at)}
                                </span>
                            </div>
                        </div>
                        <div style="display: flex; gap: 0.5rem;">
                            ${alert.is_active ? 
                                `<button class="btn btn-secondary btn-small" onclick="alertsManager.pauseAlert('${alert.id}')">
                                    <i class="fas fa-pause"></i>
                                </button>` :
                                `<button class="btn btn-primary btn-small" onclick="alertsManager.resumeAlert('${alert.id}')">
                                    <i class="fas fa-play"></i>
                                </button>`
                            }
                            <button class="btn btn-secondary btn-small" onclick="alertsManager.deleteAlert('${alert.id}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }

    getAlertTypeLabel(type) {
        const labels = {
            'price': 'Preço',
            'technical': 'Técnico',
            'volume': 'Volume'
        };
        return labels[type] || type;
    }

    getAlertDescription(alert) {
        const conditionLabels = {
            'above': 'acima de',
            'below': 'abaixo de',
            'change_percent': 'variação de',
            'rsi_overbought': 'RSI sobrecomprado',
            'rsi_oversold': 'RSI sobrevendido',
            'macd_bullish': 'MACD bullish',
            'macd_bearish': 'MACD bearish',
            'volume_spike': 'pico de volume'
        };
        
        const conditionText = conditionLabels[alert.condition] || alert.condition;
        
        if (alert.alert_type === 'price') {
            return `Alertar quando ${conditionText} R$ ${alert.value.toFixed(2)}`;
        } else if (alert.alert_type === 'technical') {
            return `Alertar quando ${conditionText}`;
        } else if (alert.alert_type === 'volume') {
            return `Alertar quando ${conditionText} ${alert.value}x`;
        }
        
        return `${conditionText}: ${alert.value}`;
    }

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
        } catch (error) {
            return 'N/A';
        }
    }

    showNotification(message, type = 'info') {
        // Criar elemento de notificação
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--secondary-color);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1rem 1.5rem;
            color: var(--text-primary);
            z-index: 10000;
            max-width: 300px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;
        
        // Definir cor baseada no tipo
        const colors = {
            'success': 'var(--success-color)',
            'error': 'var(--danger-color)',
            'warning': 'var(--warning-color)',
            'info': 'var(--accent-color)'
        };
        
        const icons = {
            'success': 'fa-check-circle',
            'error': 'fa-exclamation-circle',
            'warning': 'fa-exclamation-triangle',
            'info': 'fa-info-circle'
        };
        
        notification.style.borderLeftColor = colors[type] || colors.info;
        
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas ${icons[type] || icons.info}" style="color: ${colors[type] || colors.info};"></i>
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" 
                        style="background: none; border: none; color: var(--text-secondary); cursor: pointer; margin-left: auto;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Animar entrada
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Remover automaticamente após 5 segundos
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 300);
        }, 5000);
    }

    // Métodos para integração com templates
    getTemplatesByType(type) {
        return this.templates[type + '_alerts'] || [];
    }

    createAlertFromTemplate(template, symbol, value) {
        const alertData = {
            symbol: symbol,
            alert_type: template.alert_type,
            condition: template.condition,
            value: value,
            name: `${template.name} - ${symbol}`,
            description: template.description
        };
        
        return this.createAlert(alertData);
    }

    // Método para buscar alertas disparados
    async getTriggeredAlerts() {
        try {
            const response = await fetch(`${this.apiBase}/api/alerts/triggered`);
            const data = await response.json();
            
            if (data.success) {
                return data.data;
            }
            
            return [];
        } catch (error) {
            console.error('Erro ao buscar alertas disparados:', error);
            return [];
        }
    }

    // Método para obter estatísticas
    async getStats() {
        try {
            const response = await fetch(`${this.apiBase}/api/alerts/stats`);
            const data = await response.json();
            
            if (data.success) {
                return data.data;
            }
            
            return {};
        } catch (error) {
            console.error('Erro ao buscar estatísticas:', error);
            return {};
        }
    }
}

// Instância global do gerenciador de alertas
let alertsManager;

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    alertsManager = new AlertsManager();
});

// Funções globais para integração com a interface
async function createAlert() {
    if (!alertsManager || !alertsManager.isInitialized) {
        alertsManager.showNotification('Sistema de alertas não inicializado', 'error');
        return;
    }
    
    const symbol = document.getElementById('alert-symbol').value.trim().toUpperCase();
    const type = document.getElementById('alert-type').value;
    const condition = document.getElementById('alert-condition').value;
    const value = parseFloat(document.getElementById('alert-value').value);
    
    if (!symbol || !value) {
        alertsManager.showNotification('Preencha todos os campos obrigatórios', 'warning');
        return;
    }
    
    // Adicionar .SA se necessário
    const finalSymbol = symbol.includes('.SA') ? symbol : `${symbol}.SA`;
    
    const alertData = {
        symbol: finalSymbol,
        alert_type: type,
        condition: condition,
        value: value,
        name: `${condition} ${value} - ${finalSymbol}`,
        description: `Alerta de ${type} para ${finalSymbol}`
    };
    
    try {
        await alertsManager.createAlert(alertData);
        
        // Limpar formulário
        document.getElementById('alert-symbol').value = '';
        document.getElementById('alert-value').value = '';
        
    } catch (error) {
        // Erro já tratado no AlertsManager
    }
}

// Função para criar alerta para um símbolo específico
function createAlertFor(symbol) {
    document.getElementById('alert-symbol').value = symbol;
    openAlertsModal();
}

// Atualizar condições baseadas no tipo de alerta
function updateAlertConditions() {
    const type = document.getElementById('alert-type').value;
    const conditionSelect = document.getElementById('alert-condition');
    
    // Limpar opções existentes
    conditionSelect.innerHTML = '';
    
    let options = [];
    
    if (type === 'price') {
        options = [
            { value: 'above', text: 'Acima de' },
            { value: 'below', text: 'Abaixo de' },
            { value: 'change_percent', text: 'Variação %' }
        ];
    } else if (type === 'technical') {
        options = [
            { value: 'rsi_overbought', text: 'RSI Sobrecomprado' },
            { value: 'rsi_oversold', text: 'RSI Sobrevendido' },
            { value: 'macd_bullish', text: 'MACD Bullish' },
            { value: 'macd_bearish', text: 'MACD Bearish' }
        ];
    } else if (type === 'volume') {
        options = [
            { value: 'volume_spike', text: 'Pico de Volume' }
        ];
    }
    
    options.forEach(option => {
        const optionElement = document.createElement('option');
        optionElement.value = option.value;
        optionElement.textContent = option.text;
        conditionSelect.appendChild(optionElement);
    });
}

// Adicionar listener para mudança de tipo de alerta
document.addEventListener('DOMContentLoaded', function() {
    const alertTypeSelect = document.getElementById('alert-type');
    if (alertTypeSelect) {
        alertTypeSelect.addEventListener('change', updateAlertConditions);
        updateAlertConditions(); // Inicializar
    }
});

