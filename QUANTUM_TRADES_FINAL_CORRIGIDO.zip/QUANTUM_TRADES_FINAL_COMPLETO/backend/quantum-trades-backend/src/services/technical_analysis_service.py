import logging
from typing import Dict, List, Optional, Union, Any
from datetime import datetime, timedelta
import json
from src.services.technical_indicators import TechnicalIndicators, IndicatorAnalyzer, IndicatorResult, IndicatorType
from src.services.predictive_cache_service import predictive_cache_service

logger = logging.getLogger(__name__)

class TechnicalAnalysisService:
    """Serviço de análise técnica integrado com cache e dados de mercado"""
    
    def __init__(self, cache_service=None):
        self.cache_service = cache_service or predictive_cache_service
        self.indicators = TechnicalIndicators()
        self.analyzer = IndicatorAnalyzer()
        
        # Configurações padrão de indicadores
        self.default_configs = {
            'sma_short': {'period': 20},
            'sma_long': {'period': 50},
            'ema_fast': {'period': 12},
            'ema_slow': {'period': 26},
            'rsi': {'period': 14},
            'macd': {'fast_period': 12, 'slow_period': 26, 'signal_period': 9},
            'bollinger': {'period': 20, 'std_dev': 2.0},
            'stochastic': {'k_period': 14, 'd_period': 3},
            'williams_r': {'period': 14}
        }
        
        # Presets de estratégias
        self.strategy_presets = {
            'day_trading': {
                'indicators': ['ema_fast', 'rsi', 'stochastic', 'bollinger'],
                'timeframe': '5m',
                'description': 'Estratégia para day trading com indicadores rápidos'
            },
            'swing_trading': {
                'indicators': ['sma_short', 'sma_long', 'rsi', 'macd'],
                'timeframe': '1h',
                'description': 'Estratégia para swing trading com médias móveis'
            },
            'long_term': {
                'indicators': ['sma_long', 'macd', 'bollinger'],
                'timeframe': '1d',
                'description': 'Estratégia para investimento de longo prazo'
            },
            'momentum': {
                'indicators': ['rsi', 'macd', 'stochastic', 'williams_r'],
                'timeframe': '15m',
                'description': 'Estratégia focada em momentum'
            },
            'trend_following': {
                'indicators': ['sma_short', 'sma_long', 'ema_fast', 'ema_slow'],
                'timeframe': '1h',
                'description': 'Estratégia de seguimento de tendência'
            }
        }
    
    def calculate_indicators(self, symbol: str, price_data: Dict[str, List[float]], 
                           indicators_config: Optional[Dict] = None) -> Dict[str, Any]:
        """Calcula indicadores técnicos para um símbolo"""
        if not price_data or 'close' not in price_data:
            raise ValueError("Dados de preço são obrigatórios (pelo menos 'close')")
        
        config = indicators_config or self.default_configs
        results = {}
        
        closes = price_data['close']
        highs = price_data.get('high', closes)
        lows = price_data.get('low', closes)
        volumes = price_data.get('volume', [])
        
        try:
            # Médias móveis
            if 'sma_short' in config:
                results['sma_short'] = self.indicators.sma(closes, config['sma_short']['period'])
            
            if 'sma_long' in config:
                results['sma_long'] = self.indicators.sma(closes, config['sma_long']['period'])
            
            if 'ema_fast' in config:
                results['ema_fast'] = self.indicators.ema(closes, config['ema_fast']['period'])
            
            if 'ema_slow' in config:
                results['ema_slow'] = self.indicators.ema(closes, config['ema_slow']['period'])
            
            # Indicadores de momentum
            if 'rsi' in config:
                results['rsi'] = self.indicators.rsi(closes, config['rsi']['period'])
            
            if 'macd' in config:
                macd_config = config['macd']
                results['macd'] = self.indicators.macd(
                    closes, 
                    macd_config['fast_period'], 
                    macd_config['slow_period'], 
                    macd_config['signal_period']
                )
            
            # Indicadores de volatilidade
            if 'bollinger' in config:
                bb_config = config['bollinger']
                results['bollinger'] = self.indicators.bollinger_bands(
                    closes, 
                    bb_config['period'], 
                    bb_config['std_dev']
                )
            
            # Osciladores
            if 'stochastic' in config:
                stoch_config = config['stochastic']
                results['stochastic'] = self.indicators.stochastic(
                    highs, lows, closes,
                    stoch_config['k_period'],
                    stoch_config['d_period']
                )
            
            if 'williams_r' in config:
                results['williams_r'] = self.indicators.williams_r(
                    highs, lows, closes,
                    config['williams_r']['period']
                )
            
            # Cache dos resultados
            cache_key = f"indicators:{symbol}:{hash(str(config))}"
            self.cache_service.set_smart(cache_key, results, 'indicators')
            
            logger.info(f"Indicadores calculados para {symbol}: {list(results.keys())}")
            
        except Exception as e:
            logger.error(f"Erro ao calcular indicadores para {symbol}: {e}")
            raise
        
        return results
    
    def analyze_symbol(self, symbol: str, price_data: Dict[str, List[float]], 
                      strategy: str = 'swing_trading') -> Dict[str, Any]:
        """Análise técnica completa de um símbolo"""
        if strategy not in self.strategy_presets:
            raise ValueError(f"Estratégia '{strategy}' não encontrada")
        
        preset = self.strategy_presets[strategy]
        
        # Configurar indicadores baseado na estratégia
        indicators_config = {}
        for indicator_name in preset['indicators']:
            if indicator_name in self.default_configs:
                indicators_config[indicator_name] = self.default_configs[indicator_name]
        
        # Calcular indicadores
        indicators = self.calculate_indicators(symbol, price_data, indicators_config)
        
        # Análise de tendência
        trend_analysis = {}
        if 'sma_short' in indicators and 'sma_long' in indicators:
            trend_analysis = self.analyzer.analyze_trend(
                indicators['sma_short'], 
                indicators['sma_long']
            )
        
        # Análise de momentum
        momentum_analysis = {}
        if 'rsi' in indicators and 'macd' in indicators:
            momentum_analysis = self.analyzer.analyze_momentum(
                indicators['rsi'], 
                indicators['macd']
            )
        
        # Gerar sinais de trading
        trading_signals = self.analyzer.generate_trading_signals(indicators)
        
        # Análise de suporte e resistência
        support_resistance = self._analyze_support_resistance(price_data['close'])
        
        # Compilar análise completa
        analysis = {
            'symbol': symbol,
            'strategy': strategy,
            'timestamp': datetime.now().isoformat(),
            'indicators': self._serialize_indicators(indicators),
            'trend_analysis': trend_analysis,
            'momentum_analysis': momentum_analysis,
            'trading_signals': trading_signals,
            'support_resistance': support_resistance,
            'market_conditions': self._assess_market_conditions(indicators),
            'risk_assessment': self._assess_risk(indicators, price_data),
            'recommendations': self._generate_recommendations(trading_signals, trend_analysis, momentum_analysis)
        }
        
        # Cache da análise
        cache_key = f"analysis:{symbol}:{strategy}"
        self.cache_service.set_smart(cache_key, analysis, 'analysis')
        
        return analysis
    
    def _serialize_indicators(self, indicators: Dict[str, Any]) -> Dict[str, Any]:
        """Serializa indicadores para JSON"""
        serialized = {}
        
        for name, indicator in indicators.items():
            if isinstance(indicator, IndicatorResult):
                serialized[name] = {
                    'name': indicator.name,
                    'type': indicator.type.value,
                    'values': indicator.values[-50:],  # Últimos 50 valores
                    'latest_value': indicator.values[-1] if indicator.values else None,
                    'latest_signal': indicator.signals[-1] if indicator.signals else None,
                    'metadata': indicator.metadata
                }
            elif isinstance(indicator, dict):
                # Para indicadores compostos como MACD
                serialized[name] = {}
                for sub_name, sub_indicator in indicator.items():
                    if isinstance(sub_indicator, IndicatorResult):
                        serialized[name][sub_name] = {
                            'name': sub_indicator.name,
                            'type': sub_indicator.type.value,
                            'values': sub_indicator.values[-50:],
                            'latest_value': sub_indicator.values[-1] if sub_indicator.values else None,
                            'latest_signal': sub_indicator.signals[-1] if sub_indicator.signals else None,
                            'metadata': sub_indicator.metadata
                        }
        
        return serialized
    
    def _analyze_support_resistance(self, prices: List[float]) -> Dict[str, Any]:
        """Identifica níveis de suporte e resistência"""
        if len(prices) < 20:
            return {'support_levels': [], 'resistance_levels': []}
        
        # Usar últimos 100 preços para análise
        recent_prices = prices[-100:]
        
        # Encontrar máximos e mínimos locais
        highs = []
        lows = []
        
        for i in range(2, len(recent_prices) - 2):
            # Máximo local
            if (recent_prices[i] > recent_prices[i-1] and 
                recent_prices[i] > recent_prices[i-2] and
                recent_prices[i] > recent_prices[i+1] and 
                recent_prices[i] > recent_prices[i+2]):
                highs.append(recent_prices[i])
            
            # Mínimo local
            if (recent_prices[i] < recent_prices[i-1] and 
                recent_prices[i] < recent_prices[i-2] and
                recent_prices[i] < recent_prices[i+1] and 
                recent_prices[i] < recent_prices[i+2]):
                lows.append(recent_prices[i])
        
        # Agrupar níveis próximos
        resistance_levels = self._cluster_levels(highs)
        support_levels = self._cluster_levels(lows)
        
        current_price = prices[-1]
        
        return {
            'support_levels': sorted(support_levels, reverse=True),
            'resistance_levels': sorted(resistance_levels),
            'nearest_support': max([s for s in support_levels if s < current_price], default=None),
            'nearest_resistance': min([r for r in resistance_levels if r > current_price], default=None),
            'current_price': current_price
        }
    
    def _cluster_levels(self, levels: List[float], tolerance: float = 0.02) -> List[float]:
        """Agrupa níveis próximos em clusters"""
        if not levels:
            return []
        
        sorted_levels = sorted(levels)
        clusters = []
        current_cluster = [sorted_levels[0]]
        
        for level in sorted_levels[1:]:
            if abs(level - current_cluster[-1]) / current_cluster[-1] <= tolerance:
                current_cluster.append(level)
            else:
                # Finalizar cluster atual e começar novo
                clusters.append(sum(current_cluster) / len(current_cluster))
                current_cluster = [level]
        
        # Adicionar último cluster
        if current_cluster:
            clusters.append(sum(current_cluster) / len(current_cluster))
        
        return clusters
    
    def _assess_market_conditions(self, indicators: Dict[str, Any]) -> Dict[str, str]:
        """Avalia condições gerais do mercado"""
        conditions = {
            'volatility': 'normal',
            'trend_strength': 'moderate',
            'market_phase': 'consolidation'
        }
        
        # Avaliar volatilidade usando Bollinger Bands
        if 'bollinger' in indicators:
            bb = indicators['bollinger']
            if 'upper_band' in bb and 'lower_band' in bb:
                upper_values = bb['upper_band'].values
                lower_values = bb['lower_band'].values
                
                if upper_values and lower_values:
                    latest_width = upper_values[-1] - lower_values[-1]
                    if len(upper_values) >= 20:
                        avg_width = sum(upper_values[i] - lower_values[i] for i in range(-20, 0)) / 20
                        
                        if latest_width > avg_width * 1.5:
                            conditions['volatility'] = 'high'
                        elif latest_width < avg_width * 0.7:
                            conditions['volatility'] = 'low'
        
        # Avaliar força da tendência
        if 'sma_short' in indicators and 'sma_long' in indicators:
            sma_short = indicators['sma_short'].values
            sma_long = indicators['sma_long'].values
            
            if sma_short and sma_long and len(sma_short) >= 10:
                short_slope = (sma_short[-1] - sma_short[-10]) / 9
                long_slope = (sma_long[-1] - sma_long[-10]) / 9
                
                if abs(short_slope) > abs(long_slope) * 2:
                    conditions['trend_strength'] = 'strong'
                elif abs(short_slope) < abs(long_slope) * 0.5:
                    conditions['trend_strength'] = 'weak'
        
        return conditions
    
    def _assess_risk(self, indicators: Dict[str, Any], price_data: Dict[str, List[float]]) -> Dict[str, Any]:
        """Avalia risco baseado em indicadores"""
        risk_assessment = {
            'risk_level': 'medium',
            'volatility_risk': 'medium',
            'trend_risk': 'medium',
            'momentum_risk': 'medium'
        }
        
        # Calcular volatilidade histórica
        closes = price_data['close']
        if len(closes) >= 20:
            returns = [(closes[i] - closes[i-1]) / closes[i-1] for i in range(1, len(closes))]
            volatility = (sum(r**2 for r in returns[-20:]) / 20) ** 0.5
            
            if volatility > 0.03:  # 3% diário
                risk_assessment['volatility_risk'] = 'high'
            elif volatility < 0.01:  # 1% diário
                risk_assessment['volatility_risk'] = 'low'
        
        # Avaliar risco de momentum
        if 'rsi' in indicators:
            rsi_values = indicators['rsi'].values
            if rsi_values:
                latest_rsi = rsi_values[-1]
                if latest_rsi > 80 or latest_rsi < 20:
                    risk_assessment['momentum_risk'] = 'high'
                elif 40 <= latest_rsi <= 60:
                    risk_assessment['momentum_risk'] = 'low'
        
        # Risco geral
        risk_factors = [
            risk_assessment['volatility_risk'],
            risk_assessment['trend_risk'],
            risk_assessment['momentum_risk']
        ]
        
        high_risk_count = risk_factors.count('high')
        low_risk_count = risk_factors.count('low')
        
        if high_risk_count >= 2:
            risk_assessment['risk_level'] = 'high'
        elif low_risk_count >= 2:
            risk_assessment['risk_level'] = 'low'
        
        return risk_assessment
    
    def _generate_recommendations(self, trading_signals: Dict, trend_analysis: Dict, 
                                momentum_analysis: Dict) -> List[str]:
        """Gera recomendações baseadas na análise"""
        recommendations = []
        
        # Recomendações baseadas em sinais de trading
        if trading_signals['action'] == 'buy':
            recommendations.append(f"Sinal de COMPRA com confiança {trading_signals['confidence']}")
        elif trading_signals['action'] == 'sell':
            recommendations.append(f"Sinal de VENDA com confiança {trading_signals['confidence']}")
        else:
            recommendations.append("Manter posição atual (HOLD)")
        
        # Recomendações baseadas em tendência
        if trend_analysis.get('trend') == 'bullish':
            if trend_analysis.get('strength') == 'strong':
                recommendations.append("Tendência de alta forte - considere posições longas")
            else:
                recommendations.append("Tendência de alta moderada - aguarde confirmação")
        elif trend_analysis.get('trend') == 'bearish':
            if trend_analysis.get('strength') == 'strong':
                recommendations.append("Tendência de baixa forte - considere posições curtas")
            else:
                recommendations.append("Tendência de baixa moderada - aguarde confirmação")
        
        # Recomendações baseadas em momentum
        if momentum_analysis.get('momentum') == 'bullish':
            recommendations.append("Momentum positivo - favorável para compras")
        elif momentum_analysis.get('momentum') == 'bearish':
            recommendations.append("Momentum negativo - favorável para vendas")
        
        return recommendations
    
    def get_strategy_presets(self) -> Dict[str, Dict]:
        """Retorna presets de estratégias disponíveis"""
        return self.strategy_presets
    
    def create_custom_strategy(self, name: str, indicators: List[str], 
                             timeframe: str, description: str) -> bool:
        """Cria estratégia customizada"""
        # Validar indicadores
        valid_indicators = set(self.default_configs.keys())
        if not all(indicator in valid_indicators for indicator in indicators):
            return False
        
        self.strategy_presets[name] = {
            'indicators': indicators,
            'timeframe': timeframe,
            'description': description,
            'custom': True
        }
        
        return True
    
    def backtest_strategy(self, symbol: str, price_data: Dict[str, List[float]], 
                         strategy: str, initial_capital: float = 10000) -> Dict[str, Any]:
        """Backtesting básico de estratégia"""
        if len(price_data['close']) < 20:  # Reduzido de 50 para 20
            raise ValueError("Dados insuficientes para backtesting (mínimo 20 pontos)")
        
        results = {
            'symbol': symbol,
            'strategy': strategy,
            'initial_capital': initial_capital,
            'final_capital': initial_capital,
            'total_return': 0,
            'total_trades': 0,
            'winning_trades': 0,
            'losing_trades': 0,
            'max_drawdown': 0,
            'sharpe_ratio': 0,
            'trades': []
        }
        
        # Simular trading baseado na estratégia
        capital = initial_capital
        position = 0  # 0 = sem posição, 1 = comprado, -1 = vendido
        entry_price = 0
        max_capital = initial_capital
        
        # Calcular indicadores para todo o período
        indicators = self.calculate_indicators(symbol, price_data, 
                                             {ind: self.default_configs[ind] 
                                              for ind in self.strategy_presets[strategy]['indicators']
                                              if ind in self.default_configs})
        
        # Simular trades (começar após período de aquecimento menor)
        start_index = max(15, len(price_data['close']) // 4)  # Usar 1/4 dos dados para aquecimento
        
        for i in range(start_index, len(price_data['close'])):
            current_price = price_data['close'][i]
            
            # Gerar sinal para o ponto atual
            current_data = {
                'close': price_data['close'][:i+1],
                'high': price_data.get('high', price_data['close'])[:i+1],
                'low': price_data.get('low', price_data['close'])[:i+1]
            }
            
            try:
                analysis = self.analyze_symbol(symbol, current_data, strategy)
                signal = analysis['trading_signals']['action']
                
                # Executar trades baseado no sinal
                if signal == 'buy' and position <= 0:
                    if position == -1:  # Fechar posição vendida
                        profit = (entry_price - current_price) * abs(position)
                        capital += profit
                        results['trades'].append({
                            'type': 'cover',
                            'price': current_price,
                            'profit': profit,
                            'timestamp': i
                        })
                    
                    # Abrir posição comprada
                    position = capital / current_price
                    entry_price = current_price
                    capital = 0
                    results['total_trades'] += 1
                    
                elif signal == 'sell' and position >= 0:
                    if position > 0:  # Fechar posição comprada
                        profit = (current_price - entry_price) * position
                        capital += current_price * position
                        results['trades'].append({
                            'type': 'sell',
                            'price': current_price,
                            'profit': profit,
                            'timestamp': i
                        })
                        
                        if profit > 0:
                            results['winning_trades'] += 1
                        else:
                            results['losing_trades'] += 1
                    
                    position = 0
                
                # Calcular capital atual
                current_capital = capital + (position * current_price if position > 0 else capital)
                max_capital = max(max_capital, current_capital)
                
                # Calcular drawdown
                drawdown = (max_capital - current_capital) / max_capital
                results['max_drawdown'] = max(results['max_drawdown'], drawdown)
                
            except Exception as e:
                logger.warning(f"Erro no backtesting no ponto {i}: {e}")
                continue
        
        # Fechar posição final se necessário
        final_price = price_data['close'][-1]
        if position > 0:
            capital += position * final_price
            profit = (final_price - entry_price) * position
            results['trades'].append({
                'type': 'final_sell',
                'price': final_price,
                'profit': profit,
                'timestamp': len(price_data['close']) - 1
            })
        
        results['final_capital'] = capital
        results['total_return'] = (capital - initial_capital) / initial_capital * 100
        
        # Calcular Sharpe ratio básico
        if results['trades']:
            returns = [trade['profit'] / initial_capital for trade in results['trades']]
            if len(returns) > 1:
                avg_return = sum(returns) / len(returns)
                std_return = (sum((r - avg_return)**2 for r in returns) / (len(returns) - 1))**0.5
                results['sharpe_ratio'] = avg_return / std_return if std_return > 0 else 0
        
        return results

