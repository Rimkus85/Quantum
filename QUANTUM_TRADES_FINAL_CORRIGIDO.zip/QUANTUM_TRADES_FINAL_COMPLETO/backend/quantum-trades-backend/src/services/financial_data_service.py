import requests
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import time
import logging

logger = logging.getLogger(__name__)

class FinancialDataService:
    """Serviço para integração com APIs financeiras"""
    
    def __init__(self, cache_service=None):
        self.cache_service = cache_service
        self.yahoo_base_url = "https://query1.finance.yahoo.com/v8/finance/chart/"
        self.alpha_vantage_base_url = "https://www.alphavantage.co/query"
        self.alpha_vantage_api_key = "demo"  # Usar variável de ambiente em produção
        
        # Rate limiting
        self.last_yahoo_request = 0
        self.last_alpha_vantage_request = 0
        self.yahoo_rate_limit = 0.1  # 100ms entre requests
        self.alpha_vantage_rate_limit = 12  # 12 segundos entre requests (5 por minuto)
    
    def _rate_limit_yahoo(self):
        """Aplica rate limiting para Yahoo Finance"""
        now = time.time()
        time_since_last = now - self.last_yahoo_request
        if time_since_last < self.yahoo_rate_limit:
            time.sleep(self.yahoo_rate_limit - time_since_last)
        self.last_yahoo_request = time.time()
    
    def _rate_limit_alpha_vantage(self):
        """Aplica rate limiting para Alpha Vantage"""
        now = time.time()
        time_since_last = now - self.last_alpha_vantage_request
        if time_since_last < self.alpha_vantage_rate_limit:
            time.sleep(self.alpha_vantage_rate_limit - time_since_last)
        self.last_alpha_vantage_request = time.time()
    
    def get_stock_quote(self, symbol: str) -> Optional[Dict]:
        """Obtém cotação atual de uma ação"""
        cache_key = f"quote:{symbol}"
        
        # Tentar cache primeiro
        if self.cache_service:
            cached_data = self.cache_service.get(cache_key)
            if cached_data:
                return cached_data
        
        # Tentar Yahoo Finance primeiro
        quote_data = self._get_yahoo_quote(symbol)
        
        # Fallback para Alpha Vantage se Yahoo falhar
        if not quote_data:
            quote_data = self._get_alpha_vantage_quote(symbol)
        
        # Cache o resultado se obtido com sucesso
        if quote_data and self.cache_service:
            self.cache_service.set(cache_key, quote_data, timeout=60)  # Cache por 1 minuto
        
        return quote_data
    
    def _get_yahoo_quote(self, symbol: str) -> Optional[Dict]:
        """Obtém cotação do Yahoo Finance"""
        try:
            self._rate_limit_yahoo()
            
            url = f"{self.yahoo_base_url}{symbol}"
            params = {
                'interval': '1d',
                'range': '1d',
                'includePrePost': 'true'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if 'chart' not in data or not data['chart']['result']:
                return None
            
            result = data['chart']['result'][0]
            meta = result['meta']
            
            # Dados da última cotação
            current_price = meta.get('regularMarketPrice', 0)
            previous_close = meta.get('previousClose', 0)
            change = current_price - previous_close if current_price and previous_close else 0
            change_percent = (change / previous_close * 100) if previous_close else 0
            
            return {
                'symbol': symbol,
                'price': current_price,
                'previous_close': previous_close,
                'change': change,
                'change_percent': change_percent,
                'volume': meta.get('regularMarketVolume', 0),
                'market_cap': meta.get('marketCap'),
                'currency': meta.get('currency', 'USD'),
                'exchange': meta.get('exchangeName'),
                'timestamp': datetime.now().isoformat(),
                'source': 'yahoo'
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter cotação do Yahoo Finance para {symbol}: {e}")
            return None
    
    def _get_alpha_vantage_quote(self, symbol: str) -> Optional[Dict]:
        """Obtém cotação do Alpha Vantage"""
        try:
            self._rate_limit_alpha_vantage()
            
            params = {
                'function': 'GLOBAL_QUOTE',
                'symbol': symbol,
                'apikey': self.alpha_vantage_api_key
            }
            
            response = requests.get(self.alpha_vantage_base_url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if 'Global Quote' not in data:
                return None
            
            quote = data['Global Quote']
            
            current_price = float(quote.get('05. price', 0))
            previous_close = float(quote.get('08. previous close', 0))
            change = float(quote.get('09. change', 0))
            change_percent = float(quote.get('10. change percent', '0%').replace('%', ''))
            
            return {
                'symbol': symbol,
                'price': current_price,
                'previous_close': previous_close,
                'change': change,
                'change_percent': change_percent,
                'volume': int(quote.get('06. volume', 0)),
                'high': float(quote.get('03. high', 0)),
                'low': float(quote.get('04. low', 0)),
                'open': float(quote.get('02. open', 0)),
                'timestamp': datetime.now().isoformat(),
                'source': 'alpha_vantage'
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter cotação do Alpha Vantage para {symbol}: {e}")
            return None
    
    def get_historical_data(self, symbol: str, period: str = '1y') -> Optional[Dict]:
        """Obtém dados históricos de uma ação"""
        cache_key = f"historical:{symbol}:{period}"
        
        # Tentar cache primeiro (cache mais longo para dados históricos)
        if self.cache_service:
            cached_data = self.cache_service.get(cache_key)
            if cached_data:
                return cached_data
        
        # Tentar Yahoo Finance
        historical_data = self._get_yahoo_historical(symbol, period)
        
        # Cache o resultado se obtido com sucesso
        if historical_data and self.cache_service:
            # Cache por 1 hora para dados históricos
            self.cache_service.set(cache_key, historical_data, timeout=3600)
        
        return historical_data
    
    def _get_yahoo_historical(self, symbol: str, period: str) -> Optional[Dict]:
        """Obtém dados históricos do Yahoo Finance"""
        try:
            self._rate_limit_yahoo()
            
            # Mapear período para range do Yahoo
            period_map = {
                '1d': '1d',
                '5d': '5d',
                '1m': '1mo',
                '3m': '3mo',
                '6m': '6mo',
                '1y': '1y',
                '2y': '2y',
                '5y': '5y',
                '10y': '10y'
            }
            
            yahoo_period = period_map.get(period, '1y')
            
            url = f"{self.yahoo_base_url}{symbol}"
            params = {
                'interval': '1d',
                'range': yahoo_period,
                'includePrePost': 'false'
            }
            
            response = requests.get(url, params=params, timeout=15)
            response.raise_for_status()
            
            data = response.json()
            
            if 'chart' not in data or not data['chart']['result']:
                return None
            
            result = data['chart']['result'][0]
            timestamps = result['timestamp']
            quotes = result['indicators']['quote'][0]
            
            # Converter para formato mais amigável
            historical_data = []
            for i, timestamp in enumerate(timestamps):
                if quotes['close'][i] is not None:  # Pular dias sem dados
                    historical_data.append({
                        'date': datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d'),
                        'open': quotes['open'][i],
                        'high': quotes['high'][i],
                        'low': quotes['low'][i],
                        'close': quotes['close'][i],
                        'volume': quotes['volume'][i] or 0
                    })
            
            return {
                'symbol': symbol,
                'period': period,
                'data': historical_data,
                'timestamp': datetime.now().isoformat(),
                'source': 'yahoo'
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter dados históricos do Yahoo Finance para {symbol}: {e}")
            return None
    
    def search_symbols(self, query: str) -> List[Dict]:
        """Busca símbolos de ações"""
        cache_key = f"search:{query.lower()}"
        
        # Tentar cache primeiro
        if self.cache_service:
            cached_data = self.cache_service.get(cache_key)
            if cached_data:
                return cached_data
        
        # Buscar símbolos
        results = self._search_yahoo_symbols(query)
        
        # Cache o resultado
        if results and self.cache_service:
            self.cache_service.set(cache_key, results, timeout=3600)  # Cache por 1 hora
        
        return results or []
    
    def _search_yahoo_symbols(self, query: str) -> List[Dict]:
        """Busca símbolos no Yahoo Finance"""
        try:
            self._rate_limit_yahoo()
            
            url = "https://query1.finance.yahoo.com/v1/finance/search"
            params = {
                'q': query,
                'quotesCount': 10,
                'newsCount': 0
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if 'quotes' not in data:
                return []
            
            results = []
            for quote in data['quotes']:
                results.append({
                    'symbol': quote.get('symbol'),
                    'name': quote.get('longname') or quote.get('shortname'),
                    'exchange': quote.get('exchange'),
                    'type': quote.get('quoteType'),
                    'currency': quote.get('currency')
                })
            
            return results
            
        except Exception as e:
            logger.error(f"Erro ao buscar símbolos: {e}")
            return []
    
    def get_market_summary(self) -> Dict:
        """Obtém resumo do mercado (principais índices)"""
        cache_key = "market_summary"
        
        # Tentar cache primeiro
        if self.cache_service:
            cached_data = self.cache_service.get(cache_key)
            if cached_data:
                return cached_data
        
        # Principais índices para acompanhar
        indices = [
            '^BVSP',    # Ibovespa
            '^GSPC',    # S&P 500
            '^DJI',     # Dow Jones
            '^IXIC',    # NASDAQ
            'BRL=X'     # USD/BRL
        ]
        
        summary = {}
        for index in indices:
            quote = self.get_stock_quote(index)
            if quote:
                summary[index] = quote
        
        # Cache por 5 minutos
        if summary and self.cache_service:
            self.cache_service.set(cache_key, summary, timeout=300)
        
        return summary


    
    def _generate_mock_quote(self, symbol: str) -> Dict:
        """Gera dados mockados para cotação"""
        import random
        import hashlib
        
        # Usar hash do símbolo para gerar dados consistentes
        seed = int(hashlib.md5(symbol.encode()).hexdigest()[:8], 16)
        random.seed(seed)
        
        base_price = 50 + (seed % 200)  # Preço base entre 50 e 250
        change_percent = (random.random() - 0.5) * 10  # Variação de -5% a +5%
        change = base_price * (change_percent / 100)
        current_price = base_price + change
        
        return {
            'symbol': symbol,
            'price': round(current_price, 2),
            'previous_close': round(base_price, 2),
            'change': round(change, 2),
            'change_percent': round(change_percent, 2),
            'volume': random.randint(100000, 10000000),
            'currency': 'BRL' if '.SA' in symbol else 'USD',
            'timestamp': datetime.now().isoformat(),
            'source': 'mock_data'
        }
    
    def _generate_mock_market_summary(self) -> Dict:
        """Gera resumo mockado do mercado"""
        symbols = ['^BVSP', '^GSPC', '^DJI', '^IXIC', 'BRL=X']
        summary = {}
        
        for symbol in symbols:
            summary[symbol] = self._generate_mock_quote(symbol)
        
        return summary
    
    def _fetch_with_timeout(self, url: str, timeout: int = 5, **kwargs) -> Optional[requests.Response]:
        """Faz requisição HTTP com timeout"""
        try:
            response = requests.get(url, timeout=timeout, **kwargs)
            response.raise_for_status()
            return response
        except requests.exceptions.Timeout:
            print(f"Timeout ao acessar {url}")
            return None
        except requests.exceptions.RequestException as e:
            print(f"Erro ao acessar {url}: {e}")
            return None
    
    def get_stock_quote_with_fallback(self, symbol: str) -> Dict:
        """Obtém cotação com fallback garantido para dados mockados"""
        try:
            # Tentar obter dados reais
            quote_data = self.get_stock_quote(symbol)
            
            if quote_data:
                return quote_data
                
        except Exception as e:
            print(f"Erro ao obter cotação real para {symbol}: {e}")
        
        # Sempre retornar dados mockados como fallback
        return self._generate_mock_quote(symbol)
    
    def get_market_summary_with_fallback(self) -> Dict:
        """Obtém resumo do mercado com fallback garantido"""
        try:
            # Tentar obter dados reais
            summary = self.get_market_summary()
            
            if summary:
                return summary
                
        except Exception as e:
            print(f"Erro ao obter resumo real do mercado: {e}")
        
        # Sempre retornar dados mockados como fallback
        return self._generate_mock_market_summary()

