#!/usr/bin/env python3
"""
Serviço para obter dados reais de mercado usando Yahoo Finance API
"""

import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient
import json
from datetime import datetime
import logging

class RealMarketDataService:
    """Serviço para obter dados reais de ações brasileiras"""
    
    def __init__(self):
        self.client = ApiClient()
        self.logger = logging.getLogger(__name__)
        
        # Lista de ações brasileiras populares
        self.brazilian_stocks = {
            'PETR4': {'symbol': 'PETR4.SA', 'name': 'Petrobras PN'},
            'VALE3': {'symbol': 'VALE3.SA', 'name': 'Vale ON'},
            'ITUB4': {'symbol': 'ITUB4.SA', 'name': 'Itaú Unibanco PN'},
            'BBDC4': {'symbol': 'BBDC4.SA', 'name': 'Bradesco PN'},
            'ABEV3': {'symbol': 'ABEV3.SA', 'name': 'Ambev ON'},
            'MGLU3': {'symbol': 'MGLU3.SA', 'name': 'Magazine Luiza ON'},
            'WEGE3': {'symbol': 'WEGE3.SA', 'name': 'WEG ON'},
            'RENT3': {'symbol': 'RENT3.SA', 'name': 'Localiza ON'},
            'LREN3': {'symbol': 'LREN3.SA', 'name': 'Lojas Renner ON'},
            'JBSS3': {'symbol': 'JBSS3.SA', 'name': 'JBS ON'},
            'SUZB3': {'symbol': 'SUZB3.SA', 'name': 'Suzano ON'},
            'VIVT3': {'symbol': 'VIVT3.SA', 'name': 'Telefônica Brasil ON'},
            'GGBR4': {'symbol': 'GGBR4.SA', 'name': 'Gerdau PN'},
            'USIM5': {'symbol': 'USIM5.SA', 'name': 'Usiminas PNA'},
            'CSNA3': {'symbol': 'CSNA3.SA', 'name': 'CSN ON'},
            'GOAU4': {'symbol': 'GOAU4.SA', 'name': 'Metalúrgica Gerdau PN'},
            'EMBR3': {'symbol': 'EMBR3.SA', 'name': 'Embraer ON'},
            'AZUL4': {'symbol': 'AZUL4.SA', 'name': 'Azul PN'},
            'GOLL4': {'symbol': 'GOLL4.SA', 'name': 'Gol PN'},
            'CIEL3': {'symbol': 'CIEL3.SA', 'name': 'Cielo ON'}
        }
    
    def get_stock_data(self, symbol):
        """
        Obtém dados de uma ação específica
        
        Args:
            symbol (str): Símbolo da ação (ex: 'PETR4')
            
        Returns:
            dict: Dados da ação ou None se erro
        """
        try:
            # Converter símbolo para formato Yahoo Finance
            if symbol in self.brazilian_stocks:
                yahoo_symbol = self.brazilian_stocks[symbol]['symbol']
                stock_name = self.brazilian_stocks[symbol]['name']
            else:
                # Se não estiver na lista, assumir que já tem .SA
                yahoo_symbol = symbol if '.SA' in symbol else f"{symbol}.SA"
                stock_name = symbol
            
            # Buscar dados da API
            response = self.client.call_api('YahooFinance/get_stock_chart', query={
                'symbol': yahoo_symbol,
                'region': 'BR',
                'interval': '1d',
                'range': '1d'
            })
            
            if not response or 'chart' not in response or not response['chart']['result']:
                self.logger.error(f"Dados não encontrados para {symbol}")
                return None
            
            result = response['chart']['result'][0]
            meta = result['meta']
            
            # Calcular variação percentual
            current_price = meta.get('regularMarketPrice', 0)
            previous_close = meta.get('chartPreviousClose', 0)
            change_percent = 0
            if previous_close > 0:
                change_percent = ((current_price - previous_close) / previous_close) * 100
            
            # Formatar dados
            stock_data = {
                'symbol': symbol.replace('.SA', ''),
                'name': meta.get('longName', stock_name),
                'price': current_price,
                'change': change_percent,
                'volume': meta.get('regularMarketVolume', 0),
                'currency': meta.get('currency', 'BRL'),
                'exchange': meta.get('fullExchangeName', 'São Paulo'),
                'dayHigh': meta.get('regularMarketDayHigh', 0),
                'dayLow': meta.get('regularMarketDayLow', 0),
                'fiftyTwoWeekHigh': meta.get('fiftyTwoWeekHigh', 0),
                'fiftyTwoWeekLow': meta.get('fiftyTwoWeekLow', 0),
                'lastUpdate': datetime.now().isoformat()
            }
            
            return stock_data
            
        except Exception as e:
            self.logger.error(f"Erro ao buscar dados para {symbol}: {str(e)}")
            return None
    
    def get_multiple_stocks(self, symbols):
        """
        Obtém dados de múltiplas ações
        
        Args:
            symbols (list): Lista de símbolos
            
        Returns:
            list: Lista de dados das ações
        """
        results = []
        for symbol in symbols:
            data = self.get_stock_data(symbol)
            if data:
                results.append(data)
        return results
    
    def get_popular_stocks(self):
        """
        Obtém dados das ações mais populares
        
        Returns:
            list: Lista de dados das ações populares
        """
        popular_symbols = ['PETR4', 'VALE3', 'ITUB4', 'BBDC4', 'ABEV3']
        return self.get_multiple_stocks(popular_symbols)
    
    def search_stocks(self, query):
        """
        Busca ações por símbolo ou nome
        
        Args:
            query (str): Termo de busca
            
        Returns:
            list: Lista de ações que correspondem à busca
        """
        query_upper = query.upper()
        results = []
        
        for symbol, info in self.brazilian_stocks.items():
            if (query_upper in symbol or 
                query_upper in info['name'].upper()):
                
                data = self.get_stock_data(symbol)
                if data:
                    results.append(data)
        
        return results[:8]  # Limitar a 8 resultados
    
    def get_market_status(self):
        """
        Obtém status do mercado
        
        Returns:
            dict: Status do mercado
        """
        try:
            # Usar IBOV como referência para status do mercado
            response = self.client.call_api('YahooFinance/get_stock_chart', query={
                'symbol': '^BVSP',  # Ibovespa
                'region': 'BR',
                'interval': '1d',
                'range': '1d'
            })
            
            if response and 'chart' in response and response['chart']['result']:
                result = response['chart']['result'][0]
                meta = result['meta']
                
                # Verificar se o mercado está aberto baseado no horário
                current_time = datetime.now()
                market_hours = current_time.hour >= 10 and current_time.hour < 18
                weekday = current_time.weekday() < 5  # Segunda a sexta
                
                return {
                    'status': 'Aberto' if market_hours and weekday else 'Fechado',
                    'lastUpdate': datetime.now().isoformat(),
                    'ibovespa': {
                        'value': meta.get('regularMarketPrice', 0),
                        'change': ((meta.get('regularMarketPrice', 0) - meta.get('chartPreviousClose', 0)) / meta.get('chartPreviousClose', 1)) * 100 if meta.get('chartPreviousClose', 0) > 0 else 0
                    }
                }
            
        except Exception as e:
            self.logger.error(f"Erro ao obter status do mercado: {str(e)}")
        
        return {
            'status': 'Indisponível',
            'lastUpdate': datetime.now().isoformat(),
            'ibovespa': {'value': 0, 'change': 0}
        }

# Instância global do serviço
market_service = RealMarketDataService()

