import threading
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, asdict
from enum import Enum
import json
from collections import defaultdict, deque
import uuid

from src.services.technical_analysis_service import TechnicalAnalysisService
from src.services.optimized_financial_service import OptimizedFinancialDataService
from src.services.predictive_cache_service import predictive_cache_service
from src.services.websocket_service import websocket_service

logger = logging.getLogger(__name__)

class AlertType(Enum):
    """Tipos de alertas"""
    PRICE = "price"
    TECHNICAL = "technical"
    VOLUME = "volume"
    NEWS = "news"
    CUSTOM = "custom"

class AlertCondition(Enum):
    """Condições de alerta"""
    ABOVE = "above"
    BELOW = "below"
    CROSSES_ABOVE = "crosses_above"
    CROSSES_BELOW = "crosses_below"
    EQUALS = "equals"
    CHANGE_PERCENT = "change_percent"
    RSI_OVERBOUGHT = "rsi_overbought"
    RSI_OVERSOLD = "rsi_oversold"
    MACD_BULLISH = "macd_bullish"
    MACD_BEARISH = "macd_bearish"
    BOLLINGER_SQUEEZE = "bollinger_squeeze"
    VOLUME_SPIKE = "volume_spike"

class AlertPriority(Enum):
    """Prioridades de alerta"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AlertStatus(Enum):
    """Status do alerta"""
    ACTIVE = "active"
    TRIGGERED = "triggered"
    PAUSED = "paused"
    EXPIRED = "expired"
    DELETED = "deleted"

@dataclass
class Alert:
    """Estrutura de um alerta"""
    id: str
    user_id: str
    symbol: str
    alert_type: AlertType
    condition: AlertCondition
    value: float
    priority: AlertPriority
    message: str
    status: AlertStatus
    created_at: datetime
    expires_at: Optional[datetime] = None
    triggered_at: Optional[datetime] = None
    trigger_count: int = 0
    max_triggers: int = 1
    cooldown_minutes: int = 5
    last_triggered: Optional[datetime] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}

class AlertsEngine:
    """Engine de monitoramento e processamento de alertas"""
    
    def __init__(self):
        self.alerts = {}  # alert_id -> Alert
        self.user_alerts = defaultdict(set)  # user_id -> set of alert_ids
        self.symbol_alerts = defaultdict(set)  # symbol -> set of alert_ids
        self.triggered_alerts = deque(maxlen=10000)  # Histórico de alertas disparados
        
        # Serviços
        self.technical_service = TechnicalAnalysisService()
        self.financial_service = OptimizedFinancialDataService(predictive_cache_service)
        
        # Threading
        self.monitoring_thread = None
        self.running = False
        self.check_interval = 10  # Verificar a cada 10 segundos
        self._lock = threading.RLock()
        
        # Cache de dados para otimização
        self.price_cache = {}
        self.technical_cache = {}
        self.cache_ttl = 30  # 30 segundos
        
        # Métricas
        self.metrics = {
            'total_alerts': 0,
            'active_alerts': 0,
            'triggered_alerts': 0,
            'false_positives': 0,
            'processing_time_ms': 0,
            'last_check': None
        }
        
        # Machine Learning básico para redução de falsos positivos
        self.ml_model = AlertMLOptimizer()
    
    def start_monitoring(self):
        """Inicia o monitoramento de alertas"""
        if self.running:
            return
        
        self.running = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_worker, daemon=True)
        self.monitoring_thread.start()
        
        logger.info("Engine de alertas iniciado")
    
    def stop_monitoring(self):
        """Para o monitoramento de alertas"""
        self.running = False
        
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=10)
        
        logger.info("Engine de alertas parado")
    
    def _monitoring_worker(self):
        """Worker thread para monitoramento contínuo"""
        while self.running:
            try:
                start_time = time.time()
                
                # Processar alertas ativos
                self._process_active_alerts()
                
                # Limpar alertas expirados
                self._cleanup_expired_alerts()
                
                # Atualizar métricas
                processing_time = (time.time() - start_time) * 1000
                self.metrics['processing_time_ms'] = processing_time
                self.metrics['last_check'] = datetime.now().isoformat()
                
                # Aguardar próximo ciclo
                time.sleep(self.check_interval)
                
            except Exception as e:
                logger.error(f"Erro no worker de monitoramento: {e}")
                time.sleep(30)  # Aguardar mais tempo em caso de erro
    
    def create_alert(self, user_id: str, symbol: str, alert_type: AlertType,
                    condition: AlertCondition, value: float, priority: AlertPriority,
                    message: str, expires_in_hours: Optional[int] = None,
                    max_triggers: int = 1, cooldown_minutes: int = 5,
                    metadata: Optional[Dict] = None) -> str:
        """Cria um novo alerta"""
        alert_id = str(uuid.uuid4())
        
        expires_at = None
        if expires_in_hours:
            expires_at = datetime.now() + timedelta(hours=expires_in_hours)
        
        alert = Alert(
            id=alert_id,
            user_id=user_id,
            symbol=symbol.upper(),
            alert_type=alert_type,
            condition=condition,
            value=value,
            priority=priority,
            message=message,
            status=AlertStatus.ACTIVE,
            created_at=datetime.now(),
            expires_at=expires_at,
            max_triggers=max_triggers,
            cooldown_minutes=cooldown_minutes,
            metadata=metadata or {}
        )
        
        with self._lock:
            self.alerts[alert_id] = alert
            self.user_alerts[user_id].add(alert_id)
            self.symbol_alerts[symbol.upper()].add(alert_id)
            self.metrics['total_alerts'] += 1
            self.metrics['active_alerts'] += 1
        
        logger.info(f"Alerta criado: {alert_id} para {user_id} - {symbol} {condition.value} {value}")
        
        return alert_id
    
    def _process_active_alerts(self):
        """Processa todos os alertas ativos"""
        active_alerts = []
        
        with self._lock:
            for alert in self.alerts.values():
                if alert.status == AlertStatus.ACTIVE:
                    active_alerts.append(alert)
        
        # Agrupar por símbolo para otimizar requisições
        symbols_to_check = set(alert.symbol for alert in active_alerts)
        
        # Obter dados atuais para todos os símbolos
        current_data = {}
        for symbol in symbols_to_check:
            try:
                current_data[symbol] = self._get_current_data(symbol)
            except Exception as e:
                logger.warning(f"Erro ao obter dados para {symbol}: {e}")
        
        # Verificar cada alerta
        for alert in active_alerts:
            try:
                if alert.symbol in current_data:
                    self._check_alert(alert, current_data[alert.symbol])
            except Exception as e:
                logger.error(f"Erro ao verificar alerta {alert.id}: {e}")
    
    def _get_current_data(self, symbol: str) -> Dict[str, Any]:
        """Obtém dados atuais do símbolo com cache"""
        cache_key = f"alert_data:{symbol}"
        
        # Verificar cache
        if cache_key in self.price_cache:
            cached_data, timestamp = self.price_cache[cache_key]
            if time.time() - timestamp < self.cache_ttl:
                return cached_data
        
        # Obter dados frescos
        quote_data = self.financial_service.get_stock_quote_with_fallback(symbol)
        
        # Para alertas técnicos, também obter dados históricos
        historical_data = None
        if any(alert.alert_type == AlertType.TECHNICAL for alert in self.alerts.values() 
               if alert.symbol == symbol and alert.status == AlertStatus.ACTIVE):
            try:
                # Simular dados históricos (em produção, usar API real)
                historical_data = self._get_historical_data_for_alerts(symbol)
            except Exception as e:
                logger.warning(f"Erro ao obter dados históricos para {symbol}: {e}")
        
        current_data = {
            'quote': quote_data,
            'historical': historical_data,
            'timestamp': time.time()
        }
        
        # Cache dos dados
        self.price_cache[cache_key] = (current_data, time.time())
        
        return current_data
    
    def _check_alert(self, alert: Alert, current_data: Dict[str, Any]):
        """Verifica se um alerta deve ser disparado"""
        # Verificar cooldown
        if alert.last_triggered:
            cooldown_end = alert.last_triggered + timedelta(minutes=alert.cooldown_minutes)
            if datetime.now() < cooldown_end:
                return
        
        # Verificar limite de triggers
        if alert.trigger_count >= alert.max_triggers:
            alert.status = AlertStatus.EXPIRED
            return
        
        quote_data = current_data.get('quote')
        if not quote_data:
            return
        
        triggered = False
        trigger_value = None
        
        try:
            # Verificar condição baseada no tipo de alerta
            if alert.alert_type == AlertType.PRICE:
                triggered, trigger_value = self._check_price_alert(alert, quote_data)
            
            elif alert.alert_type == AlertType.TECHNICAL:
                historical_data = current_data.get('historical')
                if historical_data:
                    triggered, trigger_value = self._check_technical_alert(alert, historical_data)
            
            elif alert.alert_type == AlertType.VOLUME:
                triggered, trigger_value = self._check_volume_alert(alert, quote_data)
            
            # Aplicar ML para reduzir falsos positivos
            if triggered:
                confidence = self.ml_model.predict_alert_quality(alert, current_data)
                if confidence < 0.7:  # Threshold de confiança
                    logger.debug(f"Alerta {alert.id} filtrado por ML (confiança: {confidence:.2f})")
                    self.metrics['false_positives'] += 1
                    return
            
            if triggered:
                self._trigger_alert(alert, trigger_value)
                
        except Exception as e:
            logger.error(f"Erro ao verificar alerta {alert.id}: {e}")
    
    def _check_price_alert(self, alert: Alert, quote_data: Dict) -> tuple[bool, Optional[float]]:
        """Verifica alertas de preço"""
        current_price = quote_data.get('price', 0)
        
        if alert.condition == AlertCondition.ABOVE:
            return current_price > alert.value, current_price
        
        elif alert.condition == AlertCondition.BELOW:
            return current_price < alert.value, current_price
        
        elif alert.condition == AlertCondition.EQUALS:
            tolerance = alert.value * 0.001  # 0.1% de tolerância
            return abs(current_price - alert.value) <= tolerance, current_price
        
        elif alert.condition == AlertCondition.CHANGE_PERCENT:
            change_percent = quote_data.get('change_percent', 0)
            if alert.value > 0:  # Alerta para alta
                return change_percent >= alert.value, change_percent
            else:  # Alerta para baixa
                return change_percent <= alert.value, change_percent
        
        return False, None
    
    def _check_technical_alert(self, alert: Alert, historical_data: Dict) -> tuple[bool, Optional[float]]:
        """Verifica alertas técnicos"""
        try:
            # Calcular indicadores
            indicators = self.technical_service.calculate_indicators(alert.symbol, historical_data)
            
            if alert.condition == AlertCondition.RSI_OVERBOUGHT:
                if 'rsi' in indicators:
                    rsi_values = indicators['rsi'].values
                    if rsi_values:
                        current_rsi = rsi_values[-1]
                        return current_rsi >= alert.value, current_rsi
            
            elif alert.condition == AlertCondition.RSI_OVERSOLD:
                if 'rsi' in indicators:
                    rsi_values = indicators['rsi'].values
                    if rsi_values:
                        current_rsi = rsi_values[-1]
                        return current_rsi <= alert.value, current_rsi
            
            elif alert.condition == AlertCondition.MACD_BULLISH:
                if 'macd' in indicators:
                    macd_data = indicators['macd']
                    if 'macd_line' in macd_data and 'signal_line' in macd_data:
                        macd_line = macd_data['macd_line'].values
                        signal_line = macd_data['signal_line'].values
                        
                        if len(macd_line) >= 2 and len(signal_line) >= 2:
                            # Cruzamento bullish
                            prev_macd = macd_line[-2]
                            curr_macd = macd_line[-1]
                            prev_signal = signal_line[-2]
                            curr_signal = signal_line[-1]
                            
                            crossed = prev_macd <= prev_signal and curr_macd > curr_signal
                            return crossed, curr_macd
            
            elif alert.condition == AlertCondition.MACD_BEARISH:
                if 'macd' in indicators:
                    macd_data = indicators['macd']
                    if 'macd_line' in macd_data and 'signal_line' in macd_data:
                        macd_line = macd_data['macd_line'].values
                        signal_line = macd_data['signal_line'].values
                        
                        if len(macd_line) >= 2 and len(signal_line) >= 2:
                            # Cruzamento bearish
                            prev_macd = macd_line[-2]
                            curr_macd = macd_line[-1]
                            prev_signal = signal_line[-2]
                            curr_signal = signal_line[-1]
                            
                            crossed = prev_macd >= prev_signal and curr_macd < curr_signal
                            return crossed, curr_macd
            
        except Exception as e:
            logger.error(f"Erro ao verificar alerta técnico {alert.id}: {e}")
        
        return False, None
    
    def _check_volume_alert(self, alert: Alert, quote_data: Dict) -> tuple[bool, Optional[float]]:
        """Verifica alertas de volume"""
        current_volume = quote_data.get('volume', 0)
        
        if alert.condition == AlertCondition.VOLUME_SPIKE:
            # Comparar com volume médio (simulado)
            avg_volume = current_volume * 0.7  # Simular volume médio
            spike_ratio = current_volume / avg_volume if avg_volume > 0 else 0
            
            return spike_ratio >= alert.value, spike_ratio
        
        elif alert.condition == AlertCondition.ABOVE:
            return current_volume > alert.value, current_volume
        
        return False, None
    
    def _trigger_alert(self, alert: Alert, trigger_value: Optional[float]):
        """Dispara um alerta"""
        with self._lock:
            alert.triggered_at = datetime.now()
            alert.last_triggered = datetime.now()
            alert.trigger_count += 1
            
            # Atualizar status se atingiu limite de triggers
            if alert.trigger_count >= alert.max_triggers:
                alert.status = AlertStatus.TRIGGERED
                self.metrics['active_alerts'] -= 1
            
            self.metrics['triggered_alerts'] += 1
        
        # Criar registro do alerta disparado
        triggered_alert = {
            'alert_id': alert.id,
            'user_id': alert.user_id,
            'symbol': alert.symbol,
            'condition': alert.condition.value,
            'trigger_value': trigger_value,
            'expected_value': alert.value,
            'message': alert.message,
            'priority': alert.priority.value,
            'triggered_at': alert.triggered_at.isoformat(),
            'metadata': alert.metadata
        }
        
        self.triggered_alerts.append(triggered_alert)
        
        # Enviar notificações
        self._send_notifications(alert, triggered_alert)
        
        logger.info(f"Alerta disparado: {alert.id} - {alert.symbol} {alert.condition.value} (valor: {trigger_value})")
    
    def _send_notifications(self, alert: Alert, triggered_alert: Dict):
        """Envia notificações do alerta"""
        try:
            # Notificação via WebSocket
            if websocket_service:
                websocket_service.broadcast_alert(alert.user_id, triggered_alert)
            
            # Aqui poderia adicionar outras formas de notificação:
            # - Email
            # - SMS
            # - Push notifications
            # - Webhook
            
        except Exception as e:
            logger.error(f"Erro ao enviar notificações para alerta {alert.id}: {e}")
    
    def _cleanup_expired_alerts(self):
        """Remove alertas expirados"""
        current_time = datetime.now()
        expired_alerts = []
        
        with self._lock:
            for alert_id, alert in self.alerts.items():
                if (alert.expires_at and current_time > alert.expires_at) or \
                   alert.status in [AlertStatus.EXPIRED, AlertStatus.DELETED]:
                    expired_alerts.append(alert_id)
        
        for alert_id in expired_alerts:
            self.delete_alert(alert_id)
    
    def delete_alert(self, alert_id: str) -> bool:
        """Remove um alerta"""
        with self._lock:
            if alert_id not in self.alerts:
                return False
            
            alert = self.alerts[alert_id]
            
            # Remover dos índices
            self.user_alerts[alert.user_id].discard(alert_id)
            self.symbol_alerts[alert.symbol].discard(alert_id)
            
            # Atualizar métricas
            if alert.status == AlertStatus.ACTIVE:
                self.metrics['active_alerts'] -= 1
            
            # Remover alerta
            del self.alerts[alert_id]
            
            logger.info(f"Alerta removido: {alert_id}")
            return True
    
    def get_user_alerts(self, user_id: str, status_filter: Optional[AlertStatus] = None) -> List[Dict]:
        """Obtém alertas de um usuário"""
        user_alert_ids = self.user_alerts.get(user_id, set())
        alerts = []
        
        for alert_id in user_alert_ids:
            if alert_id in self.alerts:
                alert = self.alerts[alert_id]
                if status_filter is None or alert.status == status_filter:
                    alerts.append(asdict(alert))
        
        return sorted(alerts, key=lambda x: x['created_at'], reverse=True)
    
    def get_triggered_alerts(self, user_id: Optional[str] = None, limit: int = 100) -> List[Dict]:
        """Obtém histórico de alertas disparados"""
        triggered = list(self.triggered_alerts)
        
        if user_id:
            triggered = [alert for alert in triggered if alert['user_id'] == user_id]
        
        return triggered[-limit:]
    
    def get_metrics(self) -> Dict[str, Any]:
        """Obtém métricas do engine de alertas"""
        with self._lock:
            return {
                **self.metrics,
                'symbols_monitored': len(self.symbol_alerts),
                'users_with_alerts': len(self.user_alerts),
                'cache_size': len(self.price_cache),
                'timestamp': datetime.now().isoformat()
            }
    
    def _get_historical_data_for_alerts(self, symbol: str) -> Dict[str, List[float]]:
        """Obtém dados históricos simplificados para alertas"""
        # Implementação simplificada - em produção usar API real
        quote_data = self.financial_service.get_stock_quote_with_fallback(symbol)
        
        if not quote_data:
            return {'close': [], 'high': [], 'low': [], 'volume': []}
        
        # Simular dados históricos básicos
        current_price = quote_data['price']
        
        # Gerar 50 pontos de dados simulados
        import random
        prices = []
        highs = []
        lows = []
        volumes = []
        
        price = current_price
        for _ in range(50):
            change = random.uniform(-0.02, 0.02)  # ±2%
            price = price * (1 + change)
            
            high = price * random.uniform(1.0, 1.01)
            low = price * random.uniform(0.99, 1.0)
            volume = random.randint(100000, 1000000)
            
            prices.append(price)
            highs.append(high)
            lows.append(low)
            volumes.append(volume)
        
        return {
            'close': prices,
            'high': highs,
            'low': lows,
            'volume': volumes
        }

class AlertMLOptimizer:
    """Otimizador ML básico para reduzir falsos positivos"""
    
    def __init__(self):
        self.alert_history = deque(maxlen=1000)
        self.false_positive_patterns = set()
    
    def predict_alert_quality(self, alert: Alert, current_data: Dict) -> float:
        """Prediz qualidade do alerta (0-1, onde 1 = alta qualidade)"""
        confidence = 0.8  # Base confidence
        
        # Ajustar baseado no tipo de alerta
        if alert.alert_type == AlertType.PRICE:
            confidence += 0.1  # Alertas de preço são mais confiáveis
        
        # Ajustar baseado na prioridade
        if alert.priority == AlertPriority.HIGH:
            confidence += 0.05
        elif alert.priority == AlertPriority.LOW:
            confidence -= 0.05
        
        # Verificar padrões de falsos positivos
        pattern_key = f"{alert.symbol}:{alert.condition.value}:{alert.alert_type.value}"
        if pattern_key in self.false_positive_patterns:
            confidence -= 0.2
        
        # Ajustar baseado na volatilidade
        quote_data = current_data.get('quote', {})
        if 'change_percent' in quote_data:
            volatility = abs(quote_data['change_percent'])
            if volatility > 5:  # Alta volatilidade
                confidence -= 0.1
        
        return max(0.0, min(1.0, confidence))
    
    def record_false_positive(self, alert: Alert):
        """Registra um falso positivo para aprendizado"""
        pattern_key = f"{alert.symbol}:{alert.condition.value}:{alert.alert_type.value}"
        self.false_positive_patterns.add(pattern_key)

# Instância global do engine de alertas
alerts_engine = AlertsEngine()

