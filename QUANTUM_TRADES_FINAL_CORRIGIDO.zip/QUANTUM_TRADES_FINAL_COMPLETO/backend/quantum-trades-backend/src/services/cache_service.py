import time
import threading
from typing import Any, Optional
import json
from datetime import datetime, timedelta

class InMemoryCacheService:
    """Serviço de cache em memória com TTL"""
    
    def __init__(self):
        self._cache = {}
        self._lock = threading.RLock()
        self._cleanup_interval = 300  # 5 minutos
        self._last_cleanup = time.time()
    
    def _cleanup_expired(self):
        """Remove itens expirados do cache"""
        current_time = time.time()
        
        # Só faz cleanup a cada intervalo definido
        if current_time - self._last_cleanup < self._cleanup_interval:
            return
        
        with self._lock:
            expired_keys = []
            for key, (value, expiry) in self._cache.items():
                if expiry and current_time > expiry:
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self._cache[key]
            
            self._last_cleanup = current_time
    
    def get(self, key: str) -> Optional[Any]:
        """Obtém um valor do cache"""
        self._cleanup_expired()
        
        with self._lock:
            if key not in self._cache:
                return None
            
            value, expiry = self._cache[key]
            
            # Verificar se expirou
            if expiry and time.time() > expiry:
                del self._cache[key]
                return None
            
            return value
    
    def set(self, key: str, value: Any, timeout: Optional[int] = None) -> bool:
        """Define um valor no cache com TTL opcional"""
        expiry = None
        if timeout:
            expiry = time.time() + timeout
        
        with self._lock:
            self._cache[key] = (value, expiry)
        
        return True
    
    def delete(self, key: str) -> bool:
        """Remove um item do cache"""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
        return False
    
    def clear(self) -> bool:
        """Limpa todo o cache"""
        with self._lock:
            self._cache.clear()
        return True
    
    def exists(self, key: str) -> bool:
        """Verifica se uma chave existe no cache"""
        return self.get(key) is not None
    
    def get_stats(self) -> dict:
        """Retorna estatísticas do cache"""
        with self._lock:
            total_items = len(self._cache)
            expired_items = 0
            current_time = time.time()
            
            for key, (value, expiry) in self._cache.items():
                if expiry and current_time > expiry:
                    expired_items += 1
            
            return {
                'total_items': total_items,
                'expired_items': expired_items,
                'active_items': total_items - expired_items,
                'last_cleanup': datetime.fromtimestamp(self._last_cleanup).isoformat()
            }

class SmartCacheService(InMemoryCacheService):
    """Cache inteligente com estratégias baseadas no tipo de dados"""
    
    def __init__(self):
        super().__init__()
        self.hit_count = 0
        self.miss_count = 0
        self.default_timeouts = {
            'quote': 60,        # Cotações: 1 minuto
            'historical': 3600, # Dados históricos: 1 hora
            'search': 3600,     # Busca de símbolos: 1 hora
            'market_summary': 300,  # Resumo do mercado: 5 minutos
            'user': 1800,       # Dados de usuário: 30 minutos
            'alerts': 300       # Alertas: 5 minutos
        }
    
    def get(self, key: str) -> Optional[Any]:
        """Obtém valor do cache com contagem de hits/misses"""
        value = super().get(key)
        
        if value is not None:
            self.hit_count += 1
        else:
            self.miss_count += 1
        
        return value
    
    def set_smart(self, key: str, value: Any, data_type: str = 'default') -> bool:
        """Define valor no cache com timeout baseado no tipo de dados"""
        timeout = self.default_timeouts.get(data_type, 300)  # Default: 5 minutos
        
        # Ajustar timeout baseado na volatilidade dos dados
        if data_type == 'quote':
            # Para cotações, usar timeout menor durante horário de mercado
            now = datetime.now()
            if 9 <= now.hour <= 18:  # Horário de mercado aproximado
                timeout = 30  # 30 segundos durante pregão
            else:
                timeout = 300  # 5 minutos fora do pregão
        
        return self.set(key, value, timeout)
    
    def get_hit_ratio(self) -> float:
        """Calcula a taxa de acerto do cache"""
        total = self.hit_count + self.miss_count
        if total == 0:
            return 0.0
        return self.hit_count / total
    
    def get_cache_stats(self) -> dict:
        """Retorna estatísticas completas do cache"""
        base_stats = self.get_stats()
        base_stats.update({
            'hit_count': self.hit_count,
            'miss_count': self.miss_count,
            'hit_ratio': self.get_hit_ratio(),
            'total_requests': self.hit_count + self.miss_count
        })
        return base_stats
    
    def warm_cache(self, symbols: list, financial_service):
        """Pré-carrega o cache com dados de símbolos populares"""
        for symbol in symbols:
            try:
                # Carregar cotação
                quote = financial_service.get_stock_quote(symbol)
                if quote:
                    self.set_smart(f"quote:{symbol}", quote, 'quote')
                
                # Carregar dados históricos básicos
                historical = financial_service.get_historical_data(symbol, '1m')
                if historical:
                    self.set_smart(f"historical:{symbol}:1m", historical, 'historical')
                    
            except Exception as e:
                print(f"Erro ao pré-carregar dados para {symbol}: {e}")

# Instância global do cache
cache_service = SmartCacheService()

