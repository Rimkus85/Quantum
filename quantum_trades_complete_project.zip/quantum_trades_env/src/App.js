/**
 * App.js atualizado
 * Implementação das rotas protegidas com controle de acesso
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

// Contextos
import { AuthProvider } from './contexts/AuthContext';

// Tema
import theme from './theme';

// Layouts
import MainLayout from './layouts/MainLayout';

// Páginas
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import RegisterPage from './pages/RegisterPage';
import AccessDeniedPage from './pages/AccessDeniedPage';
import UpgradePage from './pages/UpgradePage';

// Componentes
import ProtectedRoute from './components/ProtectedRoute';

// Constantes
import { ACCESS_LEVELS } from './utils/UserProfileStructure';

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            {/* Rotas públicas */}
            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            
            {/* Rotas protegidas com controle de acesso */}
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute requiredLevel={ACCESS_LEVELS.BASIC}>
                  <MainLayout>
                    <DashboardPage />
                  </MainLayout>
                </ProtectedRoute>
              } 
            />
            
            {/* Rota para página de acesso negado */}
            <Route path="/access-denied" element={<AccessDeniedPage />} />
            
            {/* Rota para upgrade de conta */}
            <Route 
              path="/upgrade" 
              element={
                <ProtectedRoute requiredLevel={ACCESS_LEVELS.BASIC}>
                  <MainLayout>
                    <UpgradePage />
                  </MainLayout>
                </ProtectedRoute>
              } 
            />
            
            {/* Rotas protegidas para usuários premium */}
            <Route 
              path="/orders" 
              element={
                <ProtectedRoute requiredLevel={ACCESS_LEVELS.PREMIUM}>
                  <MainLayout>
                    <div>Página de Ordens (Premium)</div>
                  </MainLayout>
                </ProtectedRoute>
              } 
            />
            
            <Route 
              path="/research" 
              element={
                <ProtectedRoute requiredLevel={ACCESS_LEVELS.PREMIUM}>
                  <MainLayout>
                    <div>Página de Research (Premium)</div>
                  </MainLayout>
                </ProtectedRoute>
              } 
            />
            
            {/* Rotas protegidas para administradores */}
            <Route 
              path="/admin" 
              element={
                <ProtectedRoute requiredLevel={ACCESS_LEVELS.ADMIN}>
                  <MainLayout>
                    <div>Painel de Administração</div>
                  </MainLayout>
                </ProtectedRoute>
              } 
            />
            
            {/* Rota para página não encontrada */}
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
