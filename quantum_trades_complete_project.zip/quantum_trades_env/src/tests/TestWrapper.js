/**
 * TestWrapper.js
 * Componente wrapper para testes que fornece todos os contextos necessários
 */
import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import { BrowserRouter } from 'react-router-dom';
import theme from '../theme';

// Mock do AuthProvider para testes
const MockAuthProvider = ({ children }) => {
  // Simula um usuário autenticado com nível básico
  const authContextValue = {
    isAuthenticated: true,
    user: {
      id: 'test-user-id',
      name: 'Usuário Teste',
      email: 'teste@exemplo.com',
      level: 1, // Nível básico
    },
    login: jest.fn(),
    logout: jest.fn(),
    hasPermission: jest.fn().mockImplementation((level) => level <= 1),
  };

  return (
    <div data-testid="auth-provider">
      {React.Children.map(children, child => 
        React.isValidElement(child) 
          ? React.cloneElement(child, { authContext: authContextValue }) 
          : child
      )}
    </div>
  );
};

// Componente wrapper completo para testes
const TestWrapper = ({ children }) => (
  <ThemeProvider theme={theme}>
    <BrowserRouter>
      <MockAuthProvider>
        {children}
      </MockAuthProvider>
    </BrowserRouter>
  </ThemeProvider>
);

export default TestWrapper;
