/**
 * BackgroundServiceTest.js
 * Arquivo para testar o serviço de execução em background
 */

import BackgroundService from '../services/BackgroundService.js';

// Função para executar os testes
async function runTests() {
  console.log('Iniciando testes do serviço de execução em background...');
  
  try {
    // Configuração de listeners para eventos
    setupEventListeners();
    
    // Teste 1: Iniciar o serviço
    console.log('\nTeste 1: Iniciar o serviço');
    const startResult = BackgroundService.start(2000); // Intervalo de 2 segundos para testes
    console.log(`Resultado da inicialização: ${startResult}`);
    console.log(`Status do serviço: ${JSON.stringify(BackgroundService.getStatus())}`);
    
    // Teste 2: Adicionar tarefa de análise
    console.log('\nTeste 2: Adicionar tarefa de análise');
    const analysisTaskId = BackgroundService.addTask({
      type: 'analysis',
      data: {
        symbol: 'PETR4',
        pattern: {
          hiloChange: true,
          hammerSignal: true,
          volumeIncrease: 2
        }
      }
    });
    console.log(`ID da tarefa de análise: ${analysisTaskId}`);
    
    // Teste 3: Adicionar tarefa de ordem
    console.log('\nTeste 3: Adicionar tarefa de ordem');
    const orderTaskId = BackgroundService.addTask({
      type: 'order',
      data: {
        symbol: 'VALE3',
        operation: 'buy',
        quantity: 100,
        price: 68.50,
        source: 'manual'
      }
    });
    console.log(`ID da tarefa de ordem: ${orderTaskId}`);
    
    // Teste 4: Adicionar tarefa de notificação
    console.log('\nTeste 4: Adicionar tarefa de notificação');
    const notificationTaskId = BackgroundService.addTask({
      type: 'notification',
      data: {
        type: 'info',
        title: 'Teste de Notificação',
        message: 'Esta é uma notificação de teste do serviço de background.'
      }
    });
    console.log(`ID da tarefa de notificação: ${notificationTaskId}`);
    
    // Aguarda processamento das tarefas
    console.log('\nAguardando processamento das tarefas...');
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    // Teste 5: Verificar status do serviço
    console.log('\nTeste 5: Verificar status do serviço');
    console.log(`Status do serviço: ${JSON.stringify(BackgroundService.getStatus())}`);
    
    // Teste 6: Verificar histórico de ordens
    console.log('\nTeste 6: Verificar histórico de ordens');
    const orderHistory = BackgroundService.getOrderHistory();
    console.log(`Histórico de ordens: ${JSON.stringify(orderHistory)}`);
    
    // Teste 7: Remover uma tarefa
    console.log('\nTeste 7: Adicionar e remover uma tarefa');
    const tempTaskId = BackgroundService.addTask({
      type: 'notification',
      data: {
        type: 'info',
        title: 'Tarefa Temporária',
        message: 'Esta tarefa será removida imediatamente.'
      }
    });
    console.log(`ID da tarefa temporária: ${tempTaskId}`);
    
    const removeResult = BackgroundService.removeTask(tempTaskId);
    console.log(`Resultado da remoção: ${removeResult}`);
    
    // Aguarda mais um pouco para processamento final
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Teste 8: Parar o serviço
    console.log('\nTeste 8: Parar o serviço');
    const stopResult = BackgroundService.stop();
    console.log(`Resultado da parada: ${stopResult}`);
    console.log(`Status final do serviço: ${JSON.stringify(BackgroundService.getStatus())}`);
    
    console.log('\nTestes concluídos com sucesso!');
  } catch (error) {
    console.error('Erro durante os testes:', error);
  }
}

// Configura listeners para eventos do serviço
function setupEventListeners() {
  // Evento de início do serviço
  BackgroundService.on('serviceStarted', (data) => {
    console.log(`[Evento] Serviço iniciado em: ${data.timestamp}`);
  });
  
  // Evento de parada do serviço
  BackgroundService.on('serviceStopped', (data) => {
    console.log(`[Evento] Serviço parado em: ${data.timestamp}`);
  });
  
  // Evento de adição de tarefa
  BackgroundService.on('taskAdded', (data) => {
    console.log(`[Evento] Tarefa adicionada: ${data.taskId}`);
  });
  
  // Evento de início de tarefa
  BackgroundService.on('taskStarted', (data) => {
    console.log(`[Evento] Tarefa iniciada: ${data.taskId}`);
  });
  
  // Evento de conclusão de tarefa
  BackgroundService.on('taskCompleted', (data) => {
    console.log(`[Evento] Tarefa concluída: ${data.taskId}`);
    if (data.task.result) {
      console.log(`[Evento] Resultado: ${JSON.stringify(data.task.result)}`);
    }
  });
  
  // Evento de falha de tarefa
  BackgroundService.on('taskFailed', (data) => {
    console.log(`[Evento] Tarefa falhou: ${data.taskId} - Erro: ${data.error}`);
  });
  
  // Evento de ordem enfileirada
  BackgroundService.on('orderQueued', (data) => {
    console.log(`[Evento] Ordem enfileirada: ${data.order.id} - ${data.order.symbol} ${data.order.operation}`);
  });
  
  // Evento de ordem em processamento
  BackgroundService.on('orderProcessing', (data) => {
    console.log(`[Evento] Ordem em processamento: ${data.order.id}`);
  });
  
  // Evento de ordem concluída
  BackgroundService.on('orderCompleted', (data) => {
    console.log(`[Evento] Ordem concluída: ${data.order.id} - Preço: ${data.order.executedPrice}`);
  });
  
  // Evento de ordem falhou
  BackgroundService.on('orderFailed', (data) => {
    console.log(`[Evento] Ordem falhou: ${data.order.id} - Erro: ${data.error}`);
  });
  
  // Evento de notificação
  BackgroundService.on('notification', (data) => {
    console.log(`[Evento] Notificação: ${data.notification.id} - ${data.notification.title}`);
    console.log(`[Evento] Mensagem: ${data.notification.message}`);
  });
}

// Executa os testes
runTests();
