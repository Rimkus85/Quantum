/**
 * setup-jest.js
 * Configuração inicial para testes Jest do Quantum Trades
 * Este arquivo corrige problemas de importação do jest-dom
 */

import '@testing-library/jest-dom';

// Configuração global para Jest
jest.setTimeout(30000); // Aumenta o timeout para 30 segundos

// Mock para localStorage
const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};

global.localStorage = localStorageMock;

// Mock para matchMedia (necessário para testes de responsividade)
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(),
    removeListener: jest.fn(),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});
