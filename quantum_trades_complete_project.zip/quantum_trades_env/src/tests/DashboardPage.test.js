/**
 * DashboardPage.test.js
 * Testes automatizados para a página de Dashboard do Quantum Trades
 */
import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import DashboardPage from '../pages/DashboardPage';
import TestWrapper from './TestWrapper';
import mockMatchMedia from './mockMediaQuery';

// Aplicar mock de matchMedia antes de todos os testes
beforeAll(() => {
  mockMatchMedia();
});

// Mock de dados para os testes
jest.mock('../services/StatisticalAnalysis', () => ({
  getPerformanceData: jest.fn().mockResolvedValue({
    daily: '+5,67%',
    monthly: '-1,23%',
    yearly: '+15,78%'
  }),
  getRecentOperations: jest.fn().mockResolvedValue([
    { id: 1, asset: 'PETR4', type: 'Compra', value: 'R$ 28,50', date: '2025-06-01', result: '+2,5%' },
    { id: 2, asset: 'VALE3', type: 'Venda', value: 'R$ 68,20', date: '2025-05-28', result: '-1,2%' }
  ])
}));

describe('Testes da Página de Dashboard', () => {
  test('Deve renderizar o título da página', async () => {
    render(
      <TestWrapper>
        <DashboardPage />
      </TestWrapper>
    );
    
    // Verificar título da página
    expect(screen.getByText(/dashboard/i)).toBeInTheDocument();
  });

  test('Deve exibir os cards de desempenho', async () => {
    render(
      <TestWrapper>
        <DashboardPage />
      </TestWrapper>
    );
    
    // Verificar cards de desempenho
    await waitFor(() => {
      expect(screen.getByText(/desempenho/i)).toBeInTheDocument();
    });
    
    // Verificar dados de desempenho
    await waitFor(() => {
      expect(screen.getByText(/\+5,67%/)).toBeInTheDocument();
      expect(screen.getByText(/-1,23%/)).toBeInTheDocument();
      expect(screen.getByText(/\+15,78%/)).toBeInTheDocument();
    });
  });

  test('Deve exibir a seção de operações recentes', async () => {
    render(
      <TestWrapper>
        <DashboardPage />
      </TestWrapper>
    );
    
    // Verificar título da seção
    await waitFor(() => {
      expect(screen.getByText(/operações recentes/i)).toBeInTheDocument();
    });
  });

  test('Deve verificar responsividade em dispositivos móveis', async () => {
    // Simular dispositivo móvel
    window.matchMedia = jest.fn().mockImplementation(query => ({
      matches: query.includes('max-width'),
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
      dispatchEvent: jest.fn(),
    }));
    
    render(
      <TestWrapper>
        <DashboardPage />
      </TestWrapper>
    );
    
    // Verificar adaptações para mobile
    expect(screen.getByText(/dashboard/i)).toBeInTheDocument();
  });
});
