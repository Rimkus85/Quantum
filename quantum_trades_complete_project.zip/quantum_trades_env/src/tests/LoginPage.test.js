/**
 * LoginPage.test.js
 * Testes automatizados para a página de login do Quantum Trades
 */

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import LoginPage from '../pages/LoginPage';

// Mock do serviço de autenticação
jest.mock('../services/AuthService', () => ({
  login: jest.fn().mockImplementation((username, password) => {
    if (username === 'Rimkus' && password === 'password123') {
      return Promise.resolve({ success: true, token: 'fake-token' });
    } else {
      return Promise.reject({ message: 'Credenciais inválidas' });
    }
  })
}));

// Componente de teste com Router
const LoginPageWithRouter = () => (
  <BrowserRouter>
    <LoginPage />
  </BrowserRouter>
);

describe('Testes da Página de Login', () => {
  beforeEach(() => {
    // Limpar mocks antes de cada teste
    jest.clearAllMocks();
    // Limpar localStorage
    localStorage.clear();
  });

  test('Deve renderizar corretamente a página de login', () => {
    render(<LoginPageWithRouter />);
    
    // Verificar elementos principais
    expect(screen.getByRole('heading', { name: /quantum trades/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/usuário/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/senha/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /entrar/i })).toBeInTheDocument();
  });

  test('Deve mostrar erro quando campos estão vazios', async () => {
    render(<LoginPageWithRouter />);
    
    // Clicar no botão de login sem preencher campos
    fireEvent.click(screen.getByRole('button', { name: /entrar/i }));
    
    // Verificar mensagens de erro
    await waitFor(() => {
      expect(screen.getByText(/campo obrigatório/i)).toBeInTheDocument();
    });
  });

  test('Deve realizar login com credenciais corretas', async () => {
    render(<LoginPageWithRouter />);
    
    // Preencher campos
    fireEvent.change(screen.getByLabelText(/usuário/i), { target: { value: 'Rimkus' } });
    fireEvent.change(screen.getByLabelText(/senha/i), { target: { value: 'password123' } });
    
    // Clicar no botão de login
    fireEvent.click(screen.getByRole('button', { name: /entrar/i }));
    
    // Verificar redirecionamento ou sucesso
    await waitFor(() => {
      expect(localStorage.setItem).toHaveBeenCalledWith('token', 'fake-token');
    });
  });

  test('Deve mostrar erro com credenciais incorretas', async () => {
    render(<LoginPageWithRouter />);
    
    // Preencher campos com valores incorretos
    fireEvent.change(screen.getByLabelText(/usuário/i), { target: { value: 'usuario_incorreto' } });
    fireEvent.change(screen.getByLabelText(/senha/i), { target: { value: 'senha_incorreta' } });
    
    // Clicar no botão de login
    fireEvent.click(screen.getByRole('button', { name: /entrar/i }));
    
    // Verificar mensagem de erro
    await waitFor(() => {
      expect(screen.getByText(/credenciais inválidas/i)).toBeInTheDocument();
    });
  });

  test('Deve verificar responsividade em dispositivos móveis', () => {
    // Simular viewport de dispositivo móvel
    window.matchMedia = jest.fn().mockImplementation(query => ({
      matches: query.includes('max-width: 600px'),
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    }));
    
    render(<LoginPageWithRouter />);
    
    // Verificar elementos adaptados para mobile
    // (Depende da implementação específica da responsividade)
    expect(screen.getByRole('heading', { name: /quantum trades/i })).toBeInTheDocument();
  });
});
