/**
 * setupTests.js
 * Configuração unificada para testes automatizados do Quantum Trades
 */
import '@testing-library/jest-dom';
import { configure } from '@testing-library/react';

// Configuração global para testes
configure({
  testIdAttribute: 'data-testid',
});

// Aumenta o timeout para 30 segundos
jest.setTimeout(30000);

// Mock para localStorage
const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};
global.localStorage = localStorageMock;

// Mock para matchMedia (necessário para testes de responsividade)
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(),
    removeListener: jest.fn(),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});
