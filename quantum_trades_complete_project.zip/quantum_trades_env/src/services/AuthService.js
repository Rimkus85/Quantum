/**
 * AuthService.js
 * Serviço de autenticação aprimorado para a fase 2 do Quantum Trades
 * Inclui persistência de sessão com localStorage e expiração de token
 */

class AuthService {
  constructor() {
    this.isAuthenticated = false;
    this.currentUser = null;
    this.token = null;
    this.tokenExpiration = null;
    
    // Constantes para localStorage
    this.STORAGE_KEY_USER = 'quantum_trades_user';
    this.STORAGE_KEY_TOKEN = 'quantum_trades_token';
    this.STORAGE_KEY_EXPIRATION = 'quantum_trades_token_expiration';
    
    // Tempo de expiração do token em milissegundos (8 horas)
    this.TOKEN_EXPIRATION_TIME = 8 * 60 * 60 * 1000;
    
    // Usuários de teste
    this.users = [
      {
        id: 1,
        username: 'Rimkus',
        password: 'password123',
        name: 'Rimkus Trader',
        email: 'rimkus@quantumtrades.com',
        level: 2, // Nível de acesso (1: básico, 2: premium, 3: admin)
        apiKeys: {
          profit: 'profit_api_key_123456',
          binance: 'binance_api_key_789012'
        },
        preferences: {
          theme: 'dark',
          notifications: true,
          twoFactorAuth: false
        },
        lastLogin: '2025-05-28T15:30:00Z'
      },
      {
        id: 2,
        username: 'usuario_teste',
        password: 'teste123',
        name: 'Usuário de Teste',
        email: 'teste@quantumtrades.com',
        level: 1, // Nível de acesso básico
        apiKeys: {
          profit: '',
          binance: ''
        },
        preferences: {
          theme: 'light',
          notifications: true,
          twoFactorAuth: false
        },
        lastLogin: '2025-05-25T10:15:00Z'
      },
      {
        id: 3,
        username: 'admin',
        password: 'admin123',
        name: 'Administrador',
        email: 'admin@quantumtrades.com',
        level: 3, // Nível de acesso admin
        apiKeys: {
          profit: 'profit_api_key_admin',
          binance: 'binance_api_key_admin'
        },
        preferences: {
          theme: 'dark',
          notifications: true,
          twoFactorAuth: true
        },
        lastLogin: '2025-06-01T08:45:00Z'
      }
    ];
    
    // Inicializa a sessão a partir do localStorage
    this.initializeFromStorage();
  }

  /**
   * Inicializa a sessão a partir do localStorage
   * @private
   */
  initializeFromStorage() {
    try {
      // Verifica se está em ambiente com localStorage disponível
      if (typeof window !== 'undefined' && window.localStorage) {
        const storedUser = localStorage.getItem(this.STORAGE_KEY_USER);
        const storedToken = localStorage.getItem(this.STORAGE_KEY_TOKEN);
        const storedExpiration = localStorage.getItem(this.STORAGE_KEY_EXPIRATION);
        
        if (storedUser && storedToken && storedExpiration) {
          const expirationTime = parseInt(storedExpiration, 10);
          
          // Verifica se o token ainda é válido
          if (expirationTime > Date.now()) {
            this.currentUser = JSON.parse(storedUser);
            this.token = storedToken;
            this.tokenExpiration = expirationTime;
            this.isAuthenticated = true;
            
            // Configura temporizador para expiração automática
            this.setupExpirationTimer();
            
            console.log(`Sessão restaurada para: ${this.currentUser.username}`);
          } else {
            // Token expirado, limpa o armazenamento
            console.log('Token expirado, limpando sessão');
            this.clearStorage();
          }
        }
      }
    } catch (error) {
      console.error('Erro ao inicializar sessão do localStorage:', error);
      this.clearStorage();
    }
  }

  /**
   * Salva os dados da sessão no localStorage
   * @private
   */
  saveToStorage() {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        if (this.currentUser && this.token && this.tokenExpiration) {
          localStorage.setItem(this.STORAGE_KEY_USER, JSON.stringify(this.currentUser));
          localStorage.setItem(this.STORAGE_KEY_TOKEN, this.token);
          localStorage.setItem(this.STORAGE_KEY_EXPIRATION, this.tokenExpiration.toString());
        } else {
          this.clearStorage();
        }
      }
    } catch (error) {
      console.error('Erro ao salvar sessão no localStorage:', error);
    }
  }

  /**
   * Limpa os dados da sessão do localStorage
   * @private
   */
  clearStorage() {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.removeItem(this.STORAGE_KEY_USER);
        localStorage.removeItem(this.STORAGE_KEY_TOKEN);
        localStorage.removeItem(this.STORAGE_KEY_EXPIRATION);
      }
    } catch (error) {
      console.error('Erro ao limpar sessão do localStorage:', error);
    }
  }

  /**
   * Configura temporizador para expiração automática do token
   * @private
   */
  setupExpirationTimer() {
    // Limpa qualquer temporizador existente
    if (this.expirationTimer) {
      clearTimeout(this.expirationTimer);
    }
    
    // Calcula o tempo restante até a expiração
    const timeRemaining = this.tokenExpiration - Date.now();
    
    if (timeRemaining > 0) {
      // Configura novo temporizador
      this.expirationTimer = setTimeout(() => {
        console.log('Token expirado automaticamente');
        this.logout();
      }, timeRemaining);
      
      console.log(`Token expira em ${Math.round(timeRemaining / 60000)} minutos`);
    } else {
      // Token já expirou
      this.logout();
    }
  }

  /**
   * Gera um novo token com tempo de expiração
   * @private
   * @returns {Object} Token e tempo de expiração
   */
  generateToken() {
    const token = `qt_token_${Math.random().toString(36).substring(2, 15)}_${Date.now()}`;
    const expiration = Date.now() + this.TOKEN_EXPIRATION_TIME;
    
    return { token, expiration };
  }

  /**
   * Renova o token atual
   * @returns {Promise<Object>} Resultado da renovação
   */
  async renewToken() {
    if (!this.isAuthenticated || !this.currentUser) {
      return {
        success: false,
        message: 'Usuário não autenticado.'
      };
    }
    
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Gera novo token
    const { token, expiration } = this.generateToken();
    this.token = token;
    this.tokenExpiration = expiration;
    
    // Salva no localStorage
    this.saveToStorage();
    
    // Configura temporizador para expiração
    this.setupExpirationTimer();
    
    console.log(`Token renovado para: ${this.currentUser.username}`);
    
    return {
      success: true,
      token: this.token,
      expiration: this.tokenExpiration,
      message: 'Token renovado com sucesso!'
    };
  }

  /**
   * Realiza login do usuário
   * @param {string} username - Nome de usuário
   * @param {string} password - Senha
   * @returns {Promise<Object>} Resultado da autenticação
   */
  async login(username, password) {
    console.log(`Tentativa de login: ${username}`);
    
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Busca usuário
    const user = this.users.find(u => 
      u.username.toLowerCase() === username.toLowerCase() && 
      u.password === password
    );
    
    if (user) {
      // Login bem-sucedido
      this.isAuthenticated = true;
      this.currentUser = { ...user };
      delete this.currentUser.password; // Remove senha dos dados do usuário
      
      // Gera token com expiração
      const { token, expiration } = this.generateToken();
      this.token = token;
      this.tokenExpiration = expiration;
      
      // Salva no localStorage
      this.saveToStorage();
      
      // Configura temporizador para expiração
      this.setupExpirationTimer();
      
      // Atualiza último login
      user.lastLogin = new Date().toISOString();
      
      console.log(`Login bem-sucedido: ${username}`);
      
      return {
        success: true,
        user: this.currentUser,
        token: this.token,
        expiration: this.tokenExpiration,
        message: 'Login realizado com sucesso!'
      };
    } else {
      // Login falhou
      console.log(`Login falhou: ${username}`);
      
      return {
        success: false,
        message: 'Nome de usuário ou senha incorretos.'
      };
    }
  }

  /**
   * Realiza logout do usuário
   * @returns {Promise<Object>} Resultado do logout
   */
  async logout() {
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Limpa temporizador de expiração
    if (this.expirationTimer) {
      clearTimeout(this.expirationTimer);
      this.expirationTimer = null;
    }
    
    this.isAuthenticated = false;
    this.currentUser = null;
    this.token = null;
    this.tokenExpiration = null;
    
    // Limpa localStorage
    this.clearStorage();
    
    console.log('Logout realizado com sucesso');
    
    return {
      success: true,
      message: 'Logout realizado com sucesso!'
    };
  }

  /**
   * Verifica se o usuário está autenticado
   * @returns {boolean} Status de autenticação
   */
  isUserAuthenticated() {
    // Verifica se o token expirou
    if (this.tokenExpiration && this.tokenExpiration < Date.now()) {
      console.log('Token expirado durante verificação');
      this.logout();
      return false;
    }
    
    return this.isAuthenticated;
  }

  /**
   * Obtém dados do usuário atual
   * @returns {Object|null} Dados do usuário ou null se não autenticado
   */
  getCurrentUser() {
    // Verifica se o token expirou
    if (this.tokenExpiration && this.tokenExpiration < Date.now()) {
      console.log('Token expirado durante obtenção de usuário');
      this.logout();
      return null;
    }
    
    return this.currentUser;
  }

  /**
   * Obtém o token atual
   * @returns {string|null} Token ou null se não autenticado
   */
  getToken() {
    // Verifica se o token expirou
    if (this.tokenExpiration && this.tokenExpiration < Date.now()) {
      console.log('Token expirado durante obtenção de token');
      this.logout();
      return null;
    }
    
    return this.token;
  }

  /**
   * Obtém o tempo de expiração do token
   * @returns {number|null} Timestamp de expiração ou null se não autenticado
   */
  getTokenExpiration() {
    return this.tokenExpiration;
  }

  /**
   * Verifica se o usuário tem permissão para acessar determinado recurso
   * @param {number} requiredLevel - Nível de acesso necessário
   * @returns {boolean} Se o usuário tem permissão
   */
  hasPermission(requiredLevel) {
    if (!this.isUserAuthenticated() || !this.currentUser) {
      return false;
    }
    
    return this.currentUser.level >= requiredLevel;
  }

  /**
   * Atualiza dados do usuário
   * @param {Object} userData - Novos dados do usuário
   * @returns {Promise<Object>} Resultado da atualização
   */
  async updateUserData(userData) {
    if (!this.isUserAuthenticated() || !this.currentUser) {
      return {
        success: false,
        message: 'Usuário não autenticado.'
      };
    }
    
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Encontra o usuário na lista
    const userIndex = this.users.findIndex(u => u.id === this.currentUser.id);
    
    if (userIndex !== -1) {
      // Atualiza dados permitidos (exceto id, username e password)
      const updatedUser = { ...this.users[userIndex] };
      
      if (userData.name) updatedUser.name = userData.name;
      if (userData.email) updatedUser.email = userData.email;
      if (userData.apiKeys) updatedUser.apiKeys = { ...updatedUser.apiKeys, ...userData.apiKeys };
      if (userData.preferences) updatedUser.preferences = { ...updatedUser.preferences, ...userData.preferences };
      
      // Atualiza na lista de usuários
      this.users[userIndex] = updatedUser;
      
      // Atualiza usuário atual
      this.currentUser = { ...updatedUser };
      delete this.currentUser.password;
      
      // Atualiza no localStorage
      this.saveToStorage();
      
      console.log(`Dados do usuário atualizados: ${this.currentUser.username}`);
      
      return {
        success: true,
        user: this.currentUser,
        message: 'Dados atualizados com sucesso!'
      };
    } else {
      return {
        success: false,
        message: 'Usuário não encontrado.'
      };
    }
  }

  /**
   * Simula recuperação de senha
   * @param {string} email - Email do usuário
   * @returns {Promise<Object>} Resultado da recuperação
   */
  async recoverPassword(email) {
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const user = this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (user) {
      console.log(`Recuperação de senha solicitada para: ${email}`);
      
      return {
        success: true,
        message: 'Instruções para recuperação de senha foram enviadas para seu email.'
      };
    } else {
      return {
        success: false,
        message: 'Email não encontrado em nossa base de dados.'
      };
    }
  }

  /**
   * Simula registro de novo usuário
   * @param {Object} userData - Dados do novo usuário
   * @returns {Promise<Object>} Resultado do registro
   */
  async register(userData) {
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    // Verifica se username já existe
    if (this.users.some(u => u.username.toLowerCase() === userData.username.toLowerCase())) {
      return {
        success: false,
        message: 'Nome de usuário já está em uso.'
      };
    }
    
    // Verifica se email já existe
    if (this.users.some(u => u.email.toLowerCase() === userData.email.toLowerCase())) {
      return {
        success: false,
        message: 'Email já está em uso.'
      };
    }
    
    // Cria novo usuário
    const newUser = {
      id: this.users.length + 1,
      username: userData.username,
      password: userData.password,
      name: userData.name || userData.username,
      email: userData.email,
      level: 1, // Novos usuários começam no nível básico
      apiKeys: {
        profit: userData.apiKeys?.profit || '',
        binance: userData.apiKeys?.binance || ''
      },
      preferences: {
        theme: 'light',
        notifications: true,
        twoFactorAuth: false
      },
      lastLogin: new Date().toISOString()
    };
    
    // Adiciona à lista de usuários
    this.users.push(newUser);
    
    console.log(`Novo usuário registrado: ${newUser.username}`);
    
    return {
      success: true,
      message: 'Registro realizado com sucesso! Você já pode fazer login.'
    };
  }
  
  /**
   * Atualiza o nível de acesso do usuário
   * @param {number} userId - ID do usuário
   * @param {number} newLevel - Novo nível de acesso
   * @returns {Promise<Object>} Resultado da atualização
   */
  async updateUserLevel(userId, newLevel) {
    // Verifica se o usuário atual é administrador
    if (!this.isUserAuthenticated() || !this.currentUser || this.currentUser.level < 3) {
      return {
        success: false,
        message: 'Permissão negada. Apenas administradores podem atualizar níveis de acesso.'
      };
    }
    
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Encontra o usuário na lista
    const userIndex = this.users.findIndex(u => u.id === userId);
    
    if (userIndex !== -1) {
      // Atualiza o nível do usuário
      this.users[userIndex].level = newLevel;
      
      // Se for o usuário atual, atualiza também o usuário atual
      if (this.currentUser.id === userId) {
        this.currentUser.level = newLevel;
        this.saveToStorage();
      }
      
      console.log(`Nível de acesso atualizado para usuário ID ${userId}: ${newLevel}`);
      
      return {
        success: true,
        message: 'Nível de acesso atualizado com sucesso!'
      };
    } else {
      return {
        success: false,
        message: 'Usuário não encontrado.'
      };
    }
  }
  
  /**
   * Obtém a lista de níveis de acesso disponíveis
   * @returns {Array} Lista de níveis de acesso
   */
  getAccessLevels() {
    return [
      { id: 1, name: 'Básico', description: 'Acesso às funcionalidades básicas da plataforma' },
      { id: 2, name: 'Premium', description: 'Acesso a funcionalidades avançadas e análises exclusivas' },
      { id: 3, name: 'Admin', description: 'Acesso completo a todas as funcionalidades e configurações' }
    ];
  }
}

// Exporta uma instância única do serviço
const authService = new AuthService();
export default authService;
