/**
 * StatisticalAnalysis.js
 * Serviço para análise estatística de dados históricos e cálculo de potencial de lucro
 */

class StatisticalAnalysis {
  /**
   * Calcula a regressão estatística com base em dados históricos
   * @param {string} symbol - Símbolo do ativo (ex: PETR4)
   * @param {Array} historicalData - Dados históricos de 10 anos
   * @param {Array} recentData - Dados dos últimos 2 anos para validação
   * @param {Object} pattern - Padrão a ser analisado (ex: {hiloChange: true, hammerSignal: true, volumeIncrease: 2})
   * @returns {Object} Resultado da análise com potencial de lucro e ajuste de gain
   */
  static calculateProfitPotential(symbol, historicalData, recentData, pattern) {
    // Filtra os dados históricos para encontrar ocorrências do padrão
    const historicalMatches = this.findPatternMatches(historicalData, pattern);
    
    // Calcula o potencial médio de lucro com base nas ocorrências históricas
    const historicalProfitPotential = this.calculateAverageProfitPotential(historicalMatches);
    
    // Filtra os dados recentes para encontrar ocorrências do padrão
    const recentMatches = this.findPatternMatches(recentData, pattern);
    
    // Calcula o potencial médio de lucro com base nas ocorrências recentes
    const recentProfitPotential = this.calculateAverageProfitPotential(recentMatches);
    
    // Ajusta o gain com base na comparação entre potencial histórico e recente
    const adjustedGain = this.adjustGainBasedOnComparison(historicalProfitPotential, recentProfitPotential);
    
    return {
      symbol,
      pattern,
      historicalProfitPotential,
      recentProfitPotential,
      adjustedGain,
      confidence: this.calculateConfidence(historicalMatches.length, recentMatches.length),
      recommendation: this.generateRecommendation(adjustedGain)
    };
  }
  
  /**
   * Encontra ocorrências de um padrão específico nos dados
   * @param {Array} data - Dados históricos ou recentes
   * @param {Object} pattern - Padrão a ser encontrado
   * @returns {Array} Ocorrências do padrão nos dados
   */
  static findPatternMatches(data, pattern) {
    return data.filter(day => {
      // Verifica mudança no HiLo
      const hiloChangeMatch = !pattern.hiloChange || this.checkHiLoChange(day, data[data.indexOf(day) - 1]);
      
      // Verifica sinal de martelo
      const hammerSignalMatch = !pattern.hammerSignal || this.checkHammerSignal(day);
      
      // Verifica aumento de volume
      const volumeIncreaseMatch = !pattern.volumeIncrease || this.checkVolumeIncrease(day, data[data.indexOf(day) - 1], pattern.volumeIncrease);
      
      return hiloChangeMatch && hammerSignalMatch && volumeIncreaseMatch;
    });
  }
  
  /**
   * Verifica se houve mudança no padrão HiLo
   * @param {Object} currentDay - Dados do dia atual
   * @param {Object} previousDay - Dados do dia anterior
   * @returns {boolean} Verdadeiro se houve mudança no HiLo
   */
  static checkHiLoChange(currentDay, previousDay) {
    if (!previousDay) return false;
    
    const previousHiLo = previousDay.high / previousDay.low;
    const currentHiLo = currentDay.high / currentDay.low;
    
    // Considera mudança significativa se a diferença for maior que 5%
    return Math.abs(currentHiLo - previousHiLo) / previousHiLo > 0.05;
  }
  
  /**
   * Verifica se o candle forma um padrão de martelo
   * @param {Object} day - Dados do dia
   * @returns {boolean} Verdadeiro se for um padrão de martelo
   */
  static checkHammerSignal(day) {
    const bodySize = Math.abs(day.close - day.open);
    const totalSize = day.high - day.low;
    const lowerShadow = Math.min(day.open, day.close) - day.low;
    
    // Critérios para padrão de martelo:
    // 1. Corpo pequeno (menos de 30% do tamanho total)
    // 2. Sombra inferior longa (pelo menos 60% do tamanho total)
    return bodySize / totalSize < 0.3 && lowerShadow / totalSize > 0.6;
  }
  
  /**
   * Verifica se houve aumento de volume conforme o percentual especificado
   * @param {Object} currentDay - Dados do dia atual
   * @param {Object} previousDay - Dados do dia anterior
   * @param {number} percentIncrease - Percentual de aumento esperado
   * @returns {boolean} Verdadeiro se o volume aumentou conforme esperado
   */
  static checkVolumeIncrease(currentDay, previousDay, percentIncrease) {
    if (!previousDay) return false;
    
    const increaseRatio = currentDay.volume / previousDay.volume;
    return increaseRatio > (1 + percentIncrease / 100);
  }
  
  /**
   * Calcula o potencial médio de lucro com base nas ocorrências encontradas
   * @param {Array} matches - Ocorrências do padrão
   * @returns {number} Potencial médio de lucro em percentual
   */
  static calculateAverageProfitPotential(matches) {
    if (matches.length === 0) return 0;
    
    const profitPotentials = matches.map(match => {
      const entryPrice = match.close;
      const subsequentDays = match.subsequentDays || [];
      
      if (subsequentDays.length === 0) return 0;
      
      // Encontra o preço máximo nos dias subsequentes (até 30 dias)
      const maxPrice = Math.max(...subsequentDays.slice(0, 30).map(day => day.high));
      
      // Calcula o potencial de lucro em percentual
      return ((maxPrice - entryPrice) / entryPrice) * 100;
    });
    
    // Calcula a média dos potenciais de lucro
    return profitPotentials.reduce((sum, potential) => sum + potential, 0) / profitPotentials.length;
  }
  
  /**
   * Ajusta o gain com base na comparação entre potencial histórico e recente
   * @param {number} historicalPotential - Potencial médio histórico
   * @param {number} recentPotential - Potencial médio recente
   * @returns {number} Gain ajustado
   */
  static adjustGainBasedOnComparison(historicalPotential, recentPotential) {
    // Se o potencial recente for maior que o histórico, mantém o histórico
    if (recentPotential >= historicalPotential) {
      return historicalPotential;
    }
    
    // Se o potencial recente for menor, reduz o gain para o valor recente
    return recentPotential;
  }
  
  /**
   * Calcula o nível de confiança da análise
   * @param {number} historicalMatchesCount - Quantidade de ocorrências históricas
   * @param {number} recentMatchesCount - Quantidade de ocorrências recentes
   * @returns {number} Nível de confiança (0-100)
   */
  static calculateConfidence(historicalMatchesCount, recentMatchesCount) {
    // Fatores que influenciam a confiança:
    // 1. Quantidade de ocorrências históricas (mais é melhor)
    // 2. Quantidade de ocorrências recentes (mais é melhor)
    // 3. Proporção entre ocorrências recentes e históricas (mais próximo de 1 é melhor)
    
    const historicalFactor = Math.min(historicalMatchesCount / 10, 1); // Máximo de 10 ocorrências para 100%
    const recentFactor = Math.min(recentMatchesCount / 5, 1); // Máximo de 5 ocorrências para 100%
    
    let proportionFactor = 1;
    if (historicalMatchesCount > 0) {
      const proportion = recentMatchesCount / historicalMatchesCount;
      proportionFactor = proportion > 1 ? 1 : proportion;
    }
    
    return Math.round((historicalFactor * 0.4 + recentFactor * 0.4 + proportionFactor * 0.2) * 100);
  }
  
  /**
   * Gera uma recomendação com base no gain ajustado
   * @param {number} adjustedGain - Gain ajustado
   * @returns {string} Recomendação
   */
  static generateRecommendation(adjustedGain) {
    if (adjustedGain >= 10) {
      return "Forte potencial de alta. Recomendação de compra.";
    } else if (adjustedGain >= 5) {
      return "Potencial moderado de alta. Considerar compra com cautela.";
    } else if (adjustedGain >= 2) {
      return "Potencial baixo de alta. Monitorar para oportunidades melhores.";
    } else {
      return "Potencial insuficiente. Não recomendado para compra.";
    }
  }
}

export default StatisticalAnalysis;
