/**
 * MainLayout.js atualizado
 * Layout principal com menu lateral atualizado para controle de acesso
 */

import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { 
  Box, 
  Drawer, 
  AppBar, 
  Toolbar, 
  IconButton, 
  Typography,
  Avatar,
  Menu,
  MenuItem,
  Divider,
  useMediaQuery
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import MenuIcon from '@mui/icons-material/Menu';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import LogoutIcon from '@mui/icons-material/Logout';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

// Logo
import LogoQuantumTrades from '../assets/logo-quantum-trades.png';

// Menu com controle de acesso
import MenuWithAccessControl from '../components/MenuWithAccessControl';

// Largura do drawer
const drawerWidth = 240;

/**
 * Layout principal da aplicação
 * 
 * @param {Object} props - Propriedades do componente
 * @param {React.ReactNode} props.children - Conteúdo a ser renderizado
 * @returns {React.ReactElement} Layout principal
 */
const MainLayout = ({ children }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
  
  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  
  const handleProfileMenuClose = () => {
    setAnchorEl(null);
  };
  
  const handleLogout = async () => {
    handleProfileMenuClose();
    await logout();
    navigate('/login');
  };
  
  const handleNavigateToProfile = () => {
    handleProfileMenuClose();
    navigate('/profile');
  };
  
  // Conteúdo do drawer
  const drawer = (
    <MenuWithAccessControl />
  );
  
  return (
    <Box sx={{ display: 'flex' }}>
      {/* AppBar */}
      <AppBar
        position="fixed"
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
          backgroundColor: '#10263d'
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="abrir menu"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          
          <Box sx={{ display: { xs: 'none', sm: 'block' } }}>
            <img 
              src={LogoQuantumTrades} 
              alt="Quantum Trades" 
              style={{ height: 40 }} 
            />
          </Box>
          
          <Box sx={{ flexGrow: 1 }} />
          
          <IconButton
            color="inherit"
            aria-label="perfil do usuário"
            edge="end"
            onClick={handleProfileMenuOpen}
          >
            {user?.profileImage ? (
              <Avatar 
                src={user.profileImage} 
                alt={user.name} 
                sx={{ width: 32, height: 32 }}
              />
            ) : (
              <AccountCircleIcon />
            )}
          </IconButton>
          
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleProfileMenuClose}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
          >
            <Box sx={{ px: 2, py: 1 }}>
              <Typography variant="subtitle1" fontWeight="bold">
                {user?.name || 'Usuário'}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {user?.email || 'email@exemplo.com'}
              </Typography>
            </Box>
            
            <Divider />
            
            <MenuItem onClick={handleNavigateToProfile}>
              <AccountCircleIcon fontSize="small" sx={{ mr: 1 }} />
              <Typography variant="body2">Meu Perfil</Typography>
            </MenuItem>
            
            <MenuItem onClick={handleLogout}>
              <LogoutIcon fontSize="small" sx={{ mr: 1 }} />
              <Typography variant="body2">Sair</Typography>
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>
      
      {/* Drawer para dispositivos móveis */}
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true, // Melhor desempenho em dispositivos móveis
          }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { 
              boxSizing: 'border-box', 
              width: drawerWidth,
              backgroundColor: theme.palette.background.default
            },
          }}
        >
          <Box sx={{ p: 2, display: 'flex', alignItems: 'center' }}>
            <img 
              src={LogoQuantumTrades} 
              alt="Quantum Trades" 
              style={{ height: 40 }} 
            />
          </Box>
          <Divider />
          {drawer}
        </Drawer>
        
        {/* Drawer permanente para desktop */}
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { 
              boxSizing: 'border-box', 
              width: drawerWidth,
              backgroundColor: theme.palette.background.default,
              borderRight: `1px solid ${theme.palette.divider}`
            },
          }}
          open
        >
          <Box sx={{ p: 2, display: 'flex', alignItems: 'center' }}>
            <img 
              src={LogoQuantumTrades} 
              alt="Quantum Trades" 
              style={{ height: 40 }} 
            />
          </Box>
          <Divider />
          {drawer}
        </Drawer>
      </Box>
      
      {/* Conteúdo principal */}
      <Box
        component="main"
        sx={{ 
          flexGrow: 1, 
          p: 3, 
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          marginTop: '64px' // Altura da AppBar
        }}
      >
        {children}
      </Box>
    </Box>
  );
};

MainLayout.propTypes = {
  children: PropTypes.node.isRequired,
};

export default MainLayout;
