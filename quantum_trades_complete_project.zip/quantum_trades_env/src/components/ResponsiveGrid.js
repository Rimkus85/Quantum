/**
 * ResponsiveGrid.js
 * Componente de grid responsivo para o Quantum Trades
 * Corrigido para melhor adaptação em telas pequenas
 */

import React from 'react';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

/**
 * Componente de grid responsivo que se adapta a diferentes tamanhos de tela
 * 
 * @param {Object} props - Propriedades do componente
 * @param {React.ReactNode} props.children - Elementos filhos do grid
 * @param {number} props.spacing - Espaçamento entre os itens do grid (desktop)
 * @param {number} props.mobileSpacing - Espaçamento entre os itens do grid (mobile)
 * @param {Object} props.sx - Estilos adicionais para o grid
 * @returns {React.ReactElement} Grid responsivo
 */
const ResponsiveGrid = ({ 
  children, 
  spacing = 3, 
  mobileSpacing = 2,
  sx = {}
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  return (
    <Box sx={{ 
      width: '100%', 
      overflow: 'visible',
      ...sx 
    }}>
      <Grid 
        container 
        spacing={isMobile ? mobileSpacing : spacing}
        sx={{
          overflow: 'visible',
          '& .MuiGrid-item': {
            display: 'flex',
            minHeight: isMobile ? 180 : 220,
            // Ajuste para melhor adaptação em telas pequenas
            width: '100%'
          }
        }}
      >
        {React.Children.map(children, (child, index) => (
          <Grid 
            item 
            xs={12} 
            sm={6} 
            md={4} 
            lg={3} 
            key={index}
            sx={{
              // Ajuste para garantir que o conteúdo não seja cortado
              '& > *': {
                width: '100%',
                height: '100%'
              }
            }}
          >
            {child}
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default ResponsiveGrid;
