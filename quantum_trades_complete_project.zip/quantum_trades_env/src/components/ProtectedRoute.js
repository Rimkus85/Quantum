/**
 * ProtectedRoute.js
 * Componente para proteger rotas com base no nível de acesso do usuário
 */

import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import PropTypes from 'prop-types';
import { useAuth } from '../contexts/AuthContext';
import { ACCESS_LEVELS } from '../utils/UserProfileStructure';

/**
 * Componente para proteger rotas com base no nível de acesso do usuário
 * 
 * @param {Object} props - Propriedades do componente
 * @param {React.ReactNode} props.children - Componente a ser renderizado se o usuário tiver permissão
 * @param {number} props.requiredLevel - Nível de acesso necessário para acessar a rota
 * @returns {React.ReactElement} Componente renderizado ou redirecionamento
 */
const ProtectedRoute = ({ children, requiredLevel = ACCESS_LEVELS.BASIC }) => {
  const { isAuthenticated, hasPermission } = useAuth();
  const location = useLocation();
  
  // Se o usuário não estiver autenticado, redireciona para a página de login
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  // Verifica se o usuário tem o nível de permissão necessário
  const hasAccess = hasPermission(requiredLevel);
  
  if (!hasAccess) {
    // Se o usuário não tiver permissão, redireciona para uma página de acesso negado
    return <Navigate to="/access-denied" state={{ requiredLevel }} replace />;
  }
  
  // Se o usuário tiver permissão, renderiza o componente
  return children;
};

ProtectedRoute.propTypes = {
  children: PropTypes.node.isRequired,
  requiredLevel: PropTypes.number
};

export default ProtectedRoute;
