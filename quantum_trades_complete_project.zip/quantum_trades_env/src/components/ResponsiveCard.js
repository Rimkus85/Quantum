/**
 * ResponsiveCard.js
 * Componente de card responsivo para o Quantum Trades
 * Corrigido para evitar corte de texto em telas pequenas
 */

import React from 'react';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';

/**
 * Componente de card responsivo que se adapta a diferentes tamanhos de tela
 * 
 * @param {Object} props - Propriedades do componente
 * @param {string} props.title - Título do card
 * @param {string} props.subtitle - Subtítulo do card (opcional)
 * @param {React.ReactNode} props.content - Conteúdo do card
 * @param {number} props.elevation - Elevação do card (sombra)
 * @param {number} props.minHeight - Altura mínima do card
 * @param {Object} props.sx - Estilos adicionais para o card
 * @returns {React.ReactElement} Card responsivo
 */
const ResponsiveCard = ({ 
  title, 
  subtitle, 
  content, 
  elevation = 1, 
  minHeight,
  sx = {}
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  return (
    <Card 
      elevation={elevation}
      sx={{ 
        minHeight: minHeight || (isMobile ? 180 : 220),
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        borderRadius: 2,
        overflow: 'visible',
        ...sx
      }}
    >
      <CardContent sx={{ 
        p: isMobile ? 2 : 3, 
        pb: isMobile ? 1 : 2,
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column'
      }}>
        <Box sx={{ mb: subtitle ? 0.5 : 2 }}>
          <Typography 
            variant={isMobile ? "h6" : "h5"} 
            component="h2" 
            sx={{ 
              fontWeight: 600,
              fontSize: isMobile ? '1rem' : '1.25rem', // Ajuste de tamanho para telas pequenas
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis' // Evita corte de texto com ellipsis
            }}
          >
            {title}
          </Typography>
          
          {subtitle && (
            <Typography 
              variant="body2" 
              color="text.secondary"
              sx={{
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis' // Evita corte de texto com ellipsis
              }}
            >
              {subtitle}
            </Typography>
          )}
        </Box>
        
        {title && <Divider sx={{ mb: 2 }} />}
        
        <Box sx={{ 
          flexGrow: 1, 
          overflow: 'auto',
          // Ajuste para evitar corte de conteúdo
          '& .MuiTypography-root': {
            overflow: 'hidden',
            textOverflow: 'ellipsis'
          }
        }}>
          {content}
        </Box>
      </CardContent>
    </Card>
  );
};

export default ResponsiveCard;
