import axios from 'axios';

// Configuração base para APIs
const baseConfig = {
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  }
};

// API para B3
const b3Api = axios.create({
  ...baseConfig,
  baseURL: '/api/b3',
});

// API para S&P500
const sp500Api = axios.create({
  ...baseConfig,
  baseURL: '/api/sp500',
});

// API para Binance (criptomoedas)
const binanceApi = axios.create({
  ...baseConfig,
  baseURL: '/api/crypto',
});

// API para ProfitChart Pro
const profitChartApi = axios.create({
  ...baseConfig,
  baseURL: '/api/profitchart',
});

// Funções para obter dados de mercado
export const getMarketData = async (market) => {
  try {
    let response;
    
    switch(market) {
      case 'b3':
        response = await b3Api.get('/market-data');
        break;
      case 'sp500':
        response = await sp500Api.get('/market-data');
        break;
      case 'crypto':
        response = await binanceApi.get('/market-data');
        break;
      default:
        throw new Error('Mercado não suportado');
    }
    
    return response.data;
  } catch (error) {
    console.error(`Erro ao obter dados do mercado ${market}:`, error);
    // Dados mockados para desenvolvimento
    return getMockMarketData(market);
  }
};

// Funções para obter sinais de trading
export const getTradingSignals = async (market, filters = {}) => {
  try {
    let response;
    const queryParams = new URLSearchParams(filters).toString();
    
    switch(market) {
      case 'b3':
        response = await b3Api.get(`/signals?${queryParams}`);
        break;
      case 'sp500':
        response = await sp500Api.get(`/signals?${queryParams}`);
        break;
      case 'crypto':
        response = await binanceApi.get(`/signals?${queryParams}`);
        break;
      case 'all':
        // Obter sinais de todos os mercados
        const [b3Response, sp500Response, cryptoResponse] = await Promise.all([
          b3Api.get(`/signals?${queryParams}`),
          sp500Api.get(`/signals?${queryParams}`),
          binanceApi.get(`/signals?${queryParams}`)
        ]);
        
        return {
          b3: b3Response.data,
          sp500: sp500Response.data,
          crypto: cryptoResponse.data
        };
      default:
        throw new Error('Mercado não suportado');
    }
    
    return response.data;
  } catch (error) {
    console.error(`Erro ao obter sinais de trading para ${market}:`, error);
    // Dados mockados para desenvolvimento
    return getMockTradingSignals(market);
  }
};

// Funções para o agente de execução
export const calculateRiskReturn = async (capital, signal) => {
  try {
    const response = await axios.post('/api/execution/risk-return', {
      capital,
      signal
    });
    
    return response.data;
  } catch (error) {
    console.error('Erro ao calcular risco/retorno:', error);
    // Cálculo mockado para desenvolvimento
    return getMockRiskReturn(capital, signal);
  }
};

export const executeOrder = async (orderData) => {
  try {
    const response = await axios.post('/api/execution/order', orderData);
    
    return response.data;
  } catch (error) {
    console.error('Erro ao executar ordem:', error);
    // Resposta mockada para desenvolvimento
    return {
      success: true,
      orderId: `mock-${Date.now()}`,
      message: 'Ordem simulada executada com sucesso'
    };
  }
};

// Funções para IA adaptativa
export const getAiInsights = async (ticker, market) => {
  try {
    const response = await axios.get(`/api/ai/insights?ticker=${ticker}&market=${market}`);
    
    return response.data;
  } catch (error) {
    console.error('Erro ao obter insights da IA:', error);
    // Dados mockados para desenvolvimento
    return getMockAiInsights(ticker, market);
  }
};

export const getAdaptationMetrics = async () => {
  try {
    const response = await axios.get('/api/ai/adaptation-metrics');
    
    return response.data;
  } catch (error) {
    console.error('Erro ao obter métricas de adaptação:', error);
    // Dados mockados para desenvolvimento
    return getMockAdaptationMetrics();
  }
};

// Funções para relatórios analíticos
export const getPerformanceReport = async (filters = {}) => {
  try {
    const queryParams = new URLSearchParams(filters).toString();
    const response = await axios.get(`/api/reports/performance?${queryParams}`);
    
    return response.data;
  } catch (error) {
    console.error('Erro ao obter relatório de performance:', error);
    // Dados mockados para desenvolvimento
    return getMockPerformanceReport(filters);
  }
};

export const getVolumeReport = async (filters = {}) => {
  try {
    const queryParams = new URLSearchParams(filters).toString();
    const response = await axios.get(`/api/reports/volume?${queryParams}`);
    
    return response.data;
  } catch (error) {
    console.error('Erro ao obter relatório de volume:', error);
    // Dados mockados para desenvolvimento
    return getMockVolumeReport(filters);
  }
};

// Dados mockados para desenvolvimento
const getMockMarketData = (market) => {
  switch(market) {
    case 'b3':
      return {
        index: {
          name: 'IBOVESPA',
          value: '128.457,98',
          change: 1254.32,
          changePercent: 0.98
        },
        topGainers: [
          { ticker: 'PETR4', name: 'Petrobras', change: 3.45 },
          { ticker: 'VALE3', name: 'Vale', change: 2.87 },
          { ticker: 'ITUB4', name: 'Itaú Unibanco', change: 2.12 }
        ],
        topLosers: [
          { ticker: 'MGLU3', name: 'Magazine Luiza', change: -4.23 },
          { ticker: 'CIEL3', name: 'Cielo', change: -3.78 },
          { ticker: 'BBDC4', name: 'Bradesco', change: -2.56 }
        ]
      };
    case 'sp500':
      return {
        index: {
          name: 'S&P 500',
          value: '5.123,45',
          change: -12.67,
          changePercent: -0.25
        },
        topGainers: [
          { ticker: 'AAPL', name: 'Apple Inc.', change: 2.34 },
          { ticker: 'MSFT', name: 'Microsoft', change: 1.98 },
          { ticker: 'AMZN', name: 'Amazon', change: 1.76 }
        ],
        topLosers: [
          { ticker: 'META', name: 'Meta Platforms', change: -3.21 },
          { ticker: 'TSLA', name: 'Tesla', change: -2.87 },
          { ticker: 'NFLX', name: 'Netflix', change: -1.98 }
        ]
      };
    case 'crypto':
      return {
        topCryptos: [
          { 
            ticker: 'BTC/USD', 
            name: 'Bitcoin', 
            value: '67.892,45',
            change: 1432.67,
            changePercent: 2.15
          },
          { 
            ticker: 'ETH/USD', 
            name: 'Ethereum', 
            value: '3.456,78',
            change: 87.45,
            changePercent: 2.60
          },
          { 
            ticker: 'SOL/USD', 
            name: 'Solana', 
            value: '142,56',
            change: 5.67,
            changePercent: 4.14
          },
          { 
            ticker: 'AVAX/USD', 
            name: 'Avalanche', 
            value: '38,92',
            change: 1.23,
            changePercent: 3.26
          },
          { 
            ticker: 'ONE/USD', 
            name: 'Harmony', 
            value: '0,0345',
            change: 0.0023,
            changePercent: 7.14
          },
          { 
            ticker: 'XRP/USD', 
            name: 'Ripple', 
            value: '0,5678',
            change: -0.0234,
            changePercent: -3.96
          }
        ]
      };
    default:
      return {};
  }
};

const getMockTradingSignals = (market) => {
  const signals = [
    {
      id: 1,
      ticker: 'PETR4',
      market: 'B3',
      signal: 'Compra',
      pattern: 'OCO',
      volume: '1.5x',
      stopLoss: -5.2,
      stopGain: 12.8,
      score: 8.5,
      timestamp: '2025-05-17T10:30:00'
    },
    {
      id: 2,
      ticker: 'AAPL',
      market: 'S&P500',
      signal: 'Venda',
      pattern: 'Topo Duplo',
      volume: '2.1x',
      stopLoss: -4.5,
      stopGain: 10.2,
      score: 7.8,
      timestamp: '2025-05-17T11:15:00'
    },
    {
      id: 3,
      ticker: 'BTC',
      market: 'CRYPTO',
      signal: 'Compra',
      pattern: 'Engolfo',
      volume: '3.2x',
      stopLoss: -6.5,
      stopGain: 15.7,
      score: 9.2,
      timestamp: '2025-05-17T12:45:00'
    },
    {
      id: 4,
      ticker: 'VALE3',
      market: 'B3',
      signal: 'Compra',
      pattern: 'Mulher Grávida',
      volume: '1.8x',
      stopLoss: -4.8,
      stopGain: 11.5,
      score: 8.1,
      timestamp: '2025-05-17T13:20:00'
    },
    {
      id: 5,
      ticker: 'MSFT',
      market: 'S&P500',
      signal: 'Venda',
      pattern: 'OCO',
      volume: '1.3x',
      stopLoss: -3.9,
      stopGain: 9.8,
      score: 6.7,
      timestamp: '2025-05-17T14:05:00'
    },
    {
      id: 6,
      ticker: 'ETH',
      market: 'CRYPTO',
      signal: 'Compra',
      pattern: 'Engolfo',
      volume: '2.7x',
      stopLoss: -7.2,
      stopGain: 18.5,
      score: 8.9,
      timestamp: '2025-05-17T14:30:00'
    }
  ];
  
  if (market === 'all') {
    return {
      b3: signals.filter(s => s.market === 'B3'),
      sp500: signals.filter(s => s.market === 'S&P500'),
      crypto: signals.filter(s => s.market === 'CRYPTO')
    };
  }
  
  switch(market) {
    case 'b3':
      return signals.filter(s => s.market === 'B3');
    case 'sp500':
      return signals.filter(s => s.market === 'S&P500');
    case 'crypto':
      return signals.filter(s => s.market === 'CRYPTO');
    default:
      return signals;
  }
};

const getMockRiskReturn = (capital, signal) => {
  const positionSize = capital * 0.05; // 5% do capital
  const riskAmount = positionSize * (signal.stopLoss / 100);
  const potentialReturn = positionSize * (signal.stopGain / 100);
  const riskReturnRatio = Math.abs(potentialReturn / riskAmount);
  
  return {
    recommendedPositionSize: positionSize,
    riskAmount: Math.abs(riskAmount),
    potentialReturn,
    riskReturnRatio,
    confidence: signal.score / 10,
    recommendation: signal.score >= 7 ? 'Executar' : 'Avaliar'
  };
};

const getMockAiInsights = (ticker, market) => {
  return {
    ticker,
    market,
    insights: [
      {
        type: 'pattern',
        description: 'Padrão de reversão detectado com 78% de confiança',
        confidence: 0.78
      },
      {
        type: 'volume',
        description: 'Volume acima da média em 2.3x, indicando forte interesse',
        confidence: 0.85
      },
      {
        type: 'trend',
        description: 'Tendência de alta confirmada nos últimos 3 períodos',
        confidence: 0.92
      }
    ],
    historicalPerformance: {
      signalAccuracy: 0.82,
      averageReturn: 14.5,
      averageLoss: -6.2,
      winLossRatio: 2.34
    },
    adaptations: [
      {
        date: '2025-05-10',
        description: 'Ajuste de stop loss de -5.0% para -5.2% baseado em volatilidade recente',
        impact: 'Redução de falsos stops em 12%'
      },
      {
        date: '2025-05-05',
        description: 'Aumento do peso do volume na análise de 1.2x para 1.5x',
        impact: 'Aumento da taxa de acerto em 3.5%'
      }
    ]
  };
};

const getMockAdaptationMetrics = () => {
  return {
    overallImprovement: 14.2,
    marketImprovements: {
      b3: 12.5,
      sp500: 15.8,
      crypto: 18.3
    },
    topAdaptations: [
      {
        parameter: 'Volume Weight',
        improvement: 8.7,
        description: 'Aumento do peso do volume na análise'
      },
      {
        parameter: 'Stop Loss Dynamic',
        improvement: 6.5,
        description: 'Implementação de stops dinâmicos baseados em ATR'
      },
      {
        parameter: 'Pattern Recognition',
        improvement: 5.2,
        description: 'Refinamento dos algoritmos de reconhecimento de padrões'
      }
    ],
    learningCurve: [
      { date: '2025-01', accuracy: 0.68 },
      { date: '2025-02', accuracy: 0.72 },
      { date: '2025-03', accuracy: 0.75 },
      { date: '2025-04', accuracy: 0.79 },
      { date: '2025-05', accuracy: 0.83 }
    ]
  };
};

const getMockPerformanceReport = (filters) => {
  return {
    overall: {
      totalTrades: 248,
      winningTrades: 195,
      losingTrades: 53,
      winRate: 78.6,
      averageReturn: 12.7,
      averageLoss: -4.2,
      profitFactor: 3.02,
      sharpeRatio: 1.87,
      maxDrawdown: -8.5
    },
    byMarket: [
      {
        market: 'B3',
        trades: 124,
        winRate: 76.6,
        averageReturn: 11.2,
        profitFactor: 2.87
      },
      {
        market: 'S&P500',
        trades: 86,
        winRate: 79.1,
        averageReturn: 13.5,
        profitFactor: 3.12
      },
      {
        market: 'CRYPTO',
        trades: 38,
        winRate: 84.2,
        averageReturn: 16.8,
        profitFactor: 3.45
      }
    ],
    topPerformers: [
      {
        ticker: 'BTC',
        market: 'CRYPTO',
        trades: 12,
        winRate: 91.7,
        totalReturn: 34.5
      },
      {
        ticker: 'AAPL',
        market: 'S&P500',
        trades: 15,
        winRate: 86.7,
        totalReturn: 28.9
      },
      {
        ticker: 'PETR4',
        market: 'B3',
        trades: 18,
        winRate: 83.3,
        totalReturn: 26.7
      }
    ],
    monthlyPerformance: [
      { month: 'Jan 2025', return: 4.2 },
      { month: 'Feb 2025', return: 5.7 },
      { month: 'Mar 2025', return: 3.8 },
      { month: 'Apr 2025', return: 6.5 },
      { month: 'May 2025', return: 5.9 }
    ]
  };
};

const getMockVolumeReport = (filters) => {
  return {
    totalVolume: {
      value: 12567890,
      change: 15.7
    },
    byMarket: [
      {
        market: 'B3',
        volume: 5678900,
        percentage: 45.2,
        change: 12.3
      },
      {
        market: 'S&P500',
        volume: 4321000,
        percentage: 34.4,
        change: 18.7
      },
      {
        market: 'CRYPTO',
        volume: 2567990,
        percentage: 20.4,
        change: 23.5
      }
    ],
    topVolume: [
      {
        ticker: 'PETR4',
        market: 'B3',
        volume: 1234500,
        percentage: 9.8
      },
      {
        ticker: 'BTC',
        market: 'CRYPTO',
        volume: 987600,
        percentage: 7.9
      },
      {
        ticker: 'AAPL',
        market: 'S&P500',
        volume: 876500,
        percentage: 7.0
      }
    ],
    volumeTrend: [
      { date: '2025-01', volume: 8765400 },
      { date: '2025-02', volume: 9876500 },
      { date: '2025-03', volume: 10234500 },
      { date: '2025-04', volume: 11456700 },
      { date: '2025-05', volume: 12567890 }
    ]
  };
};

export default {
  getMarketData,
  getTradingSignals,
  calculateRiskReturn,
  executeOrder,
  getAiInsights,
  getAdaptationMetrics,
  getPerformanceReport,
  getVolumeReport
};
