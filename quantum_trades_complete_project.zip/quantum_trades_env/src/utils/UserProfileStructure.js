/**
 * UserProfileStructure.js
 * Definição da estrutura de perfis de usuário para o Quantum Trades
 * Este arquivo contém constantes e tipos para os diferentes níveis de acesso
 */

/**
 * Níveis de acesso do sistema
 * @readonly
 * @enum {number}
 */
export const ACCESS_LEVELS = {
  /** Acesso básico - funcionalidades limitadas */
  BASIC: 1,
  
  /** Acesso premium - funcionalidades avançadas */
  PREMIUM: 2,
  
  /** Acesso administrativo - controle total */
  ADMIN: 3
};

/**
 * Descrições dos níveis de acesso
 * @readonly
 * @type {Object.<number, {name: string, description: string, features: string[]}>}
 */
export const ACCESS_LEVEL_DETAILS = {
  [ACCESS_LEVELS.BASIC]: {
    name: 'Básico',
    description: 'Acesso às funcionalidades básicas da plataforma',
    features: [
      'Visualização do dashboard principal',
      'Consulta de cotações em tempo real',
      'Histórico de preços limitado a 30 dias',
      'Acesso a 5 ativos favoritos'
    ]
  },
  [ACCESS_LEVELS.PREMIUM]: {
    name: 'Premium',
    description: 'Acesso a funcionalidades avançadas e análises exclusivas',
    features: [
      'Todas as funcionalidades do plano Básico',
      'Emissão de ordens de compra e venda',
      'Histórico completo de preços',
      'Análises técnicas avançadas',
      'Acesso ilimitado a ativos favoritos',
      'Alertas personalizados',
      'Relatórios de desempenho'
    ]
  },
  [ACCESS_LEVELS.ADMIN]: {
    name: 'Administrador',
    description: 'Acesso completo a todas as funcionalidades e configurações',
    features: [
      'Todas as funcionalidades do plano Premium',
      'Gerenciamento de usuários',
      'Configurações do sistema',
      'Relatórios administrativos',
      'Monitoramento de performance',
      'Acesso ao painel de controle'
    ]
  }
};

/**
 * Mapeamento de recursos do sistema para níveis de acesso mínimos necessários
 * @readonly
 * @type {Object.<string, number>}
 */
export const RESOURCE_ACCESS_MAP = {
  // Páginas
  'dashboard': ACCESS_LEVELS.BASIC,
  'profile': ACCESS_LEVELS.BASIC,
  'orders': ACCESS_LEVELS.PREMIUM,
  'portfolio': ACCESS_LEVELS.BASIC,
  'research': ACCESS_LEVELS.PREMIUM,
  'reports': ACCESS_LEVELS.PREMIUM,
  'admin': ACCESS_LEVELS.ADMIN,
  'user-management': ACCESS_LEVELS.ADMIN,
  'system-settings': ACCESS_LEVELS.ADMIN,
  
  // Funcionalidades
  'place-order': ACCESS_LEVELS.PREMIUM,
  'advanced-charts': ACCESS_LEVELS.PREMIUM,
  'alerts': ACCESS_LEVELS.PREMIUM,
  'api-integration': ACCESS_LEVELS.PREMIUM,
  'export-data': ACCESS_LEVELS.PREMIUM,
  'customize-dashboard': ACCESS_LEVELS.PREMIUM,
  'ai-assistant': ACCESS_LEVELS.PREMIUM
};

/**
 * Verifica se um usuário tem acesso a um recurso específico
 * @param {number} userLevel - Nível de acesso do usuário
 * @param {string} resourceKey - Chave do recurso a ser verificado
 * @returns {boolean} - Verdadeiro se o usuário tem acesso, falso caso contrário
 */
export const hasResourceAccess = (userLevel, resourceKey) => {
  const requiredLevel = RESOURCE_ACCESS_MAP[resourceKey];
  
  // Se o recurso não estiver mapeado, assume que é acessível a todos
  if (requiredLevel === undefined) {
    return true;
  }
  
  return userLevel >= requiredLevel;
};

/**
 * Obtém os recursos acessíveis para um determinado nível de usuário
 * @param {number} userLevel - Nível de acesso do usuário
 * @returns {string[]} - Lista de chaves de recursos acessíveis
 */
export const getAccessibleResources = (userLevel) => {
  return Object.entries(RESOURCE_ACCESS_MAP)
    .filter(([_, requiredLevel]) => userLevel >= requiredLevel)
    .map(([resourceKey, _]) => resourceKey);
};

/**
 * Obtém os detalhes do nível de acesso do usuário
 * @param {number} userLevel - Nível de acesso do usuário
 * @returns {Object|null} - Detalhes do nível de acesso ou null se inválido
 */
export const getAccessLevelDetails = (userLevel) => {
  return ACCESS_LEVEL_DETAILS[userLevel] || null;
};

export default {
  ACCESS_LEVELS,
  ACCESS_LEVEL_DETAILS,
  RESOURCE_ACCESS_MAP,
  hasResourceAccess,
  getAccessibleResources,
  getAccessLevelDetails
};
