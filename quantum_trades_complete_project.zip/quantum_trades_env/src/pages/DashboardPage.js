/**
 * DashboardPage.js
 * Página de dashboard responsiva para o Quantum Trades
 */

import React from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  useTheme, 
  useMediaQuery,
  IconButton,
  Tooltip,
  Divider
} from '@mui/material';
import { 
  TrendingUp, 
  TrendingDown, 
  Info, 
  Refresh,
  MoreVert
} from '@mui/icons-material';
import ResponsiveCard from '../components/ResponsiveCard';
import ResponsiveGrid from '../components/ResponsiveGrid';

const DashboardPage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.down('md'));
  
  // Dados simulados para o dashboard
  const portfolioValue = 'R$ 1.245.678,90';
  const dailyChange = '+2,34%';
  const isPositiveChange = true;
  
  const performanceData = [
    { name: 'Hoje', value: '+2,34%', positive: true },
    { name: 'Semana', value: '+5,67%', positive: true },
    { name: 'Mês', value: '-1,23%', positive: false },
    { name: 'Ano', value: '+15,78%', positive: true },
  ];
  
  const topAssets = [
    { name: 'PETR4', value: 'R$ 32,45', change: '+1,2%', positive: true },
    { name: 'VALE3', value: 'R$ 68,90', change: '-0,5%', positive: false },
    { name: 'ITUB4', value: 'R$ 27,80', change: '+0,8%', positive: true },
    { name: 'BBDC4', value: 'R$ 19,75', change: '+1,5%', positive: true },
  ];
  
  const recentOperations = [
    { type: 'Compra', asset: 'PETR4', quantity: 100, price: 'R$ 32,10', date: '01/06/2025' },
    { type: 'Venda', asset: 'MGLU3', quantity: 200, price: 'R$ 4,75', date: '31/05/2025' },
    { type: 'Compra', asset: 'VALE3', quantity: 50, price: 'R$ 68,50', date: '30/05/2025' },
  ];

  return (
    <>
      <Box sx={{ mb: { xs: 2, sm: 3 } }}>
        <Typography 
          variant={isMobile ? "h5" : "h4"} 
          component="h1" 
          sx={{ mb: 1, fontWeight: 'medium' }}
        >
          Dashboard
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Visão geral da sua carteira e operações
        </Typography>
      </Box>
      
      {/* Resumo da carteira */}
      <Paper 
        elevation={1}
        sx={{ 
          p: { xs: 2, sm: 3 }, 
          mb: { xs: 2, sm: 3 },
          borderRadius: 2,
          backgroundColor: 'background.paper'
        }}
      >
        <Box sx={{ 
          display: 'flex', 
          flexDirection: isMobile ? 'column' : 'row',
          justifyContent: 'space-between',
          alignItems: isMobile ? 'flex-start' : 'center',
          mb: isMobile ? 2 : 0
        }}>
          <Box>
            <Typography variant="body2" color="text.secondary">
              Valor Total da Carteira
            </Typography>
            <Typography 
              variant={isMobile ? "h5" : "h4"} 
              component="div" 
              sx={{ fontWeight: 'bold', my: 0.5 }}
            >
              {portfolioValue}
            </Typography>
          </Box>
          
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center',
            mt: isMobile ? 1 : 0
          }}>
            <Box sx={{ 
              display: 'flex', 
              alignItems: 'center',
              bgcolor: isPositiveChange ? 'rgba(76, 175, 80, 0.1)' : 'rgba(244, 67, 54, 0.1)',
              color: isPositiveChange ? 'success.main' : 'error.main',
              borderRadius: 1,
              px: 1,
              py: 0.5
            }}>
              {isPositiveChange ? <TrendingUp fontSize="small" sx={{ mr: 0.5 }} /> : <TrendingDown fontSize="small" sx={{ mr: 0.5 }} />}
              <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                {dailyChange}
              </Typography>
            </Box>
            
            <Tooltip title="Atualizar dados">
              <IconButton size="small" sx={{ ml: 1 }}>
                <Refresh fontSize="small" />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
        
        {!isMobile && (
          <>
            <Divider sx={{ my: 2 }} />
            
            <Box sx={{ 
              display: 'flex', 
              justifyContent: 'space-between',
              flexWrap: 'wrap'
            }}>
              {performanceData.map((item, index) => (
                <Box key={index} sx={{ textAlign: 'center', minWidth: '80px' }}>
                  <Typography variant="body2" color="text.secondary">
                    {item.name}
                  </Typography>
                  <Typography 
                    variant="body1" 
                    sx={{ 
                      fontWeight: 'medium',
                      color: item.positive ? 'success.main' : 'error.main'
                    }}
                  >
                    {item.value}
                  </Typography>
                </Box>
              ))}
            </Box>
          </>
        )}
      </Paper>
      
      {/* Cards de informações */}
      <ResponsiveGrid 
        spacing={3} 
        mobileSpacing={2}
        columns={{ xs: 1, sm: 2, md: 2, lg: 4, xl: 4 }}
        sx={{ mb: { xs: 2, sm: 3 } }}
      >
        <ResponsiveCard
          title="Ativos em Alta"
          icon={<TrendingUp color="success" />}
          content={
            <Box>
              {topAssets.filter(asset => asset.positive).slice(0, 3).map((asset, index) => (
                <Box 
                  key={index} 
                  sx={{ 
                    display: 'flex', 
                    justifyContent: 'space-between',
                    mb: index < 2 ? 1 : 0,
                    py: 0.5
                  }}
                >
                  <Typography variant="body2" fontWeight="medium">
                    {asset.name}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Typography variant="body2">
                      {asset.value}
                    </Typography>
                    <Typography 
                      variant="body2" 
                      sx={{ 
                        ml: 1,
                        color: asset.positive ? 'success.main' : 'error.main'
                      }}
                    >
                      {asset.change}
                    </Typography>
                  </Box>
                </Box>
              ))}
            </Box>
          }
        />
        
        <ResponsiveCard
          title="Ativos em Baixa"
          icon={<TrendingDown color="error" />}
          content={
            <Box>
              {topAssets.filter(asset => !asset.positive).concat(topAssets.filter(asset => asset.positive)).slice(0, 3).map((asset, index) => (
                <Box 
                  key={index} 
                  sx={{ 
                    display: 'flex', 
                    justifyContent: 'space-between',
                    mb: index < 2 ? 1 : 0,
                    py: 0.5
                  }}
                >
                  <Typography variant="body2" fontWeight="medium">
                    {asset.name}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Typography variant="body2">
                      {asset.value}
                    </Typography>
                    <Typography 
                      variant="body2" 
                      sx={{ 
                        ml: 1,
                        color: asset.positive ? 'success.main' : 'error.main'
                      }}
                    >
                      {asset.change}
                    </Typography>
                  </Box>
                </Box>
              ))}
            </Box>
          }
        />
        
        <ResponsiveCard
          title="Operações Recentes"
          action={
            <Tooltip title="Ver todas">
              <IconButton size="small">
                <MoreVert fontSize="small" />
              </IconButton>
            </Tooltip>
          }
          content={
            <Box>
              {recentOperations.slice(0, 3).map((op, index) => (
                <Box 
                  key={index} 
                  sx={{ 
                    display: 'flex', 
                    justifyContent: 'space-between',
                    mb: index < 2 ? 1 : 0,
                    py: 0.5
                  }}
                >
                  <Box>
                    <Typography variant="body2" fontWeight="medium">
                      {op.type} • {op.asset}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {op.date}
                    </Typography>
                  </Box>
                  <Box sx={{ textAlign: 'right' }}>
                    <Typography variant="body2">
                      {op.quantity} x {op.price}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {(parseFloat(op.price.replace('R$ ', '').replace(',', '.')) * op.quantity).toLocaleString('pt-BR', {
                        style: 'currency',
                        currency: 'BRL'
                      })}
                    </Typography>
                  </Box>
                </Box>
              ))}
            </Box>
          }
        />
        
        <ResponsiveCard
          title="Desempenho"
          subtitle="Últimos 30 dias"
          icon={<Info />}
          content={
            <Box>
              {performanceData.map((item, index) => (
                <Box 
                  key={index} 
                  sx={{ 
                    display: 'flex', 
                    justifyContent: 'space-between',
                    mb: index < performanceData.length - 1 ? 1 : 0,
                    py: 0.5
                  }}
                >
                  <Typography variant="body2">
                    {item.name}
                  </Typography>
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      fontWeight: 'medium',
                      color: item.positive ? 'success.main' : 'error.main'
                    }}
                  >
                    {item.value}
                  </Typography>
                </Box>
              ))}
            </Box>
          }
        />
      </ResponsiveGrid>
    </>
  );
};

export default DashboardPage;
