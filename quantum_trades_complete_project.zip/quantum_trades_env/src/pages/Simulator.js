import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  Card, 
  CardContent, 
  CardHeader,
  Divider,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Slider,
  Switch,
  FormControlLabel,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Tooltip,
  useTheme,
  alpha,
  List,
  ListItem
} from '@mui/material';
import { 
  Code,
  PlayArrow,
  Stop,
  Save,
  Refresh,
  Settings,
  Info,
  ArrowUpward,
  ArrowDownward,
  History,
  BarChart,
  FilterList,
  Search,
  Delete,
  Edit
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { colors } from '../theme';

// Componente de TabPanel para as abas do simulador
const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simulator-tabpanel-${index}`}
      aria-labelledby={`simulator-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Função para criar propriedades de acessibilidade para as abas
const a11yProps = (index) => {
  return {
    id: `simulator-tab-${index}`,
    'aria-controls': `simulator-tabpanel-${index}`,
  };
};

// Componente principal do Simulador
const Simulator = () => {
  const { user } = useAuth();
  const theme = useTheme();
  const [tabValue, setTabValue] = useState(0);
  
  // Estados para configurações do simulador
  const [simulatorConfig, setSimulatorConfig] = useState({
    initialCapital: 10000,
    riskPerTrade: 2,
    timeframe: 'daily',
    startDate: '2024-01-01',
    endDate: '2025-01-01',
    markets: ['B3', 'S&P500', 'CRYPTO'],
    strategy: 'hilo',
    stopLossType: 'dynamic',
    takeProfitType: 'dynamic',
    volumeFilter: true,
    patternFilter: true,
    minSuccessRate: 70
  });
  
  // Estado para resultados da simulação
  const [simulationResults, setSimulationResults] = useState({
    totalTrades: 0,
    winningTrades: 0,
    losingTrades: 0,
    winRate: 0,
    profitFactor: 0,
    totalReturn: 0,
    annualizedReturn: 0,
    maxDrawdown: 0,
    sharpeRatio: 0,
    trades: []
  });
  
  // Estado para controle de simulação em andamento
  const [isSimulating, setIsSimulating] = useState(false);
  
  // Manipulador de mudança de aba
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  // Manipulador de mudança de configuração
  const handleConfigChange = (setting, value) => {
    setSimulatorConfig({
      ...simulatorConfig,
      [setting]: value
    });
  };
  
  // Manipulador para iniciar simulação
  const handleStartSimulation = () => {
    setIsSimulating(true);
    
    // Aqui seria implementada a lógica para iniciar a simulação
    // Simulando um delay para demonstração
    setTimeout(() => {
      // Dados mockados para demonstração
      setSimulationResults({
        totalTrades: 156,
        winningTrades: 112,
        losingTrades: 44,
        winRate: 71.8,
        profitFactor: 2.45,
        totalReturn: 32.7,
        annualizedReturn: 28.4,
        maxDrawdown: 8.2,
        sharpeRatio: 1.87,
        trades: [
          { id: 1, ticker: 'PETR4', market: 'B3', entryDate: '2024-02-15', exitDate: '2024-03-10', entryPrice: 34.25, exitPrice: 38.75, return: 13.14, signal: 'Compra', pattern: 'OCO', volume: '1.8x', stopLoss: -5.2, stopGain: 15.0 },
          { id: 2, ticker: 'AAPL', market: 'S&P500', entryDate: '2024-02-20', exitDate: '2024-03-05', entryPrice: 182.45, exitPrice: 195.20, return: 6.99, signal: 'Compra', pattern: 'Engolfo', volume: '1.5x', stopLoss: -4.8, stopGain: 12.0 },
          { id: 3, ticker: 'BTC', market: 'CRYPTO', entryDate: '2024-03-01', exitDate: '2024-03-20', entryPrice: 52450.00, exitPrice: 61275.00, return: 16.83, signal: 'Compra', pattern: 'Topo Duplo', volume: '2.2x', stopLoss: -6.5, stopGain: 18.0 },
          { id: 4, ticker: 'VALE3', market: 'B3', entryDate: '2024-03-10', exitDate: '2024-03-25', entryPrice: 68.75, exitPrice: 65.30, return: -5.02, signal: 'Venda', pattern: 'OCO', volume: '1.4x', stopLoss: -4.5, stopGain: 10.0 },
          { id: 5, ticker: 'MSFT', market: 'S&P500', entryDate: '2024-03-15', exitDate: '2024-04-05', entryPrice: 415.20, exitPrice: 445.80, return: 7.37, signal: 'Compra', pattern: 'Mulher Grávida', volume: '1.6x', stopLoss: -5.0, stopGain: 12.5 }
        ]
      });
      
      setIsSimulating(false);
    }, 2000);
  };
  
  // Manipulador para parar simulação
  const handleStopSimulation = () => {
    setIsSimulating(false);
    // Aqui seria implementada a lógica para interromper a simulação
  };
  
  // Manipulador para salvar configuração
  const handleSaveConfig = () => {
    // Aqui seria implementada a lógica para salvar a configuração
    console.log('Configuração salva:', simulatorConfig);
  };
  
  // Manipulador para carregar configuração
  const handleLoadConfig = () => {
    // Aqui seria implementada a lógica para carregar uma configuração salva
  };
  
  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ 
        mb: 4, 
        display: 'flex', 
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap'
      }}>
        <Box>
          <Typography variant="h4" component="h1" sx={{ fontWeight: 600, mb: 1 }}>
            Simulador
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Teste e otimize suas estratégias de trading
          </Typography>
        </Box>
        
        <Box sx={{ display: 'flex', gap: 2, mt: { xs: 2, md: 0 } }}>
          {isSimulating ? (
            <Button 
              variant="outlined" 
              color="error"
              startIcon={<Stop />}
              onClick={handleStopSimulation}
            >
              Parar Simulação
            </Button>
          ) : (
            <Button 
              variant="contained" 
              startIcon={<PlayArrow />}
              onClick={handleStartSimulation}
            >
              Iniciar Simulação
            </Button>
          )}
          
          <Button 
            variant="outlined" 
            startIcon={<Save />}
            onClick={handleSaveConfig}
          >
            Salvar Config
          </Button>
        </Box>
      </Box>
      
      <Paper sx={{ width: '100%' }}>
        {/* Navegação por abas - versão desktop */}
        <Box sx={{ display: { xs: 'none', sm: 'block' }, borderBottom: 1, borderColor: 'divider' }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            aria-label="simulador tabs"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab 
              icon={<Settings />} 
              label="Configurações" 
              {...a11yProps(0)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<BarChart />} 
              label="Resultados" 
              {...a11yProps(1)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<History />} 
              label="Histórico de Trades" 
              {...a11yProps(2)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<Code />} 
              label="Estratégia Avançada" 
              {...a11yProps(3)} 
              sx={{ textTransform: 'none' }}
            />
          </Tabs>
        </Box>
        
        {/* Navegação por dropdown - versão mobile */}
        <Box sx={{ 
          display: { xs: 'block', sm: 'none' }, 
          p: 2,
          borderBottom: 1, 
          borderColor: 'divider'
        }}>
          <FormControl fullWidth>
            <InputLabel id="mobile-tabs-label">Seção</InputLabel>
            <Select
              labelId="mobile-tabs-label"
              id="mobile-tabs-select"
              value={tabValue}
              label="Seção"
              onChange={(e) => handleTabChange(null, e.target.value)}
              sx={{ 
                minHeight: '44px',
                '& .MuiSelect-select': {
                  display: 'flex',
                  alignItems: 'center'
                }
              }}
            >
              <MenuItem value={0} sx={{ minHeight: '44px' }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Settings sx={{ mr: 1 }} />
                  <Typography>Configurações</Typography>
                </Box>
              </MenuItem>
              <MenuItem value={1} sx={{ minHeight: '44px' }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <BarChart sx={{ mr: 1 }} />
                  <Typography>Resultados</Typography>
                </Box>
              </MenuItem>
              <MenuItem value={2} sx={{ minHeight: '44px' }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <History sx={{ mr: 1 }} />
                  <Typography>Histórico de Trades</Typography>
                </Box>
              </MenuItem>
              <MenuItem value={3} sx={{ minHeight: '44px' }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Code sx={{ mr: 1 }} />
                  <Typography>Estratégia Avançada</Typography>
                </Box>
              </MenuItem>
            </Select>
          </FormControl>
        </Box>
        
        {/* Conteúdo das abas */}
        <TabPanel value={tabValue} index={0}>
          {/* Conteúdo da aba de Configurações */}
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card>
                <CardHeader title="Parâmetros Gerais" />
                <Divider />
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Capital Inicial (R$)"
                        type="number"
                        value={simulatorConfig.initialCapital}
                        onChange={(e) => handleConfigChange('initialCapital', Number(e.target.value))}
                        variant="outlined"
                        size="small"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <Typography gutterBottom>
                        Risco por Operação (% do Capital)
                      </Typography>
                      <Box sx={{ px: 1 }}>
                        <Slider
                          value={simulatorConfig.riskPerTrade}
                          onChange={(e, newValue) => handleConfigChange('riskPerTrade', newValue)}
                          step={0.5}
                          marks
                          min={0.5}
                          max={5}
                          valueLabelDisplay="auto"
                          valueLabelFormat={(value) => `${value}%`}
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Timeframe</InputLabel>
                        <Select
                          value={simulatorConfig.timeframe}
                          label="Timeframe"
                          onChange={(e) => handleConfigChange('timeframe', e.target.value)}
                        >
                          <MenuItem value="intraday">Intraday</MenuItem>
                          <MenuItem value="daily">Diário</MenuItem>
                          <MenuItem value="weekly">Semanal</MenuItem>
                          <MenuItem value="monthly">Mensal</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Data Inicial"
                        type="date"
                        value={simulatorConfig.startDate}
                        onChange={(e) => handleConfigChange('startDate', e.target.value)}
                        variant="outlined"
                        size="small"
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Data Final"
                        type="date"
                        value={simulatorConfig.endDate}
                        onChange={(e) => handleConfigChange('endDate', e.target.value)}
                        variant="outlined"
                        size="small"
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card>
                <CardHeader title="Configurações de Estratégia" />
                <Divider />
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Estratégia Base</InputLabel>
                        <Select
                          value={simulatorConfig.strategy}
                          label="Estratégia Base"
                          onChange={(e) => handleConfigChange('strategy', e.target.value)}
                        >
                          <MenuItem value="hilo">HiLo</MenuItem>
                          <MenuItem value="macd">MACD</MenuItem>
                          <MenuItem value="rsi">RSI</MenuItem>
                          <MenuItem value="custom">Personalizada</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Tipo de Stop Loss</InputLabel>
                        <Select
                          value={simulatorConfig.stopLossType}
                          label="Tipo de Stop Loss"
                          onChange={(e) => handleConfigChange('stopLossType', e.target.value)}
                        >
                          <MenuItem value="fixed">Fixo</MenuItem>
                          <MenuItem value="dynamic">Dinâmico</MenuItem>
                          <MenuItem value="atr">Baseado em ATR</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Tipo de Take Profit</InputLabel>
                        <Select
                          value={simulatorConfig.takeProfitType}
                          label="Tipo de Take Profit"
                          onChange={(e) => handleConfigChange('takeProfitType', e.target.value)}
                        >
                          <MenuItem value="fixed">Fixo</MenuItem>
                          <MenuItem value="dynamic">Dinâmico</MenuItem>
                          <MenuItem value="trailing">Trailing</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={simulatorConfig.volumeFilter}
                            onChange={(e) => handleConfigChange('volumeFilter', e.target.checked)}
                            color="primary"
                          />
                        }
                        label="Filtro de Volume"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={simulatorConfig.patternFilter}
                            onChange={(e) => handleConfigChange('patternFilter', e.target.checked)}
                            color="primary"
                          />
                        }
                        label="Filtro de Padrões"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <Typography gutterBottom>
                        Taxa Mínima de Sucesso (%)
                      </Typography>
                      <Box sx={{ px: 1 }}>
                        <Slider
                          value={simulatorConfig.minSuccessRate}
                          onChange={(e, newValue) => handleConfigChange('minSuccessRate', newValue)}
                          step={5}
                          marks
                          min={50}
                          max={95}
                          valueLabelDisplay="auto"
                          valueLabelFormat={(value) => `${value}%`}
                        />
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </TabPanel>
        
        <TabPanel value={tabValue} index={1}>
          {/* Conteúdo da aba de Resultados */}
          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <Card>
                <CardHeader title="Resumo da Simulação" />
                <Divider />
                <CardContent>
                  <Grid container spacing={3}>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Total de Trades
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 600 }}>
                        {simulationResults.totalTrades}
                      </Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Taxa de Acerto
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 600, color: colors.success.main }}>
                        {simulationResults.winRate}%
                      </Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Fator de Lucro
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 600 }}>
                        {simulationResults.profitFactor}
                      </Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Retorno Total
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 600, color: colors.success.main }}>
                        {simulationResults.totalReturn}%
                      </Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Retorno Anualizado
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 600, color: colors.success.main }}>
                        {simulationResults.annualizedReturn}%
                      </Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Drawdown Máximo
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 600, color: colors.error.main }}>
                        {simulationResults.maxDrawdown}%
                      </Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Sharpe Ratio
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 600 }}>
                        {simulationResults.sharpeRatio}
                      </Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Typography variant="subtitle2" color="text.secondary">
                        Trades Vencedores
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 600 }}>
                        {simulationResults.winningTrades}
                      </Typography>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card sx={{ height: '100%' }}>
                <CardHeader title="Distribuição de Resultados" />
                <Divider />
                <CardContent sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', height: 'calc(100% - 100px)' }}>
                  {/* Aqui seria inserido um gráfico de pizza ou donut */}
                  <Box sx={{ 
                    display: 'flex', 
                    flexDirection: 'column', 
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: '100%'
                  }}>
                    <Typography variant="body1" color="text.secondary" align="center">
                      Gráfico de distribuição de resultados
                    </Typography>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12}>
              <Card>
                <CardHeader 
                  title="Evolução do Capital" 
                  action={
                    <IconButton aria-label="configurações">
                      <Settings fontSize="small" />
                    </IconButton>
                  }
                />
                <Divider />
                <CardContent>
                  {/* Aqui seria inserido um gráfico de linha */}
                  <Box sx={{ 
                    display: 'flex', 
                    flexDirection: 'column', 
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: 300
                  }}>
                    <Typography variant="body1" color="text.secondary" align="center">
                      Gráfico de evolução do capital
                    </Typography>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </TabPanel>
        
        <TabPanel value={tabValue} index={2}>
          {/* Conteúdo da aba de Histórico de Trades */}
          <Card>
            <CardHeader 
              title="Histórico de Trades" 
              action={
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Tooltip title="Filtrar">
                    <IconButton>
                      <FilterList fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Exportar">
                    <IconButton>
                      <Save fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Box>
              }
            />
            <Divider />
            <TableContainer>
              <Table sx={{ minWidth: 650 }} size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Ticker</TableCell>
                    <TableCell>Mercado</TableCell>
                    <TableCell>Sinal</TableCell>
                    <TableCell>Data Entrada</TableCell>
                    <TableCell>Data Saída</TableCell>
                    <TableCell>Preço Entrada</TableCell>
                    <TableCell>Preço Saída</TableCell>
                    <TableCell align="right">Retorno (%)</TableCell>
                    <TableCell>Ações</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {simulationResults.trades.map((trade) => (
                    <TableRow
                      key={trade.id}
                      sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                    >
                      <TableCell component="th" scope="row">
                        <Typography variant="body2" fontWeight={500}>
                          {trade.ticker}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box 
                          component="span" 
                          sx={{ 
                            px: 1, 
                            py: 0.5, 
                            borderRadius: '12px', 
                            fontSize: '0.75rem',
                            fontWeight: 600,
                            bgcolor: 
                              trade.market === 'B3' ? alpha(colors.success.main, 0.1) : 
                              trade.market === 'S&P500' ? alpha(colors.primary.main, 0.1) : 
                              alpha(colors.warning.main, 0.1),
                            color: 
                              trade.market === 'B3' ? colors.success.main : 
                              trade.market === 'S&P500' ? colors.primary.main : 
                              colors.warning.main
                          }}
                        >
                          {trade.market}
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography 
                          variant="body2" 
                          sx={{ 
                            color: trade.signal === 'Compra' ? colors.success.main : colors.error.main,
                            fontWeight: 500
                          }}
                        >
                          {trade.signal}
                        </Typography>
                      </TableCell>
                      <TableCell>{trade.entryDate}</TableCell>
                      <TableCell>{trade.exitDate}</TableCell>
                      <TableCell>{trade.entryPrice}</TableCell>
                      <TableCell>{trade.exitPrice}</TableCell>
                      <TableCell align="right">
                        <Typography 
                          variant="body2" 
                          sx={{ 
                            color: trade.return >= 0 ? colors.success.main : colors.error.main,
                            fontWeight: 600
                          }}
                        >
                          {trade.return >= 0 ? '+' : ''}{trade.return.toFixed(2)}%
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex' }}>
                          <Tooltip title="Detalhes">
                            <IconButton size="small">
                              <Info fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Card>
        </TabPanel>
        
        <TabPanel value={tabValue} index={3}>
          {/* Conteúdo da aba de Estratégia Avançada */}
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Card>
                <CardHeader title="Editor de Estratégia" />
                <Divider />
                <CardContent>
                  <Typography variant="body2" color="text.secondary" paragraph>
                    Utilize o editor abaixo para criar ou modificar estratégias personalizadas.
                  </Typography>
                  
                  <Box 
                    sx={{ 
                      bgcolor: alpha(colors.black.main, 0.9), 
                      p: 2, 
                      borderRadius: 1,
                      fontFamily: '"Space Mono", monospace',
                      fontSize: '0.875rem',
                      color: colors.text.primary,
                      height: 300,
                      overflowY: 'auto'
                    }}
                  >
                    <Typography 
                      variant="body2" 
                      component="pre" 
                      sx={{ 
                        fontFamily: 'inherit',
                        color: alpha(colors.text.primary, 0.8)
                      }}
                    >
                      {`// Estratégia personalizada
function strategy(data) {
  const signals = [];
  
  // Cálculo de médias móveis
  const sma20 = calculateSMA(data.close, 20);
  const sma50 = calculateSMA(data.close, 50);
  
  // Lógica de sinal
  for (let i = 1; i < data.close.length; i++) {
    if (sma20[i] > sma50[i] && sma20[i-1] <= sma50[i-1]) {
      signals.push({
        date: data.date[i],
        type: 'buy',
        price: data.close[i],
        reason: 'Cruzamento de médias para cima'
      });
    }
    else if (sma20[i] < sma50[i] && sma20[i-1] >= sma50[i-1]) {
      signals.push({
        date: data.date[i],
        type: 'sell',
        price: data.close[i],
        reason: 'Cruzamento de médias para baixo'
      });
    }
  }
  
  return signals;
}

// Função auxiliar para calcular média móvel simples
function calculateSMA(data, period) {
  const result = [];
  
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(null);
      continue;
    }
    
    let sum = 0;
    for (let j = 0; j < period; j++) {
      sum += data[i - j];
    }
    
    result.push(sum / period);
  }
  
  return result;
}`}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                    <Button 
                      variant="outlined" 
                      startIcon={<Refresh />}
                    >
                      Resetar
                    </Button>
                    <Button 
                      variant="contained" 
                      startIcon={<Save />}
                    >
                      Salvar Estratégia
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12}>
              <Card>
                <CardHeader title="Parâmetros Avançados" />
                <Divider />
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <List>
                        <ListItem>
                          <FormControlLabel
                            control={
                              <Switch
                                checked={true}
                                color="primary"
                              />
                            }
                            label="Otimização de Parâmetros"
                          />
                        </ListItem>
                        <ListItem>
                          <FormControlLabel
                            control={
                              <Switch
                                checked={true}
                                color="primary"
                              />
                            }
                            label="Validação Cruzada"
                          />
                        </ListItem>
                        <ListItem>
                          <FormControlLabel
                            control={
                              <Switch
                                checked={false}
                                color="primary"
                              />
                            }
                            label="Monte Carlo Simulation"
                          />
                        </ListItem>
                      </List>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <List>
                        <ListItem>
                          <FormControlLabel
                            control={
                              <Switch
                                checked={true}
                                color="primary"
                              />
                            }
                            label="Ajuste de Slippage"
                          />
                        </ListItem>
                        <ListItem>
                          <FormControlLabel
                            control={
                              <Switch
                                checked={true}
                                color="primary"
                              />
                            }
                            label="Incluir Custos de Transação"
                          />
                        </ListItem>
                        <ListItem>
                          <FormControlLabel
                            control={
                              <Switch
                                checked={false}
                                color="primary"
                              />
                            }
                            label="Análise de Sensibilidade"
                          />
                        </ListItem>
                      </List>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </TabPanel>
      </Paper>
    </Container>
  );
};

export default Simulator;
