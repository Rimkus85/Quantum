/**
 * AccessDeniedPage.js
 * Página exibida quando o usuário tenta acessar um recurso sem permissão
 */

import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { 
  Box, 
  Typography, 
  Button, 
  Container, 
  Paper,
  Grid
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import LockIcon from '@mui/icons-material/Lock';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { ACCESS_LEVEL_DETAILS } from '../utils/UserProfileStructure';
import { useAuth } from '../contexts/AuthContext';

/**
 * Página de acesso negado
 * 
 * @returns {React.ReactElement} Página de acesso negado
 */
const AccessDeniedPage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  
  // Obtém o nível requerido do state da navegação
  const requiredLevel = location.state?.requiredLevel || 2;
  
  // Obtém detalhes do nível requerido e do nível atual do usuário
  const requiredLevelDetails = ACCESS_LEVEL_DETAILS[requiredLevel];
  const currentLevelDetails = user ? ACCESS_LEVEL_DETAILS[user.level] : null;
  
  const handleGoBack = () => {
    navigate(-1);
  };
  
  const handleGoToDashboard = () => {
    navigate('/dashboard');
  };
  
  const handleUpgradeAccount = () => {
    navigate('/upgrade');
  };
  
  return (
    <Container maxWidth="md">
      <Box sx={{ py: 4 }}>
        <Paper 
          elevation={3}
          sx={{ 
            p: { xs: 3, sm: 4 },
            borderRadius: 2,
            textAlign: 'center'
          }}
        >
          <Box 
            sx={{ 
              display: 'flex', 
              flexDirection: 'column',
              alignItems: 'center',
              mb: 3
            }}
          >
            <Box
              sx={{
                backgroundColor: 'error.light',
                borderRadius: '50%',
                p: 2,
                mb: 2
              }}
            >
              <LockIcon 
                sx={{ 
                  fontSize: isMobile ? 40 : 60,
                  color: 'error.main'
                }} 
              />
            </Box>
            
            <Typography 
              variant={isMobile ? "h5" : "h4"} 
              component="h1"
              sx={{ fontWeight: 600, mb: 1 }}
            >
              Acesso Restrito
            </Typography>
            
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              Você não possui permissão para acessar este recurso.
            </Typography>
          </Box>
          
          <Box sx={{ mb: 4 }}>
            <Typography variant="h6" gutterBottom>
              Nível de acesso necessário:
            </Typography>
            
            <Paper
              variant="outlined"
              sx={{
                p: 2,
                mb: 3,
                backgroundColor: theme.palette.background.default
              }}
            >
              <Typography variant="h6" color="primary" gutterBottom>
                {requiredLevelDetails?.name || 'Premium'}
              </Typography>
              
              <Typography variant="body2" gutterBottom>
                {requiredLevelDetails?.description || 'Acesso a funcionalidades avançadas e análises exclusivas'}
              </Typography>
              
              {requiredLevelDetails?.features && (
                <Box sx={{ mt: 1 }}>
                  <Typography variant="body2" fontWeight="bold">
                    Recursos incluídos:
                  </Typography>
                  
                  <ul style={{ paddingLeft: '20px', marginTop: '8px' }}>
                    {requiredLevelDetails.features.slice(0, 4).map((feature, index) => (
                      <li key={index}>
                        <Typography variant="body2">{feature}</Typography>
                      </li>
                    ))}
                  </ul>
                </Box>
              )}
            </Paper>
            
            <Typography variant="h6" gutterBottom>
              Seu nível atual:
            </Typography>
            
            <Paper
              variant="outlined"
              sx={{
                p: 2,
                backgroundColor: theme.palette.background.default
              }}
            >
              <Typography variant="h6" color="text.secondary" gutterBottom>
                {currentLevelDetails?.name || 'Básico'}
              </Typography>
              
              <Typography variant="body2">
                {currentLevelDetails?.description || 'Acesso às funcionalidades básicas da plataforma'}
              </Typography>
            </Paper>
          </Box>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<ArrowBackIcon />}
                onClick={handleGoBack}
              >
                Voltar
              </Button>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <Button
                fullWidth
                variant="outlined"
                onClick={handleGoToDashboard}
              >
                Ir para Dashboard
              </Button>
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <Button
                fullWidth
                variant="contained"
                color="primary"
                onClick={handleUpgradeAccount}
              >
                Fazer Upgrade
              </Button>
            </Grid>
          </Grid>
        </Paper>
      </Box>
    </Container>
  );
};

export default AccessDeniedPage;
