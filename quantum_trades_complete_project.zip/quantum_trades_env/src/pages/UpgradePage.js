/**
 * UpgradePage.js
 * Página para upgrade de conta do usuário
 */

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Box, 
  Typography, 
  Button, 
  Container, 
  Paper,
  Grid,
  Card,
  CardContent,
  CardActions,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import CheckIcon from '@mui/icons-material/Check';
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import { ACCESS_LEVELS, ACCESS_LEVEL_DETAILS } from '../utils/UserProfileStructure';
import { useAuth } from '../contexts/AuthContext';

/**
 * Página de upgrade de conta
 * 
 * @returns {React.ReactElement} Página de upgrade de conta
 */
const UpgradePage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);
  
  const currentLevel = user?.level || ACCESS_LEVELS.BASIC;
  
  const plans = [
    {
      id: ACCESS_LEVELS.BASIC,
      name: ACCESS_LEVEL_DETAILS[ACCESS_LEVELS.BASIC].name,
      price: 'Grátis',
      description: ACCESS_LEVEL_DETAILS[ACCESS_LEVELS.BASIC].description,
      features: ACCESS_LEVEL_DETAILS[ACCESS_LEVELS.BASIC].features,
      recommended: false
    },
    {
      id: ACCESS_LEVELS.PREMIUM,
      name: ACCESS_LEVEL_DETAILS[ACCESS_LEVELS.PREMIUM].name,
      price: 'R$ 99,90/mês',
      description: ACCESS_LEVEL_DETAILS[ACCESS_LEVELS.PREMIUM].description,
      features: ACCESS_LEVEL_DETAILS[ACCESS_LEVELS.PREMIUM].features,
      recommended: true
    }
  ];
  
  const handleUpgrade = (plan) => {
    setSelectedPlan(plan);
    setOpenDialog(true);
  };
  
  const handleCloseDialog = () => {
    setOpenDialog(false);
  };
  
  const handleConfirmUpgrade = () => {
    // Aqui seria implementada a lógica real de upgrade
    // Por enquanto, apenas fechamos o diálogo e redirecionamos
    setOpenDialog(false);
    navigate('/dashboard');
  };
  
  const handleGoBack = () => {
    navigate(-1);
  };
  
  return (
    <Container maxWidth="lg">
      <Box sx={{ py: 4 }}>
        <Typography 
          variant={isMobile ? "h5" : "h4"} 
          component="h1"
          sx={{ fontWeight: 600, mb: 3 }}
        >
          Planos Quantum Trades
        </Typography>
        
        <Typography variant="body1" sx={{ mb: 4 }}>
          Escolha o plano ideal para suas necessidades de investimento e tenha acesso a recursos exclusivos.
        </Typography>
        
        <Grid container spacing={3}>
          {plans.map((plan) => (
            <Grid item xs={12} md={6} key={plan.id}>
              <Card 
                elevation={plan.recommended ? 3 : 1}
                sx={{ 
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  position: 'relative',
                  borderColor: plan.recommended ? 'primary.main' : 'inherit',
                  borderWidth: plan.recommended ? 2 : 1,
                  borderStyle: plan.recommended ? 'solid' : 'inherit',
                }}
              >
                {plan.recommended && (
                  <Box
                    sx={{
                      position: 'absolute',
                      top: 0,
                      right: 0,
                      backgroundColor: 'primary.main',
                      color: 'primary.contrastText',
                      py: 0.5,
                      px: 2,
                      borderBottomLeftRadius: 8
                    }}
                  >
                    <Typography variant="caption" fontWeight="bold">
                      Recomendado
                    </Typography>
                  </Box>
                )}
                
                <CardContent sx={{ flexGrow: 1 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    {plan.id === ACCESS_LEVELS.PREMIUM ? (
                      <StarIcon sx={{ color: '#D4AF37', mr: 1 }} />
                    ) : (
                      <StarBorderIcon sx={{ mr: 1 }} />
                    )}
                    <Typography variant="h5" component="h2">
                      {plan.name}
                    </Typography>
                  </Box>
                  
                  <Typography variant="h4" component="div" sx={{ mb: 2, fontWeight: 'bold' }}>
                    {plan.price}
                  </Typography>
                  
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {plan.description}
                  </Typography>
                  
                  <Divider sx={{ my: 2 }} />
                  
                  <List dense>
                    {plan.features.map((feature, index) => (
                      <ListItem key={index} disableGutters>
                        <ListItemIcon sx={{ minWidth: 30 }}>
                          <CheckIcon color="primary" fontSize="small" />
                        </ListItemIcon>
                        <ListItemText primary={feature} />
                      </ListItem>
                    ))}
                  </List>
                </CardContent>
                
                <CardActions sx={{ p: 2, pt: 0 }}>
                  {currentLevel === plan.id ? (
                    <Button 
                      fullWidth 
                      variant="outlined" 
                      disabled
                    >
                      Plano Atual
                    </Button>
                  ) : (
                    <Button 
                      fullWidth 
                      variant={plan.recommended ? "contained" : "outlined"}
                      color="primary"
                      onClick={() => handleUpgrade(plan)}
                      disabled={currentLevel > plan.id}
                    >
                      {currentLevel < plan.id ? 'Fazer Upgrade' : 'Fazer Downgrade'}
                    </Button>
                  )}
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
        
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Button
            variant="outlined"
            onClick={handleGoBack}
            sx={{ mr: 2 }}
          >
            Voltar
          </Button>
        </Box>
      </Box>
      
      {/* Diálogo de confirmação de upgrade */}
      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
      >
        <DialogTitle>
          Confirmar {currentLevel < (selectedPlan?.id || 0) ? 'Upgrade' : 'Downgrade'} para {selectedPlan?.name}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            {currentLevel < (selectedPlan?.id || 0) ? (
              <>
                Você está prestes a fazer upgrade para o plano {selectedPlan?.name} por {selectedPlan?.price}.
                Este plano oferece acesso a recursos avançados como emissão de ordens, análises técnicas e muito mais.
              </>
            ) : (
              <>
                Você está prestes a fazer downgrade para o plano {selectedPlan?.name}.
                Alguns recursos que você atualmente utiliza podem ficar indisponíveis após esta alteração.
              </>
            )}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancelar</Button>
          <Button onClick={handleConfirmUpgrade} variant="contained" color="primary" autoFocus>
            Confirmar
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default UpgradePage;
