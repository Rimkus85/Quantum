/**
 * RobotConfigPage.js
 * Página de configuração do robô para execução automática e recomendações
 */

import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Typography, 
  Button,
  Divider,
  TextField,
  Switch,
  FormControlLabel,
  Slider,
  Card,
  CardContent,
  CardHeader,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Snackbar,
  Alert,
  Chip,
  FormHelperText,
  CircularProgress
} from '@mui/material';
import {
  PlayArrow,
  Stop,
  Settings,
  Save,
  Timeline,
  AddCircleOutline
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import MainLayout from '../layouts/MainLayout';

const RobotConfigPage = () => {
  const { user } = useAuth();
  
  // Estado para configurações do robô
  const [robotConfig, setRobotConfig] = useState({
    active: false,
    tradingPairs: ['PETR4', 'VALE3', 'ITUB4'],
    strategy: 'regressao_linear',
    timeframe: '1d',
    riskLevel: 2,
    maxPositions: 5,
    stopLoss: 3.5,
    takeProfit: 7.0,
    useRecommendations: true,
    autoExecute: false,
    notifyBeforeExecution: true,
    executionHours: {
      start: '09:30',
      end: '17:30'
    },
    capitalAllocation: 30
  });
  
  // Estados para UI
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState('info');
  const [newPair, setNewPair] = useState('');
  
  // Estados para validação
  const [errors, setErrors] = useState({
    stopLoss: '',
    takeProfit: '',
    maxPositions: '',
    newPair: '',
    executionHours: ''
  });
  
  // Estado para rastrear se o formulário foi modificado
  const [formModified, setFormModified] = useState(false);

  // Estratégias disponíveis
  const strategies = [
    { value: 'regressao_linear', label: 'Regressão Linear (10 anos)' },
    { value: 'media_movel', label: 'Médias Móveis Cruzadas' },
    { value: 'rsi_macd', label: 'RSI + MACD' },
    { value: 'suporte_resistencia', label: 'Suporte e Resistência' },
    { value: 'machine_learning', label: 'Machine Learning Preditivo' }
  ];

  // Timeframes disponíveis
  const timeframes = [
    { value: '5m', label: '5 minutos' },
    { value: '15m', label: '15 minutos' },
    { value: '30m', label: '30 minutos' },
    { value: '1h', label: '1 hora' },
    { value: '4h', label: '4 horas' },
    { value: '1d', label: '1 dia' }
  ];

  // Efeito para marcar o formulário como não modificado após salvar
  useEffect(() => {
    if (!saving) {
      setFormModified(false);
    }
  }, [saving]);

  // Validação de campos
  const validateField = (field, value) => {
    let errorMessage = '';
    
    switch (field) {
      case 'stopLoss':
        if (value <= 0) {
          errorMessage = 'Stop Loss deve ser maior que zero';
        } else if (value >= robotConfig.takeProfit) {
          errorMessage = 'Stop Loss deve ser menor que Take Profit';
        }
        break;
        
      case 'takeProfit':
        if (value <= 0) {
          errorMessage = 'Take Profit deve ser maior que zero';
        } else if (value <= robotConfig.stopLoss) {
          errorMessage = 'Take Profit deve ser maior que Stop Loss';
        }
        break;
        
      case 'maxPositions':
        if (value <= 0) {
          errorMessage = 'Deve ser maior que zero';
        } else if (value > 20) {
          errorMessage = 'Máximo de 20 posições permitidas';
        }
        break;
        
      case 'newPair':
        if (value && !/^[A-Z0-9]{4,6}$/.test(value)) {
          errorMessage = 'Formato inválido (ex: PETR4)';
        } else if (robotConfig.tradingPairs.includes(value)) {
          errorMessage = 'Ativo já adicionado';
        }
        break;
        
      case 'executionHours':
        const { start, end } = value;
        if (start >= end) {
          errorMessage = 'Horário de início deve ser anterior ao fim';
        }
        break;
        
      default:
        break;
    }
    
    return errorMessage;
  };

  // Manipulador de alteração de configurações com validação
  const handleConfigChange = (setting, value) => {
    // Validar o campo se for um dos campos com validação
    if (['stopLoss', 'takeProfit', 'maxPositions'].includes(setting)) {
      const errorMessage = validateField(setting, value);
      setErrors(prev => ({ ...prev, [setting]: errorMessage }));
    }
    
    // Atualizar a configuração
    setRobotConfig(prevConfig => ({
      ...prevConfig,
      [setting]: value
    }));
    
    // Marcar o formulário como modificado
    setFormModified(true);
  };

  // Manipulador para horários de execução com validação
  const handleExecutionHoursChange = (type, value) => {
    const newHours = {
      ...robotConfig.executionHours,
      [type]: value
    };
    
    // Validar horários
    const errorMessage = validateField('executionHours', newHours);
    setErrors(prev => ({ ...prev, executionHours: errorMessage }));
    
    // Atualizar a configuração
    setRobotConfig(prevConfig => ({
      ...prevConfig,
      executionHours: newHours
    }));
    
    // Marcar o formulário como modificado
    setFormModified(true);
  };

  // Validar novo par de negociação
  const handleNewPairChange = (value) => {
    setNewPair(value);
    const errorMessage = validateField('newPair', value);
    setErrors(prev => ({ ...prev, newPair: errorMessage }));
  };

  // Adicionar par de negociação com validação
  const handleAddTradingPair = () => {
    // Validar o novo par
    const errorMessage = validateField('newPair', newPair);
    
    if (errorMessage) {
      setErrors(prev => ({ ...prev, newPair: errorMessage }));
      return;
    }
    
    if (newPair && !robotConfig.tradingPairs.includes(newPair)) {
      setRobotConfig(prevConfig => ({
        ...prevConfig,
        tradingPairs: [...prevConfig.tradingPairs, newPair]
      }));
      setNewPair('');
      setErrors(prev => ({ ...prev, newPair: '' }));
      setFormModified(true);
      
      // Feedback visual de sucesso
      setAlertMessage(`Ativo ${newPair} adicionado com sucesso!`);
      setAlertSeverity('success');
      setShowAlert(true);
    }
  };

  // Remover par de negociação
  const handleRemoveTradingPair = (pair) => {
    if (robotConfig.tradingPairs.length <= 1) {
      setAlertMessage('É necessário manter pelo menos um ativo para negociação');
      setAlertSeverity('warning');
      setShowAlert(true);
      return;
    }
    
    setRobotConfig(prevConfig => ({
      ...prevConfig,
      tradingPairs: prevConfig.tradingPairs.filter(p => p !== pair)
    }));
    
    setFormModified(true);
  };

  // Validar todo o formulário
  const validateForm = () => {
    const newErrors = {
      stopLoss: validateField('stopLoss', robotConfig.stopLoss),
      takeProfit: validateField('takeProfit', robotConfig.takeProfit),
      maxPositions: validateField('maxPositions', robotConfig.maxPositions),
      executionHours: validateField('executionHours', robotConfig.executionHours)
    };
    
    setErrors(prev => ({ ...prev, ...newErrors }));
    
    // Verificar se há erros
    return !Object.values(newErrors).some(error => error !== '');
  };

  // Salvar configurações com validação
  const handleSaveConfig = async () => {
    // Validar todo o formulário antes de salvar
    if (!validateForm()) {
      setAlertMessage('Corrija os erros antes de salvar');
      setAlertSeverity('error');
      setShowAlert(true);
      return;
    }
    
    setSaving(true);
    setLoading(true);
    
    try {
      // Simulação de salvamento de configurações
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setAlertMessage('Configurações do robô salvas com sucesso!');
      setAlertSeverity('success');
      setShowAlert(true);
      setFormModified(false);
    } catch (error) {
      console.error('Erro ao salvar configurações do robô:', error);
      setAlertMessage('Erro ao salvar configurações. Tente novamente.');
      setAlertSeverity('error');
      setShowAlert(true);
    } finally {
      setLoading(false);
      setSaving(false);
    }
  };

  // Iniciar/Parar robô
  const handleToggleRobot = async () => {
    // Se houver modificações não salvas, alertar o usuário
    if (formModified) {
      setAlertMessage('Salve as alterações antes de iniciar/parar o robô');
      setAlertSeverity('warning');
      setShowAlert(true);
      return;
    }
    
    setLoading(true);
    
    try {
      // Simulação de ativação/desativação do robô
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const newStatus = !robotConfig.active;
      
      setRobotConfig(prevConfig => ({
        ...prevConfig,
        active: newStatus
      }));
      
      setAlertMessage(newStatus 
        ? 'Robô ativado com sucesso! Operações automáticas iniciadas.' 
        : 'Robô desativado. Operações automáticas interrompidas.');
      setAlertSeverity(newStatus ? 'success' : 'info');
      setShowAlert(true);
    } catch (error) {
      console.error('Erro ao alterar status do robô:', error);
      setAlertMessage('Erro ao alterar status do robô. Tente novamente.');
      setAlertSeverity('error');
      setShowAlert(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        {/* Cabeçalho */}
        <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Box>
            <Typography variant="h4" component="h1" gutterBottom>
              Configuração do Robô
            </Typography>
            <Typography variant="subtitle1" color="text.secondary">
              Configure parâmetros para execução automática e recomendações.
            </Typography>
          </Box>
          <Box>
            <Button
              variant="contained"
              color={robotConfig.active ? "error" : "success"}
              startIcon={robotConfig.active ? <Stop /> : <PlayArrow />}
              onClick={handleToggleRobot}
              disabled={loading}
              sx={{ mr: 2 }}
            >
              {loading && !saving ? (
                <CircularProgress size={24} color="inherit" />
              ) : (
                robotConfig.active ? 'Parar Robô' : 'Iniciar Robô'
              )}
            </Button>
            <Button
              variant="outlined"
              startIcon={saving ? <CircularProgress size={16} /> : <Save />}
              onClick={handleSaveConfig}
              disabled={loading || !formModified}
              color={formModified ? "primary" : "inherit"}
            >
              Salvar
            </Button>
          </Box>
        </Box>
        
        <Grid container spacing={3}>
          {/* Status do Robô */}
          <Grid item xs={12}>
            <Card sx={{ mb: 3, bgcolor: robotConfig.active ? 'success.dark' : 'background.paper' }}>
              <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                <Box sx={{ mr: 2 }}>
                  {robotConfig.active ? (
                    <PlayArrow fontSize="large" color="inherit" />
                  ) : (
                    <Stop fontSize="large" color="inherit" />
                  )}
                </Box>
                <Box>
                  <Typography variant="h6">
                    Status: {robotConfig.active ? 'Ativo' : 'Inativo'}
                  </Typography>
                  <Typography variant="body2">
                    {robotConfig.active 
                      ? 'O robô está executando operações automáticas conforme configurado.' 
                      : 'O robô está desativado. Nenhuma operação automática será executada.'}
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Configurações de Estratégia */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardHeader 
                title="Estratégia de Negociação" 
                avatar={<Settings color="primary" />}
              />
              <Divider />
              <CardContent>
                <FormControl fullWidth sx={{ mb: 3 }}>
                  <InputLabel id="strategy-label">Estratégia</InputLabel>
                  <Select
                    labelId="strategy-label"
                    value={robotConfig.strategy}
                    label="Estratégia"
                    onChange={(e) => handleConfigChange('strategy', e.target.value)}
                  >
                    {strategies.map((strategy) => (
                      <MenuItem key={strategy.value} value={strategy.value}>
                        {strategy.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                
                <FormControl fullWidth sx={{ mb: 3 }}>
                  <InputLabel id="timeframe-label">Timeframe</InputLabel>
                  <Select
                    labelId="timeframe-label"
                    value={robotConfig.timeframe}
                    label="Timeframe"
                    onChange={(e) => handleConfigChange('timeframe', e.target.value)}
                  >
                    {timeframes.map((timeframe) => (
                      <MenuItem key={timeframe.value} value={timeframe.value}>
                        {timeframe.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                
                <Typography gutterBottom>
                  Nível de Risco
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                  <Box sx={{ minWidth: 35, mr: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Baixo
                    </Typography>
                  </Box>
                  <Slider
                    value={robotConfig.riskLevel}
                    min={1}
                    max={5}
                    step={1}
                    marks
                    onChange={(e, value) => handleConfigChange('riskLevel', value)}
                    sx={{ mx: 2 }}
                  />
                  <Box sx={{ minWidth: 35, ml: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Alto
                    </Typography>
                  </Box>
                </Box>
                
                <Typography gutterBottom>
                  Alocação de Capital (%)
                </Typography>
                <Slider
                  value={robotConfig.capitalAllocation}
                  min={5}
                  max={100}
                  step={5}
                  marks={[
                    { value: 5, label: '5%' },
                    { value: 25, label: '25%' },
                    { value: 50, label: '50%' },
                    { value: 75, label: '75%' },
                    { value: 100, label: '100%' }
                  ]}
                  onChange={(e, value) => handleConfigChange('capitalAllocation', value)}
                  sx={{ mb: 3 }}
                />
                
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Stop Loss (%)"
                      type="number"
                      InputProps={{ inputProps: { min: 0.5, step: 0.5 } }}
                      value={robotConfig.stopLoss}
                      onChange={(e) => handleConfigChange('stopLoss', parseFloat(e.target.value))}
                      error={!!errors.stopLoss}
                      helperText={errors.stopLoss}
                      required
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Take Profit (%)"
                      type="number"
                      InputProps={{ inputProps: { min: 0.5, step: 0.5 } }}
                      value={robotConfig.takeProfit}
                      onChange={(e) => handleConfigChange('takeProfit', parseFloat(e.target.value))}
                      error={!!errors.takeProfit}
                      helperText={errors.takeProfit}
                      required
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Configurações de Execução */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardHeader 
                title="Configurações de Execução" 
                avatar={<Timeline color="primary" />}
              />
              <Divider />
              <CardContent>
                <FormControlLabel
                  control={
                    <Switch
                      checked={robotConfig.useRecommendations}
                      onChange={(e) => handleConfigChange('useRecommendations', e.target.checked)}
                    />
                  }
                  label="Usar recomendações baseadas em análise estatística"
                  sx={{ mb: 2, display: 'block' }}
                />
                
                <FormControlLabel
                  control={
                    <Switch
                      checked={robotConfig.autoExecute}
                      onChange={(e) => handleConfigChange('autoExecute', e.target.checked)}
                    />
                  }
                  label="Executar ordens automaticamente"
                  sx={{ mb: 2, display: 'block' }}
                />
                
                <FormControlLabel
                  control={
                    <Switch
                      checked={robotConfig.notifyBeforeExecution}
                      onChange={(e) => handleConfigChange('notifyBeforeExecution', e.target.checked)}
                    />
                  }
                  label="Notificar antes de executar ordens"
                  sx={{ mb: 3, display: 'block' }}
                />
                
                <Typography gutterBottom>
                  Horário de Execução
                </Typography>
                <Grid container spacing={2} sx={{ mb: 1 }}>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Início"
                      type="time"
                      value={robotConfig.executionHours.start}
                      onChange={(e) => handleExecutionHoursChange('start', e.target.value)}
                      InputLabelProps={{ shrink: true }}
                      required
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Fim"
                      type="time"
                      value={robotConfig.executionHours.end}
                      onChange={(e) => handleExecutionHoursChange('end', e.target.value)}
                      InputLabelProps={{ shrink: true }}
                      required
                    />
                  </Grid>
                </Grid>
                
                {errors.executionHours && (
                  <FormHelperText error sx={{ mb: 2 }}>
                    {errors.executionHours}
                  </FormHelperText>
                )}
                
                <TextField
                  fullWidth
                  label="Máximo de Posições Simultâneas"
                  type="number"
                  InputProps={{ inputProps: { min: 1, max: 20 } }}
                  value={robotConfig.maxPositions}
                  onChange={(e) => handleConfigChange('maxPositions', parseInt(e.target.value))}
                  sx={{ mb: 3 }}
                  error={!!errors.maxPositions}
                  helperText={errors.maxPositions}
                  required
                />
                
                <Typography gutterBottom>
                  Pares de Negociação
                </Typography>
                <Box sx={{ display: 'flex', mb: 1 }}>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Adicionar ativo (ex: PETR4)"
                    value={newPair}
                    onChange={(e) => handleNewPairChange(e.target.value.toUpperCase())}
                    sx={{ mr: 1 }}
                    error={!!errors.newPair}
                    helperText={errors.newPair}
                  />
                  <Button
                    variant="contained"
                    onClick={handleAddTradingPair}
                    startIcon={<AddCircleOutline />}
                    disabled={!newPair || !!errors.newPair}
                  >
                    Adicionar
                  </Button>
                </Box>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 2 }}>
                  {robotConfig.tradingPairs.map((pair) => (
                    <Chip
                      key={pair}
                      label={pair}
                      onDelete={() => handleRemoveTradingPair(pair)}
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </Box>
                {robotConfig.tradingPairs.length === 0 && (
                  <FormHelperText error>
                    É necessário adicionar pelo menos um ativo para negociação
                  </FormHelperText>
                )}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        
        <Snackbar
          open={showAlert}
          autoHideDuration={6000}
          onClose={() => setShowAlert(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert 
            onClose={() => setShowAlert(false)} 
            severity={alertSeverity} 
            sx={{ width: '100%' }}
            variant="filled"
          >
            {alertMessage}
          </Alert>
        </Snackbar>
      </Container>
    </MainLayout>
  );
};

export default RobotConfigPage;
