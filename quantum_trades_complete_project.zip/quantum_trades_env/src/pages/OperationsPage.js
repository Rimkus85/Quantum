/**
 * OperationsPage.js
 * Página de operações com boleta para emissão de ordens
 */

import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button,
  Card,
  CardContent,
  CardHeader,
  Divider,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Alert,
  Snackbar,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Stepper,
  Step,
  StepLabel,
  IconButton,
  InputAdornment,
  Tooltip
} from '@mui/material';
import { 
  TrendingUp, 
  TrendingDown, 
  Send,
  Close,
  Info,
  Help,
  Add,
  Remove,
  CheckCircle,
  Warning,
  Psychology,
  Chat
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import MainLayout from '../layouts/MainLayout';

// Componente de boleta para emissão de ordens
const OrderTicket = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState('info');
  const [showAssistant, setShowAssistant] = useState(false);
  
  // Estado da ordem
  const [order, setOrder] = useState({
    symbol: '',
    operation: 'buy',
    quantity: '',
    price: '',
    stopLoss: '',
    takeProfit: '',
    strategy: ''
  });
  
  // Estratégias disponíveis
  const strategies = [
    { value: 'trend_following', label: 'Seguidor de Tendência' },
    { value: 'mean_reversion', label: 'Reversão à Média' },
    { value: 'breakout', label: 'Rompimento' },
    { value: 'scalping', label: 'Scalping' },
    { value: 'swing_trading', label: 'Swing Trading' }
  ];
  
  // Lista de ativos disponíveis
  const availableAssets = [
    // B3
    { symbol: 'PETR4', name: 'Petrobras PN', market: 'B3' },
    { symbol: 'VALE3', name: 'Vale ON', market: 'B3' },
    { symbol: 'ITUB4', name: 'Itaú Unibanco PN', market: 'B3' },
    { symbol: 'BBDC4', name: 'Bradesco PN', market: 'B3' },
    { symbol: 'ABEV3', name: 'Ambev ON', market: 'B3' },
    
    // S&P
    { symbol: 'AAPL', name: 'Apple Inc', market: 'S&P' },
    { symbol: 'MSFT', name: 'Microsoft Corp', market: 'S&P' },
    { symbol: 'AMZN', name: 'Amazon.com Inc', market: 'S&P' },
    
    // Crypto
    { symbol: 'BTC', name: 'Bitcoin', market: 'Crypto' },
    { symbol: 'ETH', name: 'Ethereum', market: 'Crypto' }
  ];
  
  // Manipulador de alteração de campos
  const handleChange = (field, value) => {
    setOrder(prevOrder => ({
      ...prevOrder,
      [field]: value
    }));
  };
  
  // Abrir diálogo de confirmação
  const handleOpenDialog = () => {
    if (!order.symbol || !order.quantity || !order.price) {
      setAlertMessage('Por favor, preencha todos os campos obrigatórios.');
      setAlertSeverity('warning');
      setShowAlert(true);
      return;
    }
    
    setOpenDialog(true);
  };
  
  // Fechar diálogo de confirmação
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setActiveStep(0);
  };
  
  // Avançar para próxima etapa
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };
  
  // Voltar para etapa anterior
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  
  // Enviar ordem
  const handleSubmitOrder = async () => {
    setLoading(true);
    
    try {
      // Simulação de envio de ordem
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      handleCloseDialog();
      
      setAlertMessage('Ordem enviada com sucesso!');
      setAlertSeverity('success');
      setShowAlert(true);
      
      // Limpa o formulário
      setOrder({
        symbol: '',
        operation: 'buy',
        quantity: '',
        price: '',
        stopLoss: '',
        takeProfit: '',
        strategy: ''
      });
    } catch (error) {
      console.error('Erro ao enviar ordem:', error);
      setAlertMessage('Erro ao enviar ordem. Tente novamente.');
      setAlertSeverity('error');
      setShowAlert(true);
    } finally {
      setLoading(false);
    }
  };
  
  // Etapas do diálogo de confirmação
  const steps = ['Estratégia', 'Confirmação', 'Envio'];
  
  // Estatísticas da estratégia (simuladas)
  const strategyStats = {
    trend_following: {
      winRate: '68%',
      avgReturn: '5.2%',
      description: 'Estratégia que segue a tendência do mercado, comprando em tendências de alta e vendendo em tendências de baixa.'
    },
    mean_reversion: {
      winRate: '72%',
      avgReturn: '3.8%',
      description: 'Estratégia baseada na premissa de que os preços tendem a reverter para a média após movimentos extremos.'
    },
    breakout: {
      winRate: '65%',
      avgReturn: '7.5%',
      description: 'Estratégia que busca identificar rompimentos de suportes ou resistências importantes.'
    },
    scalping: {
      winRate: '58%',
      avgReturn: '1.2%',
      description: 'Estratégia de curto prazo que busca lucrar com pequenas variações de preço.'
    },
    swing_trading: {
      winRate: '70%',
      avgReturn: '4.5%',
      description: 'Estratégia de médio prazo que busca capturar movimentos de preço em períodos de dias ou semanas.'
    }
  };

  return (
    <Card>
      <CardHeader 
        title="Boleta de Ordens" 
        subheader="Emissão de ordens para o mercado"
        action={
          <Tooltip title="Assistente Virtual">
            <IconButton 
              aria-label="assistente" 
              onClick={() => setShowAssistant(!showAssistant)}
              color={showAssistant ? "primary" : "default"}
            >
              <Psychology />
            </IconButton>
          </Tooltip>
        }
      />
      <Divider />
      <CardContent>
        <Grid container spacing={3}>
          {/* Assistente Virtual */}
          {showAssistant && (
            <Grid item xs={12}>
              <Paper 
                elevation={3} 
                sx={{ 
                  p: 2, 
                  mb: 2, 
                  bgcolor: 'primary.dark',
                  borderLeft: '4px solid',
                  borderColor: 'primary.main'
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>
                  <Chat sx={{ mr: 1, color: 'primary.light' }} />
                  <Box>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: 'primary.light' }}>
                      Assistente Virtual
                    </Typography>
                    <Typography variant="body2" sx={{ color: 'grey.300' }}>
                      Olá! Antes de enviar uma ordem, gostaria de saber qual estratégia você está seguindo?
                      Isso me ajudará a fornecer informações estatísticas relevantes para sua decisão.
                    </Typography>
                    
                    <Box sx={{ mt: 2 }}>
                      <FormControl fullWidth size="small">
                        <InputLabel id="strategy-select-label">Selecione sua Estratégia</InputLabel>
                        <Select
                          labelId="strategy-select-label"
                          id="strategy-select"
                          value={order.strategy}
                          label="Selecione sua Estratégia"
                          onChange={(e) => handleChange('strategy', e.target.value)}
                        >
                          {strategies.map((strategy) => (
                            <MenuItem key={strategy.value} value={strategy.value}>
                              {strategy.label}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Box>
                    
                    {order.strategy && (
                      <Box sx={{ mt: 2, p: 2, bgcolor: 'rgba(0,0,0,0.2)', borderRadius: 1 }}>
                        <Typography variant="body2" sx={{ color: 'grey.300', mb: 1 }}>
                          {strategyStats[order.strategy].description}
                        </Typography>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                          <Chip 
                            label={`Taxa de Sucesso: ${strategyStats[order.strategy].winRate}`} 
                            size="small" 
                            color="success"
                            sx={{ mr: 1 }}
                          />
                          <Chip 
                            label={`Retorno Médio: ${strategyStats[order.strategy].avgReturn}`} 
                            size="small" 
                            color="primary"
                          />
                        </Box>
                      </Box>
                    )}
                  </Box>
                </Box>
              </Paper>
            </Grid>
          )}
          
          {/* Formulário de Ordem */}
          <Grid item xs={12} md={6}>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel id="asset-select-label">Ativo</InputLabel>
              <Select
                labelId="asset-select-label"
                id="asset-select"
                value={order.symbol}
                label="Ativo"
                onChange={(e) => handleChange('symbol', e.target.value)}
              >
                <MenuItem value="" disabled>
                  <em>Selecione um ativo</em>
                </MenuItem>
                
                <MenuItem value="" disabled>
                  <Typography variant="subtitle2">B3</Typography>
                </MenuItem>
                {availableAssets
                  .filter(asset => asset.market === 'B3')
                  .map(asset => (
                    <MenuItem key={asset.symbol} value={asset.symbol}>
                      {asset.symbol} - {asset.name}
                    </MenuItem>
                  ))
                }
                
                <MenuItem value="" disabled>
                  <Typography variant="subtitle2">S&P</Typography>
                </MenuItem>
                {availableAssets
                  .filter(asset => asset.market === 'S&P')
                  .map(asset => (
                    <MenuItem key={asset.symbol} value={asset.symbol}>
                      {asset.symbol} - {asset.name}
                    </MenuItem>
                  ))
                }
                
                <MenuItem value="" disabled>
                  <Typography variant="subtitle2">Criptomoedas</Typography>
                </MenuItem>
                {availableAssets
                  .filter(asset => asset.market === 'Crypto')
                  .map(asset => (
                    <MenuItem key={asset.symbol} value={asset.symbol}>
                      {asset.symbol} - {asset.name}
                    </MenuItem>
                  ))
                }
              </Select>
            </FormControl>
            
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel id="operation-select-label">Operação</InputLabel>
              <Select
                labelId="operation-select-label"
                id="operation-select"
                value={order.operation}
                label="Operação"
                onChange={(e) => handleChange('operation', e.target.value)}
              >
                <MenuItem value="buy">Compra</MenuItem>
                <MenuItem value="sell">Venda</MenuItem>
              </Select>
            </FormControl>
            
            <TextField
              fullWidth
              label="Quantidade"
              type="number"
              value={order.quantity}
              onChange={(e) => handleChange('quantity', e.target.value)}
              sx={{ mb: 2 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <IconButton
                      size="small"
                      onClick={() => handleChange('quantity', Math.max(1, Number(order.quantity) - 1))}
                      disabled={!order.quantity || Number(order.quantity) <= 1}
                    >
                      <Remove fontSize="small" />
                    </IconButton>
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      size="small"
                      onClick={() => handleChange('quantity', Number(order.quantity) + 1 || 1)}
                    >
                      <Add fontSize="small" />
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />
          </Grid>
          
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="Preço"
              type="number"
              value={order.price}
              onChange={(e) => handleChange('price', e.target.value)}
              sx={{ mb: 2 }}
              InputProps={{
                startAdornment: <InputAdornment position="start">R$</InputAdornment>,
              }}
            />
            
            <TextField
              fullWidth
              label="Stop Loss (opcional)"
              type="number"
              value={order.stopLoss}
              onChange={(e) => handleChange('stopLoss', e.target.value)}
              sx={{ mb: 2 }}
              InputProps={{
                startAdornment: <InputAdornment position="start">R$</InputAdornment>,
              }}
            />
            
            <TextField
              fullWidth
              label="Take Profit (opcional)"
              type="number"
              value={order.takeProfit}
              onChange={(e) => handleChange('takeProfit', e.target.value)}
              sx={{ mb: 2 }}
              InputProps={{
                startAdornment: <InputAdornment position="start">R$</InputAdornment>,
              }}
            />
          </Grid>
          
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
              <Button
                variant="contained"
                color="primary"
                size="large"
                startIcon={<Send />}
                onClick={handleOpenDialog}
              >
                Enviar Ordem
              </Button>
            </Box>
          </Grid>
        </Grid>
        
        {/* Diálogo de confirmação */}
        <Dialog
          open={openDialog}
          onClose={handleCloseDialog}
          aria-labelledby="order-dialog-title"
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle id="order-dialog-title">
            {activeStep === 0 ? 'Estratégia de Investimento' : 
             activeStep === 1 ? 'Confirmar Ordem' : 'Enviando Ordem'}
          </DialogTitle>
          <DialogContent>
            <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4, mt: 2 }}>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
            
            {activeStep === 0 && (
              <>
                <DialogContentText sx={{ mb: 3 }}>
                  Para fornecer recomendações mais precisas, por favor selecione sua estratégia de investimento:
                </DialogContentText>
                
                <FormControl fullWidth sx={{ mb: 3 }}>
                  <InputLabel id="strategy-dialog-label">Estratégia</InputLabel>
                  <Select
                    labelId="strategy-dialog-label"
                    value={order.strategy}
                    label="Estratégia"
                    onChange={(e) => handleChange('strategy', e.target.value)}
                  >
                    {strategies.map((strategy) => (
                      <MenuItem key={strategy.value} value={strategy.value}>
                        {strategy.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                
                {order.strategy && (
                  <Paper elevation={1} sx={{ p: 2, bgcolor: 'background.paper', mb: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Estatísticas da Estratégia:
                    </Typography>
                    <Typography variant="body2" paragraph>
                      {strategyStats[order.strategy].description}
                    </Typography>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Chip 
                        label={`Taxa de Sucesso: ${strategyStats[order.strategy].winRate}`} 
                        size="small" 
                        color="success"
                      />
                      <Chip 
                        label={`Retorno Médio: ${strategyStats[order.strategy].avgReturn}`} 
                        size="small" 
                        color="primary"
                      />
                    </Box>
                  </Paper>
                )}
                
                <Alert severity="info" sx={{ mt: 2 }}>
                  <Typography variant="body2">
                    Escolher uma estratégia ajuda nosso sistema a fornecer recomendações mais precisas e personalizadas.
                  </Typography>
                </Alert>
              </>
            )}
            
            {activeStep === 1 && (
              <>
                <DialogContentText sx={{ mb: 3 }}>
                  Por favor, confirme os detalhes da sua ordem:
                </DialogContentText>
                
                <TableContainer component={Paper} sx={{ mb: 3 }}>
                  <Table size="small">
                    <TableBody>
                      <TableRow>
                        <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>
                          Ativo
                        </TableCell>
                        <TableCell align="right">
                          {order.symbol}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>
                          Operação
                        </TableCell>
                        <TableCell align="right" sx={{ color: order.operation === 'buy' ? 'success.main' : 'error.main' }}>
                          {order.operation === 'buy' ? 'Compra' : 'Venda'}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>
                          Quantidade
                        </TableCell>
                        <TableCell align="right">
                          {order.quantity}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>
                          Preço
                        </TableCell>
                        <TableCell align="right">
                          R$ {order.price}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>
                          Valor Total
                        </TableCell>
                        <TableCell align="right" sx={{ fontWeight: 'bold' }}>
                          R$ {(Number(order.price) * Number(order.quantity)).toFixed(2)}
                        </TableCell>
                      </TableRow>
                      {order.stopLoss && (
                        <TableRow>
                          <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>
                            Stop Loss
                          </TableCell>
                          <TableCell align="right" sx={{ color: 'error.main' }}>
                            R$ {order.stopLoss}
                          </TableCell>
                        </TableRow>
                      )}
                      {order.takeProfit && (
                        <TableRow>
                          <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>
                            Take Profit
                          </TableCell>
                          <TableCell align="right" sx={{ color: 'success.main' }}>
                            R$ {order.takeProfit}
                          </TableCell>
                        </TableRow>
                      )}
                      {order.strategy && (
                        <TableRow>
                          <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>
                            Estratégia
                          </TableCell>
                          <TableCell align="right">
                            {strategies.find(s => s.value === order.strategy)?.label}
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
                
                {order.strategy && (
                  <Alert 
                    severity={
                      Number(strategyStats[order.strategy].winRate.replace('%', '')) > 65 ? 
                      'success' : 'warning'
                    } 
                    sx={{ mb: 2 }}
                  >
                    <Typography variant="body2">
                      Baseado na sua estratégia, esta operação tem uma taxa de sucesso histórica de {strategyStats[order.strategy].winRate} 
                      com retorno médio de {strategyStats[order.strategy].avgReturn}.
                    </Typography>
                  </Alert>
                )}
              </>
            )}
            
            {activeStep === 2 && (
              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 3 }}>
                {loading ? (
                  <>
                    <CircularProgress size={60} sx={{ mb: 2 }} />
                    <Typography variant="h6">
                      Enviando sua ordem...
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                      Por favor, aguarde enquanto processamos sua solicitação.
                    </Typography>
                  </>
                ) : (
                  <>
                    <CheckCircle color="success" sx={{ fontSize: 60, mb: 2 }} />
                    <Typography variant="h6">
                      Ordem pronta para envio!
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                      Clique em "Confirmar" para finalizar o envio da ordem.
                    </Typography>
                  </>
                )}
              </Box>
            )}
          </DialogContent>
          <DialogActions>
            <Button 
              onClick={handleCloseDialog} 
              color="inherit"
              disabled={loading}
            >
              Cancelar
            </Button>
            
            {activeStep > 0 && (
              <Button 
                onClick={handleBack} 
                disabled={activeStep === 0 || loading}
              >
                Voltar
              </Button>
            )}
            
            {activeStep < steps.length - 1 ? (
              <Button 
                onClick={handleNext} 
                variant="contained" 
                color="primary"
                disabled={activeStep === 0 && !order.strategy}
              >
                Próximo
              </Button>
            ) : (
              <Button 
                onClick={handleSubmitOrder} 
                variant="contained" 
                color="primary"
                disabled={loading}
              >
                Confirmar
              </Button>
            )}
          </DialogActions>
        </Dialog>
        
        <Snackbar
          open={showAlert}
          autoHideDuration={6000}
          onClose={() => setShowAlert(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert 
            onClose={() => setShowAlert(false)} 
            severity={alertSeverity} 
            sx={{ width: '100%' }}
          >
            {alertMessage}
          </Alert>
        </Snackbar>
      </CardContent>
    </Card>
  );
};

// Componente principal da página de operações
const OperationsPage = () => {
  const [operations, setOperations] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Carrega operações
  useEffect(() => {
    const loadOperations = async () => {
      // Simulação de carregamento de dados
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Dados simulados
      setOperations([
        { id: 1, symbol: 'PETR4', type: 'buy', quantity: 100, price: 28.75, status: 'completed', date: '2025-05-28T10:30:00Z' },
        { id: 2, symbol: 'VALE3', type: 'buy', quantity: 50, price: 68.30, status: 'completed', date: '2025-05-27T14:15:00Z' },
        { id: 3, symbol: 'ITUB4', type: 'sell', quantity: 75, price: 32.45, status: 'completed', date: '2025-05-26T11:45:00Z' },
        { id: 4, symbol: 'BBDC4', type: 'buy', quantity: 120, price: 18.20, status: 'pending', date: '2025-05-29T09:20:00Z' },
        { id: 5, symbol: 'WEGE3', type: 'sell', quantity: 30, price: 42.80, status: 'pending', date: '2025-05-29T09:30:00Z' }
      ]);
      
      setLoading(false);
    };
    
    loadOperations();
  }, []);

  return (
    <MainLayout>
      <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
        {/* Cabeçalho */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom>
            Operações
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            Gerencie suas operações e envie novas ordens.
          </Typography>
        </Box>
        
        <Grid container spacing={3}>
          {/* Boleta de Ordens */}
          <Grid item xs={12} lg={6}>
            <OrderTicket />
          </Grid>
          
          {/* Lista de Operações */}
          <Grid item xs={12} lg={6}>
            <Card>
              <CardHeader 
                title="Operações Recentes" 
                subheader="Histórico de ordens enviadas"
              />
              <Divider />
              <CardContent>
                {loading ? (
                  <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                    <CircularProgress />
                  </Box>
                ) : (
                  <TableContainer>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell>Ativo</TableCell>
                          <TableCell>Tipo</TableCell>
                          <TableCell align="right">Quantidade</TableCell>
                          <TableCell align="right">Preço</TableCell>
                          <TableCell align="right">Status</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {operations.map((operation) => (
                          <TableRow key={operation.id}>
                            <TableCell>{operation.symbol}</TableCell>
                            <TableCell>
                              {operation.type === 'buy' ? (
                                <Chip 
                                  icon={<TrendingUp fontSize="small" />} 
                                  label="Compra" 
                                  size="small" 
                                  color="success" 
                                />
                              ) : (
                                <Chip 
                                  icon={<TrendingDown fontSize="small" />} 
                                  label="Venda" 
                                  size="small" 
                                  color="error" 
                                />
                              )}
                            </TableCell>
                            <TableCell align="right">{operation.quantity}</TableCell>
                            <TableCell align="right">R$ {operation.price}</TableCell>
                            <TableCell align="right">
                              <Chip 
                                label={operation.status === 'completed' ? 'Concluída' : 'Pendente'} 
                                size="small" 
                                color={operation.status === 'completed' ? 'success' : 'warning'} 
                              />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Container>
    </MainLayout>
  );
};

export default OperationsPage;
