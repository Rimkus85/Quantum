import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  CircularProgress,
  Alert,
  Card,
  CardContent,
  CardHeader,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip
} from '@mui/material';
import { 
  CheckCircle,
  Error,
  Warning,
  Info,
  Speed,
  Memory,
  Storage,
  CloudUpload
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';

const TestPage = () => {
  const { user, isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [testResults, setTestResults] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  
  const runTests = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Mock test results
      setTestResults({
        frontend: {
          authentication: { status: 'passed', message: 'Autenticação funcionando corretamente' },
          routing: { status: 'passed', message: 'Rotas protegidas funcionando corretamente' },
          responsiveness: { status: 'passed', message: 'Layout responsivo em todos os dispositivos' },
          accessibility: { status: 'warning', message: 'Alguns elementos precisam de melhorias de acessibilidade' }
        },
        backend: {
          api: { status: 'passed', message: 'Endpoints da API respondendo corretamente' },
          database: { status: 'passed', message: 'Conexão com banco de dados estável' },
          security: { status: 'passed', message: 'Validações de segurança implementadas' },
          performance: { status: 'warning', message: 'Algumas consultas podem ser otimizadas' }
        },
        integration: {
          authentication: { status: 'passed', message: 'Fluxo de autenticação integrado' },
          dataFlow: { status: 'passed', message: 'Fluxo de dados entre frontend e backend funcionando' },
          errorHandling: { status: 'warning', message: 'Tratamento de erros pode ser melhorado em alguns casos' }
        }
      });
      
      setSuccess('Testes concluídos com sucesso!');
    } catch (error) {
      console.error('Erro ao executar testes:', error);
      setError('Falha ao executar testes. Por favor, tente novamente.');
    } finally {
      setLoading(false);
    }
  };
  
  const getStatusIcon = (status) => {
    switch (status) {
      case 'passed':
        return <CheckCircle color="success" />;
      case 'failed':
        return <Error color="error" />;
      case 'warning':
        return <Warning color="warning" />;
      default:
        return <Info color="info" />;
    }
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'passed':
        return 'success';
      case 'failed':
        return 'error';
      case 'warning':
        return 'warning';
      default:
        return 'info';
    }
  };
  
  const countTestsByStatus = (results, status) => {
    if (!results) return 0;
    
    let count = 0;
    Object.values(results).forEach(category => {
      Object.values(category).forEach(test => {
        if (test.status === status) count++;
      });
    });
    
    return count;
  };
  
  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom component="h1" sx={{ fontWeight: 'bold', mb: 4 }}>
        Testes Integrados
      </Typography>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}
      
      {success && (
        <Alert severity="success" sx={{ mb: 3 }} onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      )}
      
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="body1">
          Esta página permite executar e visualizar os resultados dos testes integrados do sistema Quantum Trades.
        </Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={runTests}
          disabled={loading}
          startIcon={loading ? <CircularProgress size={24} color="inherit" /> : null}
        >
          {loading ? 'Executando Testes...' : 'Executar Testes'}
        </Button>
      </Box>
      
      {testResults ? (
        <>
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={3}>
              <Paper
                elevation={3}
                sx={{
                  p: 2,
                  display: 'flex',
                  flexDirection: 'column',
                  height: 140,
                  borderRadius: 2,
                  background: `linear-gradient(135deg, #4caf50 0%, #81c784 100%)`,
                  color: 'white'
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography component="h2" variant="h6" color="inherit">
                    Testes Passados
                  </Typography>
                  <CheckCircle />
                </Box>
                <Typography component="p" variant="h3" sx={{ mt: 2 }}>
                  {countTestsByStatus(testResults, 'passed')}
                </Typography>
                <Typography variant="body2" sx={{ mt: 1 }}>
                  Testes concluídos com sucesso
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={3}>
              <Paper
                elevation={3}
                sx={{
                  p: 2,
                  display: 'flex',
                  flexDirection: 'column',
                  height: 140,
                  borderRadius: 2,
                  background: `linear-gradient(135deg, #f44336 0%, #e57373 100%)`,
                  color: 'white'
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography component="h2" variant="h6" color="inherit">
                    Testes Falhos
                  </Typography>
                  <Error />
                </Box>
                <Typography component="p" variant="h3" sx={{ mt: 2 }}>
                  {countTestsByStatus(testResults, 'failed')}
                </Typography>
                <Typography variant="body2" sx={{ mt: 1 }}>
                  Testes que falharam
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={3}>
              <Paper
                elevation={3}
                sx={{
                  p: 2,
                  display: 'flex',
                  flexDirection: 'column',
                  height: 140,
                  borderRadius: 2,
                  background: 'linear-gradient(135deg, #ff9800 0%, #ffb74d 100%)',
                  color: 'white'
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography component="h2" variant="h6" color="inherit">
                    Avisos
                  </Typography>
                  <Warning />
                </Box>
                <Typography component="p" variant="h3" sx={{ mt: 2 }}>
                  {countTestsByStatus(testResults, 'warning')}
                </Typography>
                <Typography variant="body2" sx={{ mt: 1 }}>
                  Testes com avisos
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={3}>
              <Paper
                elevation={3}
                sx={{
                  p: 2,
                  display: 'flex',
                  flexDirection: 'column',
                  height: 140,
                  borderRadius: 2,
                  background: 'linear-gradient(135deg, #2196f3 0%, #64b5f6 100%)',
                  color: 'white'
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography component="h2" variant="h6" color="inherit">
                    Total de Testes
                  </Typography>
                  <Speed />
                </Box>
                <Typography component="p" variant="h3" sx={{ mt: 2 }}>
                  {Object.values(testResults).reduce((count, category) => count + Object.keys(category).length, 0)}
                </Typography>
                <Typography variant="body2" sx={{ mt: 1 }}>
                  Testes executados
                </Typography>
              </Paper>
            </Grid>
          </Grid>
          
          <Grid container spacing={4}>
            <Grid item xs={12} md={4}>
              <Card sx={{ height: '100%' }}>
                <CardHeader 
                  title="Frontend" 
                  avatar={<Memory color="primary" />}
                />
                <Divider />
                <CardContent>
                  <List>
                    {Object.entries(testResults.frontend).map(([key, test]) => (
                      <ListItem key={key}>
                        <ListItemIcon>
                          {getStatusIcon(test.status)}
                        </ListItemIcon>
                        <ListItemText 
                          primary={key.charAt(0).toUpperCase() + key.slice(1)} 
                          secondary={test.message}
                        />
                        <Chip 
                          label={test.status.toUpperCase()} 
                          color={getStatusColor(test.status)} 
                          size="small"
                        />
                      </ListItem>
                    ))}
                  </List>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card sx={{ height: '100%' }}>
                <CardHeader 
                  title="Backend" 
                  avatar={<Storage color="secondary" />}
                />
                <Divider />
                <CardContent>
                  <List>
                    {Object.entries(testResults.backend).map(([key, test]) => (
                      <ListItem key={key}>
                        <ListItemIcon>
                          {getStatusIcon(test.status)}
                        </ListItemIcon>
                        <ListItemText 
                          primary={key.charAt(0).toUpperCase() + key.slice(1)} 
                          secondary={test.message}
                        />
                        <Chip 
                          label={test.status.toUpperCase()} 
                          color={getStatusColor(test.status)} 
                          size="small"
                        />
                      </ListItem>
                    ))}
                  </List>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card sx={{ height: '100%' }}>
                <CardHeader 
                  title="Integração" 
                  avatar={<CloudUpload color="info" />}
                />
                <Divider />
                <CardContent>
                  <List>
                    {Object.entries(testResults.integration).map(([key, test]) => (
                      <ListItem key={key}>
                        <ListItemIcon>
                          {getStatusIcon(test.status)}
                        </ListItemIcon>
                        <ListItemText 
                          primary={key.charAt(0).toUpperCase() + key.slice(1)} 
                          secondary={test.message}
                        />
                        <Chip 
                          label={test.status.toUpperCase()} 
                          color={getStatusColor(test.status)} 
                          size="small"
                        />
                      </ListItem>
                    ))}
                  </List>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          
          <Box sx={{ mt: 4, display: 'flex', justifyContent: 'center' }}>
            <Button
              variant="contained"
              color="primary"
              onClick={() => setSuccess('Relatório de testes exportado com sucesso!')}
            >
              Exportar Relatório de Testes
            </Button>
          </Box>
        </>
      ) : (
        <Paper sx={{ p: 4, borderRadius: 2, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            Nenhum teste executado
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Clique no botão "Executar Testes" para iniciar os testes integrados do sistema.
          </Typography>
        </Paper>
      )}
    </Container>
  );
};

export default TestPage;
