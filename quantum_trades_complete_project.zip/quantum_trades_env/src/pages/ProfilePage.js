/**
 * ProfilePage.js
 * Página de perfil do usuário
 */

import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button,
  Card,
  CardContent,
  CardHeader,
  Divider,
  TextField,
  Avatar,
  CircularProgress,
  Alert,
  Snackbar,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import {
  Person,
  Email,
  Phone,
  Home,
  Edit,
  Save,
  AccountCircle
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import MainLayout from '../layouts/MainLayout';

const ProfilePage = () => {
  const { user, updateUserData } = useAuth();
  
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState('info');
  
  // Estado do formulário de perfil
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '(11) 98765-4321', // Dados simulados
    address: 'Av. Paulista, 1000 - São Paulo, SP', // Dados simulados
    bio: 'Trader profissional com mais de 5 anos de experiência em mercados de ações e criptomoedas.' // Dados simulados
  });
  
  // Manipulador de alteração de campos
  const handleChange = (field, value) => {
    setProfileData(prevData => ({
      ...prevData,
      [field]: value
    }));
  };
  
  // Salvar alterações
  const handleSave = async () => {
    setLoading(true);
    
    try {
      // Simulação de salvamento
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Atualiza dados do usuário
      if (user) {
        await updateUserData({
          name: profileData.name,
          email: profileData.email
        });
      }
      
      setEditing(false);
      setAlertMessage('Perfil atualizado com sucesso!');
      setAlertSeverity('success');
      setShowAlert(true);
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      setAlertMessage('Erro ao atualizar perfil. Tente novamente.');
      setAlertSeverity('error');
      setShowAlert(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        {/* Cabeçalho */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom>
            Perfil
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            Gerencie suas informações pessoais.
          </Typography>
        </Box>
        
        <Grid container spacing={3}>
          {/* Informações do Perfil */}
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 5 }}>
                <Avatar
                  sx={{
                    width: 120,
                    height: 120,
                    mb: 2,
                    bgcolor: 'primary.main'
                  }}
                >
                  <AccountCircle sx={{ fontSize: 80 }} />
                </Avatar>
                <Typography variant="h5" gutterBottom>
                  {user?.name || 'Usuário'}
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {user?.email || 'email@exemplo.com'}
                </Typography>
                <Typography variant="body2" color="primary" sx={{ mt: 1 }}>
                  Nível {user?.level || 1} - {user?.level > 1 ? 'Avançado' : 'Básico'}
                </Typography>
                
                <Button
                  variant="outlined"
                  startIcon={editing ? <Save /> : <Edit />}
                  sx={{ mt: 3 }}
                  onClick={() => editing ? handleSave() : setEditing(true)}
                  disabled={loading}
                >
                  {loading ? 'Salvando...' : editing ? 'Salvar Alterações' : 'Editar Perfil'}
                </Button>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Detalhes do Perfil */}
          <Grid item xs={12} md={8}>
            <Card>
              <CardHeader 
                title="Informações Pessoais" 
                subheader="Seus dados de contato e informações pessoais"
              />
              <Divider />
              <CardContent>
                {editing ? (
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Nome Completo"
                        value={profileData.name}
                        onChange={(e) => handleChange('name', e.target.value)}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Email"
                        type="email"
                        value={profileData.email}
                        onChange={(e) => handleChange('email', e.target.value)}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        label="Telefone"
                        value={profileData.phone}
                        onChange={(e) => handleChange('phone', e.target.value)}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Endereço"
                        value={profileData.address}
                        onChange={(e) => handleChange('address', e.target.value)}
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Biografia"
                        multiline
                        rows={4}
                        value={profileData.bio}
                        onChange={(e) => handleChange('bio', e.target.value)}
                      />
                    </Grid>
                  </Grid>
                ) : (
                  <List>
                    <ListItem>
                      <ListItemIcon>
                        <Person />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Nome Completo" 
                        secondary={profileData.name} 
                      />
                    </ListItem>
                    <Divider variant="inset" component="li" />
                    <ListItem>
                      <ListItemIcon>
                        <Email />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Email" 
                        secondary={profileData.email} 
                      />
                    </ListItem>
                    <Divider variant="inset" component="li" />
                    <ListItem>
                      <ListItemIcon>
                        <Phone />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Telefone" 
                        secondary={profileData.phone} 
                      />
                    </ListItem>
                    <Divider variant="inset" component="li" />
                    <ListItem>
                      <ListItemIcon>
                        <Home />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Endereço" 
                        secondary={profileData.address} 
                      />
                    </ListItem>
                    <Divider variant="inset" component="li" />
                    <ListItem>
                      <ListItemText 
                        primary="Biografia" 
                        secondary={profileData.bio} 
                      />
                    </ListItem>
                  </List>
                )}
              </CardContent>
            </Card>
            
            <Card sx={{ mt: 3 }}>
              <CardHeader 
                title="Histórico de Atividades" 
                subheader="Suas ações recentes no sistema"
              />
              <Divider />
              <CardContent>
                <List>
                  <ListItem>
                    <ListItemText 
                      primary="Login realizado" 
                      secondary="Hoje, 10:30" 
                    />
                  </ListItem>
                  <Divider component="li" />
                  <ListItem>
                    <ListItemText 
                      primary="Ordem de compra PETR4 enviada" 
                      secondary="Hoje, 10:45" 
                    />
                  </ListItem>
                  <Divider component="li" />
                  <ListItem>
                    <ListItemText 
                      primary="Análise estatística realizada" 
                      secondary="Hoje, 11:15" 
                    />
                  </ListItem>
                  <Divider component="li" />
                  <ListItem>
                    <ListItemText 
                      primary="Configurações atualizadas" 
                      secondary="Ontem, 15:20" 
                    />
                  </ListItem>
                </List>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        
        <Snackbar
          open={showAlert}
          autoHideDuration={6000}
          onClose={() => setShowAlert(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert 
            onClose={() => setShowAlert(false)} 
            severity={alertSeverity} 
            sx={{ width: '100%' }}
          >
            {alertMessage}
          </Alert>
        </Snackbar>
      </Container>
    </MainLayout>
  );
};

export default ProfilePage;
